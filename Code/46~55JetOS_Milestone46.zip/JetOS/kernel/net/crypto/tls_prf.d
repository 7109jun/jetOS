kernel/net/crypto/tls_prf.o: kernel/net/crypto/tls_prf.c \
 kernel/net/crypto/tls_prf.h kernel/net/crypto/hmac_sha256.h
kernel/net/crypto/tls_prf.h:
kernel/net/crypto/hmac_sha256.h:
