kernel/mm/vmm.o: kernel/mm/vmm.c kernel/mm/vmm.h \
 kernel/mm/../hal/x86_asm_shim.h kernel/mm/pmm.h \
 kernel/mm/../../include/efi/efi.h
kernel/mm/vmm.h:
kernel/mm/../hal/x86_asm_shim.h:
kernel/mm/pmm.h:
kernel/mm/../../include/efi/efi.h:
