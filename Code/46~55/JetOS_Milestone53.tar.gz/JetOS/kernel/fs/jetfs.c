/*
 * JetOS - kernel/fs/jetfs.c
 * JETFS v1 구현. AHCI를 통해 섹터 단위로 블록을 읽고 쓴다.
 */

#include "jetfs.h"
#include "../drivers/ahci.h"
#include "../mm/heap.h"
#include "../proc/scheduler.h"
#include "../proc/thread.h"

/* Milestone 48: 지금 이 호출을 한 게 누구인지(uid). scheduler_current()가
 * NULL이면(스케줄러가 아직 안 돌기 시작한 아주 이른 부팅 단계 —
 * jetfs_mount() 자체가 이 시점에 불릴 수 있음) root(0)로 취급한다 —
 * 그 시점엔 로그인도 전이므로 어차피 root 권한으로 파일시스템을
 * 준비하는 게 맞다. */
static uint32_t current_uid(void) {
    thread_t *t = scheduler_current();
    return t ? t->uid : JETFS_ROOT_UID;
}

static int uid_can_modify(const jetfs_inode_t *inode) {
    uint32_t me = current_uid();
    return me == JETFS_ROOT_UID || me == inode->owner_uid;
}

static int g_mounted = 0;
static int g_drive = 0;
static uint64_t g_lba_offset = 0;
static jetfs_superblock_t g_sb;
static uint32_t g_bitmap_next_hint = 0; /* Milestone 22: 데이터 블록 비트맵 할당 힌트
                                          * (아래 bitmap_alloc_block 주석 참고) */

#define INODES_PER_BLOCK (JETFS_BLOCK_SIZE / sizeof(jetfs_inode_t))
#define DIRENTS_PER_BLOCK (JETFS_BLOCK_SIZE / sizeof(jetfs_dirent_t))

/* Milestone 47: 트랜잭션 스테이징 상태(전방 선언 — block_read가
 * block_write보다 먼저 나오지만 스테이징 배열을 참조해야 해서 여기로
 * 끌어올림). */
static int g_in_txn = 0;
static int g_txn_count = 0;
static int g_txn_overflow = 0;
static uint32_t g_txn_blocks[JETFS_JOURNAL_MAX_ENTRIES];
static uint8_t *g_txn_data[JETFS_JOURNAL_MAX_ENTRIES];

static int block_read(uint32_t blockno, void *buf) {
    /* 트랜잭션 도중 같은 블록을 여러 번 읽고-고치고-쓰는 패턴(예: inode
     * 하나를 갱신할 때마다 그 inode가 들어있는 블록 전체를 읽어서 해당
     * 슬롯만 고치고 통째로 다시 쓰는 방식 — 이 프로젝트의 inode_read/
     * inode_write가 정확히 이렇게 동작한다)이 실제로 일어난다. 이번
     * 트랜잭션에서 그 블록에 먼저 쓴 내용이 있는데 이 함수가 디스크의
     * "옛날" 내용을 그대로 돌려주면, 두 번째 read-modify-write가 첫
     * 번째 변경을 통째로 덮어써버린다(실제로 이 버그가 났었음 — 파일
     * 생성 중 같은 inode 테이블 블록을 두 번 건드리는 경우 재현됨).
     * 그래서 스테이징된 블록이 있으면 디스크 대신 그걸 돌려준다. */
    if (g_in_txn && !g_txn_overflow) {
        for (int i = 0; i < g_txn_count; i++) {
            if (g_txn_blocks[i] == blockno) {
                for (int k = 0; k < JETFS_BLOCK_SIZE; k++) ((uint8_t *)buf)[k] = g_txn_data[i][k];
                return 1;
            }
        }
    }
    return ahci_read_sectors(g_drive, g_lba_offset + (uint64_t)blockno * JETFS_SECTORS_PER_BLOCK,
                              JETFS_SECTORS_PER_BLOCK, buf);
}
static int block_write_direct(uint32_t blockno, const void *buf) {
    return ahci_write_sectors(g_drive, g_lba_offset + (uint64_t)blockno * JETFS_SECTORS_PER_BLOCK,
                               JETFS_SECTORS_PER_BLOCK, buf);
}


static int block_write(uint32_t blockno, const void *buf) {
    if (g_in_txn && !g_txn_overflow) {
        for (int i = 0; i < g_txn_count; i++) {
            if (g_txn_blocks[i] == blockno) {
                for (int k = 0; k < JETFS_BLOCK_SIZE; k++) g_txn_data[i][k] = ((const uint8_t *)buf)[k];
                return 1;
            }
        }
        if (g_txn_count < JETFS_JOURNAL_MAX_ENTRIES) {
            uint8_t *copy = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
            if (copy) {
                for (int k = 0; k < JETFS_BLOCK_SIZE; k++) copy[k] = ((const uint8_t *)buf)[k];
                g_txn_blocks[g_txn_count] = blockno;
                g_txn_data[g_txn_count] = copy;
                g_txn_count++;
                return 1;
            }
        }
        g_txn_overflow = 1; /* 용량 초과 또는 kmalloc 실패 — 이 트랜잭션은 폴백 */
    }
    return block_write_direct(blockno, buf);
}

/* 메타데이터 여러 블록을 원자적으로 반영할 구간 시작. 중첩(재귀) 호출은
 * 지원하지 않는다 — jetfs.c 안에서 최상위 API 함수 하나가 한 트랜잭션을
 * 갖는 게 원칙(create/delete/rename 참고). */
static void jetfs_txn_begin(void) {
    g_in_txn = 1;
    g_txn_count = 0;
    g_txn_overflow = 0;
}

/* 스테이징된 모든 블록을 저널에 먼저 쓰고(섀도우 블록들 -> 커밋 헤더
 * 순서, 헤더 쓰기가 원자적 "커밋 지점") 실제 위치에 적용한 뒤 저널을
 * 지운다. 저널 자체 쓰기가 실패해도(디스크 문제 등) 최소한 실제
 * 위치에는 적용을 시도한다 — 저널링이 안전망일 뿐 필수 경로를 막지는
 * 않는다는 설계. */
static void jetfs_txn_commit(void) {
    if (!g_in_txn) return;
    g_in_txn = 0;
    if (g_txn_count == 0) return;

    if (!g_txn_overflow) {
        int journal_ok = 1;
        for (int i = 0; i < g_txn_count && journal_ok; i++) {
            if (!block_write_direct(g_sb.journal_start + 1 + (uint32_t)i, g_txn_data[i])) journal_ok = 0;
        }
        if (journal_ok) {
            uint8_t hbuf[JETFS_BLOCK_SIZE];
            for (int k = 0; k < JETFS_BLOCK_SIZE; k++) hbuf[k] = 0;
            jetfs_journal_header_t *h = (jetfs_journal_header_t *)hbuf;
            h->magic = JETFS_JOURNAL_MAGIC_COMMITTED;
            h->entry_count = (uint32_t)g_txn_count;
            uint32_t chk = 0;
            for (int i = 0; i < g_txn_count; i++) { h->target_block[i] = g_txn_blocks[i]; chk ^= g_txn_blocks[i]; }
            h->checksum = chk;
            block_write_direct(g_sb.journal_start, hbuf); /* <- 커밋 지점 */
        }
    }

    for (int i = 0; i < g_txn_count; i++) {
        block_write_direct(g_txn_blocks[i], g_txn_data[i]);
        kfree(g_txn_data[i]);
    }

    if (!g_txn_overflow) {
        uint8_t hbuf[JETFS_BLOCK_SIZE];
        for (int k = 0; k < JETFS_BLOCK_SIZE; k++) hbuf[k] = 0;
        ((jetfs_journal_header_t *)hbuf)->magic = JETFS_JOURNAL_MAGIC_EMPTY;
        block_write_direct(g_sb.journal_start, hbuf);
    }
    g_txn_count = 0;
}

/* Milestone 47 — 테스트 전용(제품 코드에서는 절대 호출하지 않음):
 * jetfs_txn_commit()의 "저널에 커밋까지만 하고 실제 위치엔 아직 하나도
 * 반영 안 함" 상태를 인위적으로 만든다 — 실제 정전/크래시가 정확히 그
 * 타이밍에 일어난 상황을 재현해서, 다음 부팅 때 jetfs_txn_recover()가
 * 정말로 안전하게 복구하는지 검증하기 위한 것. 커밋 헤더까지 디스크에
 * 쓰고 나면 그대로 반환(적용도 안 하고 저널도 안 지움) — 그 다음
 * 인위적으로 재부팅(실제로는 QEMU 프로세스를 강제 종료 후 같은
 * jetfs.img로 재시작)하면 진짜 크래시-복구 시나리오와 동일해진다. */
void jetfs_debug_commit_journal_only_no_apply(void) {
    if (!g_in_txn || g_txn_overflow || g_txn_count == 0) return;
    for (int i = 0; i < g_txn_count; i++) {
        block_write_direct(g_sb.journal_start + 1 + (uint32_t)i, g_txn_data[i]);
    }
    uint8_t hbuf[JETFS_BLOCK_SIZE];
    for (int k = 0; k < JETFS_BLOCK_SIZE; k++) hbuf[k] = 0;
    jetfs_journal_header_t *h = (jetfs_journal_header_t *)hbuf;
    h->magic = JETFS_JOURNAL_MAGIC_COMMITTED;
    h->entry_count = (uint32_t)g_txn_count;
    uint32_t chk = 0;
    for (int i = 0; i < g_txn_count; i++) { h->target_block[i] = g_txn_blocks[i]; chk ^= g_txn_blocks[i]; }
    h->checksum = chk;
    block_write_direct(g_sb.journal_start, hbuf); /* <- 여기까지만: "커밋됐지만 미적용" 상태로 고정 */
    /* g_in_txn/g_txn_*를 일부러 안 지운다 — 이 함수 자체가 "크래시로
     * 프로세스가 통째로 죽는" 상황을 흉내내는 것이라, 애초에 그 이후
     * 코드가 실행될 일이 없다는 전제. */
}

/* 마운트 시 1회 호출 — 이전 세션이 커밋까지는 끝냈지만("커밋 지점" 헤더
 * 쓰기까지 성공) 실제 위치 반영 전에 크래시했다면, 저장해둔 섀도우
 * 블록들을 실제 위치로 재생(replay)한다. 커밋 안 된 저널(magic이
 * EMPTY거나 헤더 자체가 깨짐)은 조용히 무시 — 그 경우 트랜잭션이 아예
 * 시작도 안 됐거나(저널에 아무 영향 없음) 헤더 쓰기 자체가 중간에
 * 잘렸다는 뜻인데, 후자는 사실상 "커밋 안 된 것"과 똑같이 취급해도
 * 안전하다(실제 위치는 아직 하나도 안 바뀐 상태이므로). */
static void jetfs_txn_recover(void) {
    uint8_t hbuf[JETFS_BLOCK_SIZE];
    if (!block_read(g_sb.journal_start, hbuf)) return;
    jetfs_journal_header_t h = *(jetfs_journal_header_t *)hbuf;
    if (h.magic != JETFS_JOURNAL_MAGIC_COMMITTED) return;
    if (h.entry_count > JETFS_JOURNAL_MAX_ENTRIES) return; /* 헤더 자체가 손상됨 — 복구 포기 */
    uint32_t chk = 0;
    for (uint32_t i = 0; i < h.entry_count; i++) chk ^= h.target_block[i];
    if (chk != h.checksum) return; /* 체크섬 불일치 — 헤더 손상, 복구 포기(안전하게 무시) */

    uint8_t *shadow = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (shadow) {
        for (uint32_t i = 0; i < h.entry_count; i++) {
            if (block_read(g_sb.journal_start + 1 + i, shadow)) {
                block_write_direct(h.target_block[i], shadow);
            }
        }
        kfree(shadow);
    }

    for (int k = 0; k < JETFS_BLOCK_SIZE; k++) hbuf[k] = 0;
    ((jetfs_journal_header_t *)hbuf)->magic = JETFS_JOURNAL_MAGIC_EMPTY;
    block_write_direct(g_sb.journal_start, hbuf);
}

static int str_eq(const char *a, const char *b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}
static void str_copy(char *dst, const char *src, int max) {
    int i = 0;
    for (; i < max - 1 && src[i]; i++) dst[i] = src[i];
    dst[i] = '\0';
}

int jetfs_mount(int drive_index, uint64_t lba_offset) {
    g_drive = drive_index;
    g_lba_offset = lba_offset;

    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(0, buf)) { kfree(buf); return 0; }

    jetfs_superblock_t *sb = (jetfs_superblock_t *)buf;
    if (sb->magic != JETFS_MAGIC) { kfree(buf); return 0; }
    /* Milestone 47: journal_start가 0이면 저널 필드가 없던 예전 mkjetfs로
     * 만든 이미지 — 조용히 "저널 없이" 계속 마운트하는 대신 명시적으로
     * 거부한다. 이유: journal_start=0은 슈퍼블록 그 자신을 저널 헤더로
     * 오인하게 만들어서(블록 0에 저널 커밋을 쓰면 슈퍼블록을 덮어씀)
     * 조용히 넘어가면 오히려 더 위험한 파일시스템 손상으로 이어진다.
     * mkjetfs로 다시 포맷해야 한다는 걸 눈에 보이게 실패시키는 쪽을
     * 택했다(M22/M23이 온디스크 포맷을 바꿀 때도 재포맷을 요구했던 것과
     * 같은 전례). */
    if (sb->journal_start == 0) { kfree(buf); return 0; }
    /* Milestone 48: inode 구조체 크기가 이 커널이 기대하는 것과 다르면
     * (owner_uid 필드 추가 전 mkjetfs로 만든 예전 이미지) inode 테이블
     * 오프셋 계산이 전부 어긋난다 — 조용히 잘못된 곳에서 inode를 읽어
     * type/소유자/블록 포인터가 쓰레기가 되는 것보다 마운트를 명시적
     * 으로 거부한다(M47과 같은 전례). */
    if (sb->inode_struct_size != (uint32_t)sizeof(jetfs_inode_t)) { kfree(buf); return 0; }

    g_sb = *sb;
    g_mounted = 1;
    g_bitmap_next_hint = 0; /* 마운트마다 처음부터(안전한 기본값 — 실제 사용중인
                              * 비트는 스캔 중 자연히 건너뛴다) */
    kfree(buf);

    jetfs_txn_recover(); /* Milestone 47: 이전 세션에서 커밋됐지만 미적용인 트랜잭션 재생 */
    return 1;
}

/* ---- inode 테이블 I/O ---- */
static int inode_read(uint32_t idx, jetfs_inode_t *out) {
    uint32_t block = g_sb.inode_table_start + idx / INODES_PER_BLOCK;
    uint32_t off = idx % INODES_PER_BLOCK;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(block, buf)) { kfree(buf); return 0; }
    *out = ((jetfs_inode_t *)buf)[off];
    kfree(buf);
    return 1;
}
static int inode_write(uint32_t idx, const jetfs_inode_t *in) {
    uint32_t block = g_sb.inode_table_start + idx / INODES_PER_BLOCK;
    uint32_t off = idx % INODES_PER_BLOCK;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(block, buf)) { kfree(buf); return 0; }
    ((jetfs_inode_t *)buf)[off] = *in;
    int ok = block_write(block, buf);
    kfree(buf);
    return ok;
}

static int inode_alloc(void) {
    jetfs_inode_t tmp;
    for (uint32_t i = 0; i < JETFS_MAX_INODES; i++) {
        if (!inode_read(i, &tmp)) return -1;
        if (!tmp.used) {
            tmp.used = 1;
            tmp.type = JETFS_TYPE_FREE;
            tmp.size = 0;
            tmp.block_count = 0;
            tmp.indirect = 0;
            tmp.double_indirect = 0;
            tmp.triple_indirect = 0;
            for (int b = 0; b < JETFS_DIRECT_BLOCKS; b++) tmp.block[b] = 0;
            inode_write(i, &tmp);
            return (int)i;
        }
    }
    return -1;
}

/* ---- 데이터 블록 비트맵 ----
 * Milestone 22에서 발견/수정: 예전 구현은 매 할당마다 비트 0번부터
 * 다시 스캔하면서, 심지어 "비트 하나 확인할 때마다" 그 비트가 속한
 * 디스크 블록을 다시 읽었다(같은 블록 안의 8*4096개 비트를 볼 때도
 * 매번 block_read를 다시 호출) — 사실상 호출 1번이 O(스캔한 비트 수)
 * 만큼의 디스크 읽기였다. 파일이 최대 ~1036블록(4.2MB)이던 시절엔
 * 감내할 만했지만, 이번에 이중 간접 블록으로 파일 크기 상한을 크게
 * 늘리면서 실제로 문제가 됐다 — 4.5MB 파일 하나 쓰는 데 수만 번의
 * 개별 블록 재할당이 쌓이며(각 재할당이 앞서 채워진 블록 수만큼
 * 다시 스캔) 사실상 O(n^2) 디스크 I/O가 되어 부팅 자체 테스트가
 * 끝나지 않는 것으로 나타났다. PMM(kernel/mm/pmm.c)이 이미 쓰고
 * 있던 "다음 빈 자리 힌트" 패턴을 그대로 가져와 ①힌트 이후부터
 * 스캔 시작 ②비트 하나가 아니라 디스크 블록 하나(비트 32768개)를
 * 한 번만 읽어 그 안을 전부 스캔하도록 고쳤다(g_bitmap_next_hint
 * 변수는 파일 위쪽에 다른 전역들과 함께 선언돼 있음). */
static int bitmap_alloc_block(void) {
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return -1;

    uint32_t total_data_blocks = g_sb.total_blocks - g_sb.data_start;
    uint32_t bits_per_block = JETFS_BLOCK_SIZE * 8;

    /* 힌트 이후 먼저 스캔, 못 찾으면 처음부터 힌트 이전까지 스캔
     * (PMM의 pmm_alloc_page()와 동일한 2-패스 구조) */
    for (int pass = 0; pass < 2; pass++) {
        uint32_t start_bit = (pass == 0) ? g_bitmap_next_hint : 0;
        uint32_t end_bit = (pass == 0) ? total_data_blocks : g_bitmap_next_hint;
        if (start_bit >= end_bit) continue;

        uint32_t bit = start_bit;
        while (bit < end_bit) {
            uint32_t byte_block = g_sb.bitmap_start + (bit / 8) / JETFS_BLOCK_SIZE;
            if (!block_read(byte_block, buf)) { kfree(buf); return -1; }

            /* 이 디스크 블록이 커버하는 비트 범위 안에서(그리고 스캔
             * 상한을 넘지 않는 선에서) 한 번 읽은 buf로 전부 스캔 */
            uint32_t block_bit_start = (bit / bits_per_block) * bits_per_block;
            uint32_t block_bit_end = block_bit_start + bits_per_block;
            if (block_bit_end > end_bit) block_bit_end = end_bit;

            for (uint32_t b = bit; b < block_bit_end; b++) {
                uint32_t byte_off = (b / 8) % JETFS_BLOCK_SIZE;
                if (!(buf[byte_off] & (1 << (b % 8)))) {
                    buf[byte_off] |= (uint8_t)(1 << (b % 8));
                    if (!block_write(byte_block, buf)) { kfree(buf); return -1; }
                    kfree(buf);
                    g_bitmap_next_hint = b + 1;
                    return (int)(g_sb.data_start + b);
                }
            }
            bit = block_bit_end;
        }
    }
    kfree(buf);
    return -1;
}

static int bitmap_free_block(uint32_t blockno) {
    if (blockno < g_sb.data_start) return 0;
    uint32_t bit = blockno - g_sb.data_start;
    uint32_t byte_block = g_sb.bitmap_start + (bit / 8) / JETFS_BLOCK_SIZE;
    uint32_t byte_off   = (bit / 8) % JETFS_BLOCK_SIZE;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(byte_block, buf)) { kfree(buf); return 0; }
    buf[byte_off] &= (uint8_t)~(1 << (bit % 8));
    int ok = block_write(byte_block, buf);
    kfree(buf);
    if (ok && bit < g_bitmap_next_hint) g_bitmap_next_hint = bit; /* 다음 할당이 이 빈자리부터 찾도록 */
    return ok;
}

/* ---- 파일 블록 매핑: 직접(0..11) + 간접(12..1035) + 이중간접
 * (1036..1049611) + 삼중간접(1049612..) 인덱스를 실제 데이터 블록
 * 번호로 변환한다. 블록 인덱스 자체는 (최대 약 10억 7천만개로)
 * uint32_t 범위 안에 들어오므로 index 타입은 그대로다 — 4GB를
 * 넘어서는 건 "바이트 크기"이지 "블록 개수"가 아니다.
 * allocate=1이면 없는 블록을 새로 할당하고(간접/이중간접/삼중간접
 * 블록 자체도 필요하면 할당), allocate=0이면 조회만 하고 없으면
 * 0을 반환한다(에러가 아니라 "구멍"으로 취급). ---- */
static int file_block_map(jetfs_inode_t *inode, uint32_t index, int allocate, uint32_t *out_blockno) {
    if (index >= JETFS_MAX_FILE_BLOCKS) return 0; /* 범위 초과 */

    if (index < JETFS_DIRECT_BLOCKS) {
        if (inode->block[index] == 0 && allocate) {
            int nb = bitmap_alloc_block();
            if (nb < 0) return 0;
            inode->block[index] = (uint32_t)nb;
        }
        *out_blockno = inode->block[index];
        return 1;
    }

    if (index < JETFS_DIRECT_BLOCKS + JETFS_INDIRECT_PTRS) {
        uint32_t iidx = index - JETFS_DIRECT_BLOCKS;
        if (inode->indirect == 0) {
            if (!allocate) { *out_blockno = 0; return 1; }
            int nb = bitmap_alloc_block();
            if (nb < 0) return 0;
            inode->indirect = (uint32_t)nb;
            uint8_t *zbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
            if (!zbuf) return 0;
            for (int i = 0; i < JETFS_BLOCK_SIZE; i++) zbuf[i] = 0;
            int ok = block_write(inode->indirect, zbuf);
            kfree(zbuf);
            if (!ok) return 0;
        }

        uint8_t *ibuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (!ibuf) return 0;
        if (!block_read(inode->indirect, ibuf)) { kfree(ibuf); return 0; }
        uint32_t *ptrs = (uint32_t *)ibuf;

        if (ptrs[iidx] == 0 && allocate) {
            int nb = bitmap_alloc_block();
            if (nb < 0) { kfree(ibuf); return 0; }
            ptrs[iidx] = (uint32_t)nb;
            if (!block_write(inode->indirect, ibuf)) { kfree(ibuf); return 0; }
        }
        *out_blockno = ptrs[iidx];
        kfree(ibuf);
        return 1;
    }

    if (index < JETFS_DIRECT_BLOCKS + JETFS_INDIRECT_PTRS + (uint64_t)JETFS_DOUBLE_INDIRECT_PTRS * JETFS_INDIRECT_PTRS) {
        /* 이중 간접 영역 (Milestone 22) */
        uint32_t didx = index - JETFS_DIRECT_BLOCKS - JETFS_INDIRECT_PTRS;
        uint32_t group = didx / JETFS_INDIRECT_PTRS;       /* 어느 간접 블록인지 (0..1023) */
        uint32_t sub   = didx % JETFS_INDIRECT_PTRS;        /* 그 간접 블록 안에서 몇 번째인지 */

        if (inode->double_indirect == 0) {
            if (!allocate) { *out_blockno = 0; return 1; }
            int nb = bitmap_alloc_block();
            if (nb < 0) return 0;
            inode->double_indirect = (uint32_t)nb;
            uint8_t *zbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
            if (!zbuf) return 0;
            for (int i = 0; i < JETFS_BLOCK_SIZE; i++) zbuf[i] = 0;
            int ok = block_write(inode->double_indirect, zbuf);
            kfree(zbuf);
            if (!ok) return 0;
        }

        uint8_t *dibuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (!dibuf) return 0;
        if (!block_read(inode->double_indirect, dibuf)) { kfree(dibuf); return 0; }
        uint32_t *dptrs = (uint32_t *)dibuf;

        if (dptrs[group] == 0) {
            if (!allocate) { kfree(dibuf); *out_blockno = 0; return 1; }
            int nb = bitmap_alloc_block();
            if (nb < 0) { kfree(dibuf); return 0; }
            dptrs[group] = (uint32_t)nb;
            if (!block_write(inode->double_indirect, dibuf)) { kfree(dibuf); return 0; }
            uint8_t *zbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
            if (!zbuf) { kfree(dibuf); return 0; }
            for (int i = 0; i < JETFS_BLOCK_SIZE; i++) zbuf[i] = 0;
            int ok = block_write(dptrs[group], zbuf);
            kfree(zbuf);
            if (!ok) { kfree(dibuf); return 0; }
        }
        uint32_t indirect_block = dptrs[group];
        kfree(dibuf);

        uint8_t *ibuf2 = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (!ibuf2) return 0;
        if (!block_read(indirect_block, ibuf2)) { kfree(ibuf2); return 0; }
        uint32_t *ptrs2 = (uint32_t *)ibuf2;

        if (ptrs2[sub] == 0 && allocate) {
            int nb = bitmap_alloc_block();
            if (nb < 0) { kfree(ibuf2); return 0; }
            ptrs2[sub] = (uint32_t)nb;
            if (!block_write(indirect_block, ibuf2)) { kfree(ibuf2); return 0; }
        }
        *out_blockno = ptrs2[sub];
        kfree(ibuf2);
        return 1;
    }

    /* 삼중 간접 영역 (Milestone 23) — 이중간접과 완전히 같은 패턴을
     * 한 단계 더 감싼 것뿐이다: 삼중간접 블록 -> (그룹당) 이중간접
     * 역할을 하는 블록 -> 간접 블록 -> 데이터 블록. */
    {
        uint64_t tidx = index - JETFS_DIRECT_BLOCKS - JETFS_INDIRECT_PTRS
                        - (uint64_t)JETFS_DOUBLE_INDIRECT_PTRS * JETFS_INDIRECT_PTRS;
        uint32_t l1 = (uint32_t)(tidx / ((uint64_t)JETFS_INDIRECT_PTRS * JETFS_INDIRECT_PTRS)); /* 0..1023: 어느 "이중간접류" 블록 */
        uint64_t rem1 = tidx % ((uint64_t)JETFS_INDIRECT_PTRS * JETFS_INDIRECT_PTRS);
        uint32_t l2 = (uint32_t)(rem1 / JETFS_INDIRECT_PTRS); /* 0..1023: 그 안에서 어느 간접 블록 */
        uint32_t l3 = (uint32_t)(rem1 % JETFS_INDIRECT_PTRS); /* 0..1023: 그 간접 블록 안 몇 번째 */

        if (inode->triple_indirect == 0) {
            if (!allocate) { *out_blockno = 0; return 1; }
            int nb = bitmap_alloc_block();
            if (nb < 0) return 0;
            inode->triple_indirect = (uint32_t)nb;
            uint8_t *zbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
            if (!zbuf) return 0;
            for (int i = 0; i < JETFS_BLOCK_SIZE; i++) zbuf[i] = 0;
            int ok = block_write(inode->triple_indirect, zbuf);
            kfree(zbuf);
            if (!ok) return 0;
        }

        uint8_t *tbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (!tbuf) return 0;
        if (!block_read(inode->triple_indirect, tbuf)) { kfree(tbuf); return 0; }
        uint32_t *tptrs = (uint32_t *)tbuf;

        if (tptrs[l1] == 0) {
            if (!allocate) { kfree(tbuf); *out_blockno = 0; return 1; }
            int nb = bitmap_alloc_block();
            if (nb < 0) { kfree(tbuf); return 0; }
            tptrs[l1] = (uint32_t)nb;
            if (!block_write(inode->triple_indirect, tbuf)) { kfree(tbuf); return 0; }
            uint8_t *zbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
            if (!zbuf) { kfree(tbuf); return 0; }
            for (int i = 0; i < JETFS_BLOCK_SIZE; i++) zbuf[i] = 0;
            int ok = block_write(tptrs[l1], zbuf);
            kfree(zbuf);
            if (!ok) { kfree(tbuf); return 0; }
        }
        uint32_t l2_block = tptrs[l1];
        kfree(tbuf);

        uint8_t *l2buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (!l2buf) return 0;
        if (!block_read(l2_block, l2buf)) { kfree(l2buf); return 0; }
        uint32_t *l2ptrs = (uint32_t *)l2buf;

        if (l2ptrs[l2] == 0) {
            if (!allocate) { kfree(l2buf); *out_blockno = 0; return 1; }
            int nb = bitmap_alloc_block();
            if (nb < 0) { kfree(l2buf); return 0; }
            l2ptrs[l2] = (uint32_t)nb;
            if (!block_write(l2_block, l2buf)) { kfree(l2buf); return 0; }
            uint8_t *zbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
            if (!zbuf) { kfree(l2buf); return 0; }
            for (int i = 0; i < JETFS_BLOCK_SIZE; i++) zbuf[i] = 0;
            int ok = block_write(l2ptrs[l2], zbuf);
            kfree(zbuf);
            if (!ok) { kfree(l2buf); return 0; }
        }
        uint32_t l3_block = l2ptrs[l2];
        kfree(l2buf);

        uint8_t *l3buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (!l3buf) return 0;
        if (!block_read(l3_block, l3buf)) { kfree(l3buf); return 0; }
        uint32_t *l3ptrs = (uint32_t *)l3buf;

        if (l3ptrs[l3] == 0 && allocate) {
            int nb = bitmap_alloc_block();
            if (nb < 0) { kfree(l3buf); return 0; }
            l3ptrs[l3] = (uint32_t)nb;
            if (!block_write(l3_block, l3buf)) { kfree(l3buf); return 0; }
        }
        *out_blockno = l3ptrs[l3];
        kfree(l3buf);
        return 1;
    }
}

/* index 블록(및 필요하면 그 이상 전부)을 비트맵에서 해제하고 간접/
 * 이중간접/삼중간접 테이블 항목도 0으로 지운다. allocate 없이 조회
 * 전용으로 쓰인다. */
static void file_block_free(jetfs_inode_t *inode, uint32_t index) {
    if (index < JETFS_DIRECT_BLOCKS) {
        if (inode->block[index]) {
            bitmap_free_block(inode->block[index]);
            inode->block[index] = 0;
        }
        return;
    }
    if (index < JETFS_DIRECT_BLOCKS + JETFS_INDIRECT_PTRS) {
        if (inode->indirect == 0) return;
        uint32_t iidx = index - JETFS_DIRECT_BLOCKS;
        uint8_t *ibuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (!ibuf) return;
        if (!block_read(inode->indirect, ibuf)) { kfree(ibuf); return; }
        uint32_t *ptrs = (uint32_t *)ibuf;
        if (ptrs[iidx]) {
            bitmap_free_block(ptrs[iidx]);
            ptrs[iidx] = 0;
            block_write(inode->indirect, ibuf);
        }
        kfree(ibuf);
        return;
    }

    if (index < JETFS_DIRECT_BLOCKS + JETFS_INDIRECT_PTRS + (uint64_t)JETFS_DOUBLE_INDIRECT_PTRS * JETFS_INDIRECT_PTRS) {
        /* 이중 간접 영역 */
        if (inode->double_indirect == 0) return;
        uint32_t didx = index - JETFS_DIRECT_BLOCKS - JETFS_INDIRECT_PTRS;
        uint32_t group = didx / JETFS_INDIRECT_PTRS;
        uint32_t sub   = didx % JETFS_INDIRECT_PTRS;

        uint8_t *dibuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (!dibuf) return;
        if (!block_read(inode->double_indirect, dibuf)) { kfree(dibuf); return; }
        uint32_t *dptrs = (uint32_t *)dibuf;
        uint32_t indirect_block = dptrs[group];
        kfree(dibuf);
        if (indirect_block == 0) return;

        uint8_t *ibuf2 = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (!ibuf2) return;
        if (!block_read(indirect_block, ibuf2)) { kfree(ibuf2); return; }
        uint32_t *ptrs2 = (uint32_t *)ibuf2;
        if (ptrs2[sub]) {
            bitmap_free_block(ptrs2[sub]);
            ptrs2[sub] = 0;
            block_write(indirect_block, ibuf2);
        }
        kfree(ibuf2);
        return;
    }

    /* 삼중 간접 영역 (Milestone 23) */
    if (inode->triple_indirect == 0) return;
    uint64_t tidx = index - JETFS_DIRECT_BLOCKS - JETFS_INDIRECT_PTRS
                    - (uint64_t)JETFS_DOUBLE_INDIRECT_PTRS * JETFS_INDIRECT_PTRS;
    uint32_t l1 = (uint32_t)(tidx / ((uint64_t)JETFS_INDIRECT_PTRS * JETFS_INDIRECT_PTRS));
    uint64_t rem1 = tidx % ((uint64_t)JETFS_INDIRECT_PTRS * JETFS_INDIRECT_PTRS);
    uint32_t l2 = (uint32_t)(rem1 / JETFS_INDIRECT_PTRS);
    uint32_t l3 = (uint32_t)(rem1 % JETFS_INDIRECT_PTRS);

    uint8_t *tbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!tbuf) return;
    if (!block_read(inode->triple_indirect, tbuf)) { kfree(tbuf); return; }
    uint32_t l2_block = ((uint32_t *)tbuf)[l1];
    kfree(tbuf);
    if (l2_block == 0) return;

    uint8_t *l2buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!l2buf) return;
    if (!block_read(l2_block, l2buf)) { kfree(l2buf); return; }
    uint32_t l3_block = ((uint32_t *)l2buf)[l2];
    kfree(l2buf);
    if (l3_block == 0) return;

    uint8_t *l3buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!l3buf) return;
    if (!block_read(l3_block, l3buf)) { kfree(l3buf); return; }
    uint32_t *l3ptrs = (uint32_t *)l3buf;
    if (l3ptrs[l3]) {
        bitmap_free_block(l3ptrs[l3]);
        l3ptrs[l3] = 0;
        block_write(l3_block, l3buf);
    }
    kfree(l3buf);
}

/* 파일의 모든 데이터 블록(직접+간접+이중간접) 및 그 메타 블록들을 회수한다. */
static void file_free_all_blocks(jetfs_inode_t *inode) {
    for (int i = 0; i < JETFS_DIRECT_BLOCKS; i++) {
        if (inode->block[i]) { bitmap_free_block(inode->block[i]); inode->block[i] = 0; }
    }
    if (inode->indirect) {
        bitmap_free_block(inode->indirect);
        inode->indirect = 0;
    }
    if (inode->double_indirect) {
        uint8_t *dibuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        uint8_t *leafbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (dibuf && leafbuf) {
            if (block_read(inode->double_indirect, dibuf)) {
                uint32_t *dptrs = (uint32_t *)dibuf;
                for (uint32_t g = 0; g < JETFS_DOUBLE_INDIRECT_PTRS; g++) {
                    if (!dptrs[g]) continue;
                    /* 이 간접 블록이 가리키는 실제 데이터(리프) 블록들을
                     * 먼저 전부 회수하고, 그 다음 간접 블록 자체를 회수 */
                    if (block_read(dptrs[g], leafbuf)) {
                        uint32_t *leaf_ptrs = (uint32_t *)leafbuf;
                        for (uint32_t s = 0; s < JETFS_INDIRECT_PTRS; s++) {
                            if (leaf_ptrs[s]) bitmap_free_block(leaf_ptrs[s]);
                        }
                    }
                    bitmap_free_block(dptrs[g]);
                }
            }
        }
        if (dibuf) kfree(dibuf);
        if (leafbuf) kfree(leafbuf);
        bitmap_free_block(inode->double_indirect);
        inode->double_indirect = 0;
    }
    if (inode->triple_indirect) {
        /* Milestone 23: 삼중 간접 트리 전체(레벨1 포인터블록 -> 레벨2
         * 간접블록들 -> 실제 리프 데이터블록들)를 3중 루프로 전부 회수.
         * 이중간접 정리 로직을 그대로 한 겹 더 감싼 것뿐이다. */
        uint8_t *tbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        uint8_t *l2buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        uint8_t *leafbuf2 = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (tbuf && l2buf && leafbuf2 && block_read(inode->triple_indirect, tbuf)) {
            uint32_t *tptrs = (uint32_t *)tbuf;
            for (uint32_t a = 0; a < JETFS_TRIPLE_INDIRECT_PTRS; a++) {
                if (!tptrs[a]) continue;
                if (block_read(tptrs[a], l2buf)) {
                    uint32_t *l2ptrs = (uint32_t *)l2buf;
                    for (uint32_t b = 0; b < JETFS_DOUBLE_INDIRECT_PTRS; b++) {
                        if (!l2ptrs[b]) continue;
                        if (block_read(l2ptrs[b], leafbuf2)) {
                            uint32_t *leaf_ptrs = (uint32_t *)leafbuf2;
                            for (uint32_t s = 0; s < JETFS_INDIRECT_PTRS; s++) {
                                if (leaf_ptrs[s]) bitmap_free_block(leaf_ptrs[s]);
                            }
                        }
                        bitmap_free_block(l2ptrs[b]);
                    }
                }
                bitmap_free_block(tptrs[a]);
            }
        }
        if (tbuf) kfree(tbuf);
        if (l2buf) kfree(l2buf);
        if (leafbuf2) kfree(leafbuf2);
        bitmap_free_block(inode->triple_indirect);
        inode->triple_indirect = 0;
    }
}

/* ---- 디렉터리 순회 ---- */
static int dir_find(uint32_t dir_inode_idx, const char *name,
                     uint32_t *out_block, uint32_t *out_slot, uint32_t *out_inode) {
    jetfs_inode_t dir;
    if (!inode_read(dir_inode_idx, &dir)) return 0;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    for (uint32_t b = 0; b < dir.block_count; b++) {
        if (!block_read(dir.block[b], buf)) continue;
        jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
        for (uint32_t s = 0; s < DIRENTS_PER_BLOCK; s++) {
            if (ents[s].used && str_eq(ents[s].name, name)) {
                if (out_block) *out_block = dir.block[b];
                if (out_slot) *out_slot = s;
                if (out_inode) *out_inode = ents[s].inode;
                kfree(buf);
                return 1;
            }
        }
    }
    kfree(buf);
    return 0;
}

static int dir_add(uint32_t dir_inode_idx, const char *name, uint32_t inode_idx) {
    jetfs_inode_t dir;
    if (!inode_read(dir_inode_idx, &dir)) return 0;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    for (uint32_t b = 0; b < dir.block_count; b++) {
        if (!block_read(dir.block[b], buf)) continue;
        jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
        for (uint32_t s = 0; s < DIRENTS_PER_BLOCK; s++) {
            if (!ents[s].used) {
                str_copy(ents[s].name, name, JETFS_MAX_NAME);
                ents[s].inode = inode_idx;
                ents[s].used = 1;
                int ok = block_write(dir.block[b], buf);
                kfree(buf);
                return ok;
            }
        }
    }

    /* 기존 블록에 빈 슬롯이 없음 -> 새 블록 추가 */
    if (dir.block_count >= JETFS_DIRECT_BLOCKS) { kfree(buf); return 0; }
    int newblock = bitmap_alloc_block();
    if (newblock < 0) { kfree(buf); return 0; }

    for (int i = 0; i < JETFS_BLOCK_SIZE; i++) buf[i] = 0;
    jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
    str_copy(ents[0].name, name, JETFS_MAX_NAME);
    ents[0].inode = inode_idx;
    ents[0].used = 1;
    if (!block_write((uint32_t)newblock, buf)) { kfree(buf); return 0; }

    dir.block[dir.block_count] = (uint32_t)newblock;
    dir.block_count++;
    inode_write(dir_inode_idx, &dir);
    kfree(buf);
    return 1;
}

static int dir_remove(uint32_t dir_inode_idx, const char *name) {
    uint32_t block, slot, inode_idx;
    if (!dir_find(dir_inode_idx, name, &block, &slot, &inode_idx)) return 0;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(block, buf)) { kfree(buf); return 0; }
    jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
    ents[slot].used = 0;
    int ok = block_write(block, buf);
    kfree(buf);
    return ok;
}

/* ---- 경로 해석: "/a/b/c" -> 부모 디렉터리 inode + 마지막 구성요소 이름 ---- */
static int resolve_parent(const char *path, uint32_t *out_parent_inode, char *out_name) {
    if (!path || path[0] != '/') return 0;
    uint32_t cur = g_sb.root_inode;
    int i = 1;
    char comp[JETFS_MAX_NAME];

    while (path[i]) {
        int c = 0;
        while (path[i] && path[i] != '/' && c < JETFS_MAX_NAME - 1) comp[c++] = path[i++];
        comp[c] = '\0';
        while (path[i] == '/') i++;

        if (!path[i]) { /* comp가 마지막 구성요소 */
            *out_parent_inode = cur;
            str_copy(out_name, comp, JETFS_MAX_NAME);
            return 1;
        }
        uint32_t next_inode;
        if (!dir_find(cur, comp, NULL, NULL, &next_inode)) return 0;
        cur = next_inode;
    }
    return 0; /* 빈 경로 또는 "/" 자체 */
}

static int resolve(const char *path, uint32_t *out_inode) {
    if (str_eq(path, "/")) { *out_inode = g_sb.root_inode; return 1; }
    uint32_t parent;
    char name[JETFS_MAX_NAME];
    if (!resolve_parent(path, &parent, name)) return 0;
    return dir_find(parent, name, NULL, NULL, out_inode);
}

/* ---- 공개 API ---- */
int jetfs_create(const char *path, jetfs_inode_type_t type) {
    if (!g_mounted) return 0;
    uint32_t parent;
    char name[JETFS_MAX_NAME];
    if (!resolve_parent(path, &parent, name)) return 0;

    uint32_t existing;
    if (dir_find(parent, name, NULL, NULL, &existing)) return 0; /* 이미 존재 */

    /* Milestone 47: inode 할당(inode_alloc이 내부적으로 "사용중" 표시를
     * 씀) + inode 초기화 + 디렉터리 항목 추가, 이 세 군데 블록 쓰기가
     * 전부 끝나야 "파일 생성"이 완료된 상태다 — 그 사이 어디서
     * 크래시해도 저널이 전부 반영되거나 전혀 반영 안 된 것처럼
     * 만들어준다(중간 상태로 남는 걸 방지). */
    jetfs_txn_begin();

    int new_inode = inode_alloc();
    if (new_inode < 0) { jetfs_txn_commit(); return 0; }

    jetfs_inode_t inode;
    inode_read((uint32_t)new_inode, &inode);
    inode.type = (uint32_t)type;
    inode.size = 0;
    inode.block_count = 0;
    inode.indirect = 0;
    inode.double_indirect = 0;
    inode.triple_indirect = 0;
    inode.owner_uid = current_uid(); /* Milestone 48 */
    inode_write((uint32_t)new_inode, &inode);

    int ok = dir_add(parent, name, (uint32_t)new_inode);
    jetfs_txn_commit();
    return ok;
}

int jetfs_read(const char *path, void *buffer, uint64_t max_size, uint64_t *out_size) {
    if (!g_mounted) return 0;
    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    if (inode.type != JETFS_TYPE_FILE) return 0;

    uint64_t to_read = inode.size < max_size ? inode.size : max_size;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    uint64_t done = 0;
    uint32_t block_idx = 0;
    while (done < to_read) {
        uint32_t blockno = 0;
        if (!file_block_map(&inode, block_idx, 0, &blockno) || blockno == 0) break; /* 구멍/오류: 여기서 중단 */
        if (!block_read(blockno, buf)) { kfree(buf); return 0; }
        uint64_t chunk = to_read - done;
        if (chunk > JETFS_BLOCK_SIZE) chunk = JETFS_BLOCK_SIZE;
        uint8_t *dst = (uint8_t *)buffer + done;
        for (uint64_t k = 0; k < chunk; k++) dst[k] = buf[k];
        done += chunk;
        block_idx++;
    }
    kfree(buf);
    if (out_size) *out_size = done;
    return 1;
}

/* write/append가 공유하는 핵심 로직: inode의 현재 크기(base_size)
 * 뒤(또는 처음부터, base_size=0이면)부터 len바이트를 써서 최종 크기를
 * base_size+len으로 만든다. write는 base_size=0(통째로 새로 씀),
 * append는 base_size=inode.size(끝에 이어붙임)로 호출한다. */
static int file_write_from(jetfs_inode_t *inode, uint32_t idx, uint64_t base_size,
                            const void *data, uint64_t len) {
    uint64_t new_size = base_size + len;
    uint32_t blocks_needed = (uint32_t)((new_size + JETFS_BLOCK_SIZE - 1) / JETFS_BLOCK_SIZE);
    if (new_size > (uint64_t)JETFS_MAX_FILE_BLOCKS * JETFS_BLOCK_SIZE) return 0; /* 구조적 상한(약 4TB) 초과 */

    /* 필요한 만큼 블록을 매핑/할당(직접 -> 간접 -> 이중 -> 삼중간접까지) */
    for (uint32_t b = 0; b < blocks_needed; b++) {
        uint32_t blockno;
        if (!file_block_map(inode, b, 1, &blockno) || blockno == 0) return 0;
    }

    /* base_size가 0(=write, 통째로 재작성)이고 크기가 줄었으면 남는
     * 블록을 회수한다. append(base_size>0)는 파일이 줄어들 일이
     * 없으므로 이 블록은 base_size==0일 때만 의미가 있다. */
    if (base_size == 0) {
        uint32_t old_blocks = (uint32_t)(((uint64_t)inode->size + JETFS_BLOCK_SIZE - 1) / JETFS_BLOCK_SIZE);
        if (old_blocks > blocks_needed) {
            for (uint32_t b = old_blocks; b > blocks_needed; b--) file_block_free(inode, b - 1);

            if (blocks_needed <= JETFS_DIRECT_BLOCKS + JETFS_INDIRECT_PTRS && inode->double_indirect) {
                uint8_t *dibuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
                if (dibuf && block_read(inode->double_indirect, dibuf)) {
                    uint32_t *dptrs = (uint32_t *)dibuf;
                    for (uint32_t g = 0; g < JETFS_DOUBLE_INDIRECT_PTRS; g++) {
                        if (dptrs[g]) bitmap_free_block(dptrs[g]);
                    }
                }
                if (dibuf) kfree(dibuf);
                bitmap_free_block(inode->double_indirect);
                inode->double_indirect = 0;
            }
            if (blocks_needed <= JETFS_DIRECT_BLOCKS && inode->indirect) {
                bitmap_free_block(inode->indirect);
                inode->indirect = 0;
            }
            /* 삼중간접까지 필요없어질 만큼 줄어드는 극단적인 경우는
             * (파일을 4GB+ 크기에서 몇 바이트로 줄이는 경우) 흔치 않아
             * triple_indirect 껍데기 회수는 다음 write에서 자연히
             * 정리되도록 남겨둔다(알려진 단순화 — 디스크 낭비는
             * "그 파일을 다시 지우면" 결국 file_free_all_blocks가 회수). */
        }
    }

    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    const uint8_t *src = (const uint8_t *)data;
    uint32_t start_block = (uint32_t)(base_size / JETFS_BLOCK_SIZE);
    uint64_t written = 0;

    for (uint32_t b = start_block; b < blocks_needed; b++) {
        uint32_t blockno;
        file_block_map(inode, b, 0, &blockno); /* 위에서 이미 할당했으므로 조회만 */

        uint64_t block_start_offset = (uint64_t)b * JETFS_BLOCK_SIZE;
        int need_partial_read = (block_start_offset < base_size); /* append가 걸치는 첫 블록: 기존 내용 보존 */
        if (need_partial_read) {
            if (!block_read(blockno, buf)) { kfree(buf); return 0; }
        }

        for (uint32_t k = 0; k < JETFS_BLOCK_SIZE; k++) {
            uint64_t abs_off = block_start_offset + k;
            if (abs_off < base_size) continue; /* 기존 내용 유지(위에서 이미 읽어둠) */
            if (abs_off < new_size) {
                buf[k] = src[abs_off - base_size];
                written++;
            } else if (!need_partial_read) {
                buf[k] = 0; /* 새로 할당된 블록의 남는 꼬리는 0으로 */
            }
        }
        if (!block_write(blockno, buf)) { kfree(buf); return 0; }
    }
    kfree(buf);
    (void)written;

    inode->size = new_size;
    return inode_write(idx, inode);
}

int jetfs_write(const char *path, const void *data, uint64_t size) {
    if (!g_mounted) return 0;
    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    if (inode.type != JETFS_TYPE_FILE) return 0;
    if (inode.flags & JETFS_FLAG_READONLY) return 0; /* Milestone 46 */
    if (!uid_can_modify(&inode)) return 0; /* Milestone 48 */

    return file_write_from(&inode, idx, 0, data, size);
}

int jetfs_append(const char *path, const void *data, uint64_t len) {
    if (!g_mounted) return 0;
    if (len == 0) return 1;
    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    if (inode.type != JETFS_TYPE_FILE) return 0;
    if (inode.flags & JETFS_FLAG_READONLY) return 0; /* Milestone 46 */
    if (!uid_can_modify(&inode)) return 0; /* Milestone 48 */

    return file_write_from(&inode, idx, inode.size, data, len);
}

int jetfs_delete(const char *path) {
    if (!g_mounted) return 0;
    uint32_t parent;
    char name[JETFS_MAX_NAME];
    if (!resolve_parent(path, &parent, name)) return 0;

    uint32_t idx;
    if (!dir_find(parent, name, NULL, NULL, &idx)) return 0;

    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    if (inode.flags & JETFS_FLAG_READONLY) return 0; /* Milestone 46 */
    if (!uid_can_modify(&inode)) return 0; /* Milestone 48 */

    /* Milestone 47: 블록 회수 + inode 해제 + 디렉터리 항목 제거를
     * 하나의 트랜잭션으로 — 중간에 크래시해도 "블록은 회수됐는데
     * 디렉터리엔 항목이 남아있는"(허상 참조) 상태가 안 생긴다. */
    jetfs_txn_begin();

    /* 데이터 블록 비트맵 회수.
     * 디렉터리는 block_count로 사용중인 직접 블록 개수를 추적한다.
     * 파일은 크기(size)로부터 필요 블록 수를 매번 계산하므로
     * block_count를 쓰지 않는다 — 그냥 할당된 직접 블록 12개 전부와
     * 간접 블록(있다면) 안의 모든 항목을 회수한다. */
    if (inode.type == JETFS_TYPE_FILE) {
        file_free_all_blocks(&inode);
    } else {
        for (uint32_t b = 0; b < inode.block_count; b++) {
            bitmap_free_block(inode.block[b]);
            inode.block[b] = 0;
        }
        inode.block_count = 0;
    }
    inode.size = 0;
    inode.used = 0;
    inode.type = JETFS_TYPE_FREE;
    inode_write(idx, &inode);

    int ok = dir_remove(parent, name);
    jetfs_txn_commit();
    return ok;
}

int jetfs_rename(const char *old_path, const char *new_path) {
    if (!g_mounted) return 0;
    uint32_t old_parent, new_parent;
    char old_name[JETFS_MAX_NAME], new_name[JETFS_MAX_NAME];
    if (!resolve_parent(old_path, &old_parent, old_name)) return 0;
    if (!resolve_parent(new_path, &new_parent, new_name)) return 0;

    uint32_t idx;
    if (!dir_find(old_parent, old_name, NULL, NULL, &idx)) return 0;

    /* Milestone 48: readonly 플래그와 달리(M46, Windows 관례를 따라
     * rename은 일부러 안 막음) 소유권은 rename도 막는다 — readonly는
     * "이 파일 내용을 건드리지 마라"는 속성이지만, 소유권은 "이
     * 파일에 대해 아무것도 할 수 없다"는 경계라서 rename을 열어두면
     * 다른 사용자의 파일을 마음대로 옮기거나 숨길 수 있게 된다. */
    jetfs_inode_t owner_check;
    if (!inode_read(idx, &owner_check)) return 0;
    if (!uid_can_modify(&owner_check)) return 0;

    /* Milestone 47: "옛 이름 제거 + 새 이름 추가"가 원자적이어야 크래시
     * 시 파일이 양쪽 디렉터리에서 동시에 사라지는(dir_remove만 반영되고
     * dir_add는 안 된 경우) 사고를 막는다. */
    jetfs_txn_begin();
    int ok = dir_remove(old_parent, old_name) && dir_add(new_parent, new_name, idx);
    jetfs_txn_commit();
    return ok;
}

int jetfs_stat(const char *path, jetfs_inode_type_t *out_type, uint64_t *out_size) {
    if (!g_mounted) return 0;
    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    if (out_type) *out_type = (jetfs_inode_type_t)inode.type;
    if (out_size) *out_size = inode.size;
    return 1;
}

int jetfs_list(const char *dir_path, jetfs_list_cb cb, void *ctx) {
    if (!g_mounted) return 0;
    uint32_t dir_idx;
    if (!resolve(dir_path, &dir_idx)) return 0;

    jetfs_inode_t dir;
    if (!inode_read(dir_idx, &dir)) return 0;
    if (dir.type != JETFS_TYPE_DIR) return 0;

    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    for (uint32_t b = 0; b < dir.block_count; b++) {
        if (!block_read(dir.block[b], buf)) continue;
        jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
        for (uint32_t s = 0; s < DIRENTS_PER_BLOCK; s++) {
            if (!ents[s].used) continue;
            jetfs_inode_t child;
            if (!inode_read(ents[s].inode, &child)) continue;
            cb(ents[s].name, (jetfs_inode_type_t)child.type, child.size, ctx);
        }
    }
    kfree(buf);
    return 1;
}

/* Milestone 46: 읽기전용 속성 설정/조회. */
int jetfs_set_readonly(const char *path, int readonly) {
    if (!g_mounted) return 0;
    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    if (readonly) inode.flags |= JETFS_FLAG_READONLY;
    else inode.flags &= ~JETFS_FLAG_READONLY;
    return inode_write(idx, &inode);
}

int jetfs_is_readonly(const char *path) {
    if (!g_mounted) return 0;
    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    return (inode.flags & JETFS_FLAG_READONLY) ? 1 : 0;
}

/* Milestone 48: 소유권 조회/변경. */
int jetfs_get_owner(const char *path) {
    if (!g_mounted) return -1;
    uint32_t idx;
    if (!resolve(path, &idx)) return -1;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return -1;
    return (int)inode.owner_uid;
}

int jetfs_chown(const char *path, uint32_t new_uid) {
    if (!g_mounted) return 0;
    if (current_uid() != JETFS_ROOT_UID) return 0; /* chown은 root만 — Unix 관례 */
    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    inode.owner_uid = new_uid;
    return inode_write(idx, &inode);
}

int jetfs_debug_crash_test_prepare(const char *path, const char *old_content, const char *new_content) {
    if (!g_mounted) return 0;
    if (!jetfs_stat(path, NULL, NULL)) {
        if (!jetfs_create(path, JETFS_TYPE_FILE)) return 0;
    }
    uint64_t old_len = 0; while (old_content[old_len]) old_len++;
    if (!jetfs_write(path, old_content, old_len)) return 0; /* 정상 경로 — 트랜잭션 밖, 실제로 적용됨 */

    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    if (inode.block[0] == 0) return 0; /* old_content가 비어있어서 블록이 아예 없으면 테스트 불가 */

    uint8_t buf[JETFS_BLOCK_SIZE];
    for (int k = 0; k < JETFS_BLOCK_SIZE; k++) buf[k] = 0;
    uint64_t new_len = 0; while (new_content[new_len]) new_len++;
    if (new_len > JETFS_BLOCK_SIZE) new_len = JETFS_BLOCK_SIZE;
    for (uint64_t k = 0; k < new_len; k++) buf[k] = (uint8_t)new_content[k];

    jetfs_txn_begin();
    block_write(inode.block[0], buf); /* 트랜잭션 안이라 실제로는 스테이징만 됨 */
    jetfs_debug_commit_journal_only_no_apply(); /* 저널 커밋까지만 하고 "크래시" */
    return 1;
}
