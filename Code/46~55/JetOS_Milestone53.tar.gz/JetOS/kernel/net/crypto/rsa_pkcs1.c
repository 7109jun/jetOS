/* JetOS - kernel/net/crypto/rsa_pkcs1.c */
#include "rsa_pkcs1.h"
#include "rng.h"
#include <string.h>

int rsa_pkcs1_encrypt(const bignum_t *n, const bignum_t *e,
                       const uint8_t *msg, size_t mlen,
                       uint8_t *out, size_t modulus_bytes) {
    if (modulus_bytes < 11 || mlen > modulus_bytes - 11) return 0;
    if (modulus_bytes > BIGNUM_MAX_LIMBS * 4) return 0;

    uint8_t em[BIGNUM_MAX_LIMBS * 4];
    size_t ps_len = modulus_bytes - mlen - 3;

    em[0] = 0x00;
    em[1] = 0x02;
    /* PS: 0이 아닌 랜덤 바이트로 패딩(RFC 8017 7.2.1) */
    uint8_t rnd[BIGNUM_MAX_LIMBS * 4];
    rng_bytes(rnd, ps_len);
    for (size_t i = 0; i < ps_len; i++) {
        uint8_t b = rnd[i];
        if (b == 0) b = 0x5A; /* 0이 나오면 임의의 0 아닌 값으로 대체(균등성보다 "0 금지"가 핵심) */
        em[2 + i] = b;
    }
    em[2 + ps_len] = 0x00;
    for (size_t i = 0; i < mlen; i++) em[3 + ps_len + i] = msg[i];

    bignum_t m, c;
    bn_from_bytes_be(&m, em, modulus_bytes);
    bn_modexp(&c, &m, e, n);

    return bn_to_bytes_be(&c, out, modulus_bytes);
}

int rsa_pkcs1_verify_sha256(const uint8_t hash[32], const uint8_t *sig, size_t sig_len,
                             const bignum_t *n, const bignum_t *e) {
    size_t modulus_bytes = bn_byte_len(n);
    if (modulus_bytes == 0 || modulus_bytes > BIGNUM_MAX_LIMBS * 4) return 0;
    if (sig_len != modulus_bytes) return 0; /* RFC 8017: 서명 길이는 반드시 modulus 길이와 같음 */

    bignum_t sig_bn, em_bn;
    bn_from_bytes_be(&sig_bn, sig, sig_len);
    if (bn_cmp(&sig_bn, n) >= 0) return 0; /* 서명값은 modulus보다 작아야 함 */
    bn_modexp(&em_bn, &sig_bn, e, n);

    uint8_t em[BIGNUM_MAX_LIMBS * 4];
    if (!bn_to_bytes_be(&em_bn, em, modulus_bytes)) return 0;

    /* DigestInfo DER 접두어(SHA-256, RFC 8017 부록 B.1의 잘 알려진 상수) —
     * x509_min.c의 인증서 서명 검증과 완전히 같은 상수(같은 알고리즘이니
     * 당연함). */
    static const uint8_t digest_prefix[19] = {
        0x30, 0x31, 0x30, 0x0d, 0x06, 0x09, 0x60, 0x86, 0x48, 0x01,
        0x65, 0x03, 0x04, 0x02, 0x01, 0x05, 0x00, 0x04, 0x20
    };
    size_t di_len = sizeof(digest_prefix) + 32;
    if (modulus_bytes < 3 + di_len) return 0;
    size_t ps_len = modulus_bytes - 3 - di_len;

    if (em[0] != 0x00 || em[1] != 0x01) return 0;
    for (size_t i = 0; i < ps_len; i++) if (em[2 + i] != 0xFF) return 0;
    if (em[2 + ps_len] != 0x00) return 0;
    if (memcmp(em + 3 + ps_len, digest_prefix, sizeof(digest_prefix)) != 0) return 0;
    if (memcmp(em + 3 + ps_len + sizeof(digest_prefix), hash, 32) != 0) return 0;
    return 1;
}
