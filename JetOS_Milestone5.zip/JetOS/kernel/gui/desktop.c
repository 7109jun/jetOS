/*
 * JetOS - kernel/gui/desktop.c
 * 데스크톱 셸: 마우스로 창을 드래그하고, 시작메뉴를 열고, 키보드로
 * 메모장 창에 타이핑할 수 있는 최소 상호작용 루프.
 */

#include "desktop.h"
#include "wm.h"
#include "../kernel.h"
#include "../drivers/keyboard.h"
#include "../drivers/mouse.h"
#include "../drivers/serial.h"
#include "../proc/scheduler.h"
#include "../hal/x86_asm_shim.h"

#define NOTEPAD_BUF_SIZE 256

static char g_notepad_buf[NOTEPAD_BUF_SIZE];
static int g_notepad_len = 0;
static int g_notepad_window = -1;
static int g_shutdown_requested = 0;

static void notepad_append(char c) {
    if (c == '\b') {
        if (g_notepad_len > 0) g_notepad_len--;
        g_notepad_buf[g_notepad_len] = '\0';
        return;
    }
    if (c == '\n') c = ' ';
    if (g_notepad_len < NOTEPAD_BUF_SIZE - 1) {
        g_notepad_buf[g_notepad_len++] = c;
        g_notepad_buf[g_notepad_len] = '\0';
    }
}

static void draw_notepad_content(void) {
    if (g_notepad_window < 0) return;
    console_t *dc = wm_get_draw_console();
    int wx, wy, ww, wh;
    wm_get_window_bounds(g_notepad_window, &wx, &wy, &ww, &wh);
    (void)ww; (void)wh;
    dc->cursor_x = (uint32_t)(wx + 10);
    dc->cursor_y = (uint32_t)(wy + WM_TITLEBAR_H + 10);
    console_print(dc, g_notepad_buf);
}

void desktop_thread_fn(void *arg) {
    (void)arg;

    wm_init(&g_console);
    keyboard_init();
    mouse_init();

    wm_create_window("ABOUT JETOS", 60, 60, 260, 120, 0x00304050);
    g_notepad_window = wm_create_window("NOTEPAD", 340, 60, 260, 120, 0x00203040);

    serial_write("STAGE: GUI DESKTOP SHELL STARTED (keyboard+mouse+wm)\n");

    int dragging = -1;
    int drag_offset_hit_titlebar = 0;
    int prev_left = 0;

    for (;;) {
        char kc = keyboard_poll_char();
        if (kc) {
            serial_write("KEY: '");
            serial_putc(kc == '\n' ? ' ' : kc);
            serial_write("'\n");
            notepad_append(kc);
        }

        mouse_event_t ev;
        if (mouse_poll_event(&ev)) {
            int nx, ny;
            wm_get_cursor(&nx, &ny);
            wm_set_cursor(nx + ev.dx, ny + ev.dy);

            if (ev.left && !prev_left) {
                /* 눌림 엣지: 클릭 대상 판별 */
                int item;
                if (wm_is_start_button_hit(nx, ny)) {
                    wm_set_start_menu_open(1);
                } else if (wm_is_start_menu_item_hit(nx, ny, &item)) {
                    wm_set_start_menu_open(0);
                    if (item == 3) { /* SHUTDOWN */
                        g_shutdown_requested = 1;
                    }
                } else {
                    wm_set_start_menu_open(0);
                    int idx = wm_window_at(nx, ny);
                    if (idx >= 0) {
                        wm_bring_to_front(idx);
                        if (wm_hit_titlebar(idx, nx, ny)) {
                            dragging = idx;
                            drag_offset_hit_titlebar = 1;
                        }
                    }
                }
            } else if (!ev.left) {
                dragging = -1;
                drag_offset_hit_titlebar = 0;
            } else if (ev.left && dragging >= 0 && drag_offset_hit_titlebar) {
                wm_move_window(dragging, ev.dx, ev.dy);
            }
            prev_left = ev.left;
        }

        wm_draw();
        draw_notepad_content();
        wm_present();

        if (g_shutdown_requested) {
            g_console.cursor_x = 20; g_console.cursor_y = 20;
            console_fill_rect(&g_console, 0, 0, g_console.width, g_console.height, 0x00000000);
            g_console.cursor_x = 40; g_console.cursor_y = 40;
            console_print(&g_console, "JETOS IS SHUTTING DOWN...");
            serial_write("STAGE: SHUTDOWN REQUESTED FROM START MENU. HALTING.\n");
            for (;;) { hal_hlt(); }
        }

        scheduler_yield();
    }
}
