/*
 * JetOS - kernel/compat/win32.c
 * win32.h에 선언된 함수들의 구현. 전부 JetAPI 호출로 위임된다.
 */

#include <stddef.h>
#include "win32.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../proc/thread.h"

#define MAX_HANDLES 16

typedef struct {
    int used;
    char path[64];
} file_handle_t;

static file_handle_t g_handles[MAX_HANDLES];

static void str_copy(char *dst, const char *src, int max) {
    int i = 0;
    for (; i < max - 1 && src[i]; i++) dst[i] = src[i];
    dst[i] = '\0';
}

HWND CreateWindowA(LPCSTR title, int x, int y, int w, int h, DWORD color_as_style_placeholder) {
    uint32_t color = color_as_style_placeholder ? color_as_style_placeholder : 0x00304050;
    int idx = CreateWindowJ(title, x, y, w, h, color);
    if (idx < 0) return NULL_HANDLE;
    return (HANDLE)(intptr_t)(idx + 1); /* 0을 "실패"로 예약하기 위해 +1 */
}

int MessageBoxA(HWND owner, LPCSTR text, LPCSTR title, DWORD type) {
    (void)owner; (void)type;
    /* Milestone 6: 실제 모달/버튼 처리 없이, 텍스트를 담은 작은 창을
     * 하나 띄우는 것으로 단순화했다 (진짜 모달 대화상자는 Window
     * Manager에 포커스 잠금 개념이 추가되는 이후 마일스톤 과제). */
    int win = CreateWindowJ(title ? title : "MESSAGE", 400, 300, 240, 80, 0x00504030);
    (void)text;
    return win >= 0 ? 1 : 0;
}

HANDLE CreateFileA(LPCSTR path, DWORD desired_access, DWORD share_mode,
                    void *security_attrs, DWORD creation_disposition,
                    DWORD flags, HANDLE template_file) {
    (void)desired_access; (void)share_mode; (void)security_attrs;
    (void)creation_disposition; (void)flags; (void)template_file;

    for (int i = 0; i < MAX_HANDLES; i++) {
        if (!g_handles[i].used) {
            CreateFileJ(path, 0); /* 없으면 생성, 있으면 무시 */
            g_handles[i].used = 1;
            str_copy(g_handles[i].path, path, sizeof(g_handles[i].path));
            return (HANDLE)(intptr_t)(i + 1);
        }
    }
    return NULL_HANDLE;
}

BOOL ReadFile(HANDLE file, LPVOID buffer, DWORD bytes_to_read, DWORD *bytes_read, void *overlapped) {
    (void)overlapped;
    int idx = (int)(intptr_t)file - 1;
    if (idx < 0 || idx >= MAX_HANDLES || !g_handles[idx].used) return FALSE;
    uint32_t out = 0;
    int ok = ReadFileJ(g_handles[idx].path, buffer, bytes_to_read, &out);
    if (bytes_read) *bytes_read = out;
    return ok ? TRUE : FALSE;
}

BOOL WriteFile(HANDLE file, LPCVOID buffer, DWORD bytes_to_write, DWORD *bytes_written, void *overlapped) {
    (void)overlapped;
    int idx = (int)(intptr_t)file - 1;
    if (idx < 0 || idx >= MAX_HANDLES || !g_handles[idx].used) return FALSE;
    int ok = WriteFileJ(g_handles[idx].path, buffer, bytes_to_write);
    if (bytes_written) *bytes_written = ok ? bytes_to_write : 0;
    return ok ? TRUE : FALSE;
}

BOOL CloseHandle(HANDLE h) {
    int idx = (int)(intptr_t)h - 1;
    if (idx < 0 || idx >= MAX_HANDLES) return FALSE;
    g_handles[idx].used = 0;
    return TRUE;
}

LPVOID VirtualAlloc(LPVOID addr, uint32_t size, DWORD alloc_type, DWORD protect) {
    (void)addr; (void)alloc_type; (void)protect;
    return VirtualAllocJ(size);
}

BOOL VirtualFree(LPVOID addr, uint32_t size, DWORD free_type) {
    (void)size; (void)free_type;
    VirtualFreeJ(addr);
    return TRUE;
}

__attribute__((noreturn))
void ExitProcess(DWORD exit_code) {
    (void)exit_code;
    thread_exit();
}
