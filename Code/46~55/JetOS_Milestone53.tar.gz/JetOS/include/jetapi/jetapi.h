#ifndef JETOS_JETAPI_H
#define JETOS_JETAPI_H

/*
 * JetAPI — JetOS 고유 Native API.
 *
 * 애플리케이션은 커널 내부 구조체(wm_window_t, jetfs_inode_t 등)를 직접
 * 건드리지 않고 이 레이어만을 통해 시스템 서비스를 사용한다:
 *
 *   Application -> JetAPI -> JetOS System Services -> JetOS Kernel
 *
 * 함수 이름은 Windows 개발자에게 익숙한 형태(CreateWindowJ, CreateFileJ,
 * VirtualAllocJ 등 - 끝에 J를 붙여 "JetOS 자체 API"임을 명확히 구분)를
 * 사용하지만, Windows API가 아니며 Windows DLL/SDK를 전혀 사용하지
 * 않는다. 전부 JetOS가 직접 구현한 코드다.
 */

#include <stdint.h>

/* ---- 윈도우 ---- */
typedef int JetWindowHandle; /* -1 = 실패 */

JetWindowHandle CreateWindowJ(const char *title, int x, int y, int w, int h, uint32_t color);
void MoveWindowJ(JetWindowHandle win, int dx, int dy);
void BringWindowToFrontJ(JetWindowHandle win);

/* ---- 파일 ---- */
int CreateFileJ(const char *path, int is_directory);
int ReadFileJ(const char *path, void *buffer, uint64_t max_size, uint64_t *out_size);
int WriteFileJ(const char *path, const void *data, uint64_t size);
int DeleteFileJ(const char *path); /* 영구 삭제 — 휴지통 없이 즉시 지움 */
int RenameFileJ(const char *old_path, const char *new_path); /* Milestone 35 */
int MoveToRecycleBinJ(const char *path); /* Milestone 35: jash의 rm과 동일 — 휴지통으로 이동 */
int IsReadOnlyJ(const char *path); /* Milestone 35 */
int SetReadOnlyJ(const char *path, int readonly); /* Milestone 35 */

typedef void (*JetFileListCallback)(const char *name, int is_dir, uint64_t size, void *ctx);
int ListDirectoryJ(const char *path, JetFileListCallback cb, void *ctx);

/* ---- 메모리 ---- */
void *VirtualAllocJ(uint32_t size);
void VirtualFreeJ(void *ptr);

/* ---- 스레드/프로세스 ---- */
typedef void (*JetThreadEntry)(void *arg);
int CreateThreadJ(const char *name, JetThreadEntry entry, void *arg);

/* ---- 시스템 정보 (설정/작업관리자 앱용) ---- */
typedef struct {
    uint64_t heap_total_bytes;
    uint64_t heap_used_bytes;
    uint64_t pmm_total_pages;
    uint64_t pmm_free_pages;
    uint64_t timer_ticks;
} JetSystemInfo;

void GetSystemInfoJ(JetSystemInfo *out);

typedef void (*JetThreadListCallback)(const char *name, uint32_t id, int state, void *ctx);
void ListThreadsJ(JetThreadListCallback cb, void *ctx);

#endif
