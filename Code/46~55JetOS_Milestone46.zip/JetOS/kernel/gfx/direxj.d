kernel/gfx/direxj.o: kernel/gfx/direxj.c kernel/gfx/direxj.h \
 kernel/gfx/../drivers/console.h kernel/gfx/../drivers/virtio_gpu.h
kernel/gfx/direxj.h:
kernel/gfx/../drivers/console.h:
kernel/gfx/../drivers/virtio_gpu.h:
