/*
 * JetOS - kernel/apps/run_dialog.c
 * Milestone 35: 실행(Run) 대화상자. 설계 이유는 run_dialog.h 참고.
 */

#include <stddef.h>
#include "run_dialog.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../gui/widget.h"
#include "../drivers/console.h"
#include "../proc/scheduler.h"
#include "../fs/jetfs.h"
#include "../exec/elf_loader.h"
#include "../exec/pe_loader.h"

static widget_textbox_t g_path_box;
static int g_win = -1;
static int g_focused = 0;
static volatile int g_running = 0;
static char g_status[64] = "";

static void str_copy_local(char *dst, const char *src, int n) {
    int i = 0; for (; src[i] && i < n - 1; i++) dst[i] = src[i];
    dst[i] = '\0';
}

static void do_run(void) {
    if (g_path_box.len == 0) return;
    const char *target = g_path_box.buf;

    uint8_t magic[4] = {0,0,0,0};
    uint64_t got = 0;
    jetfs_read(target, magic, sizeof(magic), &got);

    if (got >= 4 && magic[0] == 0x7F && magic[1] == 'E' && magic[2] == 'L' && magic[3] == 'F') {
        if (elf_execute(target)) str_copy_local(g_status, "launched (ELF, Ring3)", sizeof(g_status));
        else str_copy_local(g_status, "failed to launch ELF", sizeof(g_status));
        return;
    }

    pe_load_result_t res;
    pe_load(target, &res);
    if (res.error_code != 0) {
        str_copy_local(g_status, "error: not found or bad PE", sizeof(g_status));
        return;
    }
    int id = pe_execute(target, NULL);
    str_copy_local(g_status, id >= 0 ? "launched (PE)" : "failed to launch", sizeof(g_status));
}

static void run_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)h; (void)ctx;
    dc->cursor_x = (uint32_t)(x + 6); dc->cursor_y = (uint32_t)(y + 4);
    console_print(dc, "Path to run:");

    g_path_box.x = x + 6;
    g_path_box.y = y + 16;
    widget_textbox_draw(dc, &g_path_box, g_focused);

    console_fill_rect(dc, (uint32_t)(x + 6), (uint32_t)(y + 42), 60, 16, 0x00304050u);
    dc->cursor_x = (uint32_t)(x + 16); dc->cursor_y = (uint32_t)(y + 46);
    console_print(dc, "Run");

    dc->cursor_x = (uint32_t)(x + 6); dc->cursor_y = (uint32_t)(y + 66);
    dc->fg_color = 0x00A0D0A0u;
    console_print(dc, g_status);
    dc->fg_color = 0x00E0E0E0u;
}

static void run_click_cb(int lx, int ly, void *ctx) {
    (void)ctx;
    g_focused = (ly >= 16 && ly < 32);
    if (lx >= 6 && lx < 66 && ly >= 42 && ly < 58) do_run();
}

static void run_key_cb(char c, void *ctx) {
    (void)ctx;
    if (!g_focused) return;
    if (c == '\n' || c == '\r') { do_run(); return; }
    widget_textbox_key(&g_path_box, c);
}

static void run_on_close(void *ctx) {
    (void)ctx;
    g_running = 0;
}

static void run_thread_fn(void *arg) {
    (void)arg;
    g_running = 1;
    g_focused = 1;
    g_status[0] = '\0';

    g_win = CreateWindowJ("RUN", 400, 220, 240, 90, 0x00303040);
    if (g_win >= 0) {
        widget_textbox_init(&g_path_box, 0, 0, 220, 16, "");
        wm_set_content_callback(g_win, run_content_cb, NULL);
        wm_set_close_callback(g_win, run_on_close, NULL);
        wm_set_click_callback(g_win, run_click_cb, NULL);
        wm_set_key_callback(g_win, run_key_cb, NULL);
    }
    while (g_running) {
        scheduler_yield();
    }
}

void run_dialog_launch(void) {
    static int launched = 0;
    if (launched && g_running) return;
    launched = 1;
    CreateThreadJ("run_dialog", run_thread_fn, NULL);
}
