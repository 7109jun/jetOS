#ifndef JETOS_SEARCH_H
#define JETOS_SEARCH_H

/*
 * JetOS - kernel/apps/search.h
 * Milestone 34: 검색(파일) 앱 ("10가지 목록" 7번). Start Menu/데스크톱
 * 아이콘에서 여는 GUI 창 — jash의 `search`/`find` 명령과 같은 로직을
 * (재사용 대신) 앱 안에 다시 구현했다: 이 프로젝트의 다른 GUI 앱들
 * (file_manager, browser 등)도 전부 JetAPI/커널 API만 직접 쓰는
 * 독립적인 소형 프로그램이라, jash 내부의 static 함수를 앱이 가져다
 * 쓰는 구조 자체가 없다 — 그 관례를 그대로 따랐다.
 */

void search_launch(void);

#endif
