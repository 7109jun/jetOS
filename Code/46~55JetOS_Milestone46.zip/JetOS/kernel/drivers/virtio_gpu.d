kernel/drivers/virtio_gpu.o: kernel/drivers/virtio_gpu.c \
 kernel/drivers/virtio_gpu.h kernel/drivers/pci.h kernel/drivers/serial.h \
 kernel/drivers/../hal/x86_asm_shim.h kernel/drivers/../mm/pmm.h \
 kernel/drivers/../mm/../../include/efi/efi.h kernel/drivers/../mm/vmm.h \
 kernel/drivers/../int/pit.h
kernel/drivers/virtio_gpu.h:
kernel/drivers/pci.h:
kernel/drivers/serial.h:
kernel/drivers/../hal/x86_asm_shim.h:
kernel/drivers/../mm/pmm.h:
kernel/drivers/../mm/../../include/efi/efi.h:
kernel/drivers/../mm/vmm.h:
kernel/drivers/../int/pit.h:
