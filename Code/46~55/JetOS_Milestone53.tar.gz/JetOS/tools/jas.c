/* JetOS - tools/jas.c
 * Milestone 42: 최소 x86-64 어셈블러(jas) — jcc.c(M30, C 서브셋 컴파일러)와
 * 같은 정신으로 만든 "어셈블리 서브셋" 도구. 외부 어셈블러/링커(GNU as/ld)
 * 없이 직접 기계어를 내서 JetOS의 ELF64 로더(kernel/exec/elf_loader.c)가
 * 그대로 읽는 정적 ELF64 실행파일을 만든다. jcc가 만드는 파일과 완전히
 * 같은 ELF 레이아웃(단일 PT_LOAD, RWX, LINK_BASE=0x100000000)을 쓴다 —
 * jash `run` 명령이나 jetfs_import가 두 도구의 산출물을 구분할 필요가
 * 없다.
 *
 * 목표: "JetOS가 JetOS를 개발할 수 있는 환경"(Milestone 42/43)의 두 번째
 * 조각. jcc가 고수준 C를, jas가 저수준 어셈블리를 각각 담당해서 나중에
 * jcc가 직접 다루기 힘든 저수준 코드(인터럽트 핸들러, 컨텍스트 스위치,
 * 시스템콜 트램폴린 그 자체 등)를 JetOS 위에서 직접 작성할 방법을
 * 제공한다.
 *
 * 지원 문법 (의도적으로 좁게 잡음 — jcc.c의 "C 서브셋"과 같은 정신):
 *   - Intel 스타일: `mov dst, src` (목적지가 왼쪽). GNU AT&T 문법(%레지스터,
 *     $즉치값, src/dst 반대순서)은 지원하지 않는다 — 이 프로젝트 자체
 *     문법이라 GNU as 결과물과 바이트 단위로 같을 필요는 없고, 실제
 *     동작(디스어셈블해서 의미가 맞는지, 실행했을 때 값이 맞는지)만
 *     맞으면 된다.
 *   - 레지스터: 64비트 GPR 16개(rax..r15)만. 32/16/8비트 서브레지스터
 *     미지원.
 *   - 메모리 오타랜드: `[reg]` 또는 `[reg+disp]`/`[reg-disp]`만(베이스
 *     레지스터 하나 + 상수 변위). SIB(인덱스*스케일)나 RIP-상대주소,
 *     rsp/r12를 베이스로 쓰는 경우는 미지원(그 두 레지스터는 ModRM
 *     인코딩상 SIB 바이트가 따로 필요해서 이번 스코프에서 뺐다 —
 *     "알려진 한계"로 아래 문서화).
 *   - 명령어: mov(reg,reg/imm32/[mem] 방향 둘 다/label주소), movabs(imm64),
 *     add/sub/and/or/xor/cmp(reg,reg 또는 reg,imm32), inc/dec, push/pop,
 *     lea, jmp/je/jne/jl/jle/jg/jge/jb/jbe/ja/jae(전부 rel32 — short jump
 *     최적화 없음, 코드가 조금 커지는 대신 두 번째 패스 없이 한 번에
 *     인코딩 가능해짐: jcc.c와 똑같은 "고정 크기 인코딩 + fixup" 전략),
 *     call, ret, leave, nop, "int 0x80"(JetOS 시스템콜 ABI 그대로).
 *   - 지시어: .text/.data(섹션 전환), label:(라벨 정의),
 *     .quad(8바이트 정수 상수 나열), .byte(1바이트씩), .asciz/.string
 *     (NUL 종단 문자열).
 *   - 주석: '#' 또는 ';'로 시작하는 줄 끝까지.
 *
 * ABI: JetOS 시스템콜은 eax=번호, rdi/rsi/rdx=인자, `int 0x80`, 반환값은
 * rax(kernel/hal/syscall.h 참고 — SYS_WRITE=0, SYS_EXIT=1, SYS_GETTICK=2,
 * SYS_BRK=3, SYS_OPEN=4, SYS_READ=5, SYS_WRITE_FD=6, SYS_CLOSE=7). jas
 * 자체는 이 번호들을 전혀 모른다(그냥 "int 0x80"을 그대로 인코딩할 뿐) —
 * 어셈블리 소스가 알아서 `mov eax, 0` 등으로 채워야 한다.
 */
#ifdef __JETOS_NATIVE__
/* Milestone 44: jcc.c와 같은 방식으로 JetOS 네이티브 Ring3 프로그램으로도
 * 빌드 가능 — jetos_native_shim.h가 malloc/calloc/realloc/memcpy/memset/
 * strcmp/strlen/strdup/strtol/isspace/isxdigit/isdigit/tolower를 제공.
 * die()의 진짜 가변인자 printf 흉내(%s 여러 개 지원)는 아래에서 별도로
 * 구현(jcc.c의 dief는 %s 하나만 지원했지만 jas.c의 die()는 최대 2개
 * 필요 — die("...%s...%s...", regname, tok) 같은 호출이 실제로 있음). */
#include "jetos_native_shim.h"
#include <stdint.h>
#include <stdarg.h>
#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>
#include <stdarg.h>
#endif

/* ===================== 동적 버퍼 ===================== */
typedef struct { uint8_t *data; size_t len, cap; } Buf;
static void buf_init(Buf *b) { b->data = NULL; b->len = b->cap = 0; }
static void buf_reserve(Buf *b, size_t need) {
    if (b->len + need <= b->cap) return;
    size_t ncap = b->cap ? b->cap * 2 : 256;
    while (ncap < b->len + need) ncap *= 2;
    b->data = (uint8_t *)realloc(b->data, ncap);
    b->cap = ncap;
}
static void buf_u8(Buf *b, uint8_t v) { buf_reserve(b, 1); b->data[b->len++] = v; }
static void buf_bytes(Buf *b, const void *p, size_t n) { buf_reserve(b, n); memcpy(b->data + b->len, p, n); b->len += n; }
static void buf_u32_at(Buf *b, size_t off, uint32_t v) { memcpy(b->data + off, &v, 4); }
static void buf_u64_at(Buf *b, size_t off, uint64_t v) { memcpy(b->data + off, &v, 8); }
static void buf_u32(Buf *b, uint32_t v) { buf_bytes(b, &v, 4); }
static void buf_u64(Buf *b, uint64_t v) { buf_bytes(b, &v, 8); }

#ifdef __JETOS_NATIVE__
/* 진짜 printf가 없으므로 "%s"만 지원하는 최소 포매터 — jas.c 안에서
 * die()가 실제로 쓰는 형태(%s 0~2개, 나머지는 리터럴 텍스트)를 전부
 * 커버한다(전체 호출부는 위 파일 헤더 주석 참고). */
static void die(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    jetos_write_str("jas: ");
    for (const char *p = fmt; *p; p++) {
        if (p[0] == '%' && p[1] == 's') {
            const char *s = va_arg(ap, const char *);
            jetos_write_str(s);
            p++;
        } else {
            char c1[2] = {*p, 0};
            jetos_write_str(c1);
        }
    }
    jetos_write_str("\n");
    va_end(ap);
    jetos_exit(1);
}
#else
static void die(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    fprintf(stderr, "jas: ");
    vfprintf(stderr, fmt, ap);
    fprintf(stderr, "\n");
    va_end(ap);
    exit(1);
}
#endif

/* ===================== 레지스터 ===================== */
static const char *g_reg_names[16] = {
    "rax","rcx","rdx","rbx","rsp","rbp","rsi","rdi",
    "r8","r9","r10","r11","r12","r13","r14","r15"
};
static int reg_index(const char *name) {
    for (int i = 0; i < 16; i++) if (strcmp(g_reg_names[i], name) == 0) return i;
    return -1;
}

/* ===================== 토크나이저 ===================== */
typedef struct { char **lines; int n; } SrcLines;

static SrcLines split_lines(const char *src) {
    SrcLines sl; sl.lines = NULL; sl.n = 0;
    int cap = 0;
    const char *p = src;
    while (*p) {
        const char *start = p;
        while (*p && *p != '\n') p++;
        int len = (int)(p - start);
        char *line = (char *)malloc((size_t)len + 1);
        memcpy(line, start, (size_t)len); line[len] = '\0';
        /* 주석 제거: '#' 또는 ';' 이후 전부 버림 */
        for (int i = 0; i < len; i++) {
            if (line[i] == '#' || line[i] == ';') { line[i] = '\0'; break; }
        }
        if (sl.n >= cap) { cap = cap ? cap * 2 : 64; sl.lines = (char **)realloc(sl.lines, (size_t)cap * sizeof(char *)); }
        sl.lines[sl.n++] = line;
        if (*p == '\n') p++;
    }
    return sl;
}

/* 한 줄을 공백/콤마로 토큰화. 대괄호 [..] 안의 내용은 통째로 한 토큰. */
#define MAX_TOK 8
static int tokenize(char *line, char *toks[MAX_TOK]) {
    int n = 0;
    char *p = line;
    while (*p) {
        while (*p && (isspace((unsigned char)*p) || *p == ',')) p++;
        if (!*p) break;
        if (n >= MAX_TOK) die("토큰이 너무 많음: %s", line);
        if (*p == '[') {
            char *start = p; p++;
            while (*p && *p != ']') p++;
            if (*p == ']') p++;
            int len = (int)(p - start);
            char *tok = (char *)malloc((size_t)len + 1);
            memcpy(tok, start, (size_t)len); tok[len] = '\0';
            toks[n++] = tok;
        } else {
            char *start = p;
            while (*p && !isspace((unsigned char)*p) && *p != ',') p++;
            int len = (int)(p - start);
            char *tok = (char *)malloc((size_t)len + 1);
            memcpy(tok, start, (size_t)len); tok[len] = '\0';
            toks[n++] = tok;
        }
    }
    return n;
}

/* ===================== 라벨 / fixup ===================== */
typedef struct Label {
    char *name;
    int section; /* 0=text, 1=data */
    size_t offset;
    int defined;
    struct Label *next;
} Label;
static Label *g_labels = NULL;

static Label *find_or_make_label(const char *name) {
    for (Label *l = g_labels; l; l = l->next) if (strcmp(l->name, name) == 0) return l;
    Label *l = (Label *)calloc(1, sizeof(Label));
    l->name = strdup(name);
    l->next = g_labels; g_labels = l;
    return l;
}

typedef enum { FX_REL32, FX_ABS64_CODE, FX_ABS64_DATA } FixupKind;
typedef struct Fixup {
    FixupKind kind;
    int section;      /* 이 fixup이 들어있는 버퍼(0=text,1=data) */
    size_t patch_off;  /* 그 버퍼 안에서 패치할 위치 */
    Label *target;
    size_t next_ip;    /* REL32용: 이 명령어 바로 다음 바이트의 (섹션 내) 오프셋 */
    struct Fixup *next;
} Fixup;
static Fixup *g_fixups = NULL;
static void add_fixup(FixupKind kind, int section, size_t patch_off, Label *target, size_t next_ip) {
    Fixup *f = (Fixup *)calloc(1, sizeof(Fixup));
    f->kind = kind; f->section = section; f->patch_off = patch_off;
    f->target = target; f->next_ip = next_ip;
    f->next = g_fixups; g_fixups = f;
}

/* ===================== 인코딩 헬퍼 ===================== */
static Buf *g_text, *g_data;
static int g_cur_section = 0; /* 0=text 1=data */
static Buf *cur_buf(void) { return g_cur_section == 0 ? g_text : g_data; }

static void emit_rex_modrm_reg_rm(Buf *b, int w, int reg, int rm_reg_direct) {
    uint8_t rex = 0x40 | (w ? 0x08 : 0) | ((reg >> 3) << 2) | (rm_reg_direct >> 3);
    buf_u8(b, rex);
}

/* mod=11(레지스터 직접) ModRM 인코딩: op(들) 이후에 호출 */
static void emit_modrm_direct(Buf *b, int reg_field, int rm_reg) {
    buf_u8(b, (uint8_t)(0xC0 | ((reg_field & 7) << 3) | (rm_reg & 7)));
}

/* 메모리 오퍼랜드 [base+disp] ModRM+disp 인코딩. base==rsp/r12는 SIB가
 * 필요해 미지원(die). base==rbp/r13이면서 disp==0인 경우는 ModRM
 * mod=00,rm=101이 "RIP상대" 특수 케이스와 충돌하므로 disp8=0으로 강제
 * (항상 안전하게 mod=01 사용). */
static void emit_modrm_mem(Buf *b, int reg_field, int base_reg, int32_t disp) {
    if ((base_reg & 7) == 4) die("rsp/r12를 베이스로 쓰는 메모리 오퍼랜드는 지원하지 않음(SIB 필요)");
    int need_disp8_zero = ((base_reg & 7) == 5 && disp == 0);
    if (disp == 0 && !need_disp8_zero) {
        buf_u8(b, (uint8_t)(0x00 | ((reg_field & 7) << 3) | (base_reg & 7)));
    } else if (disp >= -128 && disp <= 127) {
        buf_u8(b, (uint8_t)(0x40 | ((reg_field & 7) << 3) | (base_reg & 7)));
        buf_u8(b, (uint8_t)(int8_t)disp);
    } else {
        buf_u8(b, (uint8_t)(0x80 | ((reg_field & 7) << 3) | (base_reg & 7)));
        buf_u32(b, (uint32_t)disp);
    }
}

/* "[reg+disp]" 또는 "[reg-disp]" 또는 "[reg]" 문자열 파싱 */
static void parse_mem_operand(const char *tok, int *base_reg, int32_t *disp) {
    if (tok[0] != '[') die("메모리 오퍼랜드가 아님: %s", tok);
    char buf[128]; size_t n = strlen(tok);
    if (n < 3 || tok[n - 1] != ']') die("괄호가 안 맞음: %s", tok);
    size_t inner_len = n - 2;
    if (inner_len >= sizeof(buf)) die("메모리 오퍼랜드가 너무 김: %s", tok);
    memcpy(buf, tok + 1, inner_len); buf[inner_len] = '\0';
    char *plus = strchr(buf, '+');
    char *minus = strchr(buf, '-');
    char *sign = plus ? plus : minus;
    char regname[32];
    if (sign) {
        size_t rl = (size_t)(sign - buf);
        if (rl >= sizeof(regname)) die("레지스터 이름이 너무 김");
        memcpy(regname, buf, rl); regname[rl] = '\0';
        long d = strtol(sign + 1, NULL, 0);
        *disp = (int32_t)(minus ? -d : d);
    } else {
        strncpy(regname, buf, sizeof(regname) - 1); regname[sizeof(regname)-1]='\0';
        *disp = 0;
    }
    int r = reg_index(regname);
    if (r < 0) die("알 수 없는 레지스터: %s (메모리 오퍼랜드 %s 안)", regname, tok);
    *base_reg = r;
}

static int is_mem_operand(const char *tok) { return tok[0] == '['; }
static int is_number(const char *tok) {
    if (!*tok) return 0;
    const char *p = tok; if (*p == '-' || *p == '+') p++;
    if (!*p) return 0;
    while (*p) { if (!isxdigit((unsigned char)*p) && *p != 'x' && *p != 'X') return 0; p++; }
    return 1;
}

/* ===================== 명령어별 인코딩 ===================== */
/* group1 산술 op의 opcode digit (0x81 /digit imm32, 0x01+8*digit류의 reg,reg 짝) */
static int arith_digit(const char *mn) {
    if (!strcmp(mn,"add")) return 0;
    if (!strcmp(mn,"or"))  return 1;
    if (!strcmp(mn,"and")) return 4;
    if (!strcmp(mn,"sub")) return 5;
    if (!strcmp(mn,"xor")) return 6;
    if (!strcmp(mn,"cmp")) return 7;
    return -1;
}
/* reg,reg 형태일 때 쓰는 "MOV류" 오퍼코드(r/m64,r64 방향: 0x01+8*digit 규칙과
 * 실제 x86 오퍼코드 표는 add=0x01,or=0x09,and=0x21,sub=0x29,xor=0x31,cmp=0x39
 * — 규칙적이라 digit*8+1로 계산 가능(0x01,0x09,0x11..은 adc/sbb 등 이번엔
 * 스킵된 것들이라 실제로는 표에서 그대로 가져옴). */
static int arith_rr_opcode(int digit) {
    static const int table[8] = {0x01,0x09,-1,-1,0x21,0x29,0x31,0x39};
    return table[digit];
}

static int jcc_opcode(const char *mn) {
    if (!strcmp(mn,"je")||!strcmp(mn,"jz"))  return 0x84;
    if (!strcmp(mn,"jne")||!strcmp(mn,"jnz")) return 0x85;
    if (!strcmp(mn,"jl"))  return 0x8C;
    if (!strcmp(mn,"jle")) return 0x8E;
    if (!strcmp(mn,"jg"))  return 0x8F;
    if (!strcmp(mn,"jge")) return 0x8D;
    if (!strcmp(mn,"jb"))  return 0x82;
    if (!strcmp(mn,"jbe")) return 0x86;
    if (!strcmp(mn,"ja"))  return 0x87;
    if (!strcmp(mn,"jae")) return 0x83;
    return -1;
}

static void assemble_line(char *line) {
    char *toks[MAX_TOK];
    /* 라벨 정의(":")는 토큰화 전에 따로 처리 — "label:" 또는 "label: 명령어..." */
    char *colon = strchr(line, ':');
    if (colon) {
        *colon = '\0';
        char lbl[128]; strncpy(lbl, line, sizeof(lbl)-1); lbl[sizeof(lbl)-1]='\0';
        /* 앞뒤 공백 제거 */
        char *s = lbl; while (isspace((unsigned char)*s)) s++;
        char *e = s + strlen(s); while (e > s && isspace((unsigned char)*(e-1))) e--; *e = '\0';
        if (*s) {
            Label *l = find_or_make_label(s);
            if (l->defined) die("라벨 중복 정의: %s", s);
            l->section = g_cur_section; l->offset = cur_buf()->len; l->defined = 1;
        }
        line = colon + 1; /* 콜론 뒤에 명령어가 더 있을 수도 있음 */
    }
    int n = tokenize(line, toks);
    if (n == 0) return;
    char *mn = toks[0];
    for (char *p = mn; *p; p++) *p = (char)tolower((unsigned char)*p);

    if (!strcmp(mn, ".text")) { g_cur_section = 0; return; }
    if (!strcmp(mn, ".data")) { g_cur_section = 1; return; }
    if (!strcmp(mn, ".quad")) {
        for (int i = 1; i < n; i++) buf_u64(cur_buf(), (uint64_t)strtoll(toks[i], NULL, 0));
        return;
    }
    if (!strcmp(mn, ".byte")) {
        for (int i = 1; i < n; i++) buf_u8(cur_buf(), (uint8_t)strtol(toks[i], NULL, 0));
        return;
    }
    if (!strcmp(mn, ".asciz") || !strcmp(mn, ".string")) {
        if (n < 2 || toks[1][0] != '"') die(".asciz는 문자열 리터럴 필요");
        /* 원본 line에서 첫 '"'~마지막 '"' 사이를 직접 뽑는다(토큰화가
         * 공백을 잘라먹으므로 문자열 안 공백 보존을 위해). */
        char *q1 = strchr(line, '"');
        char *q2 = q1 ? strrchr(line, '"') : NULL;
        if (!q1 || !q2 || q2 <= q1) die(".asciz 문자열 파싱 실패");
        for (char *p = q1 + 1; p < q2; p++) {
            if (*p == '\\' && p + 1 < q2) {
                p++;
                if (*p == 'n') buf_u8(cur_buf(), '\n');
                else if (*p == 't') buf_u8(cur_buf(), '\t');
                else if (*p == '0') buf_u8(cur_buf(), '\0');
                else buf_u8(cur_buf(), (uint8_t)*p);
            } else {
                buf_u8(cur_buf(), (uint8_t)*p);
            }
        }
        buf_u8(cur_buf(), 0);
        return;
    }
    if (!strcmp(mn, "ret"))   { buf_u8(cur_buf(), 0xC3); return; }
    if (!strcmp(mn, "leave")) { buf_u8(cur_buf(), 0xC9); return; }
    if (!strcmp(mn, "nop"))   { buf_u8(cur_buf(), 0x90); return; }
    if (!strcmp(mn, "int") && n == 2 && (!strcmp(toks[1],"0x80")||!strcmp(toks[1],"0X80"))) {
        buf_u8(cur_buf(), 0xCD); buf_u8(cur_buf(), 0x80); return;
    }

    if (!strcmp(mn, "push") || !strcmp(mn, "pop")) {
        int r = reg_index(toks[1]);
        if (r < 0) die("알 수 없는 레지스터: %s", toks[1]);
        if (r >= 8) buf_u8(cur_buf(), 0x41); /* REX.B */
        buf_u8(cur_buf(), (uint8_t)((!strcmp(mn,"push") ? 0x50 : 0x58) + (r & 7)));
        return;
    }
    if (!strcmp(mn, "inc") || !strcmp(mn, "dec")) {
        int r = reg_index(toks[1]);
        if (r < 0) die("알 수 없는 레지스터: %s", toks[1]);
        emit_rex_modrm_reg_rm(cur_buf(), 1, 0, r);
        buf_u8(cur_buf(), 0xFF);
        emit_modrm_direct(cur_buf(), !strcmp(mn,"inc") ? 0 : 1, r);
        return;
    }
    if (!strcmp(mn, "call") || !strcmp(mn, "jmp") || jcc_opcode(mn) >= 0) {
        Label *target = find_or_make_label(toks[1]);
        Buf *b = cur_buf();
        int cc = jcc_opcode(mn);
        if (!strcmp(mn, "call")) buf_u8(b, 0xE8);
        else if (!strcmp(mn, "jmp")) buf_u8(b, 0xE9);
        else { buf_u8(b, 0x0F); buf_u8(b, (uint8_t)cc); }
        size_t patch_off = b->len;
        buf_u32(b, 0); /* placeholder rel32 */
        add_fixup(FX_REL32, g_cur_section, patch_off, target, b->len);
        return;
    }
    if (!strcmp(mn, "lea")) {
        int dst = reg_index(toks[1]);
        if (dst < 0) die("lea: 목적지가 레지스터가 아님: %s", toks[1]);
        if (!is_mem_operand(toks[2])) die("lea: 두 번째 오퍼랜드는 메모리여야 함");
        int base; int32_t disp;
        parse_mem_operand(toks[2], &base, &disp);
        emit_rex_modrm_reg_rm(cur_buf(), 1, dst, base);
        buf_u8(cur_buf(), 0x8D);
        emit_modrm_mem(cur_buf(), dst, base, disp);
        return;
    }
    if (!strcmp(mn, "mov") || !strcmp(mn, "movabs")) {
        int dst = reg_index(toks[1]);
        if (is_mem_operand(toks[1])) {
            /* mov [mem], reg  — 저장 */
            int base; int32_t disp; parse_mem_operand(toks[1], &base, &disp);
            int src = reg_index(toks[2]);
            if (src < 0) die("mov [mem],src: src가 레지스터가 아님(즉치값 저장은 미지원): %s", toks[2]);
            emit_rex_modrm_reg_rm(cur_buf(), 1, src, base);
            buf_u8(cur_buf(), 0x89);
            emit_modrm_mem(cur_buf(), src, base, disp);
            return;
        }
        if (dst < 0) die("알 수 없는 레지스터: %s", toks[1]);
        if (is_mem_operand(toks[2])) {
            /* mov reg, [mem] — 적재 */
            int base; int32_t disp; parse_mem_operand(toks[2], &base, &disp);
            emit_rex_modrm_reg_rm(cur_buf(), 1, dst, base);
            buf_u8(cur_buf(), 0x8B);
            emit_modrm_mem(cur_buf(), dst, base, disp);
            return;
        }
        int src = reg_index(toks[2]);
        if (src >= 0) {
            /* mov reg, reg */
            emit_rex_modrm_reg_rm(cur_buf(), 1, src, dst);
            buf_u8(cur_buf(), 0x89);
            emit_modrm_direct(cur_buf(), src, dst);
            return;
        }
        if (is_number(toks[2])) {
            long long v = strtoll(toks[2], NULL, 0);
            if (!strcmp(mn, "movabs") || v < -2147483648LL || v > 2147483647LL) {
                /* movabs reg, imm64 */
                if (dst >= 8) buf_u8(cur_buf(), 0x49); else buf_u8(cur_buf(), 0x48);
                buf_u8(cur_buf(), (uint8_t)(0xB8 + (dst & 7)));
                buf_u64(cur_buf(), (uint64_t)v);
            } else {
                /* mov reg, imm32 (부호확장) */
                emit_rex_modrm_reg_rm(cur_buf(), 1, 0, dst);
                buf_u8(cur_buf(), 0xC7);
                emit_modrm_direct(cur_buf(), 0, dst);
                buf_u32(cur_buf(), (uint32_t)(int32_t)v);
            }
            return;
        }
        /* mov reg, label  =>  movabs reg, &label (fixup으로 나중에 실주소 채움) */
        Label *target = find_or_make_label(toks[2]);
        Buf *b = cur_buf();
        if (dst >= 8) buf_u8(b, 0x49); else buf_u8(b, 0x48);
        buf_u8(b, (uint8_t)(0xB8 + (dst & 7)));
        size_t patch_off = b->len;
        buf_u64(b, 0); /* placeholder */
        add_fixup(FX_ABS64_CODE, g_cur_section, patch_off, target, 0);
        return;
    }
    {
        int digit = arith_digit(mn);
        if (digit >= 0) {
            int dst = reg_index(toks[1]);
            if (dst < 0) die("알 수 없는 레지스터: %s", toks[1]);
            int src = reg_index(toks[2]);
            if (src >= 0) {
                int opc = arith_rr_opcode(digit);
                emit_rex_modrm_reg_rm(cur_buf(), 1, src, dst);
                buf_u8(cur_buf(), (uint8_t)opc);
                emit_modrm_direct(cur_buf(), src, dst);
            } else if (is_number(toks[2])) {
                long v = strtol(toks[2], NULL, 0);
                emit_rex_modrm_reg_rm(cur_buf(), 1, 0, dst);
                buf_u8(cur_buf(), 0x81);
                emit_modrm_direct(cur_buf(), digit, dst);
                buf_u32(cur_buf(), (uint32_t)(int32_t)v);
            } else die("%s: 두 번째 오퍼랜드가 레지스터도 숫자도 아님: %s", mn, toks[2]);
            return;
        }
    }
    die("알 수 없는 명령어/지시어: %s", mn);
}

/* ===================== ELF64 산출물(jcc.c와 완전히 같은 레이아웃) ===================== */
#define LINK_BASE 0x100000000ULL
#define HEADER_SIZE 120

static void emit_elf_header(Buf *out, uint64_t entry, uint64_t filesize) {
    uint8_t ident[16] = { 0x7F,'E','L','F', 2,1,1,0, 0,0,0,0,0,0,0,0 };
    buf_bytes(out, ident, 16);
    uint16_t e_type = 2, e_machine = 62;
    buf_bytes(out, &e_type, 2);
    buf_bytes(out, &e_machine, 2);
    uint32_t e_version = 1; buf_bytes(out, &e_version, 4);
    buf_u64(out, entry);
    buf_u64(out, 64);
    buf_u64(out, 0);
    uint32_t e_flags = 0; buf_bytes(out, &e_flags, 4);
    uint16_t e_ehsize = 64, e_phentsize = 56, e_phnum = 1, e_shentsize = 0, e_shnum = 0, e_shstrndx = 0;
    buf_bytes(out, &e_ehsize, 2);
    buf_bytes(out, &e_phentsize, 2);
    buf_bytes(out, &e_phnum, 2);
    buf_bytes(out, &e_shentsize, 2);
    buf_bytes(out, &e_shnum, 2);
    buf_bytes(out, &e_shstrndx, 2);
    uint32_t p_type = 1, p_flags = 7;
    buf_bytes(out, &p_type, 4);
    buf_bytes(out, &p_flags, 4);
    buf_u64(out, 0);
    buf_u64(out, LINK_BASE);
    buf_u64(out, LINK_BASE);
    buf_u64(out, filesize);
    buf_u64(out, filesize);
    buf_u64(out, 0x1000);
}

int main(int argc, char **argv) {
#ifdef __JETOS_NATIVE__
    /* Milestone 44: elf_loader.c가 이제 argv/argc를 실어주므로(M44),
     * jash의 `run /jas.exe <입력.s> <출력.elf>`가 그대로 동작한다.
     * 인자가 부족하면 jcc_native와 같은 스타일로 고정 경로 폴백. */
    const char *inpath = (argc >= 2) ? argv[1] : "/jas_in.s";
    const char *outpath = (argc >= 3) ? argv[2] : "/jas_out.elf";
    size_t_j fsize_native;
    char *src = jetos_read_whole_file(inpath, &fsize_native);
    if (!src) die("입력 파일(%s)을 열 수 없음", inpath);
#else
    if (argc != 3) { fprintf(stderr, "사용법: jas <입력.s> <출력.elf>\n"); return 1; }
    const char *inpath = argv[1];
    const char *outpath = argv[2];
    FILE *fin = fopen(inpath, "rb");
    if (!fin) die("'%s'를 열 수 없음", inpath);
    fseek(fin, 0, SEEK_END); long fsize = ftell(fin); fseek(fin, 0, SEEK_SET);
    char *src = (char *)malloc((size_t)fsize + 1);
    if (fread(src, 1, (size_t)fsize, fin) != (size_t)fsize) die("소스 읽기 실패");
    src[fsize] = '\0'; fclose(fin);
#endif

    Buf textbuf, databuf; buf_init(&textbuf); buf_init(&databuf);
    g_text = &textbuf; g_data = &databuf; g_cur_section = 0;

    SrcLines sl = split_lines(src);
    for (int i = 0; i < sl.n; i++) assemble_line(sl.lines[i]);

    Label *start = find_or_make_label("_start");
    if (!start->defined) die("_start 라벨이 없음(진입점 필요)");

    uint64_t code_base = LINK_BASE + HEADER_SIZE;
    uint64_t data_base = code_base + textbuf.len;
    static const char *sect_name[2] = {"text","data"};
    (void)sect_name;

    for (Fixup *f = g_fixups; f; f = f->next) {
        if (!f->target->defined) die("정의되지 않은 라벨 참조: %s", f->target->name);
        Buf *b = f->section == 0 ? &textbuf : &databuf;
        uint64_t target_addr = (f->target->section == 0 ? code_base : data_base) + f->target->offset;
        if (f->kind == FX_REL32) {
            uint64_t self_base = (f->section == 0 ? code_base : data_base) + f->next_ip;
            int64_t rel = (int64_t)(target_addr - self_base);
            if (rel < INT32_MIN || rel > INT32_MAX) die("점프 거리가 rel32 범위를 벗어남: %s", f->target->name);
            buf_u32_at(b, f->patch_off, (uint32_t)(int32_t)rel);
        } else {
            buf_u64_at(b, f->patch_off, target_addr);
        }
    }

    uint64_t entry = code_base + start->offset;
    uint64_t filesize = HEADER_SIZE + textbuf.len + databuf.len;

    Buf out; buf_init(&out);
    emit_elf_header(&out, entry, filesize);
    buf_bytes(&out, textbuf.data, textbuf.len);
    buf_bytes(&out, databuf.data, databuf.len);

#ifdef __JETOS_NATIVE__
    int fout = jetos_open(outpath, 1);
    if (fout < 0) die("출력 파일(%s)을 쓸 수 없음", outpath);
    jetos_write_fd(fout, out.data, (long)out.len);
    jetos_close(fout);
    jetos_write_str("jas: ");
    jetos_write_str(inpath);
    jetos_write_str(" -> ");
    jetos_write_str(outpath);
    jetos_write_str(" 어셈블 완료\n");
    jetos_exit(0);
#else
    FILE *fout = fopen(outpath, "wb");
    if (!fout) die("'%s'를 쓸 수 없음", outpath);
    fwrite(out.data, 1, out.len, fout);
    fclose(fout);

    fprintf(stderr, "jas: %s -> %s (%zu바이트, entry=0x%llx, text=%zu데이터=%zu)\n",
            inpath, outpath, out.len, (unsigned long long)entry, textbuf.len, databuf.len);
    return 0;
#endif
}

#ifdef __JETOS_NATIVE__
/* Milestone 44: jcc.c와 동일한 패턴 — _start가 SysV ABI 그대로
 * rdi=argc, rsi=argv를 받아 main으로 그대로 전달. */
void _start(long argc, char **argv) {
    main((int)argc, argv);
    jetos_exit(0);
}
#endif
