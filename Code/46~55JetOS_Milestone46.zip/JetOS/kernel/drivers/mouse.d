kernel/drivers/mouse.o: kernel/drivers/mouse.c kernel/drivers/mouse.h \
 kernel/drivers/../hal/x86_asm_shim.h kernel/drivers/../int/pic.h \
 kernel/drivers/serial.h
kernel/drivers/mouse.h:
kernel/drivers/../hal/x86_asm_shim.h:
kernel/drivers/../int/pic.h:
kernel/drivers/serial.h:
