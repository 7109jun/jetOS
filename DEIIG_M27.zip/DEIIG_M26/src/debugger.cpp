#include "debugger.hpp"
#include <cstdlib>
namespace deiig::debugger {
static int tool(const std::string&x){std::string cmd="gdb -q "+x;return std::system(cmd.c_str());}
int run(const std::string&e){return tool("\""+e+"\"");}
int attach(int p){return tool("-ex 'attach "+std::to_string(p)+"'");}
int command(const std::string&c){return tool("-ex \""+c+"\"");}
}
