#ifndef JETOS_WM_H
#define JETOS_WM_H

#include <stdint.h>
#include "../drivers/console.h"

#define WM_MAX_WINDOWS 8
#define WM_TITLEBAR_H 18
#define WM_TASKBAR_H 28

typedef void (*wm_content_draw_fn)(console_t *dc, int x, int y, int w, int h, void *ctx);
typedef void (*wm_close_fn)(void *ctx); /* X버튼 클릭 시 소유 앱에게 통지 */

typedef struct {
    int x, y, w, h;
    char title[32];
    uint32_t color;
    int visible;
    int minimized;
    int closed;
    int used;
    wm_content_draw_fn content_cb;
    void *content_ctx;
    wm_close_fn close_cb;
    void *close_ctx;
} wm_window_t;

void wm_init(console_t *con);
console_t *wm_get_draw_console(void); /* 오프스크린 백버퍼용 콘솔 (더블 버퍼링) */
void wm_present(void); /* 백버퍼를 실제 프레임버퍼로 한 번에 블릿 */
int  wm_create_window(const char *title, int x, int y, int w, int h, uint32_t color);
void wm_move_window(int idx, int dx, int dy);
void wm_bring_to_front(int idx);
int  wm_window_at(int x, int y);            /* 클릭 지점에 있는 최상위 창 인덱스, 없으면 -1 */
int  wm_hit_titlebar(int idx, int x, int y); /* 그 창의 타이틀바를 클릭했는지 */
int  wm_hit_close_button(int idx, int x, int y); /* 그 창의 X버튼을 클릭했는지 */
void wm_get_window_bounds(int idx, int *x, int *y, int *w, int *h);
void wm_set_content_callback(int idx, wm_content_draw_fn cb, void *ctx);

/* X버튼으로 창이 닫힐 때 호출될 콜백을 등록한다. 소유 스레드가 이
 * 콜백에서 자신의 실행 루프를 정지시키는 플래그를 세우는 용도로 쓴다
 * (스레드 자체를 강제 종료하지는 않고, 협조적으로 종료하도록 유도). */
void wm_set_close_callback(int idx, wm_close_fn cb, void *ctx);

/* 창 닫기 / 최소화 */
void wm_close_window(int idx);      /* 창을 완전히 숨기고 슬롯을 비운다 */
void wm_minimize_window(int idx);   /* 화면에서 숨기되 작업표시줄엔 남긴다 */
void wm_restore_window(int idx);    /* 최소화 해제 + 포커스 */
int  wm_is_window_minimized(int idx);
int  wm_hit_taskbar_window_button(int x, int y); /* 작업표시줄 창 버튼 클릭 시 해당 idx, 없으면 -1 */

void wm_draw(void);

/* 커서/작업표시줄/시작메뉴 상태 (desktop.c가 갱신) */
void wm_set_cursor(int x, int y);
void wm_get_cursor(int *x, int *y);
void wm_set_start_menu_open(int open);
int  wm_is_start_button_hit(int x, int y);
int  wm_is_start_menu_item_hit(int x, int y, int *out_item_index);

#endif
