/*
 * JetOS - kernel/gui/theme.c
 * Milestone 18: 런타임에 바꿀 수 있는 액센트 색상 프리셋.
 * theme.h의 THEME_* 매크로들은 여전히 "구조/명암 관계"를 정의하는
 * 고정값으로 남겨두고(레이아웃이 깨지지 않도록), 사용자가 실제로
 * "다르게 느껴지길" 원하는 부분 — 활성 타이틀바 색, 시작버튼/작업표시줄
 * 강조색 — 만 프리셋으로 바꿀 수 있게 분리했다. Settings 앱이 이
 * 함수들로 프리셋을 순환시킨다.
 */
#include "theme.h"
#include <stddef.h>

typedef struct {
    const char *name;
    uint32_t accent;         /* 시작버튼 밑줄, 작업표시줄 활성 밑줄 등 */
    uint32_t title_active;   /* 활성 타이틀바 기본색 */
    uint32_t taskbar_active; /* 작업표시줄의 활성 창 버튼 배경 */
} theme_preset_t;

static const theme_preset_t PRESETS[] = {
    { "Ocean Blue",    0x003070C0, 0x00243858, 0x00304868 },
    { "Forest Green",  0x00309050, 0x00203828, 0x00305040 },
    { "Sunset Orange", 0x00D08030, 0x00402818, 0x00503020 },
    { "Royal Purple",  0x008040C0, 0x00301840, 0x00402850 },
};
#define THEME_PRESET_COUNT (int)(sizeof(PRESETS) / sizeof(PRESETS[0]))

static int g_preset = 0;

int theme_preset_count(void) { return THEME_PRESET_COUNT; }

const char *theme_preset_name(int idx) {
    if (idx < 0 || idx >= THEME_PRESET_COUNT) return "";
    return PRESETS[idx].name;
}

void theme_set_preset(int idx) {
    if (idx >= 0 && idx < THEME_PRESET_COUNT) g_preset = idx;
}

int theme_get_preset(void) { return g_preset; }

uint32_t theme_accent(void) { return PRESETS[g_preset].accent; }
uint32_t theme_title_active(void) { return PRESETS[g_preset].title_active; }
uint32_t theme_taskbar_active(void) { return PRESETS[g_preset].taskbar_active; }
