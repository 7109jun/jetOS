/*
 * JetOS - kernel/apps/settings.c
 * 시스템 정보(힙/물리메모리/타이머 틱) + 테마 선택(Milestone 18).
 * 진짜 클릭 가능한 색상 스와치 버튼으로 테마를 바꾼다 — File Manager의
 * 클릭 내비게이션(Milestone 13)과 같은 wm_set_click_callback 인프라를
 * 재사용한다.
 */

#include <stddef.h>
#include "settings.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../gui/theme.h"
#include "../drivers/console.h"
#include "../proc/scheduler.h"

static void write_uint(console_t *dc, uint64_t v) {
    char tmp[20]; int t = 0;
    if (v == 0) { char z[2] = {'0', 0}; console_print(dc, z); return; }
    while (v > 0) { tmp[t++] = (char)('0' + (v % 10)); v /= 10; }
    char buf[20]; int i = 0;
    while (t > 0) buf[i++] = tmp[--t];
    buf[i] = '\0';
    console_print(dc, buf);
}

#define SWATCH_W 52
#define SWATCH_H 28
#define SWATCH_GAP 6
#define SWATCH_TOP_OFFSET 96 /* content 영역 y 기준 스와치 줄까지의 거리 */

static void settings_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)h; (void)ctx;
    JetSystemInfo info;
    GetSystemInfoJ(&info);

    int ty = y + 8;
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    console_print(dc, "HEAP USED/TOTAL BYTES:");
    ty += 14;
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    write_uint(dc, info.heap_used_bytes);
    console_print(dc, " / ");
    write_uint(dc, info.heap_total_bytes);
    ty += 20;

    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    console_print(dc, "PMM FREE/TOTAL PAGES:");
    ty += 14;
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    write_uint(dc, info.pmm_free_pages);
    console_print(dc, " / ");
    write_uint(dc, info.pmm_total_pages);
    ty += 22;

    /* ---- 테마 선택 (Milestone 18) ---- */
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    console_print(dc, "THEME: ");
    console_print(dc, theme_preset_name(theme_get_preset()));
    ty += 16;

    int sy = y + SWATCH_TOP_OFFSET;
    int n = theme_preset_count();
    int sx = x + 8;
    int current = theme_get_preset();
    for (int i = 0; i < n; i++) {
        /* theme_accent()는 "현재" 프리셋만 알려주므로, 다른 프리셋의
         * 스와치 색은 인덱스별 고정값을 여기서 직접 흉내낸다(테마
         * 목록 자체를 조회하는 API는 없음 — 그래서 프리셋 이름과
         * 순서만으로 대략적인 색을 매핑). */
        uint32_t swatch_color;
        switch (i % 4) {
            case 0: swatch_color = 0x003070C0; break; /* Ocean Blue */
            case 1: swatch_color = 0x00309050; break; /* Forest Green */
            case 2: swatch_color = 0x00D08030; break; /* Sunset Orange */
            default: swatch_color = 0x008040C0; break; /* Royal Purple */
        }
        console_fill_rect(dc, (uint32_t)sx, (uint32_t)sy, SWATCH_W, SWATCH_H, swatch_color);
        if (i == current) {
            /* 선택된 스와치는 밝은 테두리로 표시 */
            for (int b = 0; b < 2; b++) {
                console_fill_rect(dc, (uint32_t)(sx - b), (uint32_t)(sy - b), SWATCH_W + b * 2, 2, 0x00FFFFFF);
                console_fill_rect(dc, (uint32_t)(sx - b), (uint32_t)(sy + SWATCH_H + b - 2), SWATCH_W + b * 2, 2, 0x00FFFFFF);
            }
        }
        sx += SWATCH_W + SWATCH_GAP;
    }
}

static void settings_click_cb(int local_x, int local_y, void *ctx) {
    (void)ctx;
    if (local_y < SWATCH_TOP_OFFSET || local_y >= SWATCH_TOP_OFFSET + SWATCH_H) return;
    int rel_x = local_x - 8;
    if (rel_x < 0) return;
    int idx = rel_x / (SWATCH_W + SWATCH_GAP);
    int within = rel_x % (SWATCH_W + SWATCH_GAP);
    if (within >= SWATCH_W) return; /* 스와치 사이 여백 클릭 */
    if (idx >= 0 && idx < theme_preset_count()) {
        theme_set_preset(idx);
    }
}

static volatile int g_settings_running = 0;

static void settings_on_close(void *ctx) {
    (void)ctx;
    g_settings_running = 0;
}

static void settings_thread_fn(void *arg) {
    (void)arg;
    g_settings_running = 1;
    JetWindowHandle win = CreateWindowJ("SETTINGS", 620, 240, 280, 180, 0x00403050);
    if (win >= 0) {
        wm_set_content_callback(win, settings_content_cb, NULL);
        wm_set_close_callback(win, settings_on_close, NULL);
        wm_set_click_callback(win, settings_click_cb, NULL);
    }
    while (g_settings_running) {
        scheduler_yield();
    }
}

void settings_launch(void) {
    static int launched = 0;
    if (launched && g_settings_running) return;
    launched = 1;
    CreateThreadJ("settings", settings_thread_fn, NULL);
}
