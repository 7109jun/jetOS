kernel/hal/syscall.o: kernel/hal/syscall.c kernel/hal/syscall.h \
 kernel/hal/../drivers/serial.h kernel/hal/../int/pit.h \
 kernel/hal/../proc/thread.h kernel/hal/../proc/scheduler.h \
 kernel/hal/../proc/thread.h kernel/hal/../mm/vmm.h \
 kernel/hal/../mm/pmm.h kernel/hal/../mm/../../include/efi/efi.h \
 kernel/hal/../mm/heap.h kernel/hal/../fs/jetfs.h
kernel/hal/syscall.h:
kernel/hal/../drivers/serial.h:
kernel/hal/../int/pit.h:
kernel/hal/../proc/thread.h:
kernel/hal/../proc/scheduler.h:
kernel/hal/../proc/thread.h:
kernel/hal/../mm/vmm.h:
kernel/hal/../mm/pmm.h:
kernel/hal/../mm/../../include/efi/efi.h:
kernel/hal/../mm/heap.h:
kernel/hal/../fs/jetfs.h:
