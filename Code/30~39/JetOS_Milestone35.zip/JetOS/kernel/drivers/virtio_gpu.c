/*
 * JetOS - kernel/drivers/virtio_gpu.c
 * virtio_gpu.h 참고 — 특히 상단의 "검증 상태" 절을 먼저 읽을 것.
 */
#include "virtio_gpu.h"
#include "pci.h"
#include "serial.h" /* Milestone 32: 디버그 로그(임시 아님 — 초기화 실패 원인 진단용으로 유지) */
#include "../hal/x86_asm_shim.h"
#include "../mm/pmm.h"
#include "../int/pit.h"

#define VIRTIO_VENDOR_ID   0x1AF4
#define VIRTIO_GPU_DEVICE_ID 0x1050 /* "modern" virtio 1.0+ GPU만(virtio_gpu.h 참고) */

#define PCI_CAP_ID_VNDR 0x09
#define VIRTIO_PCI_CAP_COMMON_CFG 1
#define VIRTIO_PCI_CAP_NOTIFY_CFG 2
#define VIRTIO_PCI_CAP_ISR_CFG    3
#define VIRTIO_PCI_CAP_DEVICE_CFG 4
#define VIRTIO_PCI_CAP_PCI_CFG    5

#define VIRTIO_STATUS_ACKNOWLEDGE 1
#define VIRTIO_STATUS_DRIVER      2
#define VIRTIO_STATUS_DRIVER_OK   4
#define VIRTIO_STATUS_FEATURES_OK 8
#define VIRTIO_STATUS_FAILED      128

#define VIRTIO_F_VERSION_1_BIT 32 /* device_feature_select=1일 때의 bit0 */

/* Milestone 32: 실제 QEMU 부팅으로 드러난 문제 — 이 커널의 VMM은
 * 0~4GiB만 항등매핑한다(kernel/mm/vmm.c, "커널 identity 영역"이 딱
 * 그만큼). 그런데 virtio-gpu-pci의 "modern" capability가 가리키는
 * BAR는 64비트 BAR라서 QEMU가 4GiB 훨씬 위(테스트에서 실제로
 * 0xC000000000, 약 768GiB 지점)에 배치했다 — 그 주소를 그냥
 * 포인터로 캐스팅해서 쓰면 매핑 안 된 페이지라 즉시 PAGE FAULT로
 * 죽는다(실제로 죽는 걸 이 마일스톤에서 QEMU로 직접 확인했다). 커널
 * VMM에 "임의 물리주소를 커널 가상주소공간에 매핑"하는 범용 기능이
 * 아직 없어서(이번 마일스톤 스코프 밖 — 새로 만들려면 그 자체로
 * 신중한 별도 작업), 지금은 "4GiB 밑에 있는 BAR만 쓰고, 위에 있으면
 * 안전하게 포기"로 막는다. */
#define VMM_IDENTITY_MAP_LIMIT 0x100000000ULL /* 4GiB */

/* virtio-pci "modern" 공용 설정 구조체(virtio 1.1 spec 4.1.4.3) —
 * 필드 순서/크기가 스펙 그대로라 패딩 걱정 없이 자연 정렬됨. */
typedef volatile struct {
    uint32_t device_feature_select;
    uint32_t device_feature;
    uint32_t driver_feature_select;
    uint32_t driver_feature;
    uint16_t msix_config;
    uint16_t num_queues;
    uint8_t  device_status;
    uint8_t  config_generation;
    uint16_t queue_select;
    uint16_t queue_size;
    uint16_t queue_msix_vector;
    uint16_t queue_enable;
    uint16_t queue_notify_off;
    uint64_t queue_desc;
    uint64_t queue_avail;
    uint64_t queue_used;
} virtio_pci_common_cfg_t;

/* split virtqueue(spec 2.7) — 디스크립터/avail/used를 각각 별도
 * 페이지에 둔다(모던 virtio는 legacy와 달리 연속 배치를 요구하지
 * 않음 — 페이지 단위 할당이라 정렬 요건도 자동으로 만족됨). */
#define VQ_SIZE 8 /* 2의 거듭제곱, 컨트롤큐 하나로 커맨드를 순차 처리하니 크게 필요 없음 */

typedef struct { uint64_t addr; uint32_t len; uint16_t flags; uint16_t next; } virtq_desc_t;
#define VIRTQ_DESC_F_NEXT  1
#define VIRTQ_DESC_F_WRITE 2

typedef volatile struct { uint16_t flags; uint16_t idx; uint16_t ring[VQ_SIZE]; } virtq_avail_t;
typedef struct { uint32_t id; uint32_t len; } virtq_used_elem_t;
typedef volatile struct { uint16_t flags; uint16_t idx; virtq_used_elem_t ring[VQ_SIZE]; } virtq_used_t;

/* ---- virtio-gpu 커맨드(2D 모드에 필요한 것만, spec 5.7) ---- */
#define VIRTIO_GPU_CMD_GET_DISPLAY_INFO        0x0100
#define VIRTIO_GPU_CMD_RESOURCE_CREATE_2D      0x0101
#define VIRTIO_GPU_CMD_SET_SCANOUT             0x0103
#define VIRTIO_GPU_CMD_RESOURCE_FLUSH          0x0104
#define VIRTIO_GPU_CMD_TRANSFER_TO_HOST_2D     0x0105
#define VIRTIO_GPU_CMD_RESOURCE_ATTACH_BACKING 0x0106
#define VIRTIO_GPU_RESP_OK_NODATA              0x1100
#define VIRTIO_GPU_RESP_OK_DISPLAY_INFO        0x1101
#define VIRTIO_GPU_FORMAT_B8G8R8X8_UNORM       2 /* GOP의 B,G,R,X 바이트 순서와 일치(리틀엔디안 dword로 읽으면 0x00RRGGBB) */

typedef struct { uint32_t type, flags; uint64_t fence_id; uint32_t ctx_id, padding; } virtio_gpu_ctrl_hdr_t; /* 24바이트 */
typedef struct { uint32_t x, y, width, height; } virtio_gpu_rect_t; /* 16바이트 */

typedef struct { virtio_gpu_ctrl_hdr_t hdr; uint32_t resource_id, format, width, height; } virtio_gpu_resource_create_2d_t;
typedef struct { uint64_t addr; uint32_t length, padding; } virtio_gpu_mem_entry_t;
typedef struct { virtio_gpu_ctrl_hdr_t hdr; uint32_t resource_id, nr_entries; virtio_gpu_mem_entry_t entries[1]; } virtio_gpu_attach_backing_t;
typedef struct { virtio_gpu_ctrl_hdr_t hdr; virtio_gpu_rect_t r; uint32_t scanout_id, resource_id; } virtio_gpu_set_scanout_t;
typedef struct { virtio_gpu_ctrl_hdr_t hdr; virtio_gpu_rect_t r; uint64_t offset; uint32_t resource_id, padding; } virtio_gpu_transfer_to_host_2d_t;
typedef struct { virtio_gpu_ctrl_hdr_t hdr; virtio_gpu_rect_t r; uint32_t resource_id, padding; } virtio_gpu_resource_flush_t;

/* 가장 큰 요청 구조체 크기에 맞춘 고정 커맨드/응답 버퍼(요청은 매번
 * 이 버퍼를 덮어써서 재사용 — 동시에 커맨드 하나만 처리하는 폴링
 * 방식이라 이걸로 충분, AHCI 드라이버가 커맨드 슬롯 0번만 쓰는 것과
 * 같은 단순화). */
#define GPU_CMD_BUF_SIZE 256
#define GPU_RESP_BUF_SIZE 256

static int g_available = 0;
static virtio_pci_common_cfg_t *g_common;
static volatile uint8_t *g_notify_base;
static uint32_t g_notify_off_multiplier;
static uint16_t g_notify_off_controlq;
static virtq_desc_t *g_desc;
static virtq_avail_t *g_avail;
static virtq_used_t *g_used;
static uint16_t g_used_seen; /* 마지막으로 확인한 used.idx */
static uint8_t *g_cmd_buf, *g_resp_buf;
static uint32_t g_resource_id = 1;
static uint32_t g_fb_width, g_fb_height;

/* ---- 타임아웃 유틸(g_timer_ticks 기반 — tls.c의 timeout_ticks 관례와 동일) ---- */
#define GPU_TIMEOUT_TICKS 200 /* pit 주파수 기준 대략 수백 ms 상당 — 실제 QEMU에서 재보정 필요할 수 있음(알려진 한계) */

/* PCI 설정공간 임의 오프셋 1바이트/2바이트를 읽는 헬퍼(pci.c는 32비트
 * 단위만 제공하므로 마스킹/시프트로 뽑아낸다). */
static uint8_t pci_read8(pci_device_t *d, uint8_t off) {
    uint32_t v = pci_config_read32(d->bus, d->slot, d->func, (uint8_t)(off & 0xFC));
    return (uint8_t)(v >> ((off & 3) * 8));
}
static uint32_t pci_read32_raw(pci_device_t *d, uint8_t off) {
    return pci_config_read32(d->bus, d->slot, d->func, off);
}

/* PCI capability 리스트를 훑어 cfg_type과 일치하는 virtio-pci cap을
 * 찾는다(spec 4.1.4). 찾으면 1(bar/offset/length/extra out에 채움),
 * 못 찾으면 0. extra_out은 NOTIFY_CFG일 때만 notify_off_multiplier로
 * 채워짐(그 외엔 안 건드림). */
static int find_virtio_cap(pci_device_t *d, uint8_t cfg_type, uint8_t *bar_out, uint32_t *off_out, uint32_t *len_out, uint32_t *extra_out) {
    uint32_t status = pci_read32_raw(d, 0x04);
    if (!(status & (1u << 20))) return 0; /* capabilities list 지원 안 함 */
    uint8_t ptr = pci_read8(d, 0x34);
    int guard = 0;
    while (ptr != 0 && guard++ < 64) {
        uint8_t cap_id = pci_read8(d, ptr);
        uint8_t cap_next = pci_read8(d, (uint8_t)(ptr + 1));
        if (cap_id == PCI_CAP_ID_VNDR) {
            uint8_t cfg_type_here = pci_read8(d, (uint8_t)(ptr + 3));
            if (cfg_type_here == cfg_type) {
                *bar_out = pci_read8(d, (uint8_t)(ptr + 4));
                *off_out = pci_read32_raw(d, (uint8_t)(ptr + 8));
                *len_out = pci_read32_raw(d, (uint8_t)(ptr + 12));
                if (cfg_type == VIRTIO_PCI_CAP_NOTIFY_CFG && extra_out) {
                    *extra_out = pci_read32_raw(d, (uint8_t)(ptr + 16));
                }
                return 1;
            }
        }
        ptr = cap_next;
    }
    return 0;
}

static uint64_t bar_phys_addr(pci_device_t *d, int bar_idx) {
    uint32_t lo = d->bar[bar_idx];
    if (lo & 1) return 0; /* I/O space BAR — virtio-gpu 설정 구조체는 항상 메모리 BAR에 있음 */
    int is64 = ((lo >> 1) & 3) == 2;
    uint64_t addr = (uint64_t)(lo & 0xFFFFFFF0u);
    if (is64 && bar_idx < 5) addr |= ((uint64_t)d->bar[bar_idx + 1]) << 32;
    return addr;
}

int virtio_gpu_available(void) { return g_available; }

/* 커맨드 하나(cmd_len바이트, resp_max바이트까지 받기)를 controlq로
 * 보내고 완료까지 폴링 대기한다. 성공 1, 타임아웃/큐 이상 0. */
static int submit_command(uint32_t cmd_len, uint32_t resp_max) {
    g_desc[0].addr = (uint64_t)(uintptr_t)g_cmd_buf;
    g_desc[0].len = cmd_len;
    g_desc[0].flags = VIRTQ_DESC_F_NEXT;
    g_desc[0].next = 1;
    g_desc[1].addr = (uint64_t)(uintptr_t)g_resp_buf;
    g_desc[1].len = resp_max;
    g_desc[1].flags = VIRTQ_DESC_F_WRITE;
    g_desc[1].next = 0;

    uint16_t avail_slot = (uint16_t)(g_avail->idx % VQ_SIZE);
    g_avail->ring[avail_slot] = 0; /* 디스크립터 체인의 head index(항상 0번 슬롯 재사용) */
    g_avail->idx = (uint16_t)(g_avail->idx + 1);

    /* notify: 큐 인덱스(0=controlq)를 notify 레지스터에 쓴다(spec 4.1.4.4) */
    volatile uint16_t *notify_reg = (volatile uint16_t *)(g_notify_base + (uint64_t)g_notify_off_controlq * g_notify_off_multiplier);
    *notify_reg = 0;

    uint64_t deadline = g_timer_ticks + GPU_TIMEOUT_TICKS;
    while (g_used->idx == g_used_seen) {
        if (g_timer_ticks > deadline) return 0; /* 타임아웃 — 응답 없음 */
    }
    g_used_seen = g_used->idx;
    return 1;
}

int virtio_gpu_init(uint64_t fb_phys_addr, uint32_t width, uint32_t height, uint32_t pixels_per_scanline) {
    g_available = 0;
    if (pixels_per_scanline != width) { serial_write("[virtio-gpu] pixels_per_scanline != width, 포기\n"); return 0; }

    pci_device_t dev;
    if (!pci_find_device(VIRTIO_VENDOR_ID, VIRTIO_GPU_DEVICE_ID, &dev)) {
        serial_write("[virtio-gpu] PCI 장치를 못 찾음(vendor=0x1AF4 device=0x1050)\n");
        return 0;
    }
    serial_write("[virtio-gpu] 장치 발견: bus="); serial_write_hex64(dev.bus);
    serial_write(" slot="); serial_write_hex64(dev.slot);
    serial_write(" func="); serial_write_hex64(dev.func); serial_write("\n");
    for (int i = 0; i < 6; i++) {
        serial_write("[virtio-gpu]   bar["); serial_write_hex64((uint64_t)i); serial_write("]=");
        serial_write_hex64(dev.bar[i]); serial_write("\n");
    }

    /* 메모리 공간 + 버스 마스터 활성화(spec: 드라이버가 켜줘야 장치가
     * 메모리 BAR에 응답하고 DMA 유사 접근이 허용됨) */
    uint32_t cmd = pci_read32_raw(&dev, 0x04);
    pci_config_write32(dev.bus, dev.slot, dev.func, 0x04, cmd | 0x0006u); /* bit1=메모리공간, bit2=버스마스터 */

    uint8_t bar; uint32_t off, len, extra;
    if (!find_virtio_cap(&dev, VIRTIO_PCI_CAP_COMMON_CFG, &bar, &off, &len, &extra)) {
        serial_write("[virtio-gpu] COMMON_CFG capability를 못 찾음\n");
        return 0;
    }
    serial_write("[virtio-gpu] COMMON_CFG: bar="); serial_write_hex64(bar);
    serial_write(" off="); serial_write_hex64(off); serial_write(" len="); serial_write_hex64(len); serial_write("\n");
    if (bar > 5) return 0;
    uint64_t common_phys = bar_phys_addr(&dev, bar);
    serial_write("[virtio-gpu] common_phys="); serial_write_hex64(common_phys); serial_write("\n");
    if (!common_phys) return 0;
    if (common_phys + off + sizeof(virtio_pci_common_cfg_t) > VMM_IDENTITY_MAP_LIMIT) {
        serial_write("[virtio-gpu] COMMON_CFG BAR가 4GiB 위에 있어서(이 커널의 항등매핑 범위 밖) 포기 — 위 주석 참고\n");
        return 0;
    }
    g_common = (virtio_pci_common_cfg_t *)(uintptr_t)(common_phys + off);
    serial_write("[virtio-gpu] g_common pointer="); serial_write_hex64((uint64_t)(uintptr_t)g_common); serial_write("\n");

    if (!find_virtio_cap(&dev, VIRTIO_PCI_CAP_NOTIFY_CFG, &bar, &off, &len, &extra)) return 0;
    if (bar > 5) return 0;
    uint64_t notify_phys = bar_phys_addr(&dev, bar);
    if (!notify_phys) return 0;
    if (notify_phys + off >= VMM_IDENTITY_MAP_LIMIT) {
        serial_write("[virtio-gpu] NOTIFY_CFG BAR가 4GiB 위에 있어서 포기\n");
        return 0;
    }
    g_notify_base = (volatile uint8_t *)(uintptr_t)(notify_phys + off);
    g_notify_off_multiplier = extra;

    /* ---- 초기화 시퀀스(virtio spec 3.1.1) ---- */
    serial_write("[virtio-gpu] 리셋 쓰기 시도 직전...\n");
    g_common->device_status = 0; /* 리셋 */
    serial_write("[virtio-gpu] 리셋 쓰기 성공\n");
    { uint64_t deadline = g_timer_ticks + GPU_TIMEOUT_TICKS; while (g_common->device_status != 0) { if (g_timer_ticks > deadline) return 0; } }
    g_common->device_status = VIRTIO_STATUS_ACKNOWLEDGE;
    g_common->device_status |= VIRTIO_STATUS_DRIVER;

    g_common->device_feature_select = 1;
    uint32_t feat_hi = g_common->device_feature;
    if (!(feat_hi & 1u)) return 0; /* VIRTIO_F_VERSION_1(비트32, select=1의 비트0)을 장치가 지원 안 하면 modern 드라이버로 못 씀 */
    g_common->driver_feature_select = 0;
    g_common->driver_feature = 0; /* VIRGL(3D) 등 하위 32비트 기능은 아무 것도 요청 안 함 — 2D만 */
    g_common->driver_feature_select = 1;
    g_common->driver_feature = 1; /* VERSION_1만 */

    g_common->device_status |= VIRTIO_STATUS_FEATURES_OK;
    if (!(g_common->device_status & VIRTIO_STATUS_FEATURES_OK)) return 0; /* 장치가 기능 협상을 거부함 */

    /* controlq(큐 0) 설정 */
    g_common->queue_select = 0;
    uint16_t dev_qsize = g_common->queue_size;
    if (dev_qsize == 0) return 0; /* 큐가 없다는 뜻 — 장치 이상 */
    uint16_t use_qsize = (dev_qsize < VQ_SIZE) ? dev_qsize : VQ_SIZE;
    if (use_qsize < 2) return 0; /* 최소 2개(요청+응답) 슬롯 필요 */

    uint64_t desc_page = pmm_alloc_page();
    uint64_t avail_page = pmm_alloc_page();
    uint64_t used_page = pmm_alloc_page();
    uint64_t cmd_page = pmm_alloc_page();
    uint64_t resp_page = pmm_alloc_page();
    if (!desc_page || !avail_page || !used_page || !cmd_page || !resp_page) return 0;

    g_desc = (virtq_desc_t *)(uintptr_t)desc_page;
    g_avail = (virtq_avail_t *)(uintptr_t)avail_page;
    g_used = (virtq_used_t *)(uintptr_t)used_page;
    g_cmd_buf = (uint8_t *)(uintptr_t)cmd_page;
    g_resp_buf = (uint8_t *)(uintptr_t)resp_page;

    for (int i = 0; i < VQ_SIZE; i++) { g_desc[i].addr = 0; g_desc[i].len = 0; g_desc[i].flags = 0; g_desc[i].next = 0; }
    g_avail->flags = 0; g_avail->idx = 0;
    g_used->flags = 0; g_used->idx = 0;
    g_used_seen = 0;

    g_common->queue_size = use_qsize;
    g_common->queue_desc = desc_page;
    g_common->queue_avail = avail_page;
    g_common->queue_used = used_page;
    g_notify_off_controlq = g_common->queue_notify_off;
    g_common->queue_enable = 1;

    g_common->device_status |= VIRTIO_STATUS_DRIVER_OK;

    /* ---- GPU 2D 리소스 생성 + 기존 GOP 프레임버퍼를 백킹으로 붙이기 ---- */
    g_fb_width = width; g_fb_height = height;

    virtio_gpu_resource_create_2d_t *create = (virtio_gpu_resource_create_2d_t *)g_cmd_buf;
    create->hdr.type = VIRTIO_GPU_CMD_RESOURCE_CREATE_2D; create->hdr.flags = 0; create->hdr.fence_id = 0; create->hdr.ctx_id = 0; create->hdr.padding = 0;
    create->resource_id = g_resource_id;
    create->format = VIRTIO_GPU_FORMAT_B8G8R8X8_UNORM;
    create->width = width; create->height = height;
    if (!submit_command(sizeof(*create), GPU_RESP_BUF_SIZE)) { g_common->device_status |= VIRTIO_STATUS_FAILED; return 0; }
    if (((virtio_gpu_ctrl_hdr_t *)g_resp_buf)->type != VIRTIO_GPU_RESP_OK_NODATA) { g_common->device_status |= VIRTIO_STATUS_FAILED; return 0; }

    virtio_gpu_attach_backing_t *attach = (virtio_gpu_attach_backing_t *)g_cmd_buf;
    attach->hdr.type = VIRTIO_GPU_CMD_RESOURCE_ATTACH_BACKING; attach->hdr.flags = 0; attach->hdr.fence_id = 0; attach->hdr.ctx_id = 0; attach->hdr.padding = 0;
    attach->resource_id = g_resource_id;
    attach->nr_entries = 1;
    attach->entries[0].addr = fb_phys_addr;
    attach->entries[0].length = width * height * 4;
    attach->entries[0].padding = 0;
    if (!submit_command((uint32_t)sizeof(*attach), GPU_RESP_BUF_SIZE)) { g_common->device_status |= VIRTIO_STATUS_FAILED; return 0; }
    if (((virtio_gpu_ctrl_hdr_t *)g_resp_buf)->type != VIRTIO_GPU_RESP_OK_NODATA) { g_common->device_status |= VIRTIO_STATUS_FAILED; return 0; }

    virtio_gpu_set_scanout_t *scan = (virtio_gpu_set_scanout_t *)g_cmd_buf;
    scan->hdr.type = VIRTIO_GPU_CMD_SET_SCANOUT; scan->hdr.flags = 0; scan->hdr.fence_id = 0; scan->hdr.ctx_id = 0; scan->hdr.padding = 0;
    scan->r.x = 0; scan->r.y = 0; scan->r.width = width; scan->r.height = height;
    scan->scanout_id = 0;
    scan->resource_id = g_resource_id;
    if (!submit_command((uint32_t)sizeof(*scan), GPU_RESP_BUF_SIZE)) { g_common->device_status |= VIRTIO_STATUS_FAILED; return 0; }
    if (((virtio_gpu_ctrl_hdr_t *)g_resp_buf)->type != VIRTIO_GPU_RESP_OK_NODATA) { g_common->device_status |= VIRTIO_STATUS_FAILED; return 0; }

    g_available = 1;
    return 1;
}

void virtio_gpu_present(int x, int y, int w, int h) {
    if (!g_available) return;
    if (w <= 0 || h <= 0) return;
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x >= (int)g_fb_width || y >= (int)g_fb_height) return;
    if (x + w > (int)g_fb_width) w = (int)g_fb_width - x;
    if (y + h > (int)g_fb_height) h = (int)g_fb_height - y;
    if (w <= 0 || h <= 0) return;

    virtio_gpu_transfer_to_host_2d_t *xfer = (virtio_gpu_transfer_to_host_2d_t *)g_cmd_buf;
    xfer->hdr.type = VIRTIO_GPU_CMD_TRANSFER_TO_HOST_2D; xfer->hdr.flags = 0; xfer->hdr.fence_id = 0; xfer->hdr.ctx_id = 0; xfer->hdr.padding = 0;
    xfer->r.x = (uint32_t)x; xfer->r.y = (uint32_t)y; xfer->r.width = (uint32_t)w; xfer->r.height = (uint32_t)h;
    xfer->offset = ((uint64_t)(uint32_t)y * g_fb_width + (uint32_t)x) * 4;
    xfer->resource_id = g_resource_id; xfer->padding = 0;
    if (!submit_command((uint32_t)sizeof(*xfer), GPU_RESP_BUF_SIZE)) return; /* 실패해도 다음 프레임에 다시 시도되니 조용히 무시 */

    virtio_gpu_resource_flush_t *flush = (virtio_gpu_resource_flush_t *)g_cmd_buf;
    flush->hdr.type = VIRTIO_GPU_CMD_RESOURCE_FLUSH; flush->hdr.flags = 0; flush->hdr.fence_id = 0; flush->hdr.ctx_id = 0; flush->hdr.padding = 0;
    flush->r.x = (uint32_t)x; flush->r.y = (uint32_t)y; flush->r.width = (uint32_t)w; flush->r.height = (uint32_t)h;
    flush->resource_id = g_resource_id; flush->padding = 0;
    submit_command((uint32_t)sizeof(*flush), GPU_RESP_BUF_SIZE);
}
