kernel/drivers/hangul_font.o: kernel/drivers/hangul_font.c \
 kernel/drivers/hangul_font.h kernel/drivers/console.h
kernel/drivers/hangul_font.h:
kernel/drivers/console.h:
