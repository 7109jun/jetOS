/*
 * JetOS - kernel/hal/x86_asm_shim.h
 *
 * ============================== 중요 안내 ==============================
 * JetOS의 설계 원칙은 "Assembly 사용 금지"이다. 커널의 모든 로직(부팅
 * 시퀀스, 메모리 관리, 인터럽트 처리 로직, 콘솔, 드라이버 등)은 100% C로
 * 작성되어 있으며 실제로 그렇다 (이 파일 외 어떤 .c 파일에도 인라인
 * 어셈블리가 없다).
 *
 * 다만 x86_64 아키텍처에는 C 언어 자체로는 절대 표현할 수 없는 소수의
 * "단일 CPU 명령어"가 존재한다 (포트 입출력 IN/OUT, IDT 레지스터 적재
 * LIDT, 인터럽트 비활성화 CLI, CPU 정지 HLT). 이것은 GCC를 포함한 어떤
 * C 컴파일러로도 우회할 수 없는 x86 하드웨어 자체의 제약이며, Linux
 * 커널을 포함한 세상의 모든 "C로 작성된" x86 커널이 동일한 이유로 이런
 * 한 줄짜리 명령어들만은 예외적으로 인라인 어셈블리를 사용한다.
 *
 * 이 파일은 그런 원자적 명령어들만을 이 한 곳에 격리하기 위해 존재
 * 한다. 이 파일을 제외한 JetOS의 어떤 코드도 어셈블리를 포함하지 않으며,
 * 커널의 실질적인 로직(정책, 자료구조, 알고리즘)은 전부 순수 C로
 * 작성되어 있다. 즉 이 파일은 "어셈블리로 프로그래밍"하는 것이 아니라
 * C가 표현 못하는 CPU 명령어에 대한 얇은 포팅 계층(HAL)이다.
 * =========================================================================
 */

#ifndef JETOS_X86_ASM_SHIM_H
#define JETOS_X86_ASM_SHIM_H

#include <stdint.h>

/* 포트 I/O - 16550 UART 등 레거시 장치는 MMIO가 아닌 포트 I/O를 사용한다 */
static inline void hal_outb(uint16_t port, uint8_t val) {
    __asm__ volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}
static inline uint8_t hal_inb(uint16_t port) {
    uint8_t ret;
    __asm__ volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}
/* PCI 설정공간 접근(0xCF8/0xCFC)은 32비트 포트 I/O를 사용한다 */
static inline void hal_outl(uint16_t port, uint32_t val) {
    __asm__ volatile ("outl %0, %1" : : "a"(val), "Nd"(port));
}
static inline uint32_t hal_inl(uint16_t port) {
    uint32_t ret;
    __asm__ volatile ("inl %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

/* IDT 레지스터 적재 */
struct hal_idt_ptr {
    uint16_t limit;
    uint64_t base;
} __attribute__((packed));

static inline void hal_lidt(struct hal_idt_ptr *p) {
    /* "memory" 클로버 필수: 이 명령이 p가 가리키는 메모리를 "읽는다"는
     * 사실을 컴파일러에게 알리지 않으면, 최적화 단계에서 p의 필드에
     * 대한 이전 대입문들이 "아무도 안 읽는 죽은 코드"로 오인되어
     * 제거될 수 있다 (실제로 이 버그로 인해 IDT 리밋이 0으로 로드되어
     * 트리플 폴트가 발생했었다). */
    __asm__ volatile ("lidt (%0)" : : "r"(p) : "memory");
}
static inline void hal_sidt(struct hal_idt_ptr *p) {
    __asm__ volatile ("sidt (%0)" : : "r"(p) : "memory");
}

/* 인터럽트 제어 (memory 클로버: 인터럽트 활성/비활성화 전후로 메모리
 * 접근 순서가 재배치되지 않도록 컴파일러 최적화 장벽 역할도 겸한다) */
static inline void hal_cli(void) { __asm__ volatile ("cli" ::: "memory"); }
static inline void hal_sti(void) { __asm__ volatile ("sti" ::: "memory"); }

/* CPU 정지 (전원 관리용, 무한루프 대체) */
static inline void hal_hlt(void) { __asm__ volatile ("hlt" ::: "memory"); }

/* Page Fault 발생 시 어떤 주소에서 발생했는지는 CR2 레지스터에 담긴다 */
static inline uint64_t hal_read_cr2(void) {
    uint64_t val;
    __asm__ volatile ("mov %%cr2, %0" : "=r"(val));
    return val;
}

/* IDT 게이트에 넣을 코드 세그먼트 셀렉터는 현재 CS 레지스터 값을 그대로
 * 재사용한다 (UEFI가 이미 구성해 둔 64비트 코드 세그먼트) */
static inline uint16_t hal_read_cs(void) {
    uint16_t val;
    __asm__ volatile ("mov %%cs, %0" : "=r"(val));
    return val;
}

/* ---- GDT / TSS 적재 (Milestone 14: Ring3) ----
 * LGDT 자체는 LIDT와 완전히 같은 이유로 여기 있다. 문제는 그 다음:
 * x86_64에서 CS는 "mov"로 못 바꾼다 — CPU가 CS를 코드 세그먼트로
 * 취급하는 특별한 레지스터라, 반드시 제어 전달 명령(far jmp/call,
 * iret, retf 등)을 통해서만 바뀐다. 새 GDT를 적재한 뒤 새 커널 코드
 * 세그먼트로 CS를 전환하는 표준 기법은 "retfq"(far return) 하나로
 * 처리하는 것이다: 새 CS를 스택에 push하고 그 다음 목표 RIP를 push한
 * 뒤 retfq를 실행하면, CPU가 그 두 값을 pop하면서 CS:RIP를 동시에
 * 새로 설정해준다. */
struct hal_gdt_ptr {
    uint16_t limit;
    uint64_t base;
} __attribute__((packed));

static inline void hal_lgdt(struct hal_gdt_ptr *p) {
    __asm__ volatile ("lgdt (%0)" : : "r"(p) : "memory");
}

static inline void hal_ltr(uint16_t tss_selector) {
    __asm__ volatile ("ltr %0" : : "r"(tss_selector) : "memory");
}

/* GDT를 다시 적재한 뒤 이 함수를 부르면, kernel_cs/kernel_ds로 모든
 * 세그먼트 레지스터를 전환하고 리턴한다(호출자 입장에서는 평범한
 * 함수 호출처럼 보이지만, 내부적으로 retfq로 CS를 전환한 뒤 다시
 * call로 돌아온 지점처럼 동작하도록 스택을 구성한다). */
static inline void hal_reload_kernel_segments(uint16_t kernel_cs, uint16_t kernel_ds) {
    __asm__ volatile (
        "mov %1, %%ds\n\t"
        "mov %1, %%es\n\t"
        "mov %1, %%fs\n\t"
        "mov %1, %%gs\n\t"
        "mov %1, %%ss\n\t"
        "lea 1f(%%rip), %%rax\n\t"
        "pushq %0\n\t"
        "pushq %%rax\n\t"
        "retfq\n\t"
        "1:\n\t"
        :
        : "r"((uint64_t)kernel_cs), "r"((uint64_t)kernel_ds)
        : "rax", "memory"
    );
}

/* Ring3로 최초 진입: iretq가 요구하는 5워드짜리 스택 프레임
 * (RIP,CS,RFLAGS,RSP,SS)을 직접 구성해서 실행한다. 이 함수는 절대
 * 리턴하지 않는다(유저 코드가 시스템콜/인터럽트로 커널에 다시 들어올
 * 때는 이 호출 지점이 아니라 IDT 핸들러를 통해서 들어온다). */
__attribute__((noreturn))
static inline void hal_enter_user_mode(uint64_t entry, uint64_t user_stack,
                                        uint16_t user_cs, uint16_t user_ss) {
    __asm__ volatile (
        "movw %w2, %%ax\n\t"
        "mov %%ax, %%ds\n\t"
        "mov %%ax, %%es\n\t"
        "mov %%ax, %%fs\n\t"
        "mov %%ax, %%gs\n\t"
        "pushq %2\n\t"      /* SS */
        "pushq %1\n\t"      /* RSP */
        "pushfq\n\t"        /* RFLAGS (그대로 재사용) */
        "orq $0x200, (%%rsp)\n\t" /* IF(인터럽트 허용) 비트 세움 */
        "pushq %3\n\t"      /* CS */
        "pushq %0\n\t"      /* RIP */
        "iretq\n\t"
        :
        : "r"(entry), "r"(user_stack), "r"((uint64_t)user_ss), "r"((uint64_t)user_cs)
        : "rax", "memory"
    );
    __builtin_unreachable();
}

/* 유저 모드(Ring3)에서 커널에 서비스를 요청하는 유일한 수단: int $0x80.
 * num=시스템콜 번호, a0~a2=인자 최대 3개, 반환값=RAX. */
static inline uint64_t hal_syscall(uint64_t num, uint64_t a0, uint64_t a1, uint64_t a2) {
    register uint64_t r_a0 __asm__("rdi") = a0;
    register uint64_t r_a1 __asm__("rsi") = a1;
    register uint64_t r_a2 __asm__("rdx") = a2;
    register uint64_t r_num __asm__("rax") = num;
    __asm__ volatile (
        "int $0x80"
        : "+r"(r_num)
        : "r"(r_a0), "r"(r_a1), "r"(r_a2)
        : "memory", "rcx", "r8", "r9", "r10", "r11"
    );
    return r_num;
}

/* Virtual Memory Manager가 자체 페이지 테이블을 적용하기 위해 CR3에
 * PML4 물리주소를 적재/조회한다. TLB 플러시는 mov-to-cr3 자체가 수행한다. */
static inline void hal_write_cr3(uint64_t pml4_phys) {
    __asm__ volatile ("mov %0, %%cr3" : : "r"(pml4_phys) : "memory");
}
static inline uint64_t hal_read_cr3(void) {
    uint64_t val;
    __asm__ volatile ("mov %%cr3, %0" : "=r"(val));
    return val;
}

/* 16비트 포트 I/O — RTL8139 등 일부 레지스터(IMR/ISR/CAPR 등)는
 * 16비트 폭으로 접근한다. */
static inline void hal_outw(uint16_t port, uint16_t val) {
    __asm__ volatile ("outw %0, %1" : : "a"(val), "Nd"(port));
}
static inline uint16_t hal_inw(uint16_t port) {
    uint16_t ret;
    __asm__ volatile ("inw %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

/* Milestone 19(TLS): CPUID로 RDRAND 하드웨어 난수 지원 여부를 확인하고,
 * 지원하면 RDRAND로 32비트 진짜 난수를 얻는다. QEMU+최신 실기 대부분
 * 지원하지만, 지원하지 않는 환경을 위해 rng.c가 소프트웨어 폴백을
 * 따로 갖고 있다(이 함수는 "가능하면 쓰는" 하드웨어 원천일 뿐). */
static inline int hal_cpu_has_rdrand(void) {
    uint32_t eax, ebx, ecx, edx;
    __asm__ volatile ("cpuid" : "=a"(eax), "=b"(ebx), "=c"(ecx), "=d"(edx) : "a"(1) : );
    return (ecx >> 30) & 1;
}
static inline int hal_rdrand32(uint32_t *out) {
    uint8_t ok;
    __asm__ volatile ("rdrand %0; setc %1" : "=r"(*out), "=qm"(ok) : : "cc");
    return ok;
}

/* TSC(Time Stamp Counter) — RDRAND가 없는 환경의 소프트웨어 난수
 * 폴백에 엔트로피를 섞는 용도(rng.c 참고). */
static inline uint64_t hal_rdtsc(void) {
    uint32_t lo, hi;
    __asm__ volatile ("rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32) | lo;
}

/* Milestone 20: PMM 같은 짧은 임계구역을 cli/sti로 보호할 때, "원래
 * 인터럽트가 켜져 있었는지"를 미리 알아야 무조건 sti 하지 않고
 * 올바르게 복원할 수 있다(중첩 호출/이미 cli된 컨텍스트에서 불릴 때
 * 실수로 인터럽트를 켜버리는 사고 방지). RFLAGS의 IF 비트(9번)를 읽는다. */
static inline int hal_interrupts_enabled(void) {
    uint64_t flags;
    __asm__ volatile ("pushfq; popq %0" : "=r"(flags) : : "memory");
    return (flags >> 9) & 1;
}

#endif /* JETOS_X86_ASM_SHIM_H */
