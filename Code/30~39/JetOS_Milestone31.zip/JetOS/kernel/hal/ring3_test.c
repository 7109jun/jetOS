/*
 * JetOS - kernel/hal/ring3_test.c
 * ring3_test.h 참고. 순수 C(시스템콜 트랩만 인라인 asm 한 줄, x86_asm_shim.h
 * 소관) — 이 파일 자체는 어셈블리가 없다.
 */
#include "ring3_test.h"
#include "x86_asm_shim.h"
#include "gdt.h"
#include "syscall.h"
#include "../mm/heap.h"
#include "../drivers/serial.h"

#define RING3_STACK_SIZE 8192

/* ---- 이 함수 본문이 실제로 CPL=3(Ring3)에서 실행된다 ----
 * 평범한 C 함수처럼 보이지만, hal_enter_user_mode()가 iretq로 여기에
 * 진입하는 순간부터 CPU 권한 레벨이 3으로 바뀐다. 특권 명령(cli/sti,
 * in/out, mov-to-cr3 등)을 시도하면 즉시 #GP가 난다 — 여기서는 시스템콜
 * (int $0x80)과 순수 계산/메모리 접근만 한다. */
static void ring3_test_entry(void) {
    static const char msg1[] =
        "  [RING3] Hello from user mode! (CPL=3, real privilege transition via IRETQ)\n";
    hal_syscall(SYS_WRITE, (uint64_t)msg1, 0, 0);

    uint64_t tick = hal_syscall(SYS_GETTICK, 0, 0, 0);
    static char msg2[64];
    /* 간단한 정수->문자열 (freestanding, sprintf 없음) */
    char numbuf[24]; int n = 0;
    if (tick == 0) numbuf[n++] = '0';
    uint64_t v = tick;
    while (v) { numbuf[n++] = (char)('0' + (v % 10)); v /= 10; }
    int mi = 0;
    const char *pre = "  [RING3] SYS_GETTICK syscall returned tick=";
    for (int i = 0; pre[i]; i++) msg2[mi++] = pre[i];
    for (int i = n - 1; i >= 0; i--) msg2[mi++] = numbuf[i];
    msg2[mi++] = '\n';
    msg2[mi] = '\0';
    hal_syscall(SYS_WRITE, (uint64_t)msg2, 0, 0);

    static const char msg3[] = "  [RING3] calling SYS_EXIT now...\n";
    hal_syscall(SYS_WRITE, (uint64_t)msg3, 0, 0);

    hal_syscall(SYS_EXIT, 0, 0, 0);

    /* SYS_EXIT은 절대 돌아오지 않아야 정상 — 혹시 몰라 안전망으로
     * 무한루프(CPL=3에서 hlt는 특권 명령이라 못 씀, 그냥 스핀). */
    for (;;) { }
}

void ring3_test_thread_fn(void *arg) {
    (void)arg;
    serial_write("=== RING3 SELF-TEST START ===\n");

    uint8_t *user_stack_mem = (uint8_t *)kmalloc(RING3_STACK_SIZE);
    if (!user_stack_mem) {
        serial_write("  RING3 TEST SKIPPED (스택 할당 실패)\n");
        serial_write("=== RING3 SELF-TEST END ===\n");
        return;
    }
    uint64_t user_stack_top = ((uint64_t)user_stack_mem + RING3_STACK_SIZE) & ~0xFULL;

    /* 이 스레드가 Ring3에 있는 동안 인터럽트/시스템콜이 들어오면 CPU가
     * TSS.RSP0로 자동 전환한다 — gdt_init()이 이미 기본 커널 스택을
     * RSP0로 등록해뒀으므로 별도 설정 없이도 안전하다(이 데모는 Ring3
     * 스레드가 동시에 여러 개 있는 상황을 다루지 않는다 — 그런 경우
     * 스레드 전환마다 gdt_set_kernel_stack()을 다시 불러줘야 한다). */
    hal_enter_user_mode((uint64_t)ring3_test_entry, user_stack_top,
                         GDT_SEL_USER_CODE, GDT_SEL_USER_DATA);

    /* hal_enter_user_mode()는 noreturn이다 — 여기 도달하면 안 됨.
     * ring3_test_entry()가 SYS_EXIT을 호출하면 syscall_dispatch()
     * 안에서 thread_exit()가 이 스레드 자체를 끝내버리므로, 그 뒤로는
     * 이 함수(호출자)의 나머지 코드도 실행되지 않는다 — 정상 동작. */
}
