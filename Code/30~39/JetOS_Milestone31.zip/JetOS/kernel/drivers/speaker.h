#ifndef JETOS_SPEAKER_H
#define JETOS_SPEAKER_H

#include <stdint.h>

/*
 * JetOS - kernel/drivers/speaker.h
 * Milestone 22: PC 스피커(8254 PIT 채널2 + 포트 0x61 게이트) 드라이버.
 *
 * "오디오"라고 부르기엔 아주 원시적이다 — 이건 디지털 오디오(WAV
 * 재생 등)가 아니라, 한 번에 하나의 순수 사각파 톤만 낼 수 있는
 * 1980년대 PC 스피커 그 자체다. 실제 디지털 오디오를 내려면 AC97/HDA
 * 같은 사운드 카드 드라이버 + DMA + 오디오 포맷 디코딩이 필요한데,
 * 이건 TLS 스택만큼 큰 별도 과제라 이번엔 스코프 밖으로 뒀다(문서
 * "다음 작업" 참고). 대신 이 드라이버로 할 수 있는 것: 단일 주파수
 * 사각파 재생(비프음), 그리고 그걸 이어붙여 아주 단순한 "멜로디"
 * (주파수+길이 쌍의 배열)를 연주하는 것.
 *
 * PIT 채널0(시스템 틱, kernel/int/pit.c)과는 완전히 독립된 하드웨어
 * 채널(채널2)을 쓰므로, 스피커를 켜고 꺼도 시스템 타이머에는 영향이
 * 없다.
 */

/* 채널2를 지정 주파수(Hz)의 사각파로 설정하고 포트 0x61의 스피커
 * 게이트를 켠다. freq_hz가 너무 작으면(분주비가 16비트를 넘으면)
 * 가청 최저 주파수로 clamp한다. */
void speaker_on(uint32_t freq_hz);

/* 스피커 게이트를 끈다(소리 멈춤). PIT 채널2 자체는 계속 돌지만
 * 스피커로 연결되지 않으니 무음. */
void speaker_off(void);

/* freq_hz 톤을 duration_ms 동안 재생하고(스케줄러에 협조적으로 양보
 * 하며 대기) 끈다. 블로킹 호출 — 그동안 이 스레드는 다른 일을 못
 * 하지만 scheduler_yield()로 다른 스레드는 계속 돈다. */
void speaker_beep(uint32_t freq_hz, uint32_t duration_ms);

typedef struct {
    uint32_t freq_hz;   /* 0이면 "쉼표"(무음) */
    uint32_t duration_ms;
} speaker_note_t;

/* notes 배열을 순서대로 재생한다(음 사이에 아주 짧은 무음 간격을 둬서
 * 같은 음이 이어져도 구분되게 함). */
void speaker_play_melody(const speaker_note_t *notes, uint32_t count);

#endif
