#ifndef JETOS_TLS_H
#define JETOS_TLS_H

/*
 * JetOS - kernel/net/tls.h
 * Milestone 19: 최소 TLS 1.2 클라이언트. tcp.c 위에 얹혀서 실제
 * HTTPS 사이트에 접속할 수 있게 한다.
 *
 * 지원 범위 (의도적으로 좁게 잡음):
 *   - TLS 1.2만. TLS 1.3/1.1/1.0/SSL은 지원하지 않는다.
 *   - 암호모음(cipher suite) 두 개, ClientHello에서 둘 다 제안하고
 *     서버가 고르는 대로 따라간다:
 *       - TLS_DHE_RSA_WITH_AES_128_CBC_SHA256 (0x0067, Milestone 41
 *         추가) — 매 연결마다 새로 만드는 임시 Diffie-Hellman 키로
 *         premaster secret을 유도해 순방향 비밀성(forward secrecy)을
 *         제공한다. RSA는 여전히 ServerKeyExchange의 DH 파라미터에
 *         서명하는 인증 용도로만 쓰인다(키교환 자체는 DH가 함).
 *       - TLS_RSA_WITH_AES_128_CBC_SHA256 (0x003C) — 예전부터 있던
 *         정적 RSA 키교환(순방향 비밀성 없음). DHE를 지원하지 않는
 *         서버와의 호환을 위해 폴백으로 남겨둠.
 *     ECDHE(타원곡선) 계열은 여전히 미지원 — 타원곡선 연산 자체가
 *     별도 구현이 필요해서(bignum.c는 소수 모듈러스 기반 정수 연산만
 *     지원) 이번 스코프에는 안 들어감. RSA만 광고하고 DHE를 거부하는
 *     최신 서버는 여전히 접속 안 될 수 있음(알려진 한계).
 *   - SNI(Server Name Indication) 확장은 보낸다(이름 기반 가상호스팅
 *     서버 다수와 접속하려면 사실상 필수) — 그리고 M24부터는 이
 *     SNI 호스트명이 그대로 인증서 호스트명 검증에도 쓰인다.
 *
 * Milestone 24: 인증서 신뢰 체인 + 호스트명 검증 추가(이전까지 가장
 * 큰 알려진 한계였던 부분). tls_connect()는 이제 기본적으로:
 *   - 서버가 보낸 인증서 체인 전체(리프+중간, 최대
 *     X509_TRUST_MAX_CHAIN개)를 파싱해 서명이 실제로 이어지는지 확인
 *   - 마지막 인증서가 로컬 신뢰 저장소(/system/certs/roots.der,
 *     x509_trust.h 참고)의 루트 중 하나로 귀결되는지 확인
 *   - 모든 인증서의 유효기간이 현재(CMOS RTC 기준) 안에 있는지 확인
 *   - sni_host가 리프 인증서의 SAN(우선)/CN과 일치하는지 확인
 * 위 중 하나라도 실패하면 핸드셰이크 자체를 실패로 처리한다(연결은
 * 이미 되어 있어도 애플리케이션 데이터는 절대 주고받지 않음). 실패
 * 사유는 tls_last_error()로 확인 가능.
 *
 * Milestone 41: DHE_RSA 키교환 추가. ServerKeyExchange의 DH 파라미터는
 * 리프 인증서의 RSA 공개키로 서명 검증한다(rsa_pkcs1_verify_sha256,
 * x509 체인 서명 검증과 같은 코드를 공유 — kernel/net/crypto/rsa_pkcs1.c
 * 참고). 검증 실패는 "중간자 공격 가능성"으로 취급해 즉시 핸드셰이크를
 * 중단한다(연결을 계속 진행하지 않음).
 *
 * 여전히 남은 한계(정직하게 문서화):
 *   - basicConstraints(CA:TRUE)/keyUsage/pathLenConstraint 미검사
 *     (x509_min.h 참고).
 *   - CRL/OCSP 폐지 확인 없음.
 *   - 신뢰 저장소가 커널에 내장되어 있지 않다 — 사용자가
 *     /system/certs/roots.der를 직접 준비해야 하며, 없으면 기본값은
 *     "아무도 신뢰 안 함"(fail-closed)이라 실제 HTTPS 사이트 접속이
 *     전부 막힌다(x509_trust.h 참고).
 *   - CBC MAC 검증/패딩 검사가 상수시간이 아니다(타이밍 사이드채널
 *     이론적으로 가능 — 패딩 오라클 공격류에 대한 방어 없음).
 *   - CMOS RTC를 그대로 UTC로 가정한다(시간대 보정 없음, rtc.c 참고).
 *   - DHE의 임시 개인키 x 생성이 "p와 같은 바이트 길이 난수 + 최상위
 *     비트 클리어"로 x<p만 보장하는 실용적 방식이라, 진짜 균등분포
 *     [1,p-2] 추출은 아니다(암호학적으로 여전히 안전하지만 — 엄밀한
 *     RFC 준수보다 이 프로젝트의 "최소 bignum" 방침과의 절충).
 *   - ECDHE 미지원(위 참고).
 */

#include <stdint.h>

/* dst_ip로 TCP 연결 후 TLS 핸드셰이크까지 완료한다. sni_host는
 * ClientHello의 server_name 확장에 넣을 호스트명이자(M24부터) 인증서
 * 호스트명 검증에 쓰이는 이름이다(NULL이면 SNI 생략 + 호스트명 검증도
 * 생략 — IP 리터럴 접속처럼 이름이 없는 경우용). 인증서 체인/신뢰
 * 검증은 기본적으로 강제된다(tls_connect_ex의 allow_untrusted=0과
 * 동일). 성공 1, 실패(TCP 실패/핸드셰이크 실패/인증서 검증 실패 등) 0
 * — 실패 사유는 tls_last_error() 참고. */
int tls_connect(const char *sni_host, uint32_t dst_ip, uint16_t dst_port, uint32_t timeout_ticks);

/* tls_connect과 동일하지만 allow_untrusted가 1이면 인증서 체인 신뢰
 * 검증(x509_verify_chain)을 건너뛴다 — 호스트명 검증은 sni_host가
 * 있으면 여전히 수행한다. 오직 kernel_entry.c의 자체서명 테스트
 * 인증서용 내부 자체 테스트에서만 쓸 것 — jash/browser 등 실제 사용자
 * 접속 경로에서는 절대 1을 넘기면 안 된다. */
int tls_connect_ex(const char *sni_host, uint32_t dst_ip, uint16_t dst_port, uint32_t timeout_ticks, int allow_untrusted);

/* 가장 최근 tls_connect(_ex) 실패의 사람이 읽을 수 있는 사유(한국어).
 * 성공한 연결 이후에는 의미 없음. 연결 시도가 한 번도 없었으면
 * "연결 시도 없음"류의 기본 문자열을 돌려준다. */
const char *tls_last_error(void);

/* Milestone 41: 마지막으로 성공한 핸드셰이크가 DHE_RSA(순방향 비밀성
 * 있음, 1)였는지 정적 RSA(없음, 0)였는지. 연결 성공 전이면 의미 없음
 * (0 반환). tls_last_error()와 짝을 이루는 진단용 조회 함수 — 서버마다
 * 어느 스위트를 고를지 달라서 로그 메시지를 하드코딩하지 않기 위함. */
int tls_last_cipher_has_forward_secrecy(void);

int tls_send(const void *data, uint32_t len, uint32_t timeout_ticks);

/* 서버가 연결을 닫을 때(close_notify 또는 TCP FIN)까지 애플리케이션
 * 데이터를 복호화해서 buf에 채운다. 반환값은 실제로 채운 바이트 수. */
uint32_t tls_recv_until_close(void *buf, uint32_t buf_size, uint32_t timeout_ticks);

void tls_close(void);

#endif
