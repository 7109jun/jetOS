/*
 * JetOS - kernel/jetapi/jetapi.c
 * JetAPI 구현체. 각 함수는 해당 커널 서브시스템으로 그대로 위임(delegate)
 * 하되, 애플리케이션이 커널 내부 타입을 직접 알 필요가 없도록 얇은
 * 번역 계층 역할을 한다.
 */

#include <stddef.h>
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../fs/jetfs.h"
#include "../fs/vfs.h"
#include "../fs/recyclebin.h" /* Milestone 35 */
#include "../fs/perm.h" /* Milestone 35 */
#include "../mm/heap.h"
#include "../mm/pmm.h"
#include "../proc/thread.h"
#include "../proc/scheduler.h"
#include "../int/pit.h"

JetWindowHandle CreateWindowJ(const char *title, int x, int y, int w, int h, uint32_t color) {
    return (JetWindowHandle)wm_create_window(title, x, y, w, h, color);
}

void MoveWindowJ(JetWindowHandle win, int dx, int dy) {
    wm_move_window((int)win, dx, dy);
}

void BringWindowToFrontJ(JetWindowHandle win) {
    wm_bring_to_front((int)win);
}

int CreateFileJ(const char *path, int is_directory) {
    char real[128];
    const char *p = vfs_translate(path, real, sizeof(real));
    return jetfs_create(p, is_directory ? JETFS_TYPE_DIR : JETFS_TYPE_FILE);
}

int ReadFileJ(const char *path, void *buffer, uint64_t max_size, uint64_t *out_size) {
    char real[128];
    const char *p = vfs_translate(path, real, sizeof(real));
    return jetfs_read(p, buffer, max_size, out_size);
}

int WriteFileJ(const char *path, const void *data, uint64_t size) {
    char real[128];
    const char *p = vfs_translate(path, real, sizeof(real));
    return jetfs_write(p, data, size);
}

int DeleteFileJ(const char *path) {
    char real[128];
    const char *p = vfs_translate(path, real, sizeof(real));
    return jetfs_delete(p);
}

int RenameFileJ(const char *old_path, const char *new_path) {
    char real_old[128], real_new[128];
    const char *po = vfs_translate(old_path, real_old, sizeof(real_old));
    const char *pn = vfs_translate(new_path, real_new, sizeof(real_new));
    return jetfs_rename(po, pn);
}

int MoveToRecycleBinJ(const char *path) {
    char real[128];
    const char *p = vfs_translate(path, real, sizeof(real));
    return recyclebin_delete(p);
}

int IsReadOnlyJ(const char *path) {
    char real[128];
    const char *p = vfs_translate(path, real, sizeof(real));
    return perm_is_readonly(p);
}

int SetReadOnlyJ(const char *path, int readonly) {
    char real[128];
    const char *p = vfs_translate(path, real, sizeof(real));
    return perm_set_readonly(p, readonly);
}

typedef struct {
    JetFileListCallback cb;
    void *ctx;
} list_bridge_t;

static void jetfs_to_jetapi_cb(const char *name, jetfs_inode_type_t type, uint64_t size, void *ctx) {
    list_bridge_t *bridge = (list_bridge_t *)ctx;
    bridge->cb(name, type == JETFS_TYPE_DIR, size, bridge->ctx);
}

int ListDirectoryJ(const char *path, JetFileListCallback cb, void *ctx) {
    char real[128];
    const char *p = vfs_translate(path, real, sizeof(real));
    list_bridge_t bridge = { cb, ctx };
    return jetfs_list(p, jetfs_to_jetapi_cb, &bridge);
}

void *VirtualAllocJ(uint32_t size) {
    /* Milestone 6 단순화: 지금은 커널 힙(kmalloc) 위에 얹혀 있다.
     * 진짜 VirtualAlloc처럼 프로세스별 가상주소공간 예약/페이지 단위
     * 커밋을 흉내내려면 사용자 모드+프로세스별 페이지테이블이 필요하며,
     * 이는 사용자 모드가 도입되는 이후 마일스톤 과제다. */
    return kmalloc(size);
}

void VirtualFreeJ(void *ptr) {
    kfree(ptr);
}

int CreateThreadJ(const char *name, JetThreadEntry entry, void *arg) {
    thread_t *t = thread_create(name, entry, arg);
    return t ? (int)t->id : -1;
}

void GetSystemInfoJ(JetSystemInfo *out) {
    heap_stats_t h;
    heap_get_stats(&h);
    pmm_stats_t p;
    pmm_get_stats(&p);

    out->heap_total_bytes = h.total_bytes;
    out->heap_used_bytes = h.used_bytes;
    out->pmm_total_pages = p.total_pages;
    out->pmm_free_pages = p.free_pages;
    out->timer_ticks = g_timer_ticks;
}

typedef struct {
    JetThreadListCallback cb;
    void *ctx;
} thread_list_bridge_t;

static void scheduler_to_jetapi_cb(thread_t *t, void *ctx) {
    thread_list_bridge_t *bridge = (thread_list_bridge_t *)ctx;
    bridge->cb(t->name, t->id, (int)t->state, bridge->ctx);
}

void ListThreadsJ(JetThreadListCallback cb, void *ctx) {
    thread_list_bridge_t bridge = { cb, ctx };
    scheduler_for_each(scheduler_to_jetapi_cb, &bridge);
}
