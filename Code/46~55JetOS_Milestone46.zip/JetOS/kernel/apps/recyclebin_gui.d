kernel/apps/recyclebin_gui.o: kernel/apps/recyclebin_gui.c \
 kernel/apps/recyclebin_gui.h kernel/apps/../../include/jetapi/jetapi.h \
 kernel/apps/../gui/wm.h kernel/apps/../gui/../drivers/console.h \
 kernel/apps/../gui/notify.h kernel/apps/../drivers/console.h \
 kernel/apps/../proc/scheduler.h kernel/apps/../proc/thread.h \
 kernel/apps/../fs/recyclebin.h
kernel/apps/recyclebin_gui.h:
kernel/apps/../../include/jetapi/jetapi.h:
kernel/apps/../gui/wm.h:
kernel/apps/../gui/../drivers/console.h:
kernel/apps/../gui/notify.h:
kernel/apps/../drivers/console.h:
kernel/apps/../proc/scheduler.h:
kernel/apps/../proc/thread.h:
kernel/apps/../fs/recyclebin.h:
