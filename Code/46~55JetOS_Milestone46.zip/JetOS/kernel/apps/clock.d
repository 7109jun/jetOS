kernel/apps/clock.o: kernel/apps/clock.c kernel/apps/clock.h \
 kernel/apps/../../include/jetapi/jetapi.h kernel/apps/../gui/wm.h \
 kernel/apps/../gui/../drivers/console.h kernel/apps/../drivers/console.h \
 kernel/apps/../drivers/rtc.h kernel/apps/../proc/scheduler.h \
 kernel/apps/../proc/thread.h kernel/apps/../fs/config.h
kernel/apps/clock.h:
kernel/apps/../../include/jetapi/jetapi.h:
kernel/apps/../gui/wm.h:
kernel/apps/../gui/../drivers/console.h:
kernel/apps/../drivers/console.h:
kernel/apps/../drivers/rtc.h:
kernel/apps/../proc/scheduler.h:
kernel/apps/../proc/thread.h:
kernel/apps/../fs/config.h:
