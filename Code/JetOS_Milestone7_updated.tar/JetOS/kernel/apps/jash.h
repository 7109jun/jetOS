#ifndef JETOS_JASH_H
#define JETOS_JASH_H

/*
 * jash — JetOS 전용 셸
 * C#으로 작성된 원본(Jash.cs)의 기능을 JetOS freestanding C로 재구현.
 * 원본 Jash가 Windows Console/Win32 API를 사용하는 부분은 JetOS의
 * keyboard driver + JetAPI로 대체된다.
 *
 * 지원 명령어:
 *   help
 *   base64 encode <text>
 *   base64 decode <base64>
 *   mem list               → JetOS 스레드 목록 (원본 Process.GetProcesses 대응)
 *   mem info               → JetOS 메모리 통계 (원본 mem view 대응)
 *   browse <path>          → JETFS 파일 내용 보기 (원본 HTTP browse 대응, Milestone 7)
 *   exit / quit
 */

void jash_launch(void);
void jash_run_once(void);
void jash_inject_char(char c); /* desktop 이벤트루프가 직접 호출 */
extern int g_jash_running;    /* desktop이 키 라우팅 판별에 사용 */

#endif
