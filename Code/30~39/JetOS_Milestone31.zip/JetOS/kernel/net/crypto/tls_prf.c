/* JetOS - kernel/net/crypto/tls_prf.c */
#include "tls_prf.h"
#include "hmac_sha256.h"

#define MAX_SEED 128 /* label + seed 합쳐서 이 정도면 TLS 핸드셰이크 용도로 충분 */

void tls_prf(const uint8_t *secret, size_t secret_len,
             const char *label,
             const uint8_t *seed, size_t seed_len,
             uint8_t *out, size_t out_len) {
    uint8_t full_seed[MAX_SEED];
    size_t label_len = 0;
    while (label[label_len]) label_len++;
    size_t fs_len = label_len + seed_len;
    if (fs_len > MAX_SEED) fs_len = MAX_SEED; /* 방어적 — 호출측이 이 한도 안에서만 씀 */
    for (size_t i = 0; i < label_len && i < MAX_SEED; i++) full_seed[i] = (uint8_t)label[i];
    for (size_t i = 0; i < seed_len && label_len + i < MAX_SEED; i++) full_seed[label_len + i] = seed[i];

    uint8_t a[32];
    hmac_sha256(secret, secret_len, full_seed, fs_len, a); /* A(1) */

    size_t produced = 0;
    while (produced < out_len) {
        uint8_t buf[32 + MAX_SEED];
        size_t buflen = 0;
        for (int i = 0; i < 32; i++) buf[buflen++] = a[i];
        for (size_t i = 0; i < fs_len; i++) buf[buflen++] = full_seed[i];

        uint8_t chunk[32];
        hmac_sha256(secret, secret_len, buf, buflen, chunk);

        size_t take = (out_len - produced < 32) ? (out_len - produced) : 32;
        for (size_t i = 0; i < take; i++) out[produced + i] = chunk[i];
        produced += take;

        uint8_t a_next[32];
        hmac_sha256(secret, secret_len, a, 32, a_next);
        for (int i = 0; i < 32; i++) a[i] = a_next[i];
    }
}
