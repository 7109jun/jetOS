/*
 * JetOS - kernel/drivers/pci.c
 * 레거시 PCI Configuration Mechanism #1 (포트 0xCF8/0xCFC)을 사용한
 * 설정공간 접근과 버스 전수조사(brute-force enumeration)로 AHCI
 * 컨트롤러를 찾는다.
 */

#include "pci.h"
#include "../hal/x86_asm_shim.h"

#define PCI_CONFIG_ADDRESS 0xCF8
#define PCI_CONFIG_DATA    0xCFC

static uint32_t pci_make_address(uint8_t bus, uint8_t slot, uint8_t func, uint8_t offset) {
    return (uint32_t)(
        (1u << 31) |                       /* Enable bit */
        ((uint32_t)bus << 16) |
        ((uint32_t)(slot & 0x1F) << 11) |
        ((uint32_t)(func & 0x07) << 8) |
        (offset & 0xFC)
    );
}

uint32_t pci_config_read32(uint8_t bus, uint8_t slot, uint8_t func, uint8_t offset) {
    hal_outl(PCI_CONFIG_ADDRESS, pci_make_address(bus, slot, func, offset));
    return hal_inl(PCI_CONFIG_DATA);
}

void pci_config_write32(uint8_t bus, uint8_t slot, uint8_t func, uint8_t offset, uint32_t value) {
    hal_outl(PCI_CONFIG_ADDRESS, pci_make_address(bus, slot, func, offset));
    hal_outl(PCI_CONFIG_DATA, value);
}

int pci_find_ahci_controller(pci_device_t *out) {
    for (uint16_t bus = 0; bus < 256; bus++) {
        for (uint8_t slot = 0; slot < 32; slot++) {
            for (uint8_t func = 0; func < 8; func++) {
                uint32_t id = pci_config_read32((uint8_t)bus, slot, func, 0x00);
                uint16_t vendor = id & 0xFFFF;
                if (vendor == 0xFFFF) {
                    if (func == 0) break; /* 이 slot에 장치 없음 */
                    continue;
                }

                uint32_t class_reg = pci_config_read32((uint8_t)bus, slot, func, 0x08);
                uint8_t class_code = (class_reg >> 24) & 0xFF;
                uint8_t subclass   = (class_reg >> 16) & 0xFF;
                uint8_t prog_if    = (class_reg >> 8) & 0xFF;

                if (class_code == 0x01 && subclass == 0x06 && prog_if == 0x01) {
                    out->bus = (uint8_t)bus;
                    out->slot = slot;
                    out->func = func;
                    out->vendor_id = (uint16_t)vendor;
                    out->device_id = (uint16_t)(id >> 16);
                    out->class_code = class_code;
                    out->subclass = subclass;
                    out->prog_if = prog_if;
                    for (int b = 0; b < 6; b++) {
                        out->bar[b] = pci_config_read32((uint8_t)bus, slot, func, (uint8_t)(0x10 + b * 4));
                    }
                    return 1;
                }
            }
        }
    }
    return 0;
}
