kernel/net/net.o: kernel/net/net.c kernel/net/net.h \
 kernel/net/../drivers/rtl8139.h kernel/net/../drivers/serial.h \
 kernel/net/../int/pit.h kernel/net/../proc/scheduler.h \
 kernel/net/../proc/thread.h
kernel/net/net.h:
kernel/net/../drivers/rtl8139.h:
kernel/net/../drivers/serial.h:
kernel/net/../int/pit.h:
kernel/net/../proc/scheduler.h:
kernel/net/../proc/thread.h:
