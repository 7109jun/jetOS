#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct DeiigPluginHost DeiigPluginHost;
typedef int (*DeiigCommandHandler)(int argc, const char* const* argv, void* user_data);
typedef void (*DeiigRegisterCommandFn)(DeiigPluginHost* host, const char* name, const char* description, DeiigCommandHandler handler, void* user_data);
typedef void (*DeiigLogFn)(DeiigPluginHost* host, const char* message);

typedef struct DeiigPluginApi {
    uint32_t api_version;
    DeiigPluginHost* host;
    DeiigRegisterCommandFn register_command;
    DeiigLogFn log;
} DeiigPluginApi;

typedef const char* (*DeiigPluginInitFn)(const DeiigPluginApi* api);
typedef void (*DeiigPluginShutdownFn)(const DeiigPluginApi* api);

#define DEIIG_PLUGIN_API_VERSION 1
#define DEIIG_PLUGIN_EXPORT extern "C" __attribute__((visibility("default")))

#ifdef _WIN32
#undef DEIIG_PLUGIN_EXPORT
#define DEIIG_PLUGIN_EXPORT extern "C" __declspec(dllexport)
#endif

#ifdef __cplusplus
}
#endif
