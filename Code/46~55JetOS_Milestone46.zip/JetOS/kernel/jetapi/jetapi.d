kernel/jetapi/jetapi.o: kernel/jetapi/jetapi.c \
 kernel/jetapi/../../include/jetapi/jetapi.h kernel/jetapi/../gui/wm.h \
 kernel/jetapi/../gui/../drivers/console.h kernel/jetapi/../fs/jetfs.h \
 kernel/jetapi/../fs/vfs.h kernel/jetapi/../fs/recyclebin.h \
 kernel/jetapi/../fs/perm.h kernel/jetapi/../mm/heap.h \
 kernel/jetapi/../mm/pmm.h kernel/jetapi/../mm/../../include/efi/efi.h \
 kernel/jetapi/../proc/thread.h kernel/jetapi/../proc/scheduler.h \
 kernel/jetapi/../proc/thread.h kernel/jetapi/../int/pit.h
kernel/jetapi/../../include/jetapi/jetapi.h:
kernel/jetapi/../gui/wm.h:
kernel/jetapi/../gui/../drivers/console.h:
kernel/jetapi/../fs/jetfs.h:
kernel/jetapi/../fs/vfs.h:
kernel/jetapi/../fs/recyclebin.h:
kernel/jetapi/../fs/perm.h:
kernel/jetapi/../mm/heap.h:
kernel/jetapi/../mm/pmm.h:
kernel/jetapi/../mm/../../include/efi/efi.h:
kernel/jetapi/../proc/thread.h:
kernel/jetapi/../proc/scheduler.h:
kernel/jetapi/../proc/thread.h:
kernel/jetapi/../int/pit.h:
