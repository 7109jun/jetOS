#ifndef JETOS_PIC_H
#define JETOS_PIC_H

#include <stdint.h>

#define PIC1_OFFSET 0x20  /* IRQ0-7  -> 인터럽트 벡터 0x20-0x27 */
#define PIC2_OFFSET 0x28  /* IRQ8-15 -> 인터럽트 벡터 0x28-0x2F */

/* 8259 PIC를 리맵한다. UEFI/BIOS 기본값(IRQ0=벡터0x08)은 CPU 예외
 * 벡터(0-31)와 충돌하므로 반드시 리맵해야 한다. */
void pic_remap(void);
void pic_send_eoi(uint8_t irq);
void pic_mask_irq(uint8_t irq);
void pic_unmask_irq(uint8_t irq);

#endif
