#pragma once
#include <string>
namespace deiig::registry { int init(); int search(const std::string&q); int install(const std::string&name); }
