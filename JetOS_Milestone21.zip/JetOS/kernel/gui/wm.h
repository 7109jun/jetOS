#ifndef JETOS_WM_H
#define JETOS_WM_H

#include <stdint.h>
#include "../drivers/console.h"

#define WM_MAX_WINDOWS 8
#define WM_TITLEBAR_H 18
#define WM_TASKBAR_H 28

typedef void (*wm_content_draw_fn)(console_t *dc, int x, int y, int w, int h, void *ctx);
typedef void (*wm_close_fn)(void *ctx); /* X버튼 클릭 시 소유 앱에게 통지 */
typedef void (*wm_click_fn)(int local_x, int local_y, void *ctx); /* 콘텐츠 영역 클릭 통지 */
typedef void (*wm_key_fn)(char c, void *ctx); /* 포커스된 창에 키 입력 통지 (Milestone 19) */
typedef void (*wm_scroll_fn)(int delta, void *ctx); /* 마우스 휠/스크롤바 통지 (Milestone 19) */

typedef struct {
    int x, y, w, h;
    char title[32];
    uint32_t color;
    int visible;
    int minimized;
    int closed;
    int used;
    wm_content_draw_fn content_cb;
    void *content_ctx;
    wm_close_fn close_cb;
    void *close_ctx;
    wm_click_fn click_cb;
    void *click_ctx;
    wm_key_fn key_cb;   /* Milestone 19: 포커스 시 키 입력 수신 콜백 */
    void *key_ctx;
    wm_scroll_fn scroll_cb; /* Milestone 19: 콘텐츠 영역 스크롤 통지 */
    void *scroll_ctx;
    int win32_style; /* 1이면 Win32(CreateWindowA로 생성된 PE EXE) 스타일로 그린다 */
    int maximized;   /* Milestone 18 */
    int saved_x, saved_y, saved_w, saved_h; /* 최대화 이전 크기/위치 (복원용) */
    int content_h;   /* Milestone 19: 콘텐츠 전체 높이(스크롤 가능 시). 0이면 스크롤 없음 */
    int scroll_y;    /* Milestone 19: 현재 스크롤 오프셋 (0..content_h-보이는높이) */
} wm_window_t;

void wm_init(console_t *con);
console_t *wm_get_draw_console(void); /* 오프스크린 백버퍼용 콘솔 (더블 버퍼링) */
void wm_present(void); /* 백버퍼를 실제 프레임버퍼로 한 번에 블릿 */
int  wm_create_window(const char *title, int x, int y, int w, int h, uint32_t color);
void wm_move_window(int idx, int dx, int dy);
void wm_resize_window(int idx, int dw, int dh);
int  wm_hit_resize_handle(int idx, int x, int y);

/* 데스크톱 아이콘 (Milestone 17) */
int wm_desktop_icon_hit(int x, int y);          /* 좌표가 어느 아이콘 위인지, 없으면 -1 */
int wm_desktop_icon_double_click(int x, int y);  /* 더블클릭 완성 시 아이콘 인덱스, 아니면 -1 */
void wm_bring_to_front(int idx);
int  wm_window_at(int x, int y);            /* 클릭 지점에 있는 최상위 창 인덱스, 없으면 -1 */
int  wm_hit_titlebar(int idx, int x, int y); /* 그 창의 타이틀바를 클릭했는지 */
int  wm_hit_close_button(int idx, int x, int y); /* 그 창의 X버튼을 클릭했는지 */
int  wm_hit_maximize_button(int idx, int x, int y);
int  wm_hit_minimize_button(int idx, int x, int y);
void wm_toggle_maximize(int idx); /* Milestone 18: 최대화/복원 토글 */
void wm_get_window_bounds(int idx, int *x, int *y, int *w, int *h);
void wm_set_content_callback(int idx, wm_content_draw_fn cb, void *ctx);

/* X버튼으로 창이 닫힐 때 호출될 콜백을 등록한다. 소유 스레드가 이
 * 콜백에서 자신의 실행 루프를 정지시키는 플래그를 세우는 용도로 쓴다
 * (스레드 자체를 강제 종료하지는 않고, 협조적으로 종료하도록 유도). */
void wm_set_close_callback(int idx, wm_close_fn cb, void *ctx);

/* 창의 콘텐츠 영역(타이틀바 아래) 클릭을 앱에게 전달한다 (Milestone 13,
 * 파일 관리자 더블클릭 탐색 등에 사용). local_x/local_y는 콘텐츠
 * 영역 좌상단 기준 상대 좌표. */
void wm_set_click_callback(int idx, wm_click_fn cb, void *ctx);

/* screen 좌표의 클릭을 해당 창의 click 콜백으로 전달한다(콘텐츠
 * 영역 안일 때만). 전달했으면 1, 아니면(콜백 없음/영역 밖) 0. */
int wm_dispatch_click(int screen_x, int screen_y);

/* ===== 키보드 포커스 라우팅 일반화 (Milestone 19) =====
 * 기존에는 desktop.c가 "jash가 실행중이면 jash, 아니면 Notepad"
 * 식으로 키 입력을 하드코딩해서 나눠줬다. 이제는 클릭/생성으로
 * 포커스를 얻은 창(g_focused_idx, 기존에도 z-order 최상단 추적용으로
 * 내부에 있었으나 외부에 노출되지 않았던 상태)에 자동으로 라우팅된다.
 * 새 창은 생성 시, 그리고 클릭(타이틀바/콘텐츠/리사이즈 등 wm_bring_to_front가
 * 불리는 모든 경로)으로 포커스를 가져간다. */
void wm_set_key_callback(int idx, wm_key_fn cb, void *ctx);
int  wm_get_focused_window(void); /* 현재 포커스된 창 idx, 없으면 -1 */
void wm_dispatch_key(char c);     /* 포커스된 창의 key_cb에 문자 전달 */

/* ===== 스크롤 (Milestone 19) =====
 * 창 콘텐츠가 보이는 영역보다 클 수 있을 때 사용. content_h를 실제
 * 콘텐츠 전체 높이로 설정해두면 wm_draw()가 스크롤바를 그리고,
 * 마우스 휠/스크롤바 드래그로 scroll_y가 자동 갱신된다. content_h가
 * 0(기본값)이면 스크롤바가 그려지지 않는다(기존 창들은 영향 없음). */
void wm_set_content_height(int idx, int content_h);
void wm_set_scroll_callback(int idx, wm_scroll_fn cb, void *ctx); /* 선택: 스크롤 변화 통지 */
int  wm_get_scroll(int idx);
void wm_scroll_by(int idx, int delta); /* 휠 등으로 스크롤 오프셋 변경(클램프됨) */
void wm_scroll_to_bottom(int idx);     /* 콘솔류 창이 새 출력마다 최신 줄로 자동 이동 */
int  wm_hit_scrollbar(int idx, int x, int y); /* 스크롤바 트랙/썸을 클릭했는지 */
void wm_scrollbar_drag_to(int idx, int y);    /* 스크롤바 썸을 y 위치로 드래그 */

/* Win32(CreateWindowA로 만들어진 PE EXE) 스타일 창으로 표시할지 설정 */
void wm_set_win32_style(int idx, int enabled);

/* 창 제목을 바꾼다 (Milestone 17: Notepad "저장 안 됨" 표시 등에 사용) */
void wm_set_title(int idx, const char *title);

/* 창 닫기 / 최소화 */
void wm_close_window(int idx);      /* 창을 완전히 숨기고 슬롯을 비운다 */
void wm_minimize_window(int idx);   /* 화면에서 숨기되 작업표시줄엔 남긴다 */
void wm_restore_window(int idx);    /* 최소화 해제 + 포커스 */
int  wm_is_window_minimized(int idx);
int  wm_hit_taskbar_window_button(int x, int y); /* 작업표시줄 창 버튼 클릭 시 해당 idx, 없으면 -1 */

/* 우클릭 컨텍스트 메뉴 (Milestone 8) */
void wm_open_context_menu(int x, int y, int window_idx); /* window_idx=-1이면 "데스크톱" 메뉴 */
void wm_close_context_menu(void);
int  wm_is_context_menu_open(void);
int  wm_context_menu_target(void); /* 메뉴가 열릴 때의 window_idx (-1=데스크톱) */
int  wm_hit_context_menu_item(int x, int y, int *out_item_index); /* 항목 클릭 판정 */
int  wm_hit_context_menu(int x, int y); /* 메뉴 영역 자체를 클릭했는지(바깥 클릭 판정용) */

void wm_draw(void);

/* 커서/작업표시줄/시작메뉴 상태 (desktop.c가 갱신) */
void wm_set_cursor(int x, int y);
void wm_get_cursor(int *x, int *y);
void wm_set_start_menu_open(int open);
int  wm_is_start_button_hit(int x, int y);
int  wm_is_start_menu_item_hit(int x, int y, int *out_item_index);

#endif
