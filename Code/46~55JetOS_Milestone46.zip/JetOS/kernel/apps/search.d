kernel/apps/search.o: kernel/apps/search.c kernel/apps/search.h \
 kernel/apps/../../include/jetapi/jetapi.h kernel/apps/../gui/wm.h \
 kernel/apps/../gui/../drivers/console.h kernel/apps/../gui/widget.h \
 kernel/apps/../drivers/console.h kernel/apps/../drivers/keyboard.h \
 kernel/apps/../proc/scheduler.h kernel/apps/../proc/thread.h \
 kernel/apps/../fs/jetfs.h
kernel/apps/search.h:
kernel/apps/../../include/jetapi/jetapi.h:
kernel/apps/../gui/wm.h:
kernel/apps/../gui/../drivers/console.h:
kernel/apps/../gui/widget.h:
kernel/apps/../drivers/console.h:
kernel/apps/../drivers/keyboard.h:
kernel/apps/../proc/scheduler.h:
kernel/apps/../proc/thread.h:
kernel/apps/../fs/jetfs.h:
