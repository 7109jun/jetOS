/*
 * JetOS - kernel/compat/win32.c
 * win32.h에 선언된 함수들의 구현. 전부 JetAPI 호출로 위임된다.
 *
 * 중요: 여기 정의된 모든 함수는 win32.h에서 WINAPI(=ms_abi)로 선언되어
 * 있다. PE32+ EXE가 IAT를 통해 이 함수들을 직접 호출하므로, 정의도
 * 반드시 선언과 동일하게 ms_abi여야 한다 (그렇지 않으면 링크는 되지만
 * 실행 시 인자가 전부 엉뚱한 레지스터에서 읽혀 조용히 깨진다).
 */

#include <stddef.h>
#include "win32.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../proc/thread.h"
#include "../proc/scheduler.h"

#define MAX_HANDLES 16

typedef struct {
    int used;
    char path[64];
} file_handle_t;

static file_handle_t g_handles[MAX_HANDLES];

static void str_copy(char *dst, const char *src, int max) {
    int i = 0;
    for (; i < max - 1 && src[i]; i++) dst[i] = src[i];
    dst[i] = '\0';
}

HWND WINAPI CreateWindowA(LPCSTR title, int x, int y, int w, int h, DWORD color_as_style_placeholder) {
    uint32_t color = color_as_style_placeholder ? color_as_style_placeholder : 0x00304050;
    int idx = CreateWindowJ(title, x, y, w, h, color);
    if (idx < 0) return NULL_HANDLE;
    wm_set_win32_style(idx, 1); /* Win32 호환 레이어로 만든 창은 클래식 Windows 스타일로 표시 */
    return (HANDLE)(intptr_t)(idx + 1); /* 0을 "실패"로 예약하기 위해 +1 */
}

/* ---- MessageBoxA: 실제로 text/title을 표시하는 작은 창 ----
 * 최대 몇 개까지 동시에 떠 있을 수 있도록 텍스트를 별도 풀에 보관해
 * content 콜백이 창이 그려질 때마다 참조하게 한다 (진짜 모달 잠금은
 * WM에 포커스-락 개념이 추가되는 이후 마일스톤 과제로 남겨둔다). */
#define MAX_MSGBOXES 8
typedef struct { int used; char text[128]; } msgbox_slot_t;
static msgbox_slot_t g_msgboxes[MAX_MSGBOXES];

static void msgbox_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)h;
    int slot = (int)(intptr_t)ctx;
    dc->cursor_x = (uint32_t)(x + 10);
    dc->cursor_y = (uint32_t)(y + 12);
    if (slot >= 0 && slot < MAX_MSGBOXES && g_msgboxes[slot].used) {
        console_print(dc, g_msgboxes[slot].text);
    }
}

int WINAPI MessageBoxA(HWND owner, LPCSTR text, LPCSTR title, DWORD type) {
    (void)owner; (void)type;
    int slot = -1;
    for (int i = 0; i < MAX_MSGBOXES; i++) {
        if (!g_msgboxes[i].used) { slot = i; break; }
    }
    int win = CreateWindowJ(title ? title : "MESSAGE", 400, 300, 320, 100, 0x00504030);
    if (win >= 0 && slot >= 0) {
        g_msgboxes[slot].used = 1;
        str_copy(g_msgboxes[slot].text, text ? text : "", sizeof(g_msgboxes[slot].text));
        wm_set_content_callback(win, msgbox_content_cb, (void *)(intptr_t)slot);
        wm_set_win32_style(win, 1);
    }
    return win >= 0 ? 1 : 0;
}

HANDLE WINAPI CreateFileA(LPCSTR path, DWORD desired_access, DWORD share_mode,
                    void *security_attrs, DWORD creation_disposition,
                    DWORD flags, HANDLE template_file) {
    (void)desired_access; (void)share_mode; (void)security_attrs;
    (void)creation_disposition; (void)flags; (void)template_file;

    for (int i = 0; i < MAX_HANDLES; i++) {
        if (!g_handles[i].used) {
            CreateFileJ(path, 0); /* 없으면 생성, 있으면 무시 */
            g_handles[i].used = 1;
            str_copy(g_handles[i].path, path, sizeof(g_handles[i].path));
            return (HANDLE)(intptr_t)(i + 1);
        }
    }
    return NULL_HANDLE;
}

BOOL WINAPI ReadFile(HANDLE file, LPVOID buffer, DWORD bytes_to_read, DWORD *bytes_read, void *overlapped) {
    (void)overlapped;
    int idx = (int)(intptr_t)file - 1;
    if (idx < 0 || idx >= MAX_HANDLES || !g_handles[idx].used) return FALSE;
    uint32_t out = 0;
    int ok = ReadFileJ(g_handles[idx].path, buffer, bytes_to_read, &out);
    if (bytes_read) *bytes_read = out;
    return ok ? TRUE : FALSE;
}

BOOL WINAPI WriteFile(HANDLE file, LPCVOID buffer, DWORD bytes_to_write, DWORD *bytes_written, void *overlapped) {
    (void)overlapped;
    int idx = (int)(intptr_t)file - 1;
    if (idx < 0 || idx >= MAX_HANDLES || !g_handles[idx].used) return FALSE;
    int ok = WriteFileJ(g_handles[idx].path, buffer, bytes_to_write);
    if (bytes_written) *bytes_written = ok ? bytes_to_write : 0;
    return ok ? TRUE : FALSE;
}

BOOL WINAPI CloseHandle(HANDLE h) {
    int idx = (int)(intptr_t)h - 1;
    if (idx < 0 || idx >= MAX_HANDLES) return FALSE;
    g_handles[idx].used = 0;
    return TRUE;
}

DWORD WINAPI GetFileSize(HANDLE file, DWORD *high) {
    if (high) *high = 0;
    int idx = (int)(intptr_t)file - 1;
    if (idx < 0 || idx >= MAX_HANDLES || !g_handles[idx].used) return 0xFFFFFFFFu;
    /* JetAPI에는 별도 stat이 없으므로 최대 크기 버퍼로 한번 읽어
     * out_size만 취한다 (작은 EXE의 GetFileSize 정도 용도로는 충분). */
    uint8_t tmp[4096];
    uint32_t out = 0;
    if (!ReadFileJ(g_handles[idx].path, tmp, sizeof(tmp), &out)) return 0xFFFFFFFFu;
    return out;
}

LPVOID WINAPI VirtualAlloc(LPVOID addr, uint32_t size, DWORD alloc_type, DWORD protect) {
    (void)addr; (void)alloc_type; (void)protect;
    return VirtualAllocJ(size);
}

BOOL WINAPI VirtualFree(LPVOID addr, uint32_t size, DWORD free_type) {
    (void)size; (void)free_type;
    VirtualFreeJ(addr);
    return TRUE;
}

HANDLE WINAPI GetStdHandle(DWORD std_handle) {
    (void)std_handle;
    /* 콘솔 서브시스템 없음: 항상 "유효해 보이는" 더미 핸들을 반환해
     * EXE가 널 체크만으로 실패 판정하지 않도록 한다. 실제 입출력은
     * 안 되지만(Milestone 10+ 과제) 최소한 크래시는 막는다. */
    return (HANDLE)(intptr_t)0x1000;
}

int WINAPI lstrlenA(LPCSTR s) {
    if (!s) return 0;
    int n = 0;
    while (s[n]) n++;
    return n;
}

void WINAPI Sleep(DWORD milliseconds) {
    /* 실제 타이머 기반 대기 대신, 밀리초당 한 번 정도로 substitute해
     * 스케줄러에 양보만 반복한다 (100Hz PIT라 1tick=10ms 근사). */
    uint32_t yields = milliseconds / 10;
    if (yields == 0) yields = 1;
    for (uint32_t i = 0; i < yields; i++) scheduler_yield();
}

__attribute__((noreturn))
void WINAPI ExitProcess(DWORD exit_code) {
    (void)exit_code;
    thread_exit();
}
