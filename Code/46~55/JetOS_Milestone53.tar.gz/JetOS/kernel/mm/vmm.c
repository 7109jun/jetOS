/*
 * JetOS - kernel/mm/vmm.c
 * JetOS 자체 PML4/PDPT/PD 를 구성해 하위 4GiB를 2MiB 페이지로 항등
 * 매핑한다. 커널 이미지 자체 정적 배열로 테이블을 확보해 PMM 부트스트랩
 * 순서에 의존하지 않는다.
 *
 * Milestone 15: 프로세스별 주소공간(per-process page table) 지원 추가.
 *
 * 설계: 커널 영역(0~4GiB, 위의 g_pd 2MiB 매핑)은 모든 프로세스가
 * "공유"한다 — U비트 없이(Ring0 전용) 그대로 유지한다. 각 프로세스는
 * 자기 전용 PML4 + PDPT를 새로 받되, PDPT의 0~3번 슬롯(=커널 identity
 * 영역)은 전부 이 파일의 공유 g_pd[]를 그대로 가리키게 해서 커널
 * 코드/데이터에 항상 접근 가능하게 하고, PDPT의 4번 슬롯(가상주소
 * 4GiB~4GiB+2MiB = "유저 영역")만 그 프로세스 전용 PD+PT로 채운다.
 * 그 PT의 각 엔트리에만 U비트를 켜서, "이 프로세스가 로드한 ELF
 * 세그먼트/스택 페이지"만 Ring3에서 접근 가능하고 나머지(커널 전체)는
 * 여전히 Ring0 전용으로 남는다 — Milestone 14의 "전체 항등 매핑에
 * U비트"였던 단순화(보안 구멍)를 여기서 제대로 고친 것이다.
 *
 * 알려진 단순화: CR3 전환은 스레드 전환기(scheduler.c)와 아직 완전히
 * 일반화되어 있지 않다 — "여러 유저 프로세스 동시 실행"은 Milestone 16
 * 이후 지원되지만, 프로세스 종료 시 페이지/PT 반납(free) 로직은 아직
 * 없다(프로세스가 죽어도 그 물리 페이지들은 회수되지 않고 남는다 —
 * 다음 과제). 유저 영역 크기는 Milestone 20에서 2MiB 고정을 16MiB
 * (SYS_BRK로 필요한 만큼만 실제 매핑)로 확장했다.
 */

#include "vmm.h"
#include "../hal/x86_asm_shim.h"
#include "pmm.h"

#define PAGE_PRESENT  0x1ULL
#define PAGE_WRITABLE 0x2ULL
#define PAGE_USER     0x4ULL
#define PAGE_SIZE_2MB 0x80ULL

#define VMM_IDENTITY_GB 4

/* 유저 영역: PDPT 슬롯 4 = 가상주소 4GiB부터 시작하는 구간.
 * Milestone 20: 프로세스당 2MiB 고정이던 걸 16MiB(PD 엔트리 8개 =
 * PT 8개)로 늘렸다 — SYS_BRK로 필요한 만큼만 실제 매핑하고, 나머지는
 * "예약만 해둔 가상주소 공간"으로 남아있는 전형적인 brk 방식이다. */
#define VMM_USER_PDPT_SLOT 4
#define VMM_USER_VIRT_BASE (4ULL * 1024 * 1024 * 1024)
#define VMM_USER_CHUNK_SIZE (2ULL * 1024 * 1024) /* PD 엔트리 1개 = PT 1개 분량 */
#define VMM_USER_NUM_CHUNKS 8
#define VMM_USER_REGION_SIZE (VMM_USER_CHUNK_SIZE * VMM_USER_NUM_CHUNKS) /* = 16MiB */

/* Milestone 38: 4GiB 위 MMIO를 위한 전용 창(window). PDPT 슬롯 5 =
 * 가상주소 5GiB부터 최대 1GiB(2MiB 페이지 512개)까지 예약 — virtio
 * 장치의 64비트 BAR 몇 개 매핑하는 용도로는 차고 넘친다. */
#define VMM_MMIO_PDPT_SLOT 5
#define VMM_MMIO_VIRT_BASE (5ULL * 1024 * 1024 * 1024)
#define VMM_MMIO_CHUNK_SIZE (2ULL * 1024 * 1024)
#define VMM_MMIO_NUM_CHUNKS 512

static uint64_t g_pml4[512] __attribute__((aligned(4096)));
static uint64_t g_pdpt[512] __attribute__((aligned(4096)));
static uint64_t g_pd[VMM_IDENTITY_GB][512] __attribute__((aligned(4096)));
static uint64_t g_mmio_pd[VMM_MMIO_NUM_CHUNKS] __attribute__((aligned(4096)));
static int g_mmio_next_chunk = 0; /* 다음에 쓸 g_mmio_pd[] 인덱스(단순 범프 할당자) */

void vmm_init(void) {
    for (int i = 0; i < 512; i++) { g_pml4[i] = 0; g_pdpt[i] = 0; g_mmio_pd[i] = 0; }

    g_pml4[0] = ((uint64_t)&g_pdpt[0]) | PAGE_PRESENT | PAGE_WRITABLE;

    for (int gb = 0; gb < VMM_IDENTITY_GB; gb++) {
        g_pdpt[gb] = ((uint64_t)&g_pd[gb][0]) | PAGE_PRESENT | PAGE_WRITABLE;
        for (int e = 0; e < 512; e++) {
            uint64_t phys = ((uint64_t)gb * 1024ULL * 1024ULL * 1024ULL) +
                             ((uint64_t)e * 2ULL * 1024ULL * 1024ULL);
            g_pd[gb][e] = phys | PAGE_PRESENT | PAGE_WRITABLE | PAGE_SIZE_2MB;
        }
    }

    /* MMIO 창의 PD 자체는 미리 붙여둔다(테이블 자체는 항상 존재 —
     * 개별 엔트리는 실제로 vmm_map_mmio()가 호출될 때만 present가 된다.
     * 매핑 안 된 슬롯을 건드리면 정상적으로 페이지 폴트가 나야 하므로
     * 0으로 초기화된 채(=not present) 둔다). */
    g_pdpt[VMM_MMIO_PDPT_SLOT] = ((uint64_t)&g_mmio_pd[0]) | PAGE_PRESENT | PAGE_WRITABLE;

    hal_write_cr3((uint64_t)&g_pml4[0]);
}

uint64_t vmm_kernel_pml4_phys(void) {
    return (uint64_t)&g_pml4[0];
}

uint64_t vmm_user_virt_base(void) {
    return VMM_USER_VIRT_BASE;
}

uint64_t vmm_user_region_size(void) {
    return VMM_USER_REGION_SIZE;
}

uint64_t vmm_create_process_address_space(void) {
    uint64_t pml4_phys = pmm_alloc_page();
    uint64_t pdpt_phys = pmm_alloc_page();
    uint64_t pd_phys    = pmm_alloc_page();
    if (!pml4_phys || !pdpt_phys || !pd_phys) return 0;

    uint64_t *pml4 = (uint64_t *)pml4_phys;
    uint64_t *pdpt = (uint64_t *)pdpt_phys;
    uint64_t *pd   = (uint64_t *)pd_phys;

    for (int i = 0; i < 512; i++) { pml4[i] = 0; pdpt[i] = 0; pd[i] = 0; }

    /* PML4[0]는 U비트를 켜야 한다 — 그래야 아래쪽 유저 영역(PDPT 슬롯 4)
     * 경로에서 U비트가 실제로 효력을 갖는다(경로상의 모든 레벨이
     * U=1이어야 Ring3 접근이 허용됨). 커널 identity 영역(PDPT 슬롯
     * 0~3)은 그 아래 g_pd[] 엔트리 자체가 여전히 U=0이므로, PML4[0]의
     * U비트가 켜져 있어도 커널 메모리가 새어나가지 않는다. */
    pml4[0] = pdpt_phys | PAGE_PRESENT | PAGE_WRITABLE | PAGE_USER;

    /* 커널 identity 영역은 공유 g_pd[]를 그대로 재사용(복사 아님) —
     * 새 페이지를 안 만드니 메모리도 절약되고, 커널 코드/데이터는
     * 항상 최신 상태로 보인다. U비트 없이 그대로. */
    for (int gb = 0; gb < VMM_IDENTITY_GB; gb++) {
        pdpt[gb] = ((uint64_t)&g_pd[gb][0]) | PAGE_PRESENT | PAGE_WRITABLE;
    }

    /* 유저 영역(슬롯 4) — Milestone 20: PD 엔트리(=PT) 8개를 전부
     * 지금 마련해둔다(16MiB 전체를 "매핑 가능하게 예약"). 실제 물리
     * 페이지 연결은 여전히 vmm_map_user_page()가 필요할 때만(ELF 세그먼트
     * 로드 시, 그리고 SYS_BRK로 커질 때) 이뤄진다 — PT 자체를 미리
     * 만들어두는 것과 그 안의 개별 엔트리(present 비트)를 채우는 것은
     * 별개다. PT 8개 = 물리 페이지 8개, 16MiB짜리 유저 프로세스마다
     * 매번 드는 고정비용이라 크지 않다. */
    pdpt[VMM_USER_PDPT_SLOT] = pd_phys | PAGE_PRESENT | PAGE_WRITABLE | PAGE_USER;
    for (int chunk = 0; chunk < VMM_USER_NUM_CHUNKS; chunk++) {
        uint64_t pt_phys = pmm_alloc_page();
        if (!pt_phys) return 0; /* 이미 할당된 페이지들은 프로세스 종료 시 정리 대상(향후 과제) */
        uint64_t *pt = (uint64_t *)pt_phys;
        for (int i = 0; i < 512; i++) pt[i] = 0;
        pd[chunk] = pt_phys | PAGE_PRESENT | PAGE_WRITABLE | PAGE_USER;
    }

    /* Milestone 38: MMIO 창(슬롯 5)도 커널 identity 영역(슬롯 0~3)과
     * 완전히 같은 이유로 공유 g_mmio_pd[]를 그대로 재사용한다 — U비트
     * 없이(Ring0 전용), 그래야 이 프로세스로 전환된 뒤에도 인터럽트
     * 핸들러나 커널 코드가 드라이버 MMIO에 계속 접근할 수 있다. */
    pdpt[VMM_MMIO_PDPT_SLOT] = ((uint64_t)&g_mmio_pd[0]) | PAGE_PRESENT | PAGE_WRITABLE;

    return pml4_phys;
}

int vmm_map_user_page(uint64_t pml4_phys, uint64_t vaddr, uint64_t paddr, int writable) {
    if (vaddr < VMM_USER_VIRT_BASE || vaddr >= VMM_USER_VIRT_BASE + VMM_USER_REGION_SIZE) return 0;
    if (vaddr % PMM_PAGE_SIZE != 0) return 0;

    uint64_t *pml4 = (uint64_t *)pml4_phys;
    uint64_t pdpt_phys = pml4[0] & ~0xFFFULL;
    uint64_t *pdpt = (uint64_t *)pdpt_phys;
    uint64_t pd_phys = pdpt[VMM_USER_PDPT_SLOT] & ~0xFFFULL;
    uint64_t *pd = (uint64_t *)pd_phys;

    uint64_t offset = vaddr - VMM_USER_VIRT_BASE;
    uint64_t chunk = offset / VMM_USER_CHUNK_SIZE;
    uint64_t offset_in_chunk = offset % VMM_USER_CHUNK_SIZE;
    if (chunk >= VMM_USER_NUM_CHUNKS) return 0;

    uint64_t pt_phys = pd[chunk] & ~0xFFFULL;
    uint64_t *pt = (uint64_t *)pt_phys;
    uint64_t pt_index = offset_in_chunk / PMM_PAGE_SIZE;
    if (pt_index >= 512) return 0;

    uint64_t flags = PAGE_PRESENT | PAGE_USER;
    if (writable) flags |= PAGE_WRITABLE;
    pt[pt_index] = (paddr & ~0xFFFULL) | flags;

    /* TLB에 이 가상주소의 옛 매핑이 캐시돼 있을 수 있으니 무효화 */
    __asm__ volatile ("invlpg (%0)" : : "r"(vaddr) : "memory");
    return 1;
}

uint64_t vmm_map_mmio(uint64_t phys_addr, uint64_t size) {
    if (size == 0) return 0;

    uint64_t aligned_phys = phys_addr & ~(VMM_MMIO_CHUNK_SIZE - 1);
    uint64_t offset_in_chunk = phys_addr - aligned_phys;
    uint64_t span_bytes = offset_in_chunk + size;
    uint64_t span_chunks = (span_bytes + VMM_MMIO_CHUNK_SIZE - 1) / VMM_MMIO_CHUNK_SIZE;

    if (g_mmio_next_chunk < 0 || (uint64_t)g_mmio_next_chunk + span_chunks > VMM_MMIO_NUM_CHUNKS) {
        return 0; /* 예약해둔 1GiB 창을 이미 다 씀 */
    }

    int start_chunk = g_mmio_next_chunk;
    for (uint64_t c = 0; c < span_chunks; c++) {
        uint64_t chunk_phys = aligned_phys + c * VMM_MMIO_CHUNK_SIZE;
        g_mmio_pd[start_chunk + c] = chunk_phys | PAGE_PRESENT | PAGE_WRITABLE | PAGE_SIZE_2MB;
        uint64_t chunk_vaddr = VMM_MMIO_VIRT_BASE + (uint64_t)(start_chunk + c) * VMM_MMIO_CHUNK_SIZE;
        __asm__ volatile ("invlpg (%0)" : : "r"(chunk_vaddr) : "memory");
    }
    g_mmio_next_chunk += (int)span_chunks;

    return VMM_MMIO_VIRT_BASE + (uint64_t)start_chunk * VMM_MMIO_CHUNK_SIZE + offset_in_chunk;
}
