#ifndef JETOS_TLS_PRF_H
#define JETOS_TLS_PRF_H

/* JetOS - kernel/net/crypto/tls_prf.h - TLS 1.2 PRF (RFC 5246 5절).
 * P_hash(secret, seed) = HMAC(secret, A(1)+seed) + HMAC(secret, A(2)+seed) + ...
 * A(0)=seed, A(i)=HMAC(secret, A(i-1)). TLS 1.2는 항상 SHA-256 기반. */

#include <stdint.h>
#include <stddef.h>

void tls_prf(const uint8_t *secret, size_t secret_len,
             const char *label,
             const uint8_t *seed, size_t seed_len,
             uint8_t *out, size_t out_len);

#endif
