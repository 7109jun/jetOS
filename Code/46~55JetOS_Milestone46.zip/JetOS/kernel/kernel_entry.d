kernel/kernel_entry.o: kernel/kernel_entry.c kernel/kernel_entry.h \
 kernel/../include/jetos/boot_info.h kernel/../include/jetos/../efi/efi.h \
 kernel/kernel.h kernel/drivers/console.h kernel/drivers/serial.h \
 kernel/mm/memmap.h kernel/mm/../../include/efi/efi.h kernel/mm/pmm.h \
 kernel/mm/vmm.h kernel/mm/heap.h kernel/int/idt.h kernel/int/pic.h \
 kernel/int/pit.h kernel/hal/x86_asm_shim.h kernel/proc/thread.h \
 kernel/proc/scheduler.h kernel/proc/thread.h kernel/proc/process.h \
 kernel/proc/ipc.h kernel/drivers/ahci.h kernel/drivers/virtio_gpu.h \
 kernel/drivers/virtio_input.h kernel/fs/jetfs.h kernel/fs/perm.h \
 kernel/fs/recyclebin.h kernel/hal/power.h kernel/fs/config.h \
 kernel/fs/vfs.h kernel/fs/fat32.h kernel/shell/terminal.h \
 kernel/gui/desktop.h kernel/net/net.h kernel/net/tcp.h kernel/net/dns.h \
 kernel/net/tls.h kernel/hal/gdt.h kernel/hal/ring3_test.h \
 kernel/exec/elf_loader.h
kernel/kernel_entry.h:
kernel/../include/jetos/boot_info.h:
kernel/../include/jetos/../efi/efi.h:
kernel/kernel.h:
kernel/drivers/console.h:
kernel/drivers/serial.h:
kernel/mm/memmap.h:
kernel/mm/../../include/efi/efi.h:
kernel/mm/pmm.h:
kernel/mm/vmm.h:
kernel/mm/heap.h:
kernel/int/idt.h:
kernel/int/pic.h:
kernel/int/pit.h:
kernel/hal/x86_asm_shim.h:
kernel/proc/thread.h:
kernel/proc/scheduler.h:
kernel/proc/thread.h:
kernel/proc/process.h:
kernel/proc/ipc.h:
kernel/drivers/ahci.h:
kernel/drivers/virtio_gpu.h:
kernel/drivers/virtio_input.h:
kernel/fs/jetfs.h:
kernel/fs/perm.h:
kernel/fs/recyclebin.h:
kernel/hal/power.h:
kernel/fs/config.h:
kernel/fs/vfs.h:
kernel/fs/fat32.h:
kernel/shell/terminal.h:
kernel/gui/desktop.h:
kernel/net/net.h:
kernel/net/tcp.h:
kernel/net/dns.h:
kernel/net/tls.h:
kernel/hal/gdt.h:
kernel/hal/ring3_test.h:
kernel/exec/elf_loader.h:
