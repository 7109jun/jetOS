#include "projectgen.hpp"
#include <filesystem>
#include <fstream>
#include <string>
namespace fs=std::filesystem; namespace deiig::projectgen {
static void w(const fs::path&p,const std::string&s){fs::create_directories(p.parent_path());std::ofstream(p)<<s;}
int create(const std::string&t,const std::string&d){fs::path r=d;if(fs::exists(r)&&!fs::is_empty(r))return 2;fs::create_directories(r);if(t=="cpp"){w(r/"CMakeLists.txt","cmake_minimum_required(VERSION 3.20)\nproject(App LANGUAGES CXX)\nset(CMAKE_CXX_STANDARD 20)\nadd_executable(App src/main.cpp)\n");w(r/"src/main.cpp","#include <iostream>\nint main(){std::cout<<\"Hello from DEIIG\\n\";return 0;}\n");}
else if(t=="digg"){w(r/"main.diggcode","fn main() {\n    println(\"Hello from DIGG\");\n}\n");}
else if(t=="web"){w(r/"index.html","<!doctype html><html><head><meta charset=\"utf-8\"><title>DEIIG Web</title></head><body><h1>DEIIG Web Project</h1></body></html>\n");}
else if(t=="empty"){} else return 1;
    return 0;
}
}
