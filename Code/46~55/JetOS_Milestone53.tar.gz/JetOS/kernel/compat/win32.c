/*
 * JetOS - kernel/compat/win32.c
 * win32.h에 선언된 함수들의 구현. 전부 JetAPI 호출로 위임된다.
 *
 * 중요: 여기 정의된 모든 함수는 win32.h에서 WINAPI(=ms_abi)로 선언되어
 * 있다. PE32+ EXE가 IAT를 통해 이 함수들을 직접 호출하므로, 정의도
 * 반드시 선언과 동일하게 ms_abi여야 한다 (그렇지 않으면 링크는 되지만
 * 실행 시 인자가 전부 엉뚱한 레지스터에서 읽혀 조용히 깨진다).
 */

#include <stddef.h>
#include "win32.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../proc/thread.h"
#include "../proc/scheduler.h"
#include "../drivers/serial.h" /* Milestone 49: 콘솔 stdout/stderr를 시리얼로 배선 */
#include "../drivers/keyboard.h" /* Milestone 49: ReadConsoleA */
#include "../mm/heap.h"
#include "../fs/jetfs.h"

#define MAX_HANDLES 16

/* Milestone 49: 표준 핸들을 파일 핸들(1..MAX_HANDLES, CreateFileA가 씀)
 * 범위와 절대 겹치지 않는 매직 값으로 표현. */
#define CONSOLE_OUT_HANDLE ((HANDLE)(intptr_t)0x40000001)
#define CONSOLE_ERR_HANDLE ((HANDLE)(intptr_t)0x40000002)
#define CONSOLE_IN_HANDLE  ((HANDLE)(intptr_t)0x40000003)

static DWORD g_last_error = 0; /* Milestone 49: SetLastError/GetLastError */

typedef struct {
    int used;
    char path[64];
} file_handle_t;

static file_handle_t g_handles[MAX_HANDLES];

static void str_copy(char *dst, const char *src, int max) {
    int i = 0;
    for (; i < max - 1 && src[i]; i++) dst[i] = src[i];
    dst[i] = '\0';
}

HWND WINAPI CreateWindowA(LPCSTR title, int x, int y, int w, int h, DWORD color_as_style_placeholder) {
    uint32_t color = color_as_style_placeholder ? color_as_style_placeholder : 0x00304050;
    int idx = CreateWindowJ(title, x, y, w, h, color);
    if (idx < 0) return NULL_HANDLE;
    wm_set_win32_style(idx, 1); /* Win32 호환 레이어로 만든 창은 클래식 Windows 스타일로 표시 */
    return (HANDLE)(intptr_t)(idx + 1); /* 0을 "실패"로 예약하기 위해 +1 */
}

/* ---- MessageBoxA: 실제로 text/title을 표시하는 작은 창 ----
 * 최대 몇 개까지 동시에 떠 있을 수 있도록 텍스트를 별도 풀에 보관해
 * content 콜백이 창이 그려질 때마다 참조하게 한다 (진짜 모달 잠금은
 * WM에 포커스-락 개념이 추가되는 이후 마일스톤 과제로 남겨둔다). */
#define MAX_MSGBOXES 8
typedef struct { int used; char text[128]; } msgbox_slot_t;
static msgbox_slot_t g_msgboxes[MAX_MSGBOXES];

static void msgbox_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)h;
    int slot = (int)(intptr_t)ctx;
    dc->cursor_x = (uint32_t)(x + 10);
    dc->cursor_y = (uint32_t)(y + 12);
    if (slot >= 0 && slot < MAX_MSGBOXES && g_msgboxes[slot].used) {
        console_print(dc, g_msgboxes[slot].text);
    }
}

int WINAPI MessageBoxA(HWND owner, LPCSTR text, LPCSTR title, DWORD type) {
    (void)owner; (void)type;
    int slot = -1;
    for (int i = 0; i < MAX_MSGBOXES; i++) {
        if (!g_msgboxes[i].used) { slot = i; break; }
    }
    int win = CreateWindowJ(title ? title : "MESSAGE", 400, 300, 320, 100, 0x00504030);
    if (win >= 0 && slot >= 0) {
        g_msgboxes[slot].used = 1;
        str_copy(g_msgboxes[slot].text, text ? text : "", sizeof(g_msgboxes[slot].text));
        wm_set_content_callback(win, msgbox_content_cb, (void *)(intptr_t)slot);
        wm_set_win32_style(win, 1);
    }
    return win >= 0 ? 1 : 0;
}

HANDLE WINAPI CreateFileA(LPCSTR path, DWORD desired_access, DWORD share_mode,
                    void *security_attrs, DWORD creation_disposition,
                    DWORD flags, HANDLE template_file) {
    (void)desired_access; (void)share_mode; (void)security_attrs;
    (void)creation_disposition; (void)flags; (void)template_file;

    for (int i = 0; i < MAX_HANDLES; i++) {
        if (!g_handles[i].used) {
            CreateFileJ(path, 0); /* 없으면 생성, 있으면 무시 */
            g_handles[i].used = 1;
            str_copy(g_handles[i].path, path, sizeof(g_handles[i].path));
            return (HANDLE)(intptr_t)(i + 1);
        }
    }
    return NULL_HANDLE;
}

BOOL WINAPI ReadFile(HANDLE file, LPVOID buffer, DWORD bytes_to_read, DWORD *bytes_read, void *overlapped) {
    (void)overlapped;
    int idx = (int)(intptr_t)file - 1;
    if (idx < 0 || idx >= MAX_HANDLES || !g_handles[idx].used) return FALSE;
    uint64_t out = 0;
    int ok = ReadFileJ(g_handles[idx].path, buffer, bytes_to_read, &out);
    if (bytes_read) *bytes_read = (DWORD)out;
    return ok ? TRUE : FALSE;
}

BOOL WINAPI WriteFile(HANDLE file, LPCVOID buffer, DWORD bytes_to_write, DWORD *bytes_written, void *overlapped) {
    (void)overlapped;
    /* Milestone 49: 콘솔 표준 핸들이면 파일이 아니라 콘솔로 — 지금은
     * "콘솔 = 시리얼"로 배선한다(GUI 창에 실제로 붙이는 건 exe를 실행한
     * jash 창의 컨텍스트가 필요해 범위 밖으로 남김, 아래 주석 참고).
     * 실제 바이트 수만큼만(널 종단 가정 안 함) 쓴다. */
    if (file == CONSOLE_OUT_HANDLE || file == CONSOLE_ERR_HANDLE) {
        const char *p = (const char *)buffer;
        for (DWORD i = 0; i < bytes_to_write; i++) serial_putc(p[i]);
        if (bytes_written) *bytes_written = bytes_to_write;
        return TRUE;
    }
    int idx = (int)(intptr_t)file - 1;
    if (idx < 0 || idx >= MAX_HANDLES || !g_handles[idx].used) return FALSE;
    int ok = WriteFileJ(g_handles[idx].path, buffer, bytes_to_write);
    if (bytes_written) *bytes_written = ok ? bytes_to_write : 0;
    return ok ? TRUE : FALSE;
}

BOOL WINAPI CloseHandle(HANDLE h) {
    if (h == CONSOLE_OUT_HANDLE || h == CONSOLE_ERR_HANDLE || h == CONSOLE_IN_HANDLE) return TRUE;
    int idx = (int)(intptr_t)h - 1;
    if (idx < 0 || idx >= MAX_HANDLES) return FALSE;
    g_handles[idx].used = 0;
    return TRUE;
}

DWORD WINAPI GetFileSize(HANDLE file, DWORD *high) {
    if (high) *high = 0;
    int idx = (int)(intptr_t)file - 1;
    if (idx < 0 || idx >= MAX_HANDLES || !g_handles[idx].used) return 0xFFFFFFFFu;
    /* JetAPI에는 별도 stat이 없으므로 최대 크기 버퍼로 한번 읽어
     * out_size만 취한다 (작은 EXE의 GetFileSize 정도 용도로는 충분). */
    uint8_t tmp[4096];
    uint64_t out = 0;
    if (!ReadFileJ(g_handles[idx].path, tmp, sizeof(tmp), &out)) return 0xFFFFFFFFu;
    return (DWORD)out;
}

LPVOID WINAPI VirtualAlloc(LPVOID addr, uint32_t size, DWORD alloc_type, DWORD protect) {
    (void)addr; (void)alloc_type; (void)protect;
    return VirtualAllocJ(size);
}

BOOL WINAPI VirtualFree(LPVOID addr, uint32_t size, DWORD free_type) {
    (void)size; (void)free_type;
    VirtualFreeJ(addr);
    return TRUE;
}

HANDLE WINAPI GetStdHandle(DWORD std_handle) {
    /* Milestone 49: 이전엔 항상 같은 더미 값을 반환해서 stdout/stdin을
     * 구분 못 했다 — 이제 실제로 구분되는 핸들을 준다(WriteFile/
     * ReadConsoleA가 이 값을 보고 분기). 알 수 없는 값이 들어오면
     * (구버전 동작 유지) 여전히 "유효해 보이는" 더미를 반환해 EXE가
     * 널 체크만으로 실패 판정하지 않게 한다. */
    if (std_handle == STD_OUTPUT_HANDLE) return CONSOLE_OUT_HANDLE;
    if (std_handle == STD_ERROR_HANDLE) return CONSOLE_ERR_HANDLE;
    if (std_handle == STD_INPUT_HANDLE) return CONSOLE_IN_HANDLE;
    return (HANDLE)(intptr_t)0x1000;
}

/* Milestone 49: WriteConsoleA는 콘솔 프로그램이 WriteFile 대신 흔히
 * 쓰는 별칭 — 문자 수(바이트 아님, 하지만 우리는 ANSI만 다뤄서 동일)
 * 단위라는 차이만 있고 동작은 WriteFile의 콘솔 분기와 같다. */
BOOL WINAPI WriteConsoleA(HANDLE console, LPCVOID buffer, DWORD chars_to_write,
                          DWORD *chars_written, void *reserved) {
    (void)reserved;
    const char *p = (const char *)buffer;
    for (DWORD i = 0; i < chars_to_write; i++) serial_putc(p[i]);
    if (chars_written) *chars_written = chars_to_write;
    (void)console;
    return TRUE;
}

/* Milestone 49: 콘솔에서 한 줄 읽기. 실제 PS/2 키보드 링버퍼
 * (keyboard_poll_char)를 그대로 소비한다 — Enter를 만나면 그 자리에서
 * 끊고(개행은 버퍼에 포함, 실제 ReadConsoleA 관례와 동일), 버퍼가
 * 다 차거나 요청 문자 수를 채우면 멈춘다. 입력이 아직 없으면 들어올
 * 때까지 양보(scheduler_yield)하며 기다린다(블로킹 — 실제
 * ReadConsoleA와 같은 동기 호출). */
BOOL WINAPI ReadConsoleA(HANDLE console, LPVOID buffer, DWORD chars_to_read,
                         DWORD *chars_read, void *input_control) {
    (void)console; (void)input_control;
    char *out = (char *)buffer;
    DWORD n = 0;
    while (n < chars_to_read) {
        char c = keyboard_poll_char();
        if (!c) { scheduler_yield(); continue; }
        if (c == '\b') { if (n > 0) n--; continue; } /* 최소한의 백스페이스 처리 */
        out[n++] = c;
        if (c == '\n') break;
    }
    if (chars_read) *chars_read = n;
    return TRUE;
}

/* Milestone 49: PIT 틱 기반 근사치(실제 Windows GetTickCount와 같은
 * 단위인 "부팅 후 경과 ms"). pit.h의 틱 카운터를 그대로 재사용. */
#include "../int/pit.h"
DWORD WINAPI GetTickCount(void) {
    return (DWORD)(g_timer_ticks * 10); /* Milestone 34 주석 관례: 100Hz PIT → 1틱=10ms */
}

/* Milestone 52: 진짜 커맨드라인 인자 전달(elf_loader의 M44 argv 작업과
 * 같은 정신을 PE 쪽에도 적용). jash의 run 명령이 pe_execute(path,
 * cmdline)로 넘긴 문자열을 pe_loader.c가 win32_set_cmdline으로
 * 저장해두면, GetCommandLineA와 msvcrt.c의 __getmainargs가 여기서
 * 읽어간다. 따옴표로 감싼 인자("hello world") 같은 건 처리 안
 * 한다(정직한 한계) — 공백으로만 나눈다. */
#define MAX_PE_ARGV 16
#define PE_ARGV_BUF_SIZE 512
static char g_pe_cmdline[PE_ARGV_BUF_SIZE] = "";
static char g_pe_argv_buf[PE_ARGV_BUF_SIZE];
static char *g_pe_argv[MAX_PE_ARGV + 1];
static int g_pe_argc = 0;

void win32_set_cmdline(const char *prog_path, const char *args) {
    /* GetCommandLineA 관례: 전체 문자열 = "프로그램경로 인자들" */
    int n = 0;
    for (int i = 0; prog_path[i] && n < PE_ARGV_BUF_SIZE - 1; i++) g_pe_cmdline[n++] = prog_path[i];
    if (args && args[0]) {
        if (n < PE_ARGV_BUF_SIZE - 1) g_pe_cmdline[n++] = ' ';
        for (int i = 0; args[i] && n < PE_ARGV_BUF_SIZE - 1; i++) g_pe_cmdline[n++] = args[i];
    }
    g_pe_cmdline[n] = '\0';

    /* argv 파싱: 공백으로 분리(연속 공백은 하나로 취급), 따옴표 미지원. */
    g_pe_argc = 0;
    int bi = 0;
    const char *p = prog_path;
    while (*p && g_pe_argc < MAX_PE_ARGV) {
        int start = bi;
        while (*p && *p != ' ' && bi < PE_ARGV_BUF_SIZE - 1) g_pe_argv_buf[bi++] = *p++;
        g_pe_argv_buf[bi++] = '\0';
        g_pe_argv[g_pe_argc++] = &g_pe_argv_buf[start];
        break; /* prog_path 전체를 argv[0] 하나로(경로 자체에 공백 없다고 가정) */
    }
    p = args;
    while (p && *p) {
        while (*p == ' ') p++;
        if (!*p) break;
        int start = bi;
        while (*p && *p != ' ' && bi < PE_ARGV_BUF_SIZE - 1) g_pe_argv_buf[bi++] = *p++;
        g_pe_argv_buf[bi++] = '\0';
        if (g_pe_argc < MAX_PE_ARGV) g_pe_argv[g_pe_argc++] = &g_pe_argv_buf[start];
    }
    g_pe_argv[g_pe_argc] = (char *)0;
}

int win32_get_argv(char ***out_argv) {
    *out_argv = g_pe_argv;
    return g_pe_argc;
}

WINAPI LPCSTR GetCommandLineA(void) {
    return g_pe_cmdline;
}

/* Milestone 49: 모듈 핸들. 진짜 PE 매핑 정보를 추적하지 않으므로
 * "0이 아닌 뭔가"만 돌려준다(EXE가 자기 자신을 가리키는 용도로
 * NULL을 넘기는 경우가 대부분이라 이걸로 충분한 경우가 많음). */
WINAPI HANDLE GetModuleHandleA(LPCSTR module_name) {
    (void)module_name;
    return (HANDLE)(intptr_t)0x400000; /* 관례적인 기본 PE 이미지 베이스와 같은 모양의 더미 값 */
}

/* Milestone 49: 런타임에 함수 이름으로 포인터를 찾는 GetProcAddress.
 * pe_loader.c의 정적 IAT 연결과 같은 스텁 테이블을 쓰고 싶지만
 * find_stub은 pe_loader.c 안에 static이라 여기서는 볼 수 없다 —
 * 대신 win32.c가 아는 함수들만 별도의 작은 테이블로 취급한다. 이
 * 테이블에 없는 이름은 NULL을 반환(진짜 GetProcAddress와 동일한
 * "실패" 표현이라 호출자가 널 체크로 정상적으로 분기 가능). */
typedef struct { const char *name; void *fn; } gpa_entry_t;
static const gpa_entry_t g_gpa_table[] = {
    { "GetTickCount", (void *)GetTickCount },
    { "GetStdHandle", (void *)GetStdHandle },
    { "WriteFile", (void *)WriteFile },
    { "WriteConsoleA", (void *)WriteConsoleA },
    { "ReadConsoleA", (void *)ReadConsoleA },
    { "ExitProcess", (void *)ExitProcess },
    { "Sleep", (void *)Sleep },
};
#define GPA_COUNT (sizeof(g_gpa_table)/sizeof(g_gpa_table[0]))
static int str_eq_i2(const char *a, const char *b) {
    while (*a && *b) {
        char ca = *a, cb = *b;
        if (ca >= 'A' && ca <= 'Z') ca += 32;
        if (cb >= 'A' && cb <= 'Z') cb += 32;
        if (ca != cb) return 0;
        a++; b++;
    }
    return *a == *b;
}
WINAPI void *GetProcAddress(HANDLE module, LPCSTR proc_name) {
    (void)module;
    for (unsigned i = 0; i < GPA_COUNT; i++) {
        if (str_eq_i2(g_gpa_table[i].name, proc_name)) return g_gpa_table[i].fn;
    }
    return NULL;
}

/* Milestone 49: HeapAlloc류. 진짜 힙 오브젝트를 여러 개 관리하지
 * 않고(GetProcessHeap이 유일한 힙을 나타내는 더미 핸들 하나만 줌),
 * 실제 할당/해제는 커널 kmalloc/kfree에 그대로 위임 — VirtualAlloc이
 * JetAPI의 VirtualAllocJ(=kmalloc)에 위임하는 것과 같은 이유(Milestone
 * 6 설계 그대로 확장). */
WINAPI HANDLE GetProcessHeap(void) {
    return (HANDLE)(intptr_t)0x1; /* 힙 핸들은 하나뿐이라 값 자체엔 의미 없음 */
}
WINAPI LPVOID HeapAlloc(HANDLE heap, DWORD flags, uint32_t size) {
    (void)heap;
    void *p = kmalloc(size);
    if (p && (flags & HEAP_ZERO_MEMORY)) {
        uint8_t *b = (uint8_t *)p;
        for (uint32_t i = 0; i < size; i++) b[i] = 0;
    }
    return p;
}
WINAPI BOOL HeapFree(HANDLE heap, DWORD flags, LPVOID mem) {
    (void)heap; (void)flags;
    if (mem) kfree(mem);
    return TRUE;
}

WINAPI char *lstrcpyA(char *dst, LPCSTR src) {
    char *d = dst;
    while ((*d++ = *src++)) {}
    return dst;
}
WINAPI char *lstrcatA(char *dst, LPCSTR src) {
    char *d = dst;
    while (*d) d++;
    while ((*d++ = *src++)) {}
    return dst;
}

WINAPI void SetLastError(DWORD err) { g_last_error = err; }
WINAPI DWORD GetLastError(void) { return g_last_error; }

/* Milestone 49: 디버그 출력 — 진짜 디버거가 없으니 시리얼로. 개발 중
 * EXE가 OutputDebugStringA로 남기는 로그를 확인할 수 있어 PE 쪽
 * 자체테스트/디버깅에 바로 쓸모 있다. */
WINAPI void OutputDebugStringA(LPCSTR msg) {
    serial_write("[PE OutputDebugStringA] ");
    serial_write(msg ? msg : "(null)");
    serial_write("\n");
}

WINAPI BOOL DeleteFileA(LPCSTR path) {
    char real[128];
    /* CreateFileA와 같은 방식으로 JetAPI 델리게이션 — vfs 변환 없이
     * jetfs 직접 삭제만 지원(FAT32 대상은 스코프 밖, CreateFileA도
     * 마찬가지로 jetfs 전용). */
    int i = 0;
    while (path[i] && i < 127) { real[i] = path[i]; i++; }
    real[i] = '\0';
    return jetfs_delete(real) ? TRUE : FALSE;
}

WINAPI BOOL IsDebuggerPresent(void) { return FALSE; }

int WINAPI lstrlenA(LPCSTR s) {
    if (!s) return 0;
    int n = 0;
    while (s[n]) n++;
    return n;
}

void WINAPI Sleep(DWORD milliseconds) {
    /* 실제 타이머 기반 대기 대신, 밀리초당 한 번 정도로 substitute해
     * 스케줄러에 양보만 반복한다 (100Hz PIT라 1tick=10ms 근사). */
    uint32_t yields = milliseconds / 10;
    if (yields == 0) yields = 1;
    for (uint32_t i = 0; i < yields; i++) scheduler_yield();
}

__attribute__((noreturn))
void WINAPI ExitProcess(DWORD exit_code) {
    (void)exit_code;
    thread_exit();
}

/* Milestone 54: 진짜 멀티스레딩 — win32.h 상단 주석에 설계 이유 설명. */
typedef DWORD (WINAPI *win32_thread_proc_t)(LPVOID);
typedef struct {
    win32_thread_proc_t proc;
    LPVOID param;
} win32_thread_ctx_t;

static void win32_thread_trampoline(void *arg) {
    /* Milestone 54: thread_create가 기대하는 JetOS 네이티브 시그니처
     * void(*)(void*)와 Win32의 DWORD WINAPI ThreadProc(LPVOID) 사이의
     * 어댑터. 반환값은 지금은 어디에도 저장 안 함(GetExitCodeThread
     * 미구현 — 정직한 한계, WaitForSingleObject로 "끝났다"까지만 알 수
     * 있음). */
    win32_thread_ctx_t *ctx = (win32_thread_ctx_t *)arg;
    win32_thread_proc_t proc = ctx->proc;
    LPVOID param = ctx->param;
    kfree(ctx);
    proc(param);
    thread_exit();
}

HANDLE WINAPI CreateThread(void *sec_attrs, uint32_t stack_size, void *start_addr,
                           LPVOID param, DWORD creation_flags, DWORD *thread_id) {
    (void)sec_attrs; (void)stack_size; (void)creation_flags;
    win32_thread_ctx_t *ctx = (win32_thread_ctx_t *)kmalloc(sizeof(win32_thread_ctx_t));
    if (!ctx) return NULL;
    ctx->proc = (win32_thread_proc_t)start_addr;
    ctx->param = param;
    thread_t *t = thread_create("win32_thread", win32_thread_trampoline, ctx);
    if (!t) { kfree(ctx); return NULL; }
    if (thread_id) *thread_id = t->id;
    return (HANDLE)t; /* win32.h 주석 참고 — thread_t*를 그대로 핸들로 재사용 */
}

__attribute__((noreturn))
void WINAPI ExitThread(DWORD exit_code) {
    (void)exit_code;
    thread_exit();
    for (;;) {}
}

DWORD WINAPI WaitForSingleObject(HANDLE h, DWORD timeout_ms) {
    thread_t *t = (thread_t *)h;
    if (!t) return WAIT_OBJECT_0;
    uint32_t waited_ms = 0;
    while (t->state != THREAD_DEAD) {
        scheduler_yield();
        if (timeout_ms != INFINITE) {
            waited_ms += 1; /* 정확한 시간 측정이 아니라 "양보 1회 ~ 대략 1ms" 근사 — 정직한 한계 */
            if (waited_ms >= timeout_ms) return WAIT_TIMEOUT;
        }
    }
    return WAIT_OBJECT_0;
}

DWORD WINAPI GetCurrentThreadId(void) {
    thread_t *t = scheduler_current();
    return t ? t->id : 0;
}
