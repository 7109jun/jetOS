kernel/net/crypto/x509_min.o: kernel/net/crypto/x509_min.c \
 kernel/net/crypto/x509_min.h kernel/net/crypto/bignum.h \
 kernel/net/crypto/der.h kernel/net/crypto/sha256.h \
 kernel/net/crypto/rsa_pkcs1.h
kernel/net/crypto/x509_min.h:
kernel/net/crypto/bignum.h:
kernel/net/crypto/der.h:
kernel/net/crypto/sha256.h:
kernel/net/crypto/rsa_pkcs1.h:
