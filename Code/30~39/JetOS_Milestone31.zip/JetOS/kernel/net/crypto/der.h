#ifndef JETOS_DER_H
#define JETOS_DER_H

/*
 * JetOS - kernel/net/crypto/der.h
 * Milestone 19: X.509 인증서에서 RSA 공개키만 뽑아내는 데 필요한
 * 최소한의 DER(BER의 확정 길이 부분집합) TLV(Tag-Length-Value) 리더.
 * 완전한 ASN.1 파서가 아니다 — SEQUENCE 진입/스킵과 INTEGER/BIT STRING
 * 추출만 지원한다(x509_min.c가 필요한 전부).
 */

#include <stdint.h>
#include <stddef.h>

#define DER_TAG_INTEGER     0x02
#define DER_TAG_BITSTRING   0x03
#define DER_TAG_OCTETSTRING 0x04 /* Milestone 24: extnValue(OCTET STRING) 읽는 데 필요 */
#define DER_TAG_SEQUENCE    0x30

typedef struct {
    const uint8_t *p;
    const uint8_t *end;
} der_reader_t;

void der_init(der_reader_t *r, const uint8_t *buf, size_t len);

/* 현재 위치에서 TLV 하나를 읽고 r을 그 다음으로 전진시킨다.
 * 성공 시 1, 버퍼 끝/형식 오류면 0. */
int der_read_tlv(der_reader_t *r, uint8_t *tag, const uint8_t **val, size_t *vlen);

/* val/vlen(보통 SEQUENCE의 내용물)을 새 reader로 진입 */
void der_enter(der_reader_t *r, const uint8_t *val, size_t vlen);

#endif
