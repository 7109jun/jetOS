/* JetOS - kernel/net/crypto/rsa_pkcs1.c */
#include "rsa_pkcs1.h"
#include "rng.h"

int rsa_pkcs1_encrypt(const bignum_t *n, const bignum_t *e,
                       const uint8_t *msg, size_t mlen,
                       uint8_t *out, size_t modulus_bytes) {
    if (modulus_bytes < 11 || mlen > modulus_bytes - 11) return 0;
    if (modulus_bytes > BIGNUM_MAX_LIMBS * 4) return 0;

    uint8_t em[BIGNUM_MAX_LIMBS * 4];
    size_t ps_len = modulus_bytes - mlen - 3;

    em[0] = 0x00;
    em[1] = 0x02;
    /* PS: 0이 아닌 랜덤 바이트로 패딩(RFC 8017 7.2.1) */
    uint8_t rnd[BIGNUM_MAX_LIMBS * 4];
    rng_bytes(rnd, ps_len);
    for (size_t i = 0; i < ps_len; i++) {
        uint8_t b = rnd[i];
        if (b == 0) b = 0x5A; /* 0이 나오면 임의의 0 아닌 값으로 대체(균등성보다 "0 금지"가 핵심) */
        em[2 + i] = b;
    }
    em[2 + ps_len] = 0x00;
    for (size_t i = 0; i < mlen; i++) em[3 + ps_len + i] = msg[i];

    bignum_t m, c;
    bn_from_bytes_be(&m, em, modulus_bytes);
    bn_modexp(&c, &m, e, n);

    return bn_to_bytes_be(&c, out, modulus_bytes);
}
