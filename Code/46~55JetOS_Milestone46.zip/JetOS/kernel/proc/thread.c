/*
 * JetOS - kernel/proc/thread.c
 * 스레드 자료구조와 생성/종료. 새 스레드의 초기 스택은 switch_context()
 * 가 기대하는 레이아웃(콜리-세이브 레지스터 6개 + 복귀주소)에 맞춰
 * "이미 한 번 전환된 것처럼" 미리 조작해 둔다 — 이렇게 하면 스케줄러
 * 입장에서 "새 스레드로 전환"과 "기존 스레드로 복귀"가 완전히 동일한
 * switch_context() 호출 하나로 처리된다.
 */

#include "thread.h"
#include "scheduler.h"
#include "../mm/heap.h"
#include "../drivers/serial.h"

static uint32_t g_next_thread_id = 1;

static void thread_trampoline(void); /* 아래 정의, 새 스레드가 최초 실행을 시작하는 지점 */

thread_t *thread_create(const char *name, void (*entry)(void *arg), void *arg) {
    thread_t *t = (thread_t *)kmalloc(sizeof(thread_t));
    if (!t) return NULL;

    void *stack = kmalloc(THREAD_DEFAULT_STACK_SIZE);
    if (!stack) { kfree(t); return NULL; }

    t->stack_base = stack;
    t->stack_size = THREAD_DEFAULT_STACK_SIZE;
    t->entry = entry;
    t->arg = arg;
    t->state = THREAD_READY;
    t->id = g_next_thread_id++;
    t->next = NULL;
    t->cr3 = 0; /* 기본값: 공유 커널 주소공간 */
    t->user_brk = 0;
    for (int fi = 0; fi < THREAD_MAX_FDS; fi++) { t->fd_mode[fi] = 0; t->fd_pos[fi] = 0; t->fd_path[fi][0] = '\0'; }
    t->stdout_sink = NULL; /* Milestone 37: 기본은 시리얼로만 — elf_execute_ex가 필요하면 설정 */

    int i = 0;
    for (; i < THREAD_NAME_MAX - 1 && name && name[i]; i++) t->name[i] = name[i];
    t->name[i] = '\0';

    /* switch_context()가 popq 하는 순서(r15,r14,r13,r12,rbx,rbp)와
     * 정확히 대응하도록 초기 스택을 구성한다. 그 위에는 switch_context가
     * "ret" 할 때 사용할 복귀주소(트램폴린 함수)를 둔다. */
    uint8_t *top = (uint8_t *)stack + THREAD_DEFAULT_STACK_SIZE;
    uint64_t *sp = (uint64_t *)top;
    *(--sp) = (uint64_t)thread_trampoline; /* ret 대상 */
    *(--sp) = 0; /* rbp */
    *(--sp) = 0; /* rbx */
    *(--sp) = 0; /* r12 */
    *(--sp) = 0; /* r13 */
    *(--sp) = 0; /* r14 */
    *(--sp) = 0; /* r15 */
    t->rsp = (uint64_t)sp;

    scheduler_enqueue(t);
    return t;
}

static void thread_trampoline(void) {
    thread_t *me = scheduler_current();
    if (me && me->entry) {
        me->entry(me->arg);
    }
    thread_exit();
}

void thread_set_address_space(thread_t *t, uint64_t pml4_phys) {
    if (t) t->cr3 = pml4_phys;
}

void thread_set_user_brk(thread_t *t, uint64_t brk) {
    if (t) t->user_brk = brk;
}

__attribute__((noreturn))
void thread_exit(void) {
    scheduler_exit_current();
    __builtin_unreachable();
}
