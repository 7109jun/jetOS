/* JetOS - kernel/hal/power.c - power.h 참고. */
#include "power.h"
#include "x86_asm_shim.h"
#include "../drivers/serial.h"

void power_reboot(void) {
    serial_write("[power] 재부팅(8042 컨트롤러 리셋)\n");
    hal_cli();
    /* 8042 입력 버퍼가 빌 때까지 기다렸다가 리셋 라인을 펄스한다 —
     * 표준적인 방법(실제 하드웨어에서도 폭넓게 동작). 무한정 기다리지
     * 않도록 시도 횟수를 제한(응답 없는 컨트롤러에서 멈추지 않게). */
    for (int i = 0; i < 100000; i++) {
        if (!(hal_inb(0x64) & 0x02)) break;
    }
    hal_outb(0x64, 0xFE);
    /* 정상적으로는 여기 도달 안 함(CPU 리셋됨) — 혹시 리셋이 안 먹혔을
     * 경우를 대비한 안전망. */
    for (;;) hal_hlt();
}

void power_shutdown(void) {
    serial_write("[power] 종료(QEMU 관례 ACPI 포트) — 실기에서는 안 될 수 있음, power.h 참고\n");
    hal_cli();
    hal_outw(0x604, 0x2000); /* QEMU가 오랫동안 지원해온 고정 종료 포트/값 */
    /* 정상적으로는 여기 도달 안 함. 종료가 안 먹혔으면(실기 등) 그냥
     * 멈춰있는다 — 강제로 뭘 더 하려 들지 않음(안전 우선). */
    for (;;) hal_hlt();
}
