kernel/fs/jetfs.o: kernel/fs/jetfs.c kernel/fs/jetfs.h \
 kernel/fs/../drivers/ahci.h kernel/fs/../mm/heap.h
kernel/fs/jetfs.h:
kernel/fs/../drivers/ahci.h:
kernel/fs/../mm/heap.h:
