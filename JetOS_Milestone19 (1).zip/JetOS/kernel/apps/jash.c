/*
 * JetOS - kernel/apps/jash.c
 *
 * jash: JetOS 전용 셸.
 * C#으로 작성된 원본(Jash.cs by 7109jun/jetOS)의 명령어 구조와 기능을
 * JetOS freestanding C로 재구현했다.
 *
 * 원본 → JetOS 대응:
 *   Console.ReadLine()        → keyboard_poll_char() 링버퍼 + 라인 버퍼
 *   Console.WriteLine()       → jash_print() → serial + GUI 콘솔
 *   Process.GetProcesses()    → JetAPI ListThreadsJ()
 *   ReadProcessMemory()       → JetAPI GetSystemInfoJ() (커널 메모리 조회)
 *   HttpClient.GetByteArray() → (Milestone 7: JETFS 파일 읽기로 대체)
 *   Convert.ToBase64String()  → jash_b64_encode() (자체 구현)
 *   Convert.FromBase64String() → jash_b64_decode() (자체 구현)
 */

#include <stddef.h>
#include "jash.h"
#include "../../include/jetapi/jetapi.h"
#include "../drivers/keyboard.h"
#include "../drivers/console.h"
#include "../drivers/serial.h"
#include "../gui/wm.h"
#include "../gui/widget.h"
#include "../proc/scheduler.h"
#include "../proc/thread.h"
#include "../fs/jetfs.h"
#include "../fs/vfs.h"
#include "../hal/x86_asm_shim.h"
#include "../exec/pe_loader.h"
#include "../exec/elf_loader.h"
#include "../net/net.h"
#include "../net/tcp.h"
#include "../net/dns.h"
#include "../net/tls.h"
#include "../apps/browser.h"
#include "../int/pit.h"

/* ============================== 유틸 ============================== */

static void str_copy(char *dst, const char *src, int max) {
    int i = 0;
    for (; i < max - 1 && src && src[i]; i++) dst[i] = src[i];
    dst[i] = '\0';
}

/* static int str_eq_unused(const char *a, const char *b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
} */

static int str_eq_i(const char *a, const char *b) {
    while (*a && *b) {
        char ca = *a >= 'A' && *a <= 'Z' ? (char)(*a + 32) : *a;
        char cb = *b >= 'A' && *b <= 'Z' ? (char)(*b + 32) : *b;
        if (ca != cb) return 0;
        a++; b++;
    }
    return *a == *b;
}

static int str_len(const char *s) { int n = 0; while (s && s[n]) n++; return n; }

/* ============================== 현재 디렉터리 / 경로 처리 ============================== */
static char g_cwd[192] = "/";

/* "/a/b/../c/./d" 같은 raw 경로를 정규화된 절대경로로 만든다. */
static void normalize_path(const char *raw, char *out, int outsz) {
    char tmp[256];
    str_copy(tmp, raw, sizeof(tmp));
    char *comps[32];
    int nc = 0;
    char *p = tmp;
    while (*p) {
        while (*p == '/') p++;
        if (!*p) break;
        char *start = p;
        while (*p && *p != '/') p++;
        if (*p) { *p = '\0'; p++; }
        if (start[0] == '\0') continue;
        if (start[0] == '.' && start[1] == '\0') continue; /* "." */
        if (start[0] == '.' && start[1] == '.' && start[2] == '\0') { /* ".." */
            if (nc > 0) nc--;
            continue;
        }
        if (nc < 32) comps[nc++] = start;
    }
    int oi = 0;
    out[oi++] = '/';
    for (int i = 0; i < nc; i++) {
        if (i > 0 && oi < outsz - 1) out[oi++] = '/';
        const char *s = comps[i];
        while (*s && oi < outsz - 1) out[oi++] = *s++;
    }
    out[oi] = '\0';
}

/* 인자 경로(상대/절대/ns접두사)를 cwd 기준 정규화된 절대 jetfs 경로로 변환 */
static void path_resolve(const char *arg, char *out, int outsz) {
    char raw[256];
    if (arg[0] == ':' && arg[1]) {
        char vbuf[128];
        const char *t = vfs_translate(arg, vbuf, sizeof(vbuf));
        str_copy(raw, t, sizeof(raw));
    } else if (arg[0] == '/') {
        str_copy(raw, arg, sizeof(raw));
    } else {
        int i = 0;
        const char *c = g_cwd;
        while (*c && i < (int)sizeof(raw) - 1) raw[i++] = *c++;
        if (i == 0 || raw[i - 1] != '/') { if (i < (int)sizeof(raw) - 1) raw[i++] = '/'; }
        const char *r = arg;
        while (*r && i < (int)sizeof(raw) - 1) raw[i++] = *r++;
        raw[i] = '\0';
    }
    normalize_path(raw, out, outsz);
}

static void uint_to_str(uint64_t v, char *buf) {
    char tmp[20]; int t = 0;
    if (v == 0) { buf[0]='0'; buf[1]='\0'; return; }
    while (v > 0) { tmp[t++] = (char)('0' + (v % 10)); v /= 10; }
    int i = 0;
    while (t > 0) buf[i++] = tmp[--t];
    buf[i] = '\0';
}

/* ============================== 출력 ============================== */
/* jash 창 상태 */
static JetWindowHandle g_jash_win = -1;
static int g_jash_launched = 0;
#define JASH_BUF_MAX 2048
static char g_jash_out[JASH_BUF_MAX];
static int g_jash_out_len = 0;

static void jash_append(const char *s) {
    while (*s && g_jash_out_len < JASH_BUF_MAX - 1) {
        g_jash_out[g_jash_out_len++] = *s++;
    }
    g_jash_out[g_jash_out_len] = '\0';
}

static void jash_println(const char *s) {
    jash_append(s);
    if (g_jash_out_len < JASH_BUF_MAX - 1) g_jash_out[g_jash_out_len++] = '\n';
    g_jash_out[g_jash_out_len] = '\0';
    serial_write(s);
    serial_write("\n");
    /* Milestone 19: 새 줄이 추가되면 스크롤을 사용자가 위로 올려놓은
     * 상태가 아닌 한 최신 줄로 따라가게 한다(간단화를 위해 항상 따라감). */
    if (g_jash_win >= 0) wm_scroll_to_bottom(g_jash_win);
}

/* Milestone 19: 예전에는 "창 크기에 맞는 마지막 N줄만" 직접 잘라 그렸다
 * (스크롤백 불가). 이제 widget_draw_scrollable_text + wm의 content_h/
 * scroll_y로 대체해 PgUp/PgDn으로 과거 출력을 거슬러 볼 수 있다. */
static void jash_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)ctx;
    int scroll = wm_get_scroll(g_jash_win);
    int content_px = widget_draw_scrollable_text(dc, x + 8, y + 8, w - 16, h - 8,
                                                  g_jash_out, scroll, 0x00D0F0D0u);
    wm_set_content_height(g_jash_win, content_px);
}

/* ============================== 입력 버퍼 ============================== */
#define INPUT_MAX 256
static char g_input_buf[INPUT_MAX];
static int g_input_len = 0;
static int g_input_cursor = 0; /* 삽입 위치 (0 ~ g_input_len) */

/* ---- 명령어 히스토리 (위/아래 화살표) ---- */
#define HISTORY_MAX 16
static char g_history[HISTORY_MAX][INPUT_MAX];
static int g_history_count = 0;
static int g_history_browse = -1; /* -1이면 히스토리 탐색 중이 아님 */
static char g_history_saved[INPUT_MAX]; /* 탐색 시작 시점의 입력 내용 보존 */

static void history_push(const char *line) {
    if (!line[0]) return;
    if (g_history_count > 0 && str_eq_i(g_history[g_history_count - 1], line)) return;
    if (g_history_count < HISTORY_MAX) {
        str_copy(g_history[g_history_count++], line, INPUT_MAX);
    } else {
        for (int i = 1; i < HISTORY_MAX; i++) str_copy(g_history[i - 1], g_history[i], INPUT_MAX);
        str_copy(g_history[HISTORY_MAX - 1], line, INPUT_MAX);
    }
}

static void history_up(void) {
    if (g_history_count == 0) return;
    if (g_history_browse == -1) {
        str_copy(g_history_saved, g_input_buf, INPUT_MAX);
        g_history_browse = g_history_count - 1;
    } else if (g_history_browse > 0) {
        g_history_browse--;
    }
    str_copy(g_input_buf, g_history[g_history_browse], INPUT_MAX);
    g_input_len = str_len(g_input_buf);
    g_input_cursor = g_input_len;
}

static void history_down(void) {
    if (g_history_browse == -1) return;
    g_history_browse++;
    if (g_history_browse >= g_history_count) {
        g_history_browse = -1;
        str_copy(g_input_buf, g_history_saved, INPUT_MAX);
    } else {
        str_copy(g_input_buf, g_history[g_history_browse], INPUT_MAX);
    }
    g_input_len = str_len(g_input_buf);
    g_input_cursor = g_input_len;
}

/* 커서 위치에 문자 삽입 */
static void input_insert(char c) {
    if (g_input_len >= INPUT_MAX - 1) return;
    for (int i = g_input_len; i > g_input_cursor; i--) g_input_buf[i] = g_input_buf[i - 1];
    g_input_buf[g_input_cursor] = c;
    g_input_len++;
    g_input_cursor++;
    g_input_buf[g_input_len] = '\0';
}

/* 커서 바로 앞 문자 삭제 (백스페이스) */
static void input_backspace(void) {
    if (g_input_cursor == 0) return;
    for (int i = g_input_cursor - 1; i < g_input_len - 1; i++) g_input_buf[i] = g_input_buf[i + 1];
    g_input_len--;
    g_input_cursor--;
    g_input_buf[g_input_len] = '\0';
}

/* 커서 위치 문자 삭제 (Delete 키) */
static void input_delete_fwd(void) {
    if (g_input_cursor >= g_input_len) return;
    for (int i = g_input_cursor; i < g_input_len - 1; i++) g_input_buf[i] = g_input_buf[i + 1];
    g_input_len--;
    g_input_buf[g_input_len] = '\0';
}

/* 화면 하단에 현재 입력 프롬프트 표시 */
static void jash_draw_prompt_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)ctx;
    jash_content_cb(dc, x, y, w, h - 20, NULL);
    /* 프롬프트 줄: "jash /cwd> 입력내용" (커서는 입력 끝에 표시, 렌더링만 단순화) */
    dc->cursor_x = (uint32_t)(x + 8);
    dc->cursor_y = (uint32_t)(y + h - 20);
    dc->fg_color = 0x00A0D0FF;
    console_print(dc, "jash ");
    dc->fg_color = 0x0080A0C0;
    console_print(dc, g_cwd);
    dc->fg_color = 0x00A0D0FF;
    console_print(dc, "> ");
    dc->fg_color = 0x00E0F0FF;
    console_print(dc, g_input_buf);
    dc->fg_color = 0x00E0ECFA; /* 기본 텍스트색 복원 */
}

/* ============================== Base64 (자체 구현) ============================== */
/* 원본 Jash.cs: Convert.ToBase64String / Convert.FromBase64String 대응 */
static const char B64_CHARS[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static void b64_encode(const uint8_t *in, int in_len, char *out) {
    int i = 0, o = 0;
    while (i < in_len) {
        uint32_t b = (uint32_t)in[i++] << 16;
        if (i < in_len) b |= (uint32_t)in[i++] << 8;
        if (i < in_len) b |= (uint32_t)in[i++];
        out[o++] = B64_CHARS[(b >> 18) & 0x3F];
        out[o++] = B64_CHARS[(b >> 12) & 0x3F];
        out[o++] = (i - 1 < in_len || in_len % 3 != 1) ? B64_CHARS[(b >> 6) & 0x3F] : '=';
        out[o++] = (in_len % 3 == 0 || i <= in_len) ? B64_CHARS[b & 0x3F] : '=';
    }
    out[o] = '\0';
}

static int b64_char_val(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
}

static int b64_decode(const char *in, uint8_t *out) {
    int o = 0;
    while (*in) {
        /* 공백 무시 (원본 CleanBase64 대응) */
        char a = *in++; while (a == ' ' || a == '\n' || a == '\r') { a = *in++; }
        char b = *in++; while (b == ' ' || b == '\n' || b == '\r') { b = *in++; }
        char c = *in; if (*in) in++; while (c == ' ' || c == '\n' || c == '\r') { c = *in; if (*in) in++; }
        char d = *in; if (*in) in++; while (d == ' ' || d == '\n' || d == '\r') { d = *in; if (*in) in++; }
        if (!a || !b) break;
        int va = b64_char_val(a), vb = b64_char_val(b);
        int vc = (c && c != '=') ? b64_char_val(c) : 0;
        int vd = (d && d != '=') ? b64_char_val(d) : 0;
        if (va < 0 || vb < 0) break;
        out[o++] = (uint8_t)((va << 2) | (vb >> 4));
        if (c && c != '=') out[o++] = (uint8_t)((vb << 4) | (vc >> 2));
        if (d && d != '=') out[o++] = (uint8_t)((vc << 6) | vd);
    }
    return o;
}

/* ============================== 인수 파싱 (원본 SplitArgs 대응) ============================== */
#define MAX_ARGV 16
static char g_argv[MAX_ARGV][128];
static int g_argc;

static void split_args(const char *line) {
    g_argc = 0;
    int i = 0, in_quote = 0;
    char quote_char = '"';
    char cur[128]; int cur_len = 0;

    while (line[i]) {
        char c = line[i++];
        if (in_quote) {
            if (c == quote_char) { in_quote = 0; }
            else if (cur_len < 127) cur[cur_len++] = c;
        } else {
            if (c == '"' || c == '\'') { in_quote = 1; quote_char = c; }
            else if (c == ' ' || c == '\t') {
                if (cur_len > 0 && g_argc < MAX_ARGV) {
                    cur[cur_len] = '\0';
                    str_copy(g_argv[g_argc++], cur, 128);
                    cur_len = 0;
                }
            } else if (cur_len < 127) cur[cur_len++] = c;
        }
    }
    if (cur_len > 0 && g_argc < MAX_ARGV) {
        cur[cur_len] = '\0';
        str_copy(g_argv[g_argc++], cur, 128);
    }
}

/* ============================== 명령어 ============================== */

static void cmd_help(void) {
    jash_println("jash - JetOS Shell");
    jash_println("");
    jash_println("pwd                     print current directory");
    jash_println("cd <path>               change directory");
    jash_println("ls [path]               list directory contents");
    jash_println("mkdir <path>            create directory");
    jash_println("touch <path>            create empty file");
    jash_println("cat <path>              print file contents");
    jash_println("write <path> <text>     overwrite file with text");
    jash_println("rm <path>               delete file or directory");
    jash_println("");
    jash_println("net                     show NIC MAC/IP/gateway (Milestone 10)");
    jash_println("arp <ip>                resolve MAC via ARP");
    jash_println("ping <ip>               ICMP echo (e.g. ping 10.0.2.2)");
    jash_println("http <ip-or-host> <port> </path> [save-to]   real TCP GET (M11) + DNS (M12)");
    jash_println("https <ip-or-host> <port> </path> [save-to]  real TLS 1.2 HTTPS GET (M19, no cert trust)");
    jash_println("nslookup <hostname>     DNS lookup (Milestone 12)");
    jash_println("browser <host> <port> </path>   open GUI browser window (Milestone 18)");
    jash_println("");
    jash_println("base64 encode <text>");
    jash_println("base64 decode <base64>");
    jash_println("");
    jash_println("mem list          list all threads/processes");
    jash_println("mem info          system memory statistics");
    jash_println("");
    jash_println("browse <path>     view file contents (legacy alias of cat)");
    jash_println("");
    jash_println("run <path.exe>    run a PE32+ executable");
    jash_println("");
    jash_println("up/down arrows: command history, left/right/home/end: cursor move");
    jash_println("");
    jash_println("exit / quit");
}

static void cmd_base64(void) {
    if (g_argc < 2) { cmd_help(); return; }
    const char *sub = g_argv[1];

    if (str_eq_i(sub, "encode")) {
        /* 나머지 인자들을 공백으로 이어 붙여 텍스트로 만든다 */
        char text[512]; int tlen = 0;
        for (int i = 2; i < g_argc; i++) {
            if (i > 2 && tlen < 510) text[tlen++] = ' ';
            const char *s = g_argv[i];
            while (*s && tlen < 511) text[tlen++] = *s++;
        }
        text[tlen] = '\0';
        char out[700];
        b64_encode((const uint8_t *)text, tlen, out);
        jash_println(out);

    } else if (str_eq_i(sub, "decode")) {
        char b64[512]; int blen = 0;
        for (int i = 2; i < g_argc; i++) {
            const char *s = g_argv[i];
            while (*s && blen < 511) b64[blen++] = *s++;
        }
        b64[blen] = '\0';
        uint8_t out[400]; int outlen = b64_decode(b64, out);
        out[outlen] = '\0';
        jash_println((char *)out);
    } else {
        jash_println("unknown subcommand. try: help");
    }
}

/* 원본 MemCommand(list) 대응: JetOS 스레드 목록 */
typedef struct { int count; } mem_list_ctx_t;
static void mem_list_cb(const char *name, uint32_t id, int state, void *ctx) {
    mem_list_ctx_t *c = (mem_list_ctx_t *)ctx;
    c->count++;
    char line[80];
    const char *states[] = {"READY","RUNNING","BLOCKED","DEAD"};
    const char *st = (state >= 0 && state <= 3) ? states[state] : "?";
    char id_s[12]; uint_to_str(id, id_s);
    int i = 0;
    /* id (8자리 오른쪽 정렬 흉내) */
    int id_len = str_len(id_s);
    for (; i < 8 - id_len; i++) line[i] = ' ';
    str_copy(line + i, id_s, 12); i += id_len;
    line[i++] = ' ';
    str_copy(line + i, name, 24); i += str_len(name);
    line[i++] = ' ';
    str_copy(line + i, st, 8); i += str_len(st);
    line[i] = '\0';
    jash_println(line);
}

static void cmd_mem(void) {
    if (g_argc < 2) { cmd_help(); return; }
    const char *sub = g_argv[1];

    if (str_eq_i(sub, "list")) {
        jash_println("      id name                     state");
        mem_list_ctx_t ctx = {0};
        ListThreadsJ(mem_list_cb, &ctx);
        char c[32]; char n[8]; uint_to_str((uint64_t)ctx.count, n);
        str_copy(c, "total: ", 8); str_copy(c+7, n, 24);
        jash_println(c);

    } else if (str_eq_i(sub, "info")) {
        JetSystemInfo info;
        GetSystemInfoJ(&info);

        char line[80];
        char v[20];

        jash_println("=== JetOS Memory Info ===");
        uint_to_str(info.heap_total_bytes, v);
        str_copy(line, "heap total : ", 14); str_copy(line+13, v, 20); jash_println(line);
        uint_to_str(info.heap_used_bytes, v);
        str_copy(line, "heap used  : ", 14); str_copy(line+13, v, 20); jash_println(line);
        uint_to_str((info.heap_total_bytes - info.heap_used_bytes), v);
        str_copy(line, "heap free  : ", 14); str_copy(line+13, v, 20); jash_println(line);
        uint_to_str(info.pmm_free_pages * 4096, v);
        str_copy(line, "phys free  : ", 14); str_copy(line+13, v, 20); str_copy(line+13+str_len(v), " bytes", 8); jash_println(line);
        uint_to_str(info.timer_ticks, v);
        str_copy(line, "timer ticks: ", 14); str_copy(line+13, v, 20); jash_println(line);

    } else {
        jash_println("unknown subcommand. try: help");
    }
}

/* browse: JETFS 파일 내용 텍스트로 보기 (원본 browse는 HTTP 브라우저,
 * JetOS M7에서는 JETFS 파일 뷰어로 구현 — 네트워킹은 Milestone 7 후반) */
static void cmd_browse(void) {
    if (g_argc < 2) { jash_println("usage: browse <path>"); return; }
    char buf[1024];
    uint32_t sz = 0;
    char real[128];
    const char *rp = vfs_translate(g_argv[1], real, sizeof(real));

    if (jetfs_read(rp, buf, sizeof(buf) - 1, &sz)) {
        buf[sz] = '\0';
        jash_println("--- file contents ---");
        /* 줄 단위로 출력 */
        char line[128]; int li = 0;
        for (uint32_t i = 0; i <= sz; i++) {
            char c = (i < sz) ? buf[i] : '\n';
            if (c == '\n') {
                line[li] = '\0';
                jash_println(line);
                li = 0;
            } else if (li < 127) {
                line[li++] = c;
            }
        }
        jash_println("--- end ---");
    } else {
        jash_println("error: cannot read file (check path and JETFS mount)");
    }
}

/* run: 실행 파일 실행. 파일 앞 4바이트로 ELF64(네이티브, Milestone 15)와
 * PE32+(Windows 호환, Milestone 7/9)를 자동 구분한다.
 *   ELF magic: 0x7F 'E' 'L' 'F'
 *   PE  magic: 'M' 'Z' (DOS 헤더) ... 나중에 'PE\0\0'
 * PE 실행 시엔 기존처럼 먼저 pe_load()로 동기 검증해 오류/미해결
 * import를 jash 창에 바로 보여준 뒤 pe_execute()로 넘긴다. ELF는
 * elf_execute()가 로드+실행을 전부 담당한다(내부에서 실패 시 serial로
 * 로그를 남긴다 — jash 창 실시간 표시는 향후 과제). */
static void cmd_run(void) {
    if (g_argc < 2) { jash_println("usage: run <path>"); return; }
    char target[192];
    path_resolve(g_argv[1], target, sizeof(target));

    uint8_t magic[4] = {0,0,0,0};
    uint32_t got = 0;
    jetfs_read(target, magic, sizeof(magic), &got);

    if (got >= 4 && magic[0] == 0x7F && magic[1] == 'E' && magic[2] == 'L' && magic[3] == 'F') {
        jash_println("ELF64 실행파일 감지 — 격리된 주소공간(Ring3)에서 실행합니다.");
        if (elf_execute(target)) {
            jash_println("launched (native ELF, isolated address space).");
        } else {
            jash_println("error: failed to launch ELF (메모리 부족?)");
        }
        return;
    }

    pe_load_result_t res;
    pe_load(target, &res);

    if (res.error_code != 0) {
        jash_println("error: PE load failed:");
        jash_println(res.error_msg ? res.error_msg : "(unknown)");
        return;
    }

    if (res.unresolved_count > 0) {
        jash_println("warning: unresolved imports (no-op if called):");
        char line[128]; int li = 0;
        for (int i = 0; i < res.unresolved_count; i++) {
            const char *n = res.unresolved_imports[i];
            if (li > 0) { line[li++] = ','; line[li++] = ' '; }
            int j = 0; while (n[j] && li < 120) line[li++] = n[j++];
        }
        if (res.unresolved_truncated) { line[li++] = '.'; line[li++] = '.'; line[li++] = '.'; }
        line[li] = '\0';
        jash_println(line);
    }

    int id = pe_execute(target, NULL);
    if (id < 0) {
        jash_println("error: failed to launch exe");
    } else {
        jash_println("launched.");
    }
}

/* ============================== JETFS 셸 명령어 ============================== */

static void cmd_pwd(void) {
    jash_println(g_cwd);
}

static void cmd_cd(void) {
    char target[192];
    if (g_argc < 2) {
        str_copy(target, "/", sizeof(target));
    } else {
        path_resolve(g_argv[1], target, sizeof(target));
    }
    jetfs_inode_type_t type;
    if (!jetfs_stat(target, &type, NULL)) {
        jash_println("cd: no such path");
        return;
    }
    if (type != JETFS_TYPE_DIR) {
        jash_println("cd: not a directory");
        return;
    }
    str_copy(g_cwd, target, sizeof(g_cwd));
}

typedef struct { int count; } ls_ctx_t;
static void ls_cb(const char *name, jetfs_inode_type_t type, uint32_t size, void *ctx) {
    ls_ctx_t *c = (ls_ctx_t *)ctx;
    c->count++;
    char line[80];
    int i = 0;
    line[i++] = (type == JETFS_TYPE_DIR) ? 'd' : '-';
    line[i++] = ' ';
    if (type == JETFS_TYPE_FILE) {
        char sz[16]; uint_to_str(size, sz);
        int slen = str_len(sz);
        for (int p = 0; p < 8 - slen; p++) line[i++] = ' ';
        str_copy(line + i, sz, sizeof(line) - i); i += slen;
    } else {
        str_copy(line + i, "    <DIR>", sizeof(line) - i); i += 9;
    }
    line[i++] = ' ';
    str_copy(line + i, name, sizeof(line) - i);
    jash_println(line);
}

static void cmd_ls(void) {
    char target[192];
    if (g_argc < 2) str_copy(target, g_cwd, sizeof(target));
    else path_resolve(g_argv[1], target, sizeof(target));

    ls_ctx_t ctx = {0};
    if (!jetfs_list(target, ls_cb, &ctx)) {
        jash_println("ls: cannot list (no such directory)");
        return;
    }
    if (ctx.count == 0) jash_println("(empty)");
}

static void cmd_mkdir(void) {
    if (g_argc < 2) { jash_println("usage: mkdir <path>"); return; }
    char target[192];
    path_resolve(g_argv[1], target, sizeof(target));
    if (!jetfs_create(target, JETFS_TYPE_DIR)) jash_println("mkdir: failed (exists or parent missing)");
}

static void cmd_touch(void) {
    if (g_argc < 2) { jash_println("usage: touch <path>"); return; }
    char target[192];
    path_resolve(g_argv[1], target, sizeof(target));
    if (!jetfs_create(target, JETFS_TYPE_FILE)) jash_println("touch: failed (exists or parent missing)");
}

static void cmd_cat(void) {
    if (g_argc < 2) { jash_println("usage: cat <path>"); return; }
    char target[192];
    path_resolve(g_argv[1], target, sizeof(target));
    char buf[1024]; uint32_t sz = 0;
    if (!jetfs_read(target, buf, sizeof(buf) - 1, &sz)) {
        jash_println("cat: cannot read file");
        return;
    }
    buf[sz] = '\0';
    char line[128]; int li = 0;
    for (uint32_t i = 0; i <= sz; i++) {
        char c = (i < sz) ? buf[i] : '\n';
        if (c == '\n') { line[li] = '\0'; jash_println(line); li = 0; }
        else if (li < 127) line[li++] = c;
    }
}

static void cmd_write(void) {
    if (g_argc < 3) { jash_println("usage: write <path> <text...>"); return; }
    char target[192];
    path_resolve(g_argv[1], target, sizeof(target));

    char text[512]; int tlen = 0;
    for (int i = 2; i < g_argc; i++) {
        if (i > 2 && tlen < 510) text[tlen++] = ' ';
        const char *s = g_argv[i];
        while (*s && tlen < 511) text[tlen++] = *s++;
    }
    text[tlen] = '\0';

    jetfs_inode_type_t type;
    if (!jetfs_stat(target, &type, NULL)) {
        if (!jetfs_create(target, JETFS_TYPE_FILE)) { jash_println("write: cannot create file"); return; }
    }
    if (!jetfs_write(target, text, (uint32_t)tlen)) jash_println("write: failed (file too large? max ~4.2MB)");
}

static void cmd_rm(void) {
    if (g_argc < 2) { jash_println("usage: rm <path>"); return; }
    char target[192];
    path_resolve(g_argv[1], target, sizeof(target));
    if (!jetfs_delete(target)) jash_println("rm: failed (no such path)");
}

/* ============================== 네트워킹 명령어 (Milestone 10) ============================== */

static void cmd_net(void) {
    if (!net_available()) {
        jash_println("net: no NIC found (QEMU에 -device rtl8139 이 없으면 이렇게 나옵니다)");
        return;
    }
    uint8_t mac[6];
    net_get_mac(mac);
    char line[64]; int li = 0;
    const char *label = "MAC: ";
    for (int i = 0; label[i]; i++) line[li++] = label[i];
    static const char hex[] = "0123456789ABCDEF";
    for (int i = 0; i < 6; i++) {
        line[li++] = hex[mac[i] >> 4];
        line[li++] = hex[mac[i] & 0xF];
        if (i < 5) line[li++] = ':';
    }
    line[li] = '\0';
    jash_println(line);

    char ipbuf[16];
    net_ip_to_str(net_get_ip(), ipbuf);
    char l2[48]; int l2i = 0;
    const char *ip_label = "IP:  ";
    for (int i = 0; ip_label[i]; i++) l2[l2i++] = ip_label[i];
    for (int i = 0; ipbuf[i]; i++) l2[l2i++] = ipbuf[i];
    l2[l2i] = '\0';
    jash_println(l2);

    net_ip_to_str(net_get_gateway(), ipbuf);
    char l3[48]; int l3i = 0;
    const char *gw_label = "GW:  ";
    for (int i = 0; gw_label[i]; i++) l3[l3i++] = gw_label[i];
    for (int i = 0; ipbuf[i]; i++) l3[l3i++] = ipbuf[i];
    l3[l3i] = '\0';
    jash_println(l3);
}

static void cmd_arp(void) {
    if (!net_available()) { jash_println("arp: NIC 없음"); return; }
    if (g_argc < 2) { jash_println("usage: arp <ip>"); return; }
    uint32_t ip = net_str_to_ip(g_argv[1]);
    if (ip == 0) { jash_println("arp: 잘못된 IP 형식 (예: 10.0.2.2)"); return; }

    uint8_t mac[6];
    if (net_arp_resolve(ip, mac, 200)) { /* 200틱 = 2초 */
        char line[48]; int li = 0;
        static const char hex[] = "0123456789ABCDEF";
        for (int i = 0; i < 6; i++) {
            line[li++] = hex[mac[i] >> 4];
            line[li++] = hex[mac[i] & 0xF];
            if (i < 5) line[li++] = ':';
        }
        line[li] = '\0';
        jash_println(line);
    } else {
        jash_println("arp: timeout (응답 없음)");
    }
}

static void cmd_ping(void) {
    if (!net_available()) { jash_println("ping: NIC 없음"); return; }
    if (g_argc < 2) { jash_println("usage: ping <ip>"); return; }
    uint32_t ip = net_str_to_ip(g_argv[1]);
    if (ip == 0) { jash_println("ping: 잘못된 IP 형식 (예: 10.0.2.2)"); return; }

    uint32_t rtt_ticks;
    if (net_ping(ip, 200, &rtt_ticks)) { /* 200틱 = 2초 타임아웃 */
        /* 100Hz 타이머이므로 1틱 = 10ms */
        char n[16]; uint_to_str((uint64_t)(rtt_ticks * 10), n);
        char line[48]; int li = 0;
        const char *pre = "reply from ";
        for (int i = 0; pre[i]; i++) line[li++] = pre[i];
        char ipbuf[16]; net_ip_to_str(ip, ipbuf);
        for (int i = 0; ipbuf[i]; i++) line[li++] = ipbuf[i];
        const char *mid = ": time=";
        for (int i = 0; mid[i]; i++) line[li++] = mid[i];
        for (int i = 0; n[i]; i++) line[li++] = n[i];
        const char *suf = "ms";
        for (int i = 0; suf[i]; i++) line[li++] = suf[i];
        line[li] = '\0';
        jash_println(line);
    } else {
        jash_println("ping: timeout (응답 없음 - ARP 실패 또는 도달 불가)");
    }
}

/* http: 진짜 TCP 3-way handshake + HTTP/1.0 GET (Milestone 11).
 * usage: http <ip-or-hostname> <port> </path> [save-to]
 * Milestone 12부터는 호스트 이름도 받는다 — IP처럼 안 생겼으면
 * DNS(dns_resolve)로 먼저 풀어본다. */
static void cmd_http(void) {
    if (!net_available()) { jash_println("http: NIC 없음"); return; }
    if (g_argc < 4) { jash_println("usage: http <ip-or-host> <port> </path> [save-to]"); return; }

    uint32_t ip;
    if (!dns_resolve(g_argv[1], &ip, 300)) {
        jash_println("http: 주소를 찾을 수 없음 (DNS 실패 또는 잘못된 IP)");
        return;
    }
    int port = 0;
    for (const char *p = g_argv[2]; *p; p++) {
        if (*p < '0' || *p > '9') { jash_println("http: 잘못된 포트"); return; }
        port = port * 10 + (*p - '0');
    }
    const char *path = g_argv[3];

    jash_println("connecting...");
    if (!tcp_connect(ip, (uint16_t)port, 300)) {
        jash_println("http: connect timeout");
        return;
    }

    char req[256]; int ri = 0;
    const char *m1 = "GET ";
    for (int i = 0; m1[i]; i++) req[ri++] = m1[i];
    for (int i = 0; path[i] && ri < 200; i++) req[ri++] = path[i];
    const char *m2 = " HTTP/1.0\r\nHost: ";
    for (int i = 0; m2[i]; i++) req[ri++] = m2[i];
    for (int i = 0; g_argv[1][i] && ri < 230; i++) req[ri++] = g_argv[1][i];
    const char *m3 = "\r\nConnection: close\r\n\r\n";
    for (int i = 0; m3[i]; i++) req[ri++] = m3[i];
    req[ri] = '\0';

    if (!tcp_send(req, (uint32_t)ri, 100)) {
        jash_println("http: send failed");
        tcp_close();
        return;
    }

    static char resp[4096];
    uint32_t n = tcp_recv_until_close(resp, sizeof(resp) - 1, 300);
    resp[n] = '\0';
    tcp_close();

    char nbuf[16]; uint_to_str(n, nbuf);
    char summary[48]; int si = 0;
    const char *pre = "received ";
    for (int i = 0; pre[i]; i++) summary[si++] = pre[i];
    for (int i = 0; nbuf[i]; i++) summary[si++] = nbuf[i];
    const char *suf = " bytes";
    for (int i = 0; suf[i]; i++) summary[si++] = suf[i];
    summary[si] = '\0';
    jash_println(summary);

    if (g_argc >= 5) {
        char target[192];
        path_resolve(g_argv[4], target, sizeof(target));
        jetfs_inode_type_t t;
        if (!jetfs_stat(target, &t, NULL)) jetfs_create(target, JETFS_TYPE_FILE);
        if (jetfs_write(target, resp, n)) {
            jash_println("saved to JETFS.");
        } else {
            jash_println("warning: JETFS 저장 실패");
        }
    } else {
        /* 화면에 그대로 출력 (긴 응답은 jash 창 스크롤 한계로 뒷부분만 보일 수 있음) */
        char line[128]; int li = 0;
        for (uint32_t i = 0; i <= n; i++) {
            char c = (i < n) ? resp[i] : '\n';
            if (c == '\n') { line[li] = '\0'; jash_println(line); li = 0; }
            else if (c != '\r' && li < 127) line[li++] = c;
        }
    }
}

/* https: Milestone 19 — TLS 1.2로 실제 암호화된 HTTPS GET.
 * usage: https <ip-or-host> <port> </path> [save-to]
 * 인증서 신뢰 체인/호스트명 검증은 하지 않는다(tls.h에 문서화된
 * 한계) — 그 사실을 접속 시 매번 알려서 사용자가 알고 쓰게 한다. */
static void cmd_https(void) {
    if (!net_available()) { jash_println("https: NIC 없음"); return; }
    if (g_argc < 4) { jash_println("usage: https <ip-or-host> <port> </path> [save-to]"); return; }

    uint32_t ip;
    if (!dns_resolve(g_argv[1], &ip, 300)) {
        jash_println("https: 주소를 찾을 수 없음 (DNS 실패 또는 잘못된 IP)");
        return;
    }
    int port = 0;
    for (const char *p = g_argv[2]; *p; p++) {
        if (*p < '0' || *p > '9') { jash_println("https: 잘못된 포트"); return; }
        port = port * 10 + (*p - '0');
    }
    const char *path = g_argv[3];

    jash_println("[경고] 인증서 신뢰 체인/호스트명 검증 없이 접속합니다(TLS 암호화만 함, MITM 방어 없음).");
    jash_println("connecting (TLS 1.2 handshake)...");

    /* SNI: host가 점으로 구분된 4개 숫자(IP literal)면 보내지 않는다
     * (RFC 6066 위반이라 일부 서버가 거부함 — 개발 중 실제로 겪은
     * 문제, tls.c 참고). 실제 도메인 이름일 때만 SNI로 보낸다. */
    int looks_like_ip = 1;
    for (const char *p = g_argv[1]; *p; p++) {
        if (!((*p >= '0' && *p <= '9') || *p == '.')) { looks_like_ip = 0; break; }
    }
    const char *sni = looks_like_ip ? NULL : g_argv[1];

    if (!tls_connect(sni, ip, (uint16_t)port, 300)) {
        jash_println("https: TLS handshake 실패");
        return;
    }

    char req[256]; int ri = 0;
    const char *m1 = "GET ";
    for (int i = 0; m1[i]; i++) req[ri++] = m1[i];
    for (int i = 0; path[i] && ri < 200; i++) req[ri++] = path[i];
    const char *m2 = " HTTP/1.0\r\nHost: ";
    for (int i = 0; m2[i]; i++) req[ri++] = m2[i];
    for (int i = 0; g_argv[1][i] && ri < 230; i++) req[ri++] = g_argv[1][i];
    const char *m3 = "\r\nConnection: close\r\n\r\n";
    for (int i = 0; m3[i]; i++) req[ri++] = m3[i];
    req[ri] = '\0';

    if (!tls_send(req, (uint32_t)ri, 300)) {
        jash_println("https: send failed");
        tls_close();
        return;
    }

    static char resp[4096];
    uint32_t n = tls_recv_until_close(resp, sizeof(resp) - 1, 300);
    resp[n] = '\0';
    tls_close();

    char nbuf[16]; uint_to_str(n, nbuf);
    char summary[48]; int si = 0;
    const char *pre = "received ";
    for (int i = 0; pre[i]; i++) summary[si++] = pre[i];
    for (int i = 0; nbuf[i]; i++) summary[si++] = nbuf[i];
    const char *suf = " bytes (decrypted)";
    for (int i = 0; suf[i]; i++) summary[si++] = suf[i];
    summary[si] = '\0';
    jash_println(summary);

    if (g_argc >= 5) {
        char target[192];
        path_resolve(g_argv[4], target, sizeof(target));
        jetfs_inode_type_t t;
        if (!jetfs_stat(target, &t, NULL)) jetfs_create(target, JETFS_TYPE_FILE);
        if (jetfs_write(target, resp, n)) {
            jash_println("saved to JETFS.");
        } else {
            jash_println("warning: JETFS 저장 실패");
        }
    } else {
        char line[128]; int li = 0;
        for (uint32_t i = 0; i <= n; i++) {
            char c = (i < n) ? resp[i] : '\n';
            if (c == '\n') { line[li] = '\0'; jash_println(line); li = 0; }
            else if (c != '\r' && li < 127) line[li++] = c;
        }
    }
}

/* nslookup: DNS로 호스트 이름을 IP로 변환 (Milestone 12) */
static void cmd_nslookup(void) {
    if (!net_available()) { jash_println("nslookup: NIC 없음"); return; }
    if (g_argc < 2) { jash_println("usage: nslookup <hostname>"); return; }

    uint32_t ip;
    if (dns_resolve(g_argv[1], &ip, 300)) {
        char ipbuf[16];
        net_ip_to_str(ip, ipbuf);
        char line[48]; int li = 0;
        for (int i = 0; g_argv[1][i]; i++) line[li++] = g_argv[1][i];
        const char *sep = " -> ";
        for (int i = 0; sep[i]; i++) line[li++] = sep[i];
        for (int i = 0; ipbuf[i]; i++) line[li++] = ipbuf[i];
        line[li] = '\0';
        jash_println(line);
    } else {
        jash_println("nslookup: 실패 (DNS 서버 응답 없음 또는 레코드 없음)");
    }
}

/* browser: GUI 브라우저 창을 특정 주소로 연다 (Milestone 18) */
static void cmd_browser(void) {
    if (!net_available()) { jash_println("browser: NIC 없음"); return; }
    if (g_argc < 4) { jash_println("usage: browser <host> <port> </path>"); return; }
    int port = 0;
    for (const char *p = g_argv[2]; *p; p++) {
        if (*p < '0' || *p > '9') { jash_println("browser: 잘못된 포트"); return; }
        port = port * 10 + (*p - '0');
    }
    browser_launch_url(g_argv[1], port, g_argv[3]);
    jash_println("GUI 브라우저 창을 열었습니다.");
}

/* ============================== REPL ============================== */
int g_jash_running = 0;
static int g_jash_exit_requested = 0;

/* 외부(desktop 이벤트루프)에서 받은 문자를 jash의 입력 큐에 주입한다 */
#define JASH_INJECT_BUF 64
static char g_inject_buf[JASH_INJECT_BUF];
static int g_inject_head = 0, g_inject_tail = 0;

void jash_inject_char(char c) {
    int next = (g_inject_tail + 1) % JASH_INJECT_BUF;
    if (next == g_inject_head) return;
    g_inject_buf[g_inject_tail] = c;
    g_inject_tail = next;
}

static char jash_get_char(void) {
    if (g_inject_head == g_inject_tail) return 0;
    char c = g_inject_buf[g_inject_head];
    g_inject_head = (g_inject_head + 1) % JASH_INJECT_BUF;
    return c;
}

static int dispatch(void) {
    if (g_argc == 0) return 1;
    const char *cmd = g_argv[0];

    if (str_eq_i(cmd, "exit") || str_eq_i(cmd, "quit")) return 0;
    else if (str_eq_i(cmd, "help")) cmd_help();
    else if (str_eq_i(cmd, "base64")) cmd_base64();
    else if (str_eq_i(cmd, "mem") || str_eq_i(cmd, "memory")) cmd_mem();
    else if (str_eq_i(cmd, "browse") || str_eq_i(cmd, "browser")) cmd_browse();
    else if (str_eq_i(cmd, "run")) cmd_run();
    else if (str_eq_i(cmd, "pwd")) cmd_pwd();
    else if (str_eq_i(cmd, "cd")) cmd_cd();
    else if (str_eq_i(cmd, "ls") || str_eq_i(cmd, "dir")) cmd_ls();
    else if (str_eq_i(cmd, "mkdir")) cmd_mkdir();
    else if (str_eq_i(cmd, "touch")) cmd_touch();
    else if (str_eq_i(cmd, "cat")) cmd_cat();
    else if (str_eq_i(cmd, "write")) cmd_write();
    else if (str_eq_i(cmd, "rm") || str_eq_i(cmd, "del")) cmd_rm();
    else if (str_eq_i(cmd, "net")) cmd_net();
    else if (str_eq_i(cmd, "arp")) cmd_arp();
    else if (str_eq_i(cmd, "ping")) cmd_ping();
    else if (str_eq_i(cmd, "http")) cmd_http();
    else if (str_eq_i(cmd, "https")) cmd_https();
    else if (str_eq_i(cmd, "nslookup")) cmd_nslookup();
    else if (str_eq_i(cmd, "browser")) cmd_browser();
    else {
        jash_println("unknown command: try help");
    }
    return 1;
}

void jash_run_once(void) {
    if (!g_jash_running) return;

    char c = jash_get_char();
    if (!c) return;

    if (c == '\n' || c == '\r') {
        /* 명령 실행 */
        jash_append("\n");
        if (g_input_len > 0) {
            g_input_buf[g_input_len] = '\0';
            history_push(g_input_buf);
            g_history_browse = -1;
            split_args(g_input_buf);
            if (!dispatch()) {
                g_jash_exit_requested = 1;
            }
        }
        /* 프롬프트 */
        if (!g_jash_exit_requested) { jash_append("jash "); jash_append(g_cwd); jash_append("> "); }
        g_input_len = 0;
        g_input_cursor = 0;
        g_input_buf[0] = '\0';
    } else if (c == '\b') {
        input_backspace();
    } else if (c == (char)KEY_DEL) {
        input_delete_fwd();
    } else if (c == (char)KEY_LEFT) {
        if (g_input_cursor > 0) g_input_cursor--;
    } else if (c == (char)KEY_RIGHT) {
        if (g_input_cursor < g_input_len) g_input_cursor++;
    } else if (c == (char)KEY_HOME) {
        g_input_cursor = 0;
    } else if (c == (char)KEY_END) {
        g_input_cursor = g_input_len;
    } else if (c == (char)KEY_UP) {
        history_up();
    } else if (c == (char)KEY_DOWN) {
        history_down();
    } else if (c >= 32 && c < 127) {
        input_insert(c);
    }
}

/* ============================== 시작 ============================== */
/* X버튼으로 창이 닫힐 때 REPL 루프를 협조적으로 종료시킨다 */
static void jash_on_close(void *ctx) {
    (void)ctx;
    g_jash_exit_requested = 1;
}

/* Milestone 19: wm의 일반화된 키 포커스 라우팅 콜백. jash는 이미
 * jash_inject_char()로 스레드 안전하게 문자를 큐에 넣는 구조였으므로
 * 그대로 감싸기만 하면 된다 — desktop.c의 g_jash_running 특수 케이스는
 * 제거되었다. */
static void jash_key_cb(char c, void *ctx) {
    (void)ctx;
    jash_inject_char(c);
}

static void jash_thread_fn(void *arg) {
    (void)arg;
    g_jash_running = 1;
    g_jash_exit_requested = 0;
    g_input_len = 0;
    g_input_cursor = 0;
    g_input_buf[0] = '\0';
    g_history_count = 0;
    g_history_browse = -1;
    str_copy(g_cwd, "/", sizeof(g_cwd));
    g_jash_out_len = 0;
    g_jash_out[0] = '\0';

    jash_println("jash - JetOS Shell");
    jash_println("commands: help, pwd, cd, ls, mkdir, touch, cat, write, rm, base64, mem, browse, run, exit");
    jash_append("jash "); jash_append(g_cwd); jash_append("> ");

    wm_set_content_callback(g_jash_win, jash_draw_prompt_cb, NULL);
    wm_set_close_callback(g_jash_win, jash_on_close, NULL);

    while (!g_jash_exit_requested) {
        jash_run_once();
        scheduler_yield();
    }

    g_jash_running = 0;
    jash_println("jash: session ended");
    g_jash_launched = 0; /* 재실행 허용 */
}

void jash_launch(void) {
    if (g_jash_launched) {
        if (g_jash_win >= 0) wm_restore_window(g_jash_win);
        return;
    }
    g_jash_launched = 1;
    g_jash_win = CreateWindowJ("JASH - JetOS Shell", 60, 240, 540, 260, 0x00101820);
    if (g_jash_win >= 0) {
        wm_set_content_callback(g_jash_win, jash_content_cb, NULL);
        wm_set_key_callback(g_jash_win, jash_key_cb, NULL); /* Milestone 19 */
    }
    CreateThreadJ("jash", jash_thread_fn, NULL);
}
