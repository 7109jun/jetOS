/*
 * JetOS - kernel/fs/config.c
 * Milestone 33: 영속 구성. 설계 이유는 config.h 참고.
 */

#include "config.h"
#include "jetfs.h"
#include "../gui/theme.h"
#include "../gui/wm.h" /* Milestone 34: 배경화면 프리셋 */
#include <stddef.h>

#define CONFIG_DIR "/system"
#define CONFIG_PATH "/system/config.txt"
#define CONFIG_BUF_MAX 256

typedef struct {
    int theme_preset;
    int clock_24h;
    int wallpaper_preset; /* Milestone 34 */
} jetos_config_t;

/* 기본값: 프리셋 0(Ocean Blue), 24시간제, 배경화면 프리셋 0(Sunset) —
 * 지금까지의 하드코딩된 기본 동작과 정확히 같다(그래야 config.txt가
 * 아직 없는 기존 이미지도 첫 부팅에서 동작이 안 바뀐다). */
static jetos_config_t g_cfg = { 0, 1, 0 };

/* ---- 아주 작은 문자열/정수 헬퍼(freestanding — 표준 libc 문자열 함수
 * 없이 recyclebin.c/jash.c 등 이 프로젝트의 기존 스타일을 그대로 따름) ---- */

static int s_eq(const char *a, const char *b) {
    int i = 0;
    while (a[i] && b[i]) {
        if (a[i] != b[i]) return 0;
        i++;
    }
    return a[i] == b[i];
}

static int s_parse_int(const char *s) {
    int neg = 0, i = 0, v = 0;
    if (s[0] == '-') { neg = 1; i = 1; }
    for (; s[i] >= '0' && s[i] <= '9'; i++) v = v * 10 + (s[i] - '0');
    return neg ? -v : v;
}

/* v(음수 아님으로 가정 — 이 파일이 실제로 쓰는 값은 전부 0 이상)를
 * buf에 10진수로 쓰고 쓴 자릿수를 반환한다. */
static int s_write_uint(char *buf, int v) {
    if (v <= 0) { buf[0] = '0'; return 1; }
    char tmp[12];
    int t = 0;
    while (v > 0) { tmp[t++] = (char)('0' + v % 10); v /= 10; }
    int n = 0;
    while (t > 0) buf[n++] = tmp[--t];
    return n;
}

static void apply_kv(const char *key, const char *val) {
    if (s_eq(key, "theme_preset")) {
        int v = s_parse_int(val);
        if (v >= 0 && v < theme_preset_count()) g_cfg.theme_preset = v;
        /* 범위 밖 값(예: 손상된 config.txt)은 조용히 무시하고 기존
         * 기본값을 유지 — 잘못된 프리셋 인덱스로 theme.c를 호출해
         * 크래시할 위험을 여기서 미리 막는다. */
    } else if (s_eq(key, "clock_24h")) {
        g_cfg.clock_24h = s_parse_int(val) ? 1 : 0;
    } else if (s_eq(key, "wallpaper_preset")) {
        int v = s_parse_int(val);
        if (v >= 0 && v < wm_wallpaper_preset_count()) g_cfg.wallpaper_preset = v;
    }
    /* 그 외 알 수 없는 키는 의도적으로 무시(전방 호환성 — config.h 참고). */
}

/* buf(len 바이트, NUL 종료 아님)를 "key=value\n" 줄 단위로 파싱한다. */
static void parse_buffer(const char *buf, uint64_t len) {
    uint64_t i = 0;
    while (i < len) {
        char key[32];
        int kn = 0;
        while (i < len && buf[i] != '=' && buf[i] != '\n' && kn < (int)sizeof(key) - 1) {
            key[kn++] = buf[i++];
        }
        key[kn] = '\0';

        if (i < len && buf[i] == '=') {
            i++;
            char val[32];
            int vn = 0;
            while (i < len && buf[i] != '\n' && buf[i] != '\r' && vn < (int)sizeof(val) - 1) {
                val[vn++] = buf[i++];
            }
            val[vn] = '\0';
            if (kn > 0) apply_kv(key, val);
        }
        /* 이 줄의 나머지(있다면)를 건너뛰고 다음 줄로 */
        while (i < len && buf[i] != '\n') i++;
        if (i < len) i++;
    }
}

int config_save(void) {
    if (!jetfs_stat(CONFIG_DIR, NULL, NULL)) {
        if (!jetfs_create(CONFIG_DIR, JETFS_TYPE_DIR)) return 0;
    }

    char out[CONFIG_BUF_MAX];
    int n = 0;
    static const char k1[] = "theme_preset=";
    for (int k = 0; k1[k]; k++) out[n++] = k1[k];
    n += s_write_uint(out + n, g_cfg.theme_preset);
    out[n++] = '\n';

    static const char k2[] = "clock_24h=";
    for (int k = 0; k2[k]; k++) out[n++] = k2[k];
    n += s_write_uint(out + n, g_cfg.clock_24h);
    out[n++] = '\n';

    static const char k3[] = "wallpaper_preset=";
    for (int k = 0; k3[k]; k++) out[n++] = k3[k];
    n += s_write_uint(out + n, g_cfg.wallpaper_preset);
    out[n++] = '\n';

    if (!jetfs_stat(CONFIG_PATH, NULL, NULL)) {
        if (!jetfs_create(CONFIG_PATH, JETFS_TYPE_FILE)) return 0;
    }
    return jetfs_write(CONFIG_PATH, out, (uint64_t)n);
}

void config_load(void) {
    jetfs_inode_type_t t;
    uint64_t sz = 0;
    char buf[CONFIG_BUF_MAX];

    if (jetfs_stat(CONFIG_PATH, &t, &sz) && t == JETFS_TYPE_FILE) {
        uint64_t got = 0;
        if (jetfs_read(CONFIG_PATH, buf, sizeof(buf), &got)) {
            parse_buffer(buf, got);
        }
    } else {
        /* 첫 부팅이거나 이미지가 config.txt 없이 만들어짐 — 기본값을
         * 그대로 파일로 만들어둬서 다음 부팅부터는 "파일 없음" 분기를
         * 타지 않게 한다. */
        config_save();
    }

    theme_set_preset(g_cfg.theme_preset);
    wm_set_wallpaper_preset(g_cfg.wallpaper_preset); /* Milestone 34 */
}

int config_get_theme_preset(void) { return g_cfg.theme_preset; }

void config_set_theme_preset(int idx) {
    if (idx < 0 || idx >= theme_preset_count()) return;
    g_cfg.theme_preset = idx;
    theme_set_preset(idx);
    config_save();
}

int config_get_clock_24h(void) { return g_cfg.clock_24h; }

void config_set_clock_24h(int is_24h) {
    g_cfg.clock_24h = is_24h ? 1 : 0;
    config_save();
}

int config_get_wallpaper_preset(void) { return g_cfg.wallpaper_preset; }

void config_set_wallpaper_preset(int idx) {
    if (idx < 0 || idx >= wm_wallpaper_preset_count()) return;
    g_cfg.wallpaper_preset = idx;
    wm_set_wallpaper_preset(idx);
    config_save();
}
