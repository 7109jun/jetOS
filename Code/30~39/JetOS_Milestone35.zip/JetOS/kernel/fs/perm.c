/*
 * JetOS - kernel/fs/perm.c
 * Milestone 34: 파일 권한(소프트 읽기전용 목록). 설계 이유는 perm.h 참고.
 */

#include "perm.h"
#include "jetfs.h"
#include <stddef.h>

#define PERM_FILE "/system/readonly.txt"
#define PERM_MAX_ENTRIES 16
#define PERM_PATH_CAP 64
#define PERM_BUF_MAX 1024

static int s_eq(const char *a, const char *b) {
    int i = 0;
    while (a[i] && b[i]) { if (a[i] != b[i]) return 0; i++; }
    return a[i] == b[i];
}

/* /system/readonly.txt(줄바꿈으로 구분된 경로 목록)를 배열로 읽는다.
 * 반환값은 읽은 개수. */
static int load_list(char list[PERM_MAX_ENTRIES][PERM_PATH_CAP]) {
    jetfs_inode_type_t t;
    if (!jetfs_stat(PERM_FILE, &t, NULL) || t != JETFS_TYPE_FILE) return 0;

    char buf[PERM_BUF_MAX];
    uint64_t got = 0;
    if (!jetfs_read(PERM_FILE, buf, sizeof(buf) - 1, &got)) return 0;
    buf[got] = '\0';

    int n = 0;
    uint64_t i = 0;
    while (i < got && n < PERM_MAX_ENTRIES) {
        int c = 0;
        while (i < got && buf[i] != '\n' && c < PERM_PATH_CAP - 1) list[n][c++] = buf[i++];
        list[n][c] = '\0';
        while (i < got && buf[i] != '\n') i++; /* 너무 긴 줄의 나머지 버림 */
        if (i < got) i++;
        if (c > 0) n++;
    }
    return n;
}

static int save_list(char list[PERM_MAX_ENTRIES][PERM_PATH_CAP], int n) {
    if (!jetfs_stat("/system", NULL, NULL)) {
        jetfs_create("/system", JETFS_TYPE_DIR);
    }
    char out[PERM_BUF_MAX];
    int len = 0;
    for (int i = 0; i < n; i++) {
        for (int k = 0; list[i][k] && len < (int)sizeof(out) - 2; k++) out[len++] = list[i][k];
        out[len++] = '\n';
    }
    if (!jetfs_stat(PERM_FILE, NULL, NULL)) {
        if (!jetfs_create(PERM_FILE, JETFS_TYPE_FILE)) return 0;
    }
    return jetfs_write(PERM_FILE, out, (uint64_t)len);
}

int perm_is_readonly(const char *path) {
    char list[PERM_MAX_ENTRIES][PERM_PATH_CAP];
    int n = load_list(list);
    for (int i = 0; i < n; i++) {
        if (s_eq(list[i], path)) return 1;
    }
    return 0;
}

int perm_set_readonly(const char *path, int readonly) {
    char list[PERM_MAX_ENTRIES][PERM_PATH_CAP];
    int n = load_list(list);

    int found = -1;
    for (int i = 0; i < n; i++) {
        if (s_eq(list[i], path)) { found = i; break; }
    }

    if (readonly) {
        if (found >= 0) return 1; /* 이미 표시돼 있음 */
        if (n >= PERM_MAX_ENTRIES) return 0; /* 목록 꽉 참 */
        int k = 0;
        for (; path[k] && k < PERM_PATH_CAP - 1; k++) list[n][k] = path[k];
        list[n][k] = '\0';
        n++;
    } else {
        if (found < 0) return 1; /* 애초에 표시 안 돼 있었음 */
        for (int i = found; i < n - 1; i++) {
            int k = 0;
            for (; list[i + 1][k]; k++) list[i][k] = list[i + 1][k];
            list[i][k] = '\0';
        }
        n--;
    }
    return save_list(list, n);
}
