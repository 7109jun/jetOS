/*
 * JetOS - kernel/net/udp.c
 */
#include "udp.h"
#include "net.h"
#include "../int/pit.h"
#include "../proc/scheduler.h"
#include "../mm/heap.h"

#pragma pack(push, 1)
typedef struct {
    uint16_t src_port;
    uint16_t dst_port;
    uint16_t length;   /* UDP 헤더+데이터 길이 */
    uint16_t checksum;
} udp_header_t;
#pragma pack(pop)

static uint16_t u_htons(uint16_t v) { return (uint16_t)((v << 8) | (v >> 8)); }
#define u_ntohs u_htons

/* "마지막으로 수신된 데이터그램" 단일 슬롯 (local_port별로 최대 1개 대기) */
#define UDP_RX_SLOT_MAX 512
static volatile int g_rx_valid = 0;
static uint16_t g_rx_local_port = 0;
static uint32_t g_rx_src_ip = 0;
static uint16_t g_rx_src_port = 0;
static uint8_t g_rx_data[UDP_RX_SLOT_MAX];
static uint32_t g_rx_len = 0;

int udp_send(uint32_t dst_ip, uint16_t dst_port, uint16_t src_port, const void *data, uint32_t len) {
    uint8_t buf[1472]; /* 1500 MTU - 20 IP헤더 - 8 UDP헤더 여유 */
    if (len + sizeof(udp_header_t) > sizeof(buf)) return 0;

    udp_header_t *udp = (udp_header_t *)buf;
    udp->src_port = u_htons(src_port);
    udp->dst_port = u_htons(dst_port);
    udp->length = u_htons((uint16_t)(sizeof(udp_header_t) + len));
    udp->checksum = 0; /* IPv4에서는 UDP 체크섬 0(미계산)도 허용됨 — 단순화 */

    uint8_t *payload = buf + sizeof(udp_header_t);
    const uint8_t *src = (const uint8_t *)data;
    for (uint32_t i = 0; i < len; i++) payload[i] = src[i];

    return net_ip_send(dst_ip, 17 /* IP_PROTO_UDP */, buf, sizeof(udp_header_t) + len);
}

uint32_t udp_recv(uint16_t local_port, void *buf, uint32_t buf_size,
                   uint32_t *out_src_ip, uint16_t *out_src_port, uint32_t timeout_ticks) {
    uint64_t deadline = g_timer_ticks + timeout_ticks;
    while (g_timer_ticks < deadline) {
        net_poll();
        if (g_rx_valid && g_rx_local_port == local_port) {
            uint32_t n = g_rx_len < buf_size ? g_rx_len : buf_size;
            uint8_t *dst = (uint8_t *)buf;
            for (uint32_t i = 0; i < n; i++) dst[i] = g_rx_data[i];
            if (out_src_ip) *out_src_ip = g_rx_src_ip;
            if (out_src_port) *out_src_port = g_rx_src_port;
            g_rx_valid = 0;
            return n;
        }
        scheduler_yield();
    }
    return 0;
}

void udp_on_ip_packet(uint32_t src_ip, const uint8_t *payload, uint32_t len) {
    if (len < sizeof(udp_header_t)) return;
    const udp_header_t *udp = (const udp_header_t *)payload;
    uint16_t dst_port = u_ntohs(udp->dst_port);
    uint16_t data_len16 = u_ntohs(udp->length);
    if (data_len16 < sizeof(udp_header_t)) return;
    uint32_t data_len = (uint32_t)data_len16 - (uint32_t)sizeof(udp_header_t);
    if (data_len > len - sizeof(udp_header_t)) data_len = len - sizeof(udp_header_t);

    g_rx_valid = 1;
    g_rx_local_port = dst_port;
    g_rx_src_ip = src_ip;
    g_rx_src_port = u_ntohs(udp->src_port);
    g_rx_len = data_len < UDP_RX_SLOT_MAX ? data_len : UDP_RX_SLOT_MAX;
    const uint8_t *data = payload + sizeof(udp_header_t);
    for (uint32_t i = 0; i < g_rx_len; i++) g_rx_data[i] = data[i];
}
