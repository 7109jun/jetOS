#ifndef JETOS_VMM_H
#define JETOS_VMM_H

#include <stdint.h>

/* JetOS 자체 페이지 테이블을 구성하고 CR3에 적재한다.
 * Milestone 2에서는 하위 4GiB를 2MiB 대형 페이지로 항등 매핑(identity
 * mapping)한다 (UEFI가 만들어준 임시 테이블에 더 이상 의존하지 않기
 * 위함). 상위 4GiB를 초과하는 MMIO/메모리는 향후 마일스톤에서 동적
 * 매핑으로 확장한다. */
void vmm_init(void);

#endif
