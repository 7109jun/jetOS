/*
 * JetOS - kernel/acpi/acpi.c
 * Milestone 35: ACPI 테이블 파싱. 설계/스코프 이유는 acpi.h 참고.
 */

#include "acpi.h"
#include "../drivers/serial.h"
#include <stddef.h>

/* ---- ACPI 온디스크(온메모리) 구조체 — 사양 그대로, 패딩 없이 ---- */

typedef struct {
    char signature[8];      /* "RSD PTR " */
    uint8_t checksum;
    char oem_id[6];
    uint8_t revision;       /* 0=ACPI 1.0, 2=ACPI 2.0+ */
    uint32_t rsdt_address;
    /* ACPI 2.0+에서만 유효(revision>=2) */
    uint32_t length;
    uint64_t xsdt_address;
    uint8_t extended_checksum;
    uint8_t reserved[3];
} __attribute__((packed)) acpi_rsdp_t;

typedef struct {
    char signature[4];
    uint32_t length;
    uint8_t revision;
    uint8_t checksum;
    char oem_id[6];
    char oem_table_id[8];
    uint32_t oem_revision;
    uint32_t creator_id;
    uint32_t creator_revision;
} __attribute__((packed)) acpi_sdt_header_t;

typedef struct {
    acpi_sdt_header_t header;
    uint32_t local_apic_address;
    uint32_t flags;
    /* 뒤에 가변 길이 엔트리들이 이어짐 */
} __attribute__((packed)) acpi_madt_t;

typedef struct {
    uint8_t type;
    uint8_t length;
} __attribute__((packed)) acpi_madt_entry_header_t;

typedef struct {
    acpi_madt_entry_header_t h;
    uint8_t acpi_processor_id;
    uint8_t apic_id;
    uint32_t flags; /* bit0: enabled */
} __attribute__((packed)) acpi_madt_lapic_t;

typedef struct {
    acpi_madt_entry_header_t h;
    uint8_t ioapic_id;
    uint8_t reserved;
    uint32_t ioapic_address;
    uint32_t gsi_base;
} __attribute__((packed)) acpi_madt_ioapic_t;

#define MADT_TYPE_LOCAL_APIC 0
#define MADT_TYPE_IO_APIC 1

/* ---- 결과 저장소 ---- */
static int g_available = 0;
static uint64_t g_local_apic_addr = 0;
static acpi_ioapic_t g_ioapics[ACPI_MAX_IOAPICS];
static int g_ioapic_count = 0;
static acpi_cpu_t g_cpus[ACPI_MAX_CPUS];
static int g_cpu_count = 0;

/* 이 커널의 VMM은 0~4GiB만 항등매핑한다(M31의 VirtIO-GPU 크래시가 바로
 * 이 한계를 안 지켜서 난 문제였다 — kernel/mm/vmm.c 참고). ACPI 테이블은
 * 거의 항상 그 안에 있지만, 혹시라도 4GiB 이상이면 여기서도 똑같이
 * "안전하게 포기"한다. */
static int addr_in_range(uint64_t phys) {
    return phys != 0 && phys < 0x100000000ULL;
}

static uint8_t checksum8(const void *data, uint32_t len) {
    const uint8_t *p = (const uint8_t *)data;
    uint8_t sum = 0;
    for (uint32_t i = 0; i < len; i++) sum = (uint8_t)(sum + p[i]);
    return sum;
}

static int sig_eq(const char *a, const char *b, int n) {
    for (int i = 0; i < n; i++) if (a[i] != b[i]) return 0;
    return 1;
}

static void parse_madt(const acpi_madt_t *madt) {
    g_local_apic_addr = madt->local_apic_address;

    const uint8_t *p = (const uint8_t *)madt + sizeof(acpi_madt_t);
    const uint8_t *end = (const uint8_t *)madt + madt->header.length;

    while (p + sizeof(acpi_madt_entry_header_t) <= end) {
        const acpi_madt_entry_header_t *eh = (const acpi_madt_entry_header_t *)p;
        if (eh->length == 0 || p + eh->length > end) break; /* 손상된 테이블 방어 */

        if (eh->type == MADT_TYPE_LOCAL_APIC && eh->length >= sizeof(acpi_madt_lapic_t)) {
            const acpi_madt_lapic_t *lapic = (const acpi_madt_lapic_t *)p;
            if (g_cpu_count < ACPI_MAX_CPUS) {
                g_cpus[g_cpu_count].apic_id = lapic->apic_id;
                g_cpus[g_cpu_count].acpi_processor_id = lapic->acpi_processor_id;
                g_cpus[g_cpu_count].enabled = (lapic->flags & 1) ? 1 : 0;
                g_cpu_count++;
            }
        } else if (eh->type == MADT_TYPE_IO_APIC && eh->length >= sizeof(acpi_madt_ioapic_t)) {
            const acpi_madt_ioapic_t *io = (const acpi_madt_ioapic_t *)p;
            if (g_ioapic_count < ACPI_MAX_IOAPICS && addr_in_range(io->ioapic_address)) {
                g_ioapics[g_ioapic_count].id = io->ioapic_id;
                g_ioapics[g_ioapic_count].address = io->ioapic_address;
                g_ioapics[g_ioapic_count].gsi_base = io->gsi_base;
                g_ioapic_count++;
            }
        }
        /* type 2(Interrupt Source Override)/5(Local APIC Address Override) 등은
         * 아직 안 씀 — PIC->APIC 전환 자체를 이번 마일스톤에서 안 하므로
         * (acpi.h 상단 설명 참고) 지금 파싱해봐야 쓸 곳이 없다. 다음
         * 마일스톤에서 실제로 IRQ 라우팅을 바꿀 때 추가할 것. */
        p += eh->length;
    }
}

/* header가 서명(sig)과 일치하고 체크섬이 맞으면 1. */
static int validate_sdt(const acpi_sdt_header_t *header, const char *sig) {
    if (!sig_eq(header->signature, sig, 4)) return 0;
    if (header->length < sizeof(acpi_sdt_header_t) || header->length > 0x10000) return 0; /* 상식적 상한 */
    return checksum8(header, header->length) == 0;
}

/* RSDT(32비트 포인터 배열)나 XSDT(64비트 포인터 배열) 안에서 MADT("APIC")를
 * 찾는다. use_xsdt=1이면 8바이트 엔트리, 0이면 4바이트 엔트리로 읽는다. */
static const acpi_madt_t *find_madt(const acpi_sdt_header_t *root, int use_xsdt) {
    uint32_t entry_size = use_xsdt ? 8 : 4;
    uint32_t table_bytes = root->length - (uint32_t)sizeof(acpi_sdt_header_t);
    uint32_t n = table_bytes / entry_size;
    const uint8_t *entries = (const uint8_t *)root + sizeof(acpi_sdt_header_t);

    for (uint32_t i = 0; i < n; i++) {
        uint64_t phys;
        if (use_xsdt) {
            uint64_t v; __builtin_memcpy(&v, entries + i * 8, 8);
            phys = v;
        } else {
            uint32_t v; __builtin_memcpy(&v, entries + i * 4, 4);
            phys = v;
        }
        if (!addr_in_range(phys)) continue;
        const acpi_sdt_header_t *h = (const acpi_sdt_header_t *)(uintptr_t)phys;
        if (validate_sdt(h, "APIC")) {
            return (const acpi_madt_t *)h;
        }
    }
    return NULL;
}

int acpi_init(uint64_t rsdp_phys_addr) {
    g_available = 0;
    g_local_apic_addr = 0;
    g_ioapic_count = 0;
    g_cpu_count = 0;

    if (!addr_in_range(rsdp_phys_addr)) {
        serial_write("STAGE: ACPI SKIPPED (no RSDP or RSDP >= 4GiB)\n");
        return 0;
    }

    const acpi_rsdp_t *rsdp = (const acpi_rsdp_t *)(uintptr_t)rsdp_phys_addr;
    if (!sig_eq(rsdp->signature, "RSD PTR ", 8)) {
        serial_write("STAGE: ACPI SKIPPED (bad RSDP signature)\n");
        return 0;
    }
    /* ACPI 1.0 체크섬은 처음 20바이트만, 2.0+는 length 전체(확장 체크섬)도
     * 따로 맞아야 한다 — 규격대로 둘 다 검사한다. */
    if (checksum8(rsdp, 20) != 0) {
        serial_write("STAGE: ACPI SKIPPED (RSDP checksum mismatch)\n");
        return 0;
    }
    if (rsdp->revision >= 2 && checksum8(rsdp, rsdp->length) != 0) {
        serial_write("STAGE: ACPI SKIPPED (RSDP extended checksum mismatch)\n");
        return 0;
    }

    const acpi_madt_t *madt = NULL;
    if (rsdp->revision >= 2 && addr_in_range(rsdp->xsdt_address)) {
        const acpi_sdt_header_t *xsdt = (const acpi_sdt_header_t *)(uintptr_t)rsdp->xsdt_address;
        if (validate_sdt(xsdt, "XSDT")) madt = find_madt(xsdt, 1);
    }
    if (!madt && addr_in_range(rsdp->rsdt_address)) {
        const acpi_sdt_header_t *rsdt = (const acpi_sdt_header_t *)(uintptr_t)rsdp->rsdt_address;
        if (validate_sdt(rsdt, "RSDT")) madt = find_madt(rsdt, 0);
    }

    if (!madt) {
        serial_write("STAGE: ACPI SKIPPED (MADT/APIC table not found)\n");
        return 0;
    }

    parse_madt(madt);

    if (g_local_apic_addr == 0 || g_ioapic_count == 0 || g_cpu_count == 0) {
        serial_write("STAGE: ACPI SKIPPED (MADT parsed but missing LAPIC/IOAPIC/CPU data)\n");
        g_local_apic_addr = 0;
        g_ioapic_count = 0;
        g_cpu_count = 0;
        return 0;
    }

    g_available = 1;
    serial_write("STAGE: ACPI OK - Local APIC at 0x");
    serial_write_hex64(g_local_apic_addr);
    serial_write(", ");
    serial_write_hex64((uint64_t)g_ioapic_count);
    serial_write(" IOAPIC(s), ");
    serial_write_hex64((uint64_t)g_cpu_count);
    serial_write(" CPU(s) in MADT\n");
    return 1;
}

int acpi_available(void) { return g_available; }
uint64_t acpi_get_local_apic_addr(void) { return g_available ? g_local_apic_addr : 0; }

int acpi_get_ioapic_count(void) { return g_available ? g_ioapic_count : 0; }
const acpi_ioapic_t *acpi_get_ioapic(int idx) {
    if (!g_available || idx < 0 || idx >= g_ioapic_count) return NULL;
    return &g_ioapics[idx];
}

int acpi_get_cpu_count(void) { return g_available ? g_cpu_count : 0; }
const acpi_cpu_t *acpi_get_cpu(int idx) {
    if (!g_available || idx < 0 || idx >= g_cpu_count) return NULL;
    return &g_cpus[idx];
}
