#ifndef JETOS_AES128_H
#define JETOS_AES128_H

/* JetOS - kernel/net/crypto/aes128.h - AES-128 (FIPS 197), CBC 모드.
 * TLS_RSA_WITH_AES_128_CBC_SHA256 레코드 암호화에 쓰인다. */

#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint32_t round_key[44]; /* 11 라운드 * 4 워드 (AES-128) */
} aes128_ctx_t;

void aes128_init(aes128_ctx_t *ctx, const uint8_t key[16]);
void aes128_encrypt_block(const aes128_ctx_t *ctx, const uint8_t in[16], uint8_t out[16]);
void aes128_decrypt_block(const aes128_ctx_t *ctx, const uint8_t in[16], uint8_t out[16]);

/* CBC 모드. len은 반드시 16의 배수(호출측이 패딩을 이미 채워야 함).
 * iv는 입력으로 쓰이고 변경되지 않는다(호출측이 관리). */
void aes128_cbc_encrypt(const aes128_ctx_t *ctx, const uint8_t iv[16],
                         const uint8_t *in, uint8_t *out, size_t len);
void aes128_cbc_decrypt(const aes128_ctx_t *ctx, const uint8_t iv[16],
                         const uint8_t *in, uint8_t *out, size_t len);

#endif
