/*
 * JetOS - kernel/apps/programs_gui.c
 * Milestone 37: 설치된 프로그램 GUI. 설계 이유는 programs_gui.h 참고.
 */

#include <stddef.h>
#include "programs_gui.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../gui/notify.h"
#include "../drivers/console.h"
#include "../proc/scheduler.h"
#include "../fs/programs.h"
#include "../fs/jetfs.h"
#include "../exec/elf_loader.h"
#include "../exec/pe_loader.h"

#define PG_MAX_ITEMS 32
#define PG_ROW_H 14
#define PG_TOP_MARGIN 20

typedef struct {
    char name[32];
    char path[128];
} pg_item_t;

static pg_item_t g_items[PG_MAX_ITEMS];
static int g_item_count = 0;
static int g_selected = -1;
static char g_status[48] = "";
static int g_pg_win = -1;

static void str_copy_local(char *dst, const char *src, int n) {
    int i = 0; for (; src[i] && i < n - 1; i++) dst[i] = src[i];
    dst[i] = '\0';
}

static void pg_collect_cb(const char *name, const char *path, void *ctx) {
    (void)ctx;
    if (g_item_count >= PG_MAX_ITEMS) return;
    pg_item_t *it = &g_items[g_item_count++];
    str_copy_local(it->name, name, sizeof(it->name));
    str_copy_local(it->path, path, sizeof(it->path));
}

static void pg_reload(void) {
    g_item_count = 0;
    g_selected = -1;
    programs_list(pg_collect_cb, NULL);
}

static void pg_set_status(const char *s) { str_copy_local(g_status, s, sizeof(g_status)); }

static void pg_run_selected(void) {
    if (g_selected < 0) { pg_set_status("select a program first"); return; }
    const char *path = g_items[g_selected].path;

    uint8_t magic[4] = {0,0,0,0};
    uint64_t got = 0;
    jetfs_read(path, magic, sizeof(magic), &got);

    if (got >= 4 && magic[0] == 0x7F && magic[1] == 'E' && magic[2] == 'L' && magic[3] == 'F') {
        if (elf_execute(path)) { pg_set_status("launched (ELF)"); notify_push("Program launched", 2000); }
        else pg_set_status("launch failed");
        return;
    }
    pe_load_result_t res;
    pe_load(path, &res);
    if (res.error_code != 0) { pg_set_status("error: bad PE or missing"); return; }
    int id = pe_execute(path, NULL);
    if (id >= 0) { pg_set_status("launched (PE)"); notify_push("Program launched", 2000); }
    else pg_set_status("launch failed");
}

static void pg_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)ctx;
    dc->cursor_x = (uint32_t)(x + 6); dc->cursor_y = (uint32_t)(y + 4);
    if (g_item_count == 0) {
        console_print(dc, "No programs installed");
        dc->cursor_x = (uint32_t)(x + 6); dc->cursor_y = (uint32_t)(y + 18);
        console_print(dc, "(jash: install <path> <name>)");
    } else {
        for (int i = 0; i < g_item_count; i++) {
            int ry = y + PG_TOP_MARGIN + i * PG_ROW_H;
            if (ry > y + h - 34) break;
            if (i == g_selected) {
                console_fill_rect(dc, (uint32_t)(x + 2), (uint32_t)(ry - 1), (uint32_t)(w - 4), PG_ROW_H, 0x00405878u);
            }
            dc->cursor_x = (uint32_t)(x + 6); dc->cursor_y = (uint32_t)ry;
            console_print(dc, g_items[i].name);
        }
    }

    int status_y = y + h - 30;
    dc->cursor_x = (uint32_t)(x + 6); dc->cursor_y = (uint32_t)status_y;
    dc->fg_color = 0x00A0D0A0u;
    console_print(dc, g_status);
    dc->fg_color = 0x00E0E0E0u;

    static const char *labels[2] = { "Run", "Uninstall" };
    int bw = (w - 16) / 2;
    int by = y + h - 16;
    for (int i = 0; i < 2; i++) {
        int bx = x + 8 + i * bw;
        console_fill_rect(dc, (uint32_t)bx, (uint32_t)by, (uint32_t)(bw - 4), 14, i == 0 ? 0x00305030u : 0x00503030u);
        dc->cursor_x = (uint32_t)(bx + 3); dc->cursor_y = (uint32_t)(by + 3);
        console_print(dc, labels[i]);
    }
}

static void pg_click_cb(int lx, int ly, void *ctx) {
    (void)ctx;
    int fixed_w = 280, fixed_h = 220;
    int by = fixed_h - 16;
    if (ly >= by && ly < by + 14) {
        int bw = (fixed_w - 16) / 2;
        int idx = (lx - 8) / bw;
        if (idx == 0) {
            pg_run_selected();
        } else if (idx == 1) {
            if (g_selected < 0) { pg_set_status("select a program first"); return; }
            if (programs_uninstall(g_items[g_selected].name)) {
                pg_set_status("uninstalled");
                notify_push("Program uninstalled", 2000);
                pg_reload();
            } else {
                pg_set_status("uninstall failed");
            }
        }
        return;
    }

    if (ly < PG_TOP_MARGIN) return;
    int row = (ly - PG_TOP_MARGIN) / PG_ROW_H;
    if (row < 0 || row >= g_item_count) return;
    g_selected = (g_selected == row) ? -1 : row;
    g_status[0] = '\0';
}

static volatile int g_pg_running = 0;

static void pg_on_close(void *ctx) {
    (void)ctx;
    g_pg_running = 0;
}

static void pg_thread_fn(void *arg) {
    (void)arg;
    g_pg_running = 1;
    pg_reload();
    g_pg_win = CreateWindowJ("PROGRAMS", 380, 260, 280, 220, 0x00303040);
    if (g_pg_win >= 0) {
        wm_set_content_callback(g_pg_win, pg_content_cb, NULL);
        wm_set_close_callback(g_pg_win, pg_on_close, NULL);
        wm_set_click_callback(g_pg_win, pg_click_cb, NULL);
    }
    while (g_pg_running) {
        scheduler_yield();
    }
}

void programs_gui_launch(void) {
    static int launched = 0;
    if (launched && g_pg_running) return;
    launched = 1;
    CreateThreadJ("programs_gui", pg_thread_fn, NULL);
}
