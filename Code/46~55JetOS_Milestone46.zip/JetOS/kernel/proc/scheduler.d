kernel/proc/scheduler.o: kernel/proc/scheduler.c kernel/proc/scheduler.h \
 kernel/proc/thread.h kernel/proc/../hal/context_switch.h \
 kernel/proc/../hal/x86_asm_shim.h kernel/proc/../mm/heap.h \
 kernel/proc/../mm/vmm.h
kernel/proc/scheduler.h:
kernel/proc/thread.h:
kernel/proc/../hal/context_switch.h:
kernel/proc/../hal/x86_asm_shim.h:
kernel/proc/../mm/heap.h:
kernel/proc/../mm/vmm.h:
