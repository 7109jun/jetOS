#ifndef JETOS_IPC_H
#define JETOS_IPC_H

#include <stdint.h>

#define IPC_QUEUE_CAP 8

/* 스레드 사이의 최소 메시지 큐(메일박스) 기반 IPC.
 * 큐가 가득/비어있으면 바쁜대기(spin) + scheduler_yield()로 다른
 * 스레드에게 CPU를 양보하며 기다린다 — 진짜 블로킹(대기 큐에 스레드를
 * BLOCKED 상태로 넣고 깨우는 방식)은 향후 마일스톤 과제이며, 지금은
 * "협조적으로 양보하며 기다리는" 방식으로 단순화되어 있다. */
typedef struct {
    uint64_t buf[IPC_QUEUE_CAP];
    int head;
    int tail;
    int count;
} ipc_channel_t;

void ipc_channel_init(ipc_channel_t *ch);
void ipc_send(ipc_channel_t *ch, uint64_t msg);
uint64_t ipc_receive(ipc_channel_t *ch);

#endif
