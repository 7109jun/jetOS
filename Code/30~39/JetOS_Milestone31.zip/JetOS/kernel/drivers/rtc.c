/*
 * JetOS - kernel/drivers/rtc.c
 * CMOS RTC 폴링 읽기. 표준 PC/AT 호환 CMOS 레지스터 맵을 그대로 따른다
 * (인터럽트(IRQ8) 없이 필요할 때 직접 읽는 방식 — AHCI/RTL8139와 같은
 * "폴링" 철학).
 */
#include "rtc.h"
#include "../hal/x86_asm_shim.h"

#define CMOS_INDEX 0x70
#define CMOS_DATA  0x71

#define REG_SECONDS 0x00
#define REG_MINUTES 0x02
#define REG_HOURS   0x04
#define REG_DAY     0x07
#define REG_MONTH   0x08
#define REG_YEAR    0x09
#define REG_STATUS_A 0x0A
#define REG_STATUS_B 0x0B

static uint8_t cmos_read(uint8_t reg) {
    hal_outb(CMOS_INDEX, reg);
    return hal_inb(CMOS_DATA);
}

static int rtc_update_in_progress(void) {
    return (cmos_read(REG_STATUS_A) & 0x80) != 0;
}

static uint8_t bcd_to_bin(uint8_t v) {
    return (uint8_t)(((v >> 4) * 10) + (v & 0x0F));
}

static void read_raw(rtc_time_t *out) {
    out->second = cmos_read(REG_SECONDS);
    out->minute = cmos_read(REG_MINUTES);
    out->hour   = cmos_read(REG_HOURS);
    out->day    = cmos_read(REG_DAY);
    out->month  = cmos_read(REG_MONTH);
    out->year   = cmos_read(REG_YEAR);
}

void rtc_read(rtc_time_t *out) {
    rtc_time_t a, b;

    /* 업데이트 도중 읽어서 값이 튀는 걸 피하려고: UIP가 꺼질 때까지
     * 기다렸다가 두 번 읽어서 같은 값이 나올 때까지 반복한다(표준
     * OSDev 관례). */
    while (rtc_update_in_progress()) { /* busy-wait */ }
    read_raw(&a);
    do {
        while (rtc_update_in_progress()) { /* busy-wait */ }
        read_raw(&b);
        if (a.second == b.second && a.minute == b.minute && a.hour == b.hour &&
            a.day == b.day && a.month == b.month && a.year == b.year) break;
        a = b;
    } while (1);

    uint8_t status_b = cmos_read(REG_STATUS_B);
    int is_binary = (status_b & 0x04) != 0;
    int is_24h = (status_b & 0x02) != 0;

    if (!is_binary) {
        b.second = bcd_to_bin(b.second);
        b.minute = bcd_to_bin(b.minute);
        uint8_t pm_bit = b.hour & 0x80;
        b.hour = bcd_to_bin((uint8_t)(b.hour & 0x7F));
        if (pm_bit) b.hour |= 0x80;
        b.day = bcd_to_bin(b.day);
        b.month = bcd_to_bin(b.month);
        b.year = bcd_to_bin((uint8_t)b.year);
    }

    if (!is_24h && (b.hour & 0x80)) {
        b.hour = (uint8_t)(((b.hour & 0x7F) + 12) % 24);
    } else {
        b.hour &= 0x7F;
    }

    out->second = b.second;
    out->minute = b.minute;
    out->hour = b.hour;
    out->day = b.day;
    out->month = b.month;
    out->year = (uint16_t)(2000 + b.year); /* 세기(century) 레지스터는 다루지 않음 — 21세기로 가정 */
}
