#ifndef JETOS_WM_H
#define JETOS_WM_H

#include <stdint.h>
#include "../drivers/console.h"

#define WM_MAX_WINDOWS 8
#define WM_TITLEBAR_H 18
#define WM_TASKBAR_H 28

typedef void (*wm_content_draw_fn)(console_t *dc, int x, int y, int w, int h, void *ctx);
typedef void (*wm_close_fn)(void *ctx); /* X버튼 클릭 시 소유 앱에게 통지 */
typedef void (*wm_click_fn)(int local_x, int local_y, void *ctx); /* 콘텐츠 영역 클릭 통지 */

typedef struct {
    int x, y, w, h;
    char title[32];
    uint32_t color;
    int visible;
    int minimized;
    int closed;
    int used;
    wm_content_draw_fn content_cb;
    void *content_ctx;
    wm_close_fn close_cb;
    void *close_ctx;
    wm_click_fn click_cb;
    void *click_ctx;
    int win32_style; /* 1이면 Win32(CreateWindowA로 생성된 PE EXE) 스타일로 그린다 */
} wm_window_t;

void wm_init(console_t *con);
console_t *wm_get_draw_console(void); /* 오프스크린 백버퍼용 콘솔 (더블 버퍼링) */
void wm_present(void); /* 백버퍼를 실제 프레임버퍼로 한 번에 블릿 */
int  wm_create_window(const char *title, int x, int y, int w, int h, uint32_t color);
void wm_move_window(int idx, int dx, int dy);
void wm_resize_window(int idx, int dw, int dh);
int  wm_hit_resize_handle(int idx, int x, int y);

/* 데스크톱 아이콘 (Milestone 17) */
int wm_desktop_icon_hit(int x, int y);          /* 좌표가 어느 아이콘 위인지, 없으면 -1 */
int wm_desktop_icon_double_click(int x, int y);  /* 더블클릭 완성 시 아이콘 인덱스, 아니면 -1 */
void wm_bring_to_front(int idx);
int  wm_window_at(int x, int y);            /* 클릭 지점에 있는 최상위 창 인덱스, 없으면 -1 */
int  wm_hit_titlebar(int idx, int x, int y); /* 그 창의 타이틀바를 클릭했는지 */
int  wm_hit_close_button(int idx, int x, int y); /* 그 창의 X버튼을 클릭했는지 */
void wm_get_window_bounds(int idx, int *x, int *y, int *w, int *h);
void wm_set_content_callback(int idx, wm_content_draw_fn cb, void *ctx);

/* X버튼으로 창이 닫힐 때 호출될 콜백을 등록한다. 소유 스레드가 이
 * 콜백에서 자신의 실행 루프를 정지시키는 플래그를 세우는 용도로 쓴다
 * (스레드 자체를 강제 종료하지는 않고, 협조적으로 종료하도록 유도). */
void wm_set_close_callback(int idx, wm_close_fn cb, void *ctx);

/* 창의 콘텐츠 영역(타이틀바 아래) 클릭을 앱에게 전달한다 (Milestone 13,
 * 파일 관리자 더블클릭 탐색 등에 사용). local_x/local_y는 콘텐츠
 * 영역 좌상단 기준 상대 좌표. */
void wm_set_click_callback(int idx, wm_click_fn cb, void *ctx);

/* screen 좌표의 클릭을 해당 창의 click 콜백으로 전달한다(콘텐츠
 * 영역 안일 때만). 전달했으면 1, 아니면(콜백 없음/영역 밖) 0. */
int wm_dispatch_click(int screen_x, int screen_y);

/* Win32(CreateWindowA로 만들어진 PE EXE) 스타일 창으로 표시할지 설정 */
void wm_set_win32_style(int idx, int enabled);

/* 창 제목을 바꾼다 (Milestone 17: Notepad "저장 안 됨" 표시 등에 사용) */
void wm_set_title(int idx, const char *title);

/* 창 닫기 / 최소화 */
void wm_close_window(int idx);      /* 창을 완전히 숨기고 슬롯을 비운다 */
void wm_minimize_window(int idx);   /* 화면에서 숨기되 작업표시줄엔 남긴다 */
void wm_restore_window(int idx);    /* 최소화 해제 + 포커스 */
int  wm_is_window_minimized(int idx);
int  wm_hit_taskbar_window_button(int x, int y); /* 작업표시줄 창 버튼 클릭 시 해당 idx, 없으면 -1 */

/* 우클릭 컨텍스트 메뉴 (Milestone 8) */
void wm_open_context_menu(int x, int y, int window_idx); /* window_idx=-1이면 "데스크톱" 메뉴 */
void wm_close_context_menu(void);
int  wm_is_context_menu_open(void);
int  wm_context_menu_target(void); /* 메뉴가 열릴 때의 window_idx (-1=데스크톱) */
int  wm_hit_context_menu_item(int x, int y, int *out_item_index); /* 항목 클릭 판정 */
int  wm_hit_context_menu(int x, int y); /* 메뉴 영역 자체를 클릭했는지(바깥 클릭 판정용) */

void wm_draw(void);

/* 커서/작업표시줄/시작메뉴 상태 (desktop.c가 갱신) */
void wm_set_cursor(int x, int y);
void wm_get_cursor(int *x, int *y);
void wm_set_start_menu_open(int open);
int  wm_is_start_button_hit(int x, int y);
int  wm_is_start_menu_item_hit(int x, int y, int *out_item_index);

#endif
