#include "langintel.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <regex>
#include <string>
namespace fs=std::filesystem; namespace deiig::langintel {
std::vector<Symbol> index(const std::string&root){std::vector<Symbol> out;std::regex r("\\b(?:fn|function|class|struct)\\s+([A-Za-z_][A-Za-z0-9_]*)");std::error_code ec;for(fs::recursive_directory_iterator it(root,fs::directory_options::skip_permission_denied,ec),end;it!=end&&!ec;it.increment(ec)){if(!it->is_regular_file(ec))continue;auto ext=it->path().extension().string();if(ext!=".cpp"&&ext!=".hpp"&&ext!=".h"&&ext!=".diggcode")continue;std::ifstream f(it->path());std::string s;size_t n=0;while(std::getline(f,s)){++n;std::smatch m;if(std::regex_search(s,m,r))out.push_back({m[1].str(),it->path().string(),n});}}return out;}
void print_outline(const std::string&root){for(auto&s:index(root))std::cout<<s.name<<"  "<<s.file<<":"<<s.line<<"\n";}
void find_refs(const std::string&root,const std::string&needle){std::error_code ec;for(fs::recursive_directory_iterator it(root,fs::directory_options::skip_permission_denied,ec),end;it!=end&&!ec;it.increment(ec)){if(!it->is_regular_file(ec))continue;std::ifstream f(it->path());std::string s;size_t n=0;while(std::getline(f,s)){++n;if(s.find(needle)!=std::string::npos)std::cout<<it->path()<<":"<<n<<":"<<s<<"\n";}}}
}
