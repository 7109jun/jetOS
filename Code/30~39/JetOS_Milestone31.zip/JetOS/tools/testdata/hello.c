/* JetOS PE32+ 테스트용 "Hello, JetOS!" — CRT 없이 순수 Win32 API만 사용.
 * mingw-w64로 빌드하되 -nostdlib + 커스텀 엔트리(start)로 msvcrt 초기화를
 * 완전히 건너뛴다. JetOS의 win32.c가 구현한 MessageBoxA/ExitProcess만
 * 호출하므로 JetOS 위에서 그대로 동작해야 한다. */

typedef int BOOL;
typedef unsigned int DWORD;
typedef void *HWND;
typedef const char *LPCSTR;

__declspec(dllimport) int __stdcall MessageBoxA(HWND, LPCSTR, LPCSTR, DWORD);
__declspec(dllimport) __attribute__((noreturn)) void __stdcall ExitProcess(DWORD);

void start(void) {
    MessageBoxA((HWND)0, "Hello from a real PE32+ EXE running on JetOS!", "JetOS Hello", 0);
    ExitProcess(0);
}
