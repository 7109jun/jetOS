#ifndef JETOS_NOTIFY_H
#define JETOS_NOTIFY_H

#include <stdint.h>

/*
 * JetOS - kernel/gui/notify.h
 * Milestone 34: 알림(notification) 시스템 ("10가지 목록" 6번).
 *
 * 지금까지는 "작업이 끝났다"는 걸 각 앱이 자기 창 안(예: notepad의
 * g_notepad_status)에서만 보여줬다 — 창이 최소화돼 있거나 안 보고
 * 있으면 아예 못 봤다. 이 모듈은 화면 우하단(작업표시줄 바로 위)에
 * 몇 초간 떠 있다 자동으로 사라지는 토스트 큐를 제공한다. 여러 앱이
 * 동시에 알림을 보내도 최대 3개까지 쌓여 보이고, 큐가 다 차면 가장
 * 오래된 것부터 밀려난다.
 *
 * 이 모듈은 큐 데이터만 관리한다 — 실제 그리기는 wm.c의 wm_draw()가
 * (기존 draw_text/fill 헬퍼를 그대로 재사용해) 담당한다. wm.c의 정적
 * 드로잉 헬퍼들이 파일 내부(static)라 여기서 직접 못 쓰기도 하고,
 * "화면에 뭘 그릴지"는 전부 wm.c 안에 모아두는 이 프로젝트의 기존
 * 관례(작업표시줄/시작메뉴/컨텍스트메뉴가 전부 wm.c 안에 있음)를
 * 그대로 따른 것이다.
 */

#define NOTIFY_MAX_VISIBLE 3
#define NOTIFY_MSG_CAP 48

/* 알림을 큐에 추가한다. ttl_ms 뒤 자동으로 사라진다(PIT 100Hz 틱
 * 기준, kernel/int/pit.h의 g_timer_ticks 사용). */
void notify_push(const char *msg, uint32_t ttl_ms);

/* 만료된 알림을 정리하고, 지금 보여줄 알림들(최신순, 최대
 * NOTIFY_MAX_VISIBLE개)을 out에 채운 뒤 개수를 반환한다. wm_draw()가
 * 매 프레임 호출한다. */
int notify_get_visible(char out[NOTIFY_MAX_VISIBLE][NOTIFY_MSG_CAP]);

#endif
