/* JetOS - kernel/gui/clipboard.c - clipboard.h 참고. */
#include "clipboard.h"

static char g_buf[CLIPBOARD_CAP];
static int g_len = 0;

void clipboard_set(const char *text, int len) {
    if (len < 0) len = 0;
    if (len > CLIPBOARD_CAP - 1) len = CLIPBOARD_CAP - 1;
    for (int i = 0; i < len; i++) g_buf[i] = text[i];
    g_buf[len] = '\0';
    g_len = len;
}

const char *clipboard_get(void) { return g_buf; }
int clipboard_len(void) { return g_len; }
