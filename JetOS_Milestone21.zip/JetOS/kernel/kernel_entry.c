/*
 * JetOS - kernel/kernel_entry.c
 *
 * Milestone 1: Serial Logging / Screen Output / Basic Exception Handling
 *              / UEFI Memory Detection
 * Milestone 2: Physical Memory Manager / Virtual Memory Manager / Kernel
 *              Heap / PIC 리맵 / PIT 타이머 인터럽트
 * Milestone 3: Process / Thread / 라운드로빈 스케줄러(선점형+협조형) / IPC
 */

#include "kernel_entry.h"
#include "kernel.h"
#include "drivers/serial.h"
#include "drivers/console.h"
#include "mm/memmap.h"
#include "mm/pmm.h"
#include "mm/vmm.h"
#include "mm/heap.h"
#include "int/idt.h"
#include "int/pic.h"
#include "int/pit.h"
#include "hal/x86_asm_shim.h"
#include "proc/thread.h"
#include "proc/scheduler.h"
#include "proc/process.h"
#include "proc/ipc.h"
#include "drivers/ahci.h"
#include "fs/jetfs.h"
#include "fs/vfs.h"
#include "fs/fat32.h"
#include "shell/terminal.h"
#include "gui/desktop.h"
#include "net/net.h"
#include "net/tcp.h"
#include "net/dns.h"
#include "net/tls.h"
#include "hal/gdt.h"
#include "hal/ring3_test.h"
#include "exec/elf_loader.h"

console_t g_console;

static void log_both(console_t *con, const char *msg) {
    console_print(con, msg);
    serial_write(msg);
}

static void serial_write_uint(uint64_t v) {
    char tmp[20]; int t = 0;
    if (v == 0) { serial_putc('0'); return; }
    while (v > 0) { tmp[t++] = (char)('0' + (v % 10)); v /= 10; }
    while (t > 0) serial_putc(tmp[--t]);
}

/* ===== Milestone 3 데모: 스레드/스케줄러/IPC 동작 증명 ===== */

static volatile int g_demo_remaining = 0;
static ipc_channel_t g_demo_channel;

static void worker_thread_fn(void *arg) {
    const char *label = (const char *)arg;
    for (int i = 1; i <= 5; i++) {
        serial_write("  [thread ");
        serial_write(label);
        serial_write("] iteration ");
        serial_write_uint((uint64_t)i);
        serial_write("\n");
        scheduler_yield(); /* 협조적 양보 (타이머 선점과 별개로도 전환됨을 증명) */
    }
    g_demo_remaining--;
}

static void producer_thread_fn(void *arg) {
    (void)arg;
    for (uint64_t i = 1; i <= 3; i++) {
        serial_write("  [producer] sending ");
        serial_write_uint(i);
        serial_write("\n");
        ipc_send(&g_demo_channel, i * 100);
    }
    g_demo_remaining--;
}

static void consumer_thread_fn(void *arg) {
    (void)arg;
    for (int i = 0; i < 3; i++) {
        uint64_t msg = ipc_receive(&g_demo_channel);
        serial_write("  [consumer] received ");
        serial_write_uint(msg);
        serial_write("\n");
    }
    g_demo_remaining--;
}

static void idle_thread_fn(void *arg) {
    (void)arg;
    for (;;) {
        if (g_demo_remaining == 0) {
            g_demo_remaining = -1; /* 한 번만 출력되도록 sentinel 처리 */
            serial_write("\n=== MILESTONE 3 DEMO COMPLETE (SCHEDULER/THREADS/IPC VERIFIED) ===\n");
            serial_write("=== DESKTOP SHELL(GUI) IS NOW THE ACTIVE FOREGROUND ===\n\n");
        }
        /* zombie reaping: idle은 다른 스레드가 할 일이 없을 때만 실행되므로
         * 여기서 죽은 스레드의 스택/구조체를 안전하게 회수한다. */
        scheduler_reap_dead();
        hal_hlt();
    }
}

void kernel_entry(jetos_boot_info_t *boot_info) {
    /* ---- Milestone 1 : Serial Logging ---- */
    serial_init();
    serial_write("\n=== JETOS KERNEL - MILESTONE 1+2+3 ===\n");
    serial_write("STAGE: KERNEL ENTRY OK (loaded from separate KERNEL.ELF)\n");

    /* ---- Milestone 1 : Screen Output ---- */
    console_init(&g_console, (uint32_t *)boot_info->framebuffer_base,
                 boot_info->width, boot_info->height, boot_info->pixels_per_scanline);
    console_clear(&g_console, g_console.bg_color);
    g_console.cursor_x = 20; g_console.cursor_y = 20;
    log_both(&g_console, "JETOS MILESTONE 4");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "BOOT: OK  (KERNEL.ELF)");

    /* ---- Milestone 14 : GDT + TSS (Ring3 준비) ----
     * idt_init()보다 반드시 먼저 실행해야 한다 — idt.c가 게이트에 넣을
     * 코드 세그먼트 셀렉터를 hal_read_cs()로 "지금 CS"에서 읽어오는데,
     * 그게 우리가 방금 적재한 새 커널 코드 세그먼트여야 하기 때문이다. */
    gdt_init();
    serial_write("STAGE: GDT/TSS INIT OK (Ring3 준비)\n");

    /* ---- Milestone 1 : Basic Exception Handling (IDT) ---- */
    idt_init();
    serial_write("STAGE: IDT / EXCEPTION HANDLING OK\n");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "IDT: OK");

    /* ---- Milestone 1 : UEFI Memory Detection ---- */
    jetos_memory_summary_t mem;
    memmap_summarize(boot_info->memory_map, boot_info->memory_map_size,
                      boot_info->memory_map_descriptor_size, &mem);
    serial_write("STAGE: UEFI MEMORY MAP PARSED (usable pages=");
    serial_write_uint(mem.usable_pages);
    serial_write(")\n");

    /* ---- Milestone 2 : Physical Memory Manager ---- */
    pmm_init(boot_info->memory_map, boot_info->memory_map_size,
              boot_info->memory_map_descriptor_size);
    pmm_stats_t pstats;
    pmm_get_stats(&pstats);
    serial_write("STAGE: PMM INIT OK  free=");
    serial_write_uint(pstats.free_pages);
    serial_write(" used=");
    serial_write_uint(pstats.used_pages);
    serial_write(" (pages)\n");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "PMM: OK");

    /* ---- Milestone 2 : Virtual Memory Manager ---- */
    vmm_init();
    serial_write("STAGE: VMM INIT OK  (CR3 = JetOS PML4, 0-4GiB identity mapped)\n");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "VMM: OK");

    /* ---- Milestone 2 : Kernel Heap ---- */
    heap_init(64);
    heap_stats_t hstats;
    heap_get_stats(&hstats);
    serial_write("STAGE: HEAP INIT OK  total=");
    serial_write_uint(hstats.total_bytes);
    serial_write(" bytes\n");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "HEAP: OK");

    /* ---- Milestone 2 : Interrupts / Timer (PIC 리맵 + PIT) ---- */
    pic_remap();
    for (int i = 0; i < 16; i++) pic_mask_irq((uint8_t)i);
    pit_init(100); /* 100Hz */
    pic_unmask_irq(0);  /* 타이머 */
    pic_unmask_irq(1);  /* 키보드 */
    pic_unmask_irq(2);  /* PIC2(슬레이브) 캐스케이드 라인 — 이걸 마스크한 채로 두면
                          * IRQ8~15(마우스 IRQ12 포함)가 절대 CPU까지 전달되지 않는다 */
    /* IRQ12(마우스)는 여기서 미리 풀지 않는다 — mouse_init()이 초기화
     * ACK 교환 도중의 경쟁 상태를 피하기 위해 자체적으로 마스크/언마스크를
     * 관리한다 (kernel/drivers/mouse.c 참고). */
    serial_write("STAGE: PIC REMAP + PIT(100Hz) + KBD/MOUSE IRQ READY\n");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "TIMER: READY");

    /* ---- Milestone 3 : Process / Thread / Scheduler / IPC ---- */
    scheduler_init();
    ipc_channel_init(&g_demo_channel);

    process_t *proc = process_create("jetos_demo");
    process_spawn_thread(proc, "idle", idle_thread_fn, NULL);
    process_spawn_thread(proc, "A", worker_thread_fn, (void *)"A");
    process_spawn_thread(proc, "B", worker_thread_fn, (void *)"B");
    process_spawn_thread(proc, "C", worker_thread_fn, (void *)"C");
    process_spawn_thread(proc, "producer", producer_thread_fn, NULL);
    process_spawn_thread(proc, "consumer", consumer_thread_fn, NULL);
    process_spawn_thread(proc, "desktop", desktop_thread_fn, NULL);
    /* Milestone 14의 ring3_test_thread_fn()은 여기서 더 이상 부르지
     * 않는다 — 그 테스트는 커널 자체 코드(.text, 공유 identity 매핑)를
     * Ring3에서 직접 실행하는 방식이었는데, Milestone 15에서 그 공유
     * 영역의 U비트를 제대로 제거했기 때문에(vmm.c 참고 — 이게 바로
     * "진짜 보안 경계") 이제는 당연히 페이지 폴트가 난다. 즉 이건
     * 회귀가 아니라 M15가 고친 보안 구멍이 의도대로 막혔다는 증거다.
     * Ring3 자체의 유효성은 이제 elf_execute()가 제대로 격리된 유저
     * 영역에서 실행하는 것으로 검증한다(ring3_test.c는 참고용으로
     * 남겨둔다). */
    /* Milestone 15: 네이티브 ELF 자체 테스트 (파일 없으면 조용히 스킵).
     * Milestone 16: 두 번째 프로세스(일부러 크래시)를 "동시에" 띄워서
     * (a) 스케줄러가 여러 유저 프로세스의 CR3를 서로 안 건드리고 잘
     *     전환하는지, (b) 하나가 죽어도 커널/다른 프로세스는 멀쩡한지
     * 둘 다 한 번에 검증한다. */
    elf_execute("/test_elf");
    elf_execute("/test_elf_crash");
    elf_execute("/test_elf_baduptr"); /* Milestone 19: 유저 포인터 검증 자체 테스트 */
    elf_execute("/test_elf_brk"); /* Milestone 20: SYS_BRK 자체 테스트 */
    g_demo_remaining = 5; /* A,B,C,producer,consumer (idle/desktop/ring3_test 제외) */

    serial_write("STAGE: SCHEDULER + ");
    serial_write_uint((uint64_t)proc->thread_count);
    serial_write(" THREADS CREATED. ENABLING INTERRUPTS + STARTING MULTITASKING.\n");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "SCHEDULER: STARTING");

    hal_sti(); /* 이 시점부터 타이머 선점이 시작된다 */

    /* ---- Milestone 4 : Storage (AHCI) 최초 검증 ----
     * JetOS 자체 파일시스템을 얹기 전에, AHCI 드라이버가 실제로 디스크의
     * 섹터를 정확히 읽어오는지부터 검증한다. 부팅에 사용된 ESP(FAT32)
     * 디스크의 LBA0(부트섹터)을 읽어, FAT32 규격상 항상 마지막 2바이트에
     * 있어야 하는 부트 시그니처 0x55 0xAA를 직접 확인한다. */
    serial_write("STAGE: AHCI INIT...\n");
    int ahci_drives = ahci_init();
    if (ahci_drives > 0) {
        serial_write("STAGE: AHCI INIT OK, drives=");
        serial_write_uint((uint64_t)ahci_drives);
        serial_write("\n");
        uint8_t *sector0 = (uint8_t *)kmalloc(512);
        if (sector0 && ahci_read_sectors(0, 0, 1, sector0)) {
            serial_write("STAGE: AHCI READ LBA0 OK. boot signature = ");
            serial_write_hex64(sector0[510]);
            serial_write(" ");
            serial_write_hex64(sector0[511]);
            serial_write(sector0[510] == 0x55 && sector0[511] == 0xAA ?
                         " (VALID 0x55AA)\n" : " (UNEXPECTED)\n");
            g_console.cursor_x = 20; g_console.cursor_y += 20;
            console_print(&g_console, "AHCI: OK");
        } else {
            serial_write("STAGE: AHCI READ FAILED\n");
        }
        kfree(sector0);
    } else {
        serial_write("STAGE: AHCI INIT FAILED (no controller/drive found)\n");
    }

    /* ---- Milestone 4 : JETFS 파일시스템 + 논리 네임스페이스 + 터미널 ----
     * drive 1이 있으면(테스트에서 mkjetfs로 포맷한 두 번째 디스크) JETFS로
     * 마운트하고, 논리 네임스페이스(:> 등)를 거쳐 터미널 데모 스크립트를
     * 실행해 실제 파일 생성/쓰기/읽기/이름변경/삭제를 증명한다. */
    if (ahci_drives >= 2) {
        if (jetfs_mount(1, 0)) {
            serial_write("STAGE: JETFS MOUNT OK (drive 1)\n");
            g_console.cursor_x = 20; g_console.cursor_y += 20;
            console_print(&g_console, "JETFS: MOUNTED");

            char real_path[64];
            const char *p = vfs_translate(":>/docs", real_path, sizeof(real_path));
            serial_write("STAGE: NAMESPACE ':>/docs' -> '");
            serial_write(p);
            serial_write("'\n");

            terminal_run_demo_script();
            g_console.cursor_x = 20; g_console.cursor_y += 20;
            console_print(&g_console, "TERMINAL DEMO: OK");
        } else {
            serial_write("STAGE: JETFS MOUNT FAILED (drive 1 not JETFS-formatted?)\n");
        }
    } else {
        serial_write("STAGE: JETFS SKIPPED (no second drive attached for data volume)\n");
    }

    /* ---- Milestone 20 : FAT32 USB 드라이브(런타임 읽기 전용) ----
     * drive 2가 있으면(run_qemu.sh가 세 번째 -drive로 붙인 usb.img)
     * FAT32로 마운트해서 루트 디렉터리를 나열하고, 알려진 데모 파일
     * (HELLO.TXT)을 실제로 읽어 내용이 일치하는지 확인한다. */
    if (ahci_drives >= 3) {
        if (fat32_mount(2)) {
            serial_write("STAGE: FAT32 USB MOUNT OK (drive 2)\n");
            int idx = 0;
            fat32_dirent_t e;
            while (fat32_list_root(idx, &e)) {
                serial_write("  [FAT32] ");
                serial_write(e.short_name);
                serial_write("\n");
                idx++;
            }
            static uint8_t usb_buf[256];
            uint32_t n = fat32_read_file("HELLO.TXT", usb_buf, sizeof(usb_buf) - 1);
            if (n > 0) {
                usb_buf[n] = '\0';
                serial_write("STAGE: FAT32 READ HELLO.TXT (");
                serial_write_uint(n);
                serial_write(" bytes): ");
                serial_write((const char *)usb_buf);
                serial_write("\n");
            } else {
                serial_write("STAGE: FAT32 READ HELLO.TXT FAILED (파일 없음? USB 이미지에 넣어뒀는지 확인)\n");
            }

            /* usbrun 명령과 정확히 같은 파이프라인을 자체 테스트로 검증:
             * FAT32에서 실제 ELF를 읽어 JETFS에 쓰고 elf_execute한다.
             * "가져오기"만 확인하는 것과 "가져와서 실제로 실행까지"
             * 되는 것은 다른 문제라 별도로 증명한다. */
            static uint8_t usb_elf_buf[64 * 1024];
            uint32_t elf_n = fat32_read_file("PROGRAM.ELF", usb_elf_buf, sizeof(usb_elf_buf));
            if (elf_n > 0) {
                serial_write("STAGE: FAT32 READ PROGRAM.ELF OK (");
                serial_write_uint(elf_n);
                serial_write(" bytes)\n");
                if (!jetfs_stat("/usb_run_tmp", NULL, NULL)) jetfs_create("/usb_run_tmp", JETFS_TYPE_FILE);
                if (jetfs_write("/usb_run_tmp", usb_elf_buf, elf_n)) {
                    serial_write("STAGE: USB->JETFS IMPORT OK (/usb_run_tmp)\n");
                    if (elf_execute("/usb_run_tmp")) {
                        serial_write("STAGE: USB IMPORT+RUN (usbrun 파이프라인) OK — 실행 시작됨\n");
                    } else {
                        serial_write("STAGE: USB IMPORT+RUN FAILED (elf_execute 실패)\n");
                    }
                } else {
                    serial_write("STAGE: USB->JETFS IMPORT FAILED (jetfs_write)\n");
                }
            } else {
                serial_write("STAGE: FAT32 READ PROGRAM.ELF FAILED (파일 없음?)\n");
            }
        } else {
            serial_write("STAGE: FAT32 USB MOUNT FAILED (drive 2 not FAT32-formatted?)\n");
        }
    } else {
        serial_write("STAGE: FAT32 USB SKIPPED (no third drive attached)\n");
    }

    /* ---- Milestone 10 : 네트워킹 (RTL8139 + ARP/IPv4/ICMP) ----
     * QEMU에 `-device rtl8139`가 붙어있지 않으면 net_init()이 그냥
     * 0을 반환하므로, 네트워킹 없이도 부팅은 정상적으로 계속된다. */
    serial_write("STAGE: NET INIT...\n");
    if (net_init()) {
        g_console.cursor_x = 20; g_console.cursor_y += 20;
        console_print(&g_console, "NET: RTL8139 READY");

        /* ---- 네트워킹 자체 테스트 (AHCI/JETFS 데모와 같은 패턴) ----
         * 게이트웨이(QEMU SLIRP 기준 10.0.2.2)에 ARP로 MAC을 물어보고,
         * 이어서 ICMP echo(ping)까지 실제로 왕복시켜 링크가 "진짜로"
         * 살아있는지 부팅 시점에 증명한다. NIC은 있지만 상대가 없는
         * 환경(-netdev 없이 -device만 붙인 경우 등)에서는 그냥
         * 타임아웃으로 실패하고 넘어간다 — 부팅을 막지 않는다. */
        serial_write("=== NET SELF-TEST START (gateway ");
        char gwbuf[16]; net_ip_to_str(net_get_gateway(), gwbuf);
        serial_write(gwbuf);
        serial_write(") ===\n");

        uint8_t gw_mac[6];
        if (net_arp_resolve(net_get_gateway(), gw_mac, 300)) {
            serial_write("  ARP OK, gateway MAC = ");
            static const char hex[] = "0123456789ABCDEF";
            for (int i = 0; i < 6; i++) {
                char b[3] = { hex[gw_mac[i] >> 4], hex[gw_mac[i] & 0xF], '\0' };
                serial_write(b);
                if (i < 5) serial_write(":");
            }
            serial_write("\n");

            uint32_t rtt;
            if (net_ping(net_get_gateway(), 300, &rtt)) {
                serial_write("  PING OK, rtt=");
                serial_write_uint((uint64_t)(rtt * 10));
                serial_write("ms\n");
            } else {
                serial_write("  PING TIMEOUT (게이트웨이가 ICMP에 응답하지 않음 — 정상적일 수 있음)\n");
            }
        } else {
            serial_write("  ARP TIMEOUT (네트워크 백엔드가 연결 안 됐을 수 있음: -netdev user 필요)\n");
        }
        serial_write("=== NET SELF-TEST END ===\n");

        /* ---- Milestone 11 자체 테스트: 진짜 TCP 3-way handshake +
         * HTTP/1.0 GET + 정상 종료(FIN)까지 실제로 왕복시켜본다.
         * 상대가 없으면(NIC은 있지만 -netdev 백엔드가 없거나 8000번
         * 포트에 아무도 없으면) 그냥 타임아웃으로 실패하고 넘어간다. */
        serial_write("=== TCP SELF-TEST START (10.0.2.2:8000 GET /index.html) ===\n");
        if (tcp_connect(net_str_to_ip("10.0.2.2"), 8000, 300)) {
            serial_write("  TCP CONNECT OK (3-way handshake 완료)\n");
            static const char req[] =
                "GET /index.html HTTP/1.0\r\nHost: 10.0.2.2\r\nConnection: close\r\n\r\n";
            if (tcp_send(req, sizeof(req) - 1, 100)) {
                serial_write("  TCP SEND OK (HTTP GET 전송+ACK 확인)\n");
                static char resp[2048];
                uint32_t n = tcp_recv_until_close(resp, sizeof(resp) - 1, 300);
                resp[n] = '\0';
                serial_write("  TCP RECV: ");
                serial_write_uint(n);
                serial_write(" bytes\n  --- response ---\n");
                serial_write(resp);
                serial_write("\n  --- end response ---\n");
            } else {
                serial_write("  TCP SEND FAILED\n");
            }
            tcp_close();
            serial_write("  TCP CLOSE 완료\n");
        } else {
            serial_write("  TCP CONNECT TIMEOUT (상대가 없거나 도달 불가 — 정상적일 수 있음)\n");
        }
        serial_write("=== TCP SELF-TEST END ===\n");

        /* ---- Milestone 12 자체 테스트: 진짜 DNS 질의 ----
         * QEMU SLIRP의 내장 DNS 포워더(10.0.2.3)에 실제 도메인을
         * 물어봐서 IPv4 주소를 실제로 받아오는지 확인한다. 인터넷
         * 접근이 제한된 환경이면 그냥 타임아웃으로 실패하고 넘어간다. */
        serial_write("=== DNS SELF-TEST START (archive.ubuntu.com) ===\n");
        uint32_t resolved_ip;
        if (dns_resolve("archive.ubuntu.com", &resolved_ip, 300)) {
            char ipbuf[16];
            net_ip_to_str(resolved_ip, ipbuf);
            serial_write("  DNS OK -> ");
            serial_write(ipbuf);
            serial_write("\n");
        } else {
            serial_write("  DNS TIMEOUT/FAILED (인터넷 접근 제한 환경이면 정상적일 수 있음)\n");
        }
        serial_write("=== DNS SELF-TEST END ===\n");

        /* ---- Milestone 19 자체 테스트: 진짜 TLS 1.2 핸드셰이크 ----
         * RSA 키교환 + AES-128-CBC-SHA256으로 실제 암호화된 HTTPS
         * GET 요청-응답을 왕복시킨다(호스트가 QEMU SLIRP 게이트웨이
         * 10.0.2.2:8443에 올려둔 로컬 테스트 서버). 인증서 신뢰
         * 체인 검증은 하지 않으므로(tls.h 참고) 자체서명 인증서로도
         * 접속된다 — 여기선 "암호화 왕복이 실제로 되는지"만 증명. */
        serial_write("=== TLS SELF-TEST START (https://10.0.2.2:8443/) ===\n");
        if (tls_connect(NULL, net_str_to_ip("10.0.2.2"), 8443, 300)) {
            serial_write("  TLS HANDSHAKE OK (RSA key exchange + AES-128-CBC-SHA256)\n");
            static const char treq[] =
                "GET / HTTP/1.0\r\nHost: 10.0.2.2\r\nConnection: close\r\n\r\n";
            if (tls_send(treq, sizeof(treq) - 1, 300)) {
                serial_write("  TLS SEND OK (암호화된 HTTP GET 전송)\n");
                static char tresp[2048];
                uint32_t tn = tls_recv_until_close(tresp, sizeof(tresp) - 1, 300);
                tresp[tn] = '\0';
                serial_write("  TLS RECV: ");
                serial_write_uint(tn);
                serial_write(" bytes (복호화됨)\n  --- decrypted response ---\n");
                serial_write(tresp);
                serial_write("\n  --- end response ---\n");
            } else {
                serial_write("  TLS SEND FAILED\n");
            }
            tls_close();
            serial_write("  TLS CLOSE 완료\n");
        } else {
            serial_write("  TLS HANDSHAKE FAILED/TIMEOUT (테스트 서버가 없으면 정상적일 수 있음)\n");
        }
        serial_write("=== TLS SELF-TEST END ===\n");

        /* ---- Milestone 20 자체 테스트: httprun (다운로드 후 elf_execute) ----
         * jash의 httprun 명령과 정확히 같은 파이프라인: TCP GET →
         * HTTP 헤더 잘라내기 → JETFS에 순수 바이너리로 저장 →
         * elf_execute. 호스트가 10.0.2.2:8001에 실제 ELF를 서빙하는
         * 서버를 올려둬야 통과한다(없으면 CONNECT TIMEOUT으로 스킵). */
        serial_write("=== HTTPRUN SELF-TEST START (http://10.0.2.2:8001/) ===\n");
        {
            uint32_t ip2 = net_str_to_ip("10.0.2.2");
            if (tcp_connect(ip2, 8001, 300)) {
                static const char hreq[] =
                    "GET / HTTP/1.0\r\nHost: 10.0.2.2\r\nConnection: close\r\n\r\n";
                if (tcp_send(hreq, sizeof(hreq) - 1, 100)) {
                    static char hresp[1 << 16];
                    uint32_t hn = tcp_recv_until_close(hresp, sizeof(hresp) - 1, 300);
                    tcp_close();
                    const char *body = hresp;
                    uint32_t body_len = hn;
                    for (uint32_t i = 0; i + 3 < hn; i++) {
                        if (hresp[i]=='\r'&&hresp[i+1]=='\n'&&hresp[i+2]=='\r'&&hresp[i+3]=='\n') {
                            body = hresp + i + 4; body_len = hn - (i + 4); break;
                        }
                    }
                    serial_write("  downloaded body: "); serial_write_uint(body_len); serial_write(" bytes\n");
                    if (body_len > 0) {
                        if (!jetfs_stat("/http_run_tmp", NULL, NULL)) jetfs_create("/http_run_tmp", JETFS_TYPE_FILE);
                        if (jetfs_write("/http_run_tmp", body, body_len)) {
                            serial_write("  saved to JETFS OK\n");
                            if (elf_execute("/http_run_tmp")) {
                                serial_write("  HTTPRUN PIPELINE OK — 실행 시작됨\n");
                            } else {
                                serial_write("  HTTPRUN PIPELINE FAILED (elf_execute)\n");
                            }
                        } else {
                            serial_write("  JETFS 저장 실패\n");
                        }
                    }
                } else {
                    tcp_close();
                    serial_write("  send failed\n");
                }
            } else {
                serial_write("  TCP CONNECT TIMEOUT (테스트 서버가 없으면 정상적일 수 있음)\n");
            }
        }
        serial_write("=== HTTPRUN SELF-TEST END ===\n");
    } else {
        serial_write("STAGE: NET INIT SKIPPED (no RTL8139 NIC found)\n");
    }

    scheduler_start(); /* 반환하지 않음: 첫 스레드로 전환 */

    /* 여기 도달하면 안 됨 (안전망) */
    for (;;) { hal_hlt(); }
}
