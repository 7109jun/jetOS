kernel/hal/syscall_entry.o: kernel/hal/syscall_entry.c \
 kernel/hal/syscall.h
kernel/hal/syscall.h:
