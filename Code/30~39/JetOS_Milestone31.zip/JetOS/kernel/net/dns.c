/*
 * JetOS - kernel/net/dns.c
 */
#include "dns.h"
#include "net.h"
#include "udp.h"
#include "../int/pit.h"
#include <stddef.h>

#pragma pack(push, 1)
typedef struct {
    uint16_t id;
    uint16_t flags;
    uint16_t qdcount;
    uint16_t ancount;
    uint16_t nscount;
    uint16_t arcount;
} dns_header_t;
#pragma pack(pop)

static uint16_t d_htons(uint16_t v) { return (uint16_t)((v << 8) | (v >> 8)); }
#define d_ntohs d_htons

/* 라벨 시퀀스(도메인 이름)를 건너뛰고 그 다음 바이트 위치를 반환한다.
 * 압축 포인터(상위 2비트가 11)를 만나면 그 자리에서 이름이 끝난다고
 * 보고 포인터 2바이트만 소비한다(포인터를 실제로 따라가서 재조립할
 * 필요는 없다 — 우리는 그냥 "이 필드를 지나쳐야 한다"만 알면 된다). */
static uint32_t skip_name(const uint8_t *buf, uint32_t buf_len, uint32_t pos) {
    while (pos < buf_len) {
        uint8_t len = buf[pos];
        if ((len & 0xC0) == 0xC0) return pos + 2;
        if (len == 0) return pos + 1;
        pos += 1u + len;
    }
    return pos;
}

int dns_resolve(const char *hostname, uint32_t *out_ip, uint32_t timeout_ticks) {
    /* 이미 "a.b.c.d" 리터럴이면 질의 없이 바로 파싱 */
    uint32_t literal = net_str_to_ip(hostname);
    if (literal != 0) { *out_ip = literal; return 1; }

    if (!net_available()) return 0;

    /* ---- 질의 패킷 구성 ---- */
    uint8_t query[512];
    dns_header_t *hdr = (dns_header_t *)query;
    static uint16_t id_counter = 0x4A54; /* "JT" 시작값 — 임의의 초기 식별자 */
    uint16_t my_id = ++id_counter;

    hdr->id = d_htons(my_id);
    hdr->flags = d_htons(0x0100); /* 표준 질의, 재귀 요청(RD=1) */
    hdr->qdcount = d_htons(1);
    hdr->ancount = 0;
    hdr->nscount = 0;
    hdr->arcount = 0;

    uint32_t p = sizeof(dns_header_t);
    /* QNAME: 라벨마다 [길이][문자열...], 마지막에 0x00 */
    const char *label_start = hostname;
    while (1) {
        const char *c = label_start;
        uint32_t label_len = 0;
        while (*c && *c != '.') { c++; label_len++; }
        if (label_len == 0 || label_len > 63 || p + 1 + label_len >= sizeof(query)) return 0;
        query[p++] = (uint8_t)label_len;
        for (uint32_t i = 0; i < label_len; i++) query[p++] = (uint8_t)label_start[i];
        if (*c == '\0') break;
        label_start = c + 1;
    }
    query[p++] = 0x00; /* QNAME 종료 */

    query[p++] = 0x00; query[p++] = 0x01; /* QTYPE = A(1) */
    query[p++] = 0x00; query[p++] = 0x01; /* QCLASS = IN(1) */

    static uint16_t src_port_counter = 40000;
    uint16_t src_port = src_port_counter++;
    if (src_port_counter == 0) src_port_counter = 40000;

    if (!udp_send(NET_DNS_IP, 53, src_port, query, p)) return 0;

    /* ---- 응답 대기 ---- */
    uint8_t resp[512];
    uint32_t deadline_ticks = timeout_ticks;
    uint64_t start = g_timer_ticks;
    while (g_timer_ticks - start < deadline_ticks) {
        uint32_t remaining = deadline_ticks - (uint32_t)(g_timer_ticks - start);
        uint32_t n = udp_recv(src_port, resp, sizeof(resp), NULL, NULL, remaining < 5 ? remaining : 5);
        if (n == 0) {
            if (g_timer_ticks - start >= deadline_ticks) break;
            continue;
        }
        if (n < sizeof(dns_header_t)) continue;
        dns_header_t *rhdr = (dns_header_t *)resp;
        if (d_ntohs(rhdr->id) != my_id) continue; /* 우리가 보낸 질의의 응답이 아님 */

        uint16_t ancount = d_ntohs(rhdr->ancount);
        uint16_t qdcount = d_ntohs(rhdr->qdcount);
        uint32_t off = sizeof(dns_header_t);

        /* 질문 섹션 건너뛰기 (QNAME + QTYPE(2) + QCLASS(2)) */
        for (uint16_t i = 0; i < qdcount; i++) {
            off = skip_name(resp, n, off);
            off += 4;
        }

        for (uint16_t i = 0; i < ancount; i++) {
            if (off >= n) break;
            off = skip_name(resp, n, off);
            if (off + 10 > n) break;
            uint16_t rtype = (uint16_t)((resp[off] << 8) | resp[off + 1]);
            uint16_t rclass = (uint16_t)((resp[off + 2] << 8) | resp[off + 3]);
            uint16_t rdlen = (uint16_t)((resp[off + 8] << 8) | resp[off + 9]);
            off += 10;
            if (off + rdlen > n) break;

            if (rtype == 1 && rclass == 1 && rdlen == 4) { /* A record, IN class */
                uint32_t ip = ((uint32_t)resp[off] << 24) | ((uint32_t)resp[off + 1] << 16) |
                               ((uint32_t)resp[off + 2] << 8) | (uint32_t)resp[off + 3];
                *out_ip = ip;
                return 1;
            }
            off += rdlen;
        }
        /* 이 응답엔 A 레코드가 없었음(예: CNAME만 옴) — 우리는 체인을
         * 따라가지 않으므로 실패로 처리한다(단순화, dns.h 참고). */
        return 0;
    }
    return 0;
}
