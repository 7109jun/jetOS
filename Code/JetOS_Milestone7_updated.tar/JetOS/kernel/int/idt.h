#ifndef JETOS_IDT_H
#define JETOS_IDT_H

#include <stdint.h>

/* x86_64 IDT gate descriptor (16 bytes) */
typedef struct {
    uint16_t offset_low;
    uint16_t selector;
    uint8_t  ist;
    uint8_t  type_attr;
    uint16_t offset_mid;
    uint32_t offset_high;
    uint32_t zero;
} __attribute__((packed)) idt_entry_t;

/* GCC의 x86 interrupt attribute가 요구하는 표준 프레임 타입
 * (GCC 공식 문서 예제와 동일한 정의) */
typedef unsigned long uword_t;
struct interrupt_frame {
    uword_t ip;
    uword_t cs;
    uword_t flags;
    uword_t sp;
    uword_t ss;
};

void idt_init(void);
void idt_set_gate(int vector, void *handler, uint8_t ist, uint8_t type_attr);

#endif
