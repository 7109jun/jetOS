/* JetOS 네이티브 ELF 테스트 프로그램 #2 — 일부러 크래시를 낸다.
 * Milestone 16의 "유저 프로세스 오류 격리"를 검증하기 위한 것:
 * 이 프로그램이 NULL 포인터에 쓰기를 시도해 페이지 폴트를 내도,
 * 커널 전체가 아니라 이 프로세스만 죽어야 한다. */

static long jsyscall(long num, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile (
        "int $0x80"
        : "=a"(ret)
        : "a"(num), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory"
    );
    return ret;
}

#define SYS_WRITE 0

void _start(void) {
    static const char msg1[] =
        "[crash-test process] about to write to NULL pointer on purpose...\n";
    jsyscall(SYS_WRITE, (long)msg1, 0, 0);

    volatile long *bad_ptr = (volatile long *)0;
    *bad_ptr = 42; /* 여기서 #PF 발생 -> 커널이 이 프로세스만 종료해야 함 */

    /* 격리가 제대로 안 됐다면(혹은 폴트가 안 났다면) 여기 도달함 —
     * 도달하면 안 되는 코드라는 걸 알리는 메시지. */
    static const char msg2[] =
        "[crash-test process] ERROR: reached code after NULL write (isolation failed!)\n";
    jsyscall(SYS_WRITE, (long)msg2, 0, 0);
    for (;;) { }
}
