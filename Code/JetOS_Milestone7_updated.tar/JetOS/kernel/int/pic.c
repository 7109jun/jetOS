/*
 * JetOS - kernel/int/pic.c
 * 레거시 8259 PIC(Programmable Interrupt Controller) 초기화.
 * 모든 접근은 포트 I/O이며, hal_outb/hal_inb (기존 HAL shim) 만 사용한다
 * — 이 파일 자체에는 인라인 어셈블리가 전혀 없다.
 */

#include "pic.h"
#include "../hal/x86_asm_shim.h"

#define PIC1_CMD  0x20
#define PIC1_DATA 0x21
#define PIC2_CMD  0xA0
#define PIC2_DATA 0xA1

#define ICW1_INIT  0x10
#define ICW1_ICW4  0x01
#define ICW4_8086  0x01

static void io_wait(void) {
    hal_outb(0x80, 0); /* 사용되지 않는 포트에 쓰기 = 명령이 처리될 시간을 벎 */
}

void pic_remap(void) {
    uint8_t mask1 = hal_inb(PIC1_DATA);
    uint8_t mask2 = hal_inb(PIC2_DATA);

    hal_outb(PIC1_CMD, ICW1_INIT | ICW1_ICW4); io_wait();
    hal_outb(PIC2_CMD, ICW1_INIT | ICW1_ICW4); io_wait();

    hal_outb(PIC1_DATA, PIC1_OFFSET); io_wait();
    hal_outb(PIC2_DATA, PIC2_OFFSET); io_wait();

    hal_outb(PIC1_DATA, 4); io_wait(); /* PIC1의 IRQ2에 PIC2가 연결됨을 알림 */
    hal_outb(PIC2_DATA, 2); io_wait(); /* PIC2에게 자신이 cascade identity 2임을 알림 */

    hal_outb(PIC1_DATA, ICW4_8086); io_wait();
    hal_outb(PIC2_DATA, ICW4_8086); io_wait();

    hal_outb(PIC1_DATA, mask1);
    hal_outb(PIC2_DATA, mask2);
}

void pic_send_eoi(uint8_t irq) {
    if (irq >= 8) hal_outb(PIC2_CMD, 0x20);
    hal_outb(PIC1_CMD, 0x20);
}

void pic_mask_irq(uint8_t irq) {
    uint16_t port = (irq < 8) ? PIC1_DATA : PIC2_DATA;
    uint8_t bit = irq < 8 ? irq : irq - 8;
    uint8_t val = hal_inb(port);
    hal_outb(port, val | (1 << bit));
}

void pic_unmask_irq(uint8_t irq) {
    uint16_t port = (irq < 8) ? PIC1_DATA : PIC2_DATA;
    uint8_t bit = irq < 8 ? irq : irq - 8;
    uint8_t val = hal_inb(port);
    hal_outb(port, val & ~(1 << bit));
}
