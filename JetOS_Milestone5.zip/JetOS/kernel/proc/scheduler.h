#ifndef JETOS_SCHEDULER_H
#define JETOS_SCHEDULER_H

#include "thread.h"

#define SCHED_TIME_SLICE_TICKS 5 /* 100Hz 타이머 기준 5틱 = 50ms 타임슬라이스 */

void scheduler_init(void);

/* 준비 큐(원형 연결 리스트)에 스레드를 등록한다. thread_create()가 내부적으로 호출한다. */
void scheduler_enqueue(thread_t *t);

/* 현재 실행중인 스레드를 반환한다. */
thread_t *scheduler_current(void);

/* 협조적 양보: 다음 준비된 스레드로 전환한다 (없으면 즉시 반환). */
void scheduler_yield(void);

/* 타이머 인터럽트(isr_timer)에서 매 틱마다 호출된다. 타임슬라이스가
 * 소진되면 내부적으로 scheduler_yield()를 호출한다. */
void scheduler_tick_from_isr(void);

/* 첫 준비된 스레드로 진입한다 (멀티태스킹 시작). 반환하지 않는다. */
__attribute__((noreturn)) void scheduler_start(void);

/* 현재 스레드를 준비 큐에서 제거하고 죽은 것으로 표시한 뒤 다음
 * 스레드로 전환한다 (반환하지 않음). thread_exit()이 호출한다. */
__attribute__((noreturn)) void scheduler_exit_current(void);

#endif
