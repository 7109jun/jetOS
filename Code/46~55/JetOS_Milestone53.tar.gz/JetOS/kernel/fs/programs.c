/*
 * JetOS - kernel/fs/programs.c
 * Milestone 37: 소프트웨어 설치/제거 체계. 설계 이유는 programs.h 참고.
 */

#include "programs.h"
#include "jetfs.h"
#include "recyclebin.h"
#include <stddef.h>

#define PROGRAMS_FILE "/system/programs.txt"
#define PROGRAMS_MAX_ENTRIES 32
#define PROGRAMS_NAME_CAP 32
#define PROGRAMS_PATH_CAP 128
#define PROGRAMS_BUF_MAX 4096

typedef struct {
    char name[PROGRAMS_NAME_CAP];
    char path[PROGRAMS_PATH_CAP];
} program_entry_t;

static int s_eq(const char *a, const char *b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

/* "이름|경로\n" 줄들을 배열로 읽는다. 반환값은 읽은 개수. */
static int load_entries(program_entry_t list[PROGRAMS_MAX_ENTRIES]) {
    jetfs_inode_type_t t;
    if (!jetfs_stat(PROGRAMS_FILE, &t, NULL) || t != JETFS_TYPE_FILE) return 0;

    char buf[PROGRAMS_BUF_MAX];
    uint64_t got = 0;
    if (!jetfs_read(PROGRAMS_FILE, buf, sizeof(buf) - 1, &got)) return 0;
    buf[got] = '\0';

    int n = 0;
    uint64_t i = 0;
    while (i < got && n < PROGRAMS_MAX_ENTRIES) {
        int c = 0;
        while (i < got && buf[i] != '|' && buf[i] != '\n' && c < PROGRAMS_NAME_CAP - 1) list[n].name[c++] = buf[i++];
        list[n].name[c] = '\0';

        list[n].path[0] = '\0';
        if (i < got && buf[i] == '|') {
            i++;
            int p = 0;
            while (i < got && buf[i] != '\n' && p < PROGRAMS_PATH_CAP - 1) list[n].path[p++] = buf[i++];
            list[n].path[p] = '\0';
        }

        while (i < got && buf[i] != '\n') i++; /* 너무 긴 줄의 나머지 버림 */
        if (i < got) i++;
        if (list[n].name[0] != '\0' && list[n].path[0] != '\0') n++;
    }
    return n;
}

static int save_entries(program_entry_t list[PROGRAMS_MAX_ENTRIES], int n) {
    if (!jetfs_stat("/system", NULL, NULL)) jetfs_create("/system", JETFS_TYPE_DIR);

    char out[PROGRAMS_BUF_MAX];
    int len = 0;
    for (int i = 0; i < n; i++) {
        for (int k = 0; list[i].name[k] && len < (int)sizeof(out) - 2; k++) out[len++] = list[i].name[k];
        if (len < (int)sizeof(out) - 2) out[len++] = '|';
        for (int k = 0; list[i].path[k] && len < (int)sizeof(out) - 2; k++) out[len++] = list[i].path[k];
        if (len < (int)sizeof(out) - 2) out[len++] = '\n';
    }
    if (!jetfs_stat(PROGRAMS_FILE, NULL, NULL)) {
        if (!jetfs_create(PROGRAMS_FILE, JETFS_TYPE_FILE)) return 0;
    }
    return jetfs_write(PROGRAMS_FILE, out, (uint64_t)len);
}

int programs_install(const char *name, const char *path) {
    program_entry_t list[PROGRAMS_MAX_ENTRIES];
    int n = load_entries(list);

    for (int i = 0; i < n; i++) {
        if (s_eq(list[i].name, name)) return 0; /* 이미 있는 이름 */
    }
    if (n >= PROGRAMS_MAX_ENTRIES) return 0;

    int k = 0;
    for (; name[k] && k < PROGRAMS_NAME_CAP - 1; k++) list[n].name[k] = name[k];
    list[n].name[k] = '\0';
    k = 0;
    for (; path[k] && k < PROGRAMS_PATH_CAP - 1; k++) list[n].path[k] = path[k];
    list[n].path[k] = '\0';
    n++;

    return save_entries(list, n);
}

int programs_uninstall(const char *name) {
    program_entry_t list[PROGRAMS_MAX_ENTRIES];
    int n = load_entries(list);

    int found = -1;
    for (int i = 0; i < n; i++) { if (s_eq(list[i].name, name)) { found = i; break; } }
    if (found < 0) return 0;

    char path[PROGRAMS_PATH_CAP];
    int k = 0; for (; list[found].path[k]; k++) path[k] = list[found].path[k]; path[k] = '\0';

    for (int i = found; i < n - 1; i++) list[i] = list[i + 1];
    n--;

    if (!save_entries(list, n)) return 0;
    recyclebin_delete(path); /* 실행파일 자체도 휴지통으로 — 실수로 제거해도 복구 가능 */
    return 1;
}

int programs_list(programs_list_cb cb, void *ctx) {
    program_entry_t list[PROGRAMS_MAX_ENTRIES];
    int n = load_entries(list);
    for (int i = 0; i < n; i++) cb(list[i].name, list[i].path, ctx);
    return n;
}
