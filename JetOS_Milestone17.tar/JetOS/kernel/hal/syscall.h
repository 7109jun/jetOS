#ifndef JETOS_SYSCALL_H
#define JETOS_SYSCALL_H

#include <stdint.h>

/*
 * JetOS - kernel/hal/syscall.h
 * Milestone 14: INT 0x80 기반 최소 시스템콜 게이트.
 *
 * 호출 규약(단순화된 SysV 유사 방식): RAX=시스템콜 번호, RDI/RSI/RDX=
 * 인자 0~2. 반환값은 RAX. 유저 코드는 `int $0x80` 한 줄로 커널에 진입한다.
 *
 * 알려진 단순화: 지금은 프로세스별 주소공간 분리가 없으므로(vmm.c 참고)
 * 유저가 넘긴 포인터를 "커널 주소인지" 검증하는 절차가 없다 — 진짜
 * 프로세스 격리가 생기기 전까지는 신뢰 경계가 사실상 없는 상태다.
 */

typedef struct {
    uint64_t r15, r14, r13, r12, r11, r10, r9, r8;
    uint64_t rbp, rdi, rsi, rdx, rcx, rbx, rax;
} syscall_regs_t;

#define SYS_WRITE   0 /* rdi = const char* (NUL 종료 문자열) — serial_write로 출력 */
#define SYS_EXIT    1 /* 유저 스레드 종료 (돌아오지 않음) */
#define SYS_GETTICK 2 /* 반환값(rax) = g_timer_ticks */

/* 시스템콜 진입점(naked, 어셈블리) — idt.c가 벡터 0x80에 이 함수를 건다. */
void syscall_entry(void);

/* 실제 처리 로직(순수 C) — syscall_entry가 레지스터를 저장한 뒤 호출한다. */
void syscall_dispatch(syscall_regs_t *regs);

#endif
