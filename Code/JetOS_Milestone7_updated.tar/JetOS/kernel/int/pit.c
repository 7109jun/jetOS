/*
 * JetOS - kernel/int/pit.c
 * 8253/8254 PIT 채널0 설정. 포트 0x40(데이터)/0x43(명령)만 사용하며
 * 전부 hal_outb 기반 순수 C 구현이다.
 */

#include "pit.h"
#include "../hal/x86_asm_shim.h"

#define PIT_CH0_DATA 0x40
#define PIT_CMD      0x43
#define PIT_MODE3_SQUARE_WAVE 0x36 /* channel0, lobyte/hibyte, mode3, binary */

volatile uint64_t g_timer_ticks = 0;

void pit_init(uint32_t frequency_hz) {
    if (frequency_hz == 0) frequency_hz = 100;
    uint32_t divisor = (uint32_t)(PIT_BASE_FREQUENCY / frequency_hz);
    if (divisor == 0) divisor = 1;
    if (divisor > 0xFFFF) divisor = 0xFFFF;

    hal_outb(PIT_CMD, PIT_MODE3_SQUARE_WAVE);
    hal_outb(PIT_CH0_DATA, (uint8_t)(divisor & 0xFF));
    hal_outb(PIT_CH0_DATA, (uint8_t)((divisor >> 8) & 0xFF));
}
