kernel/apps/settings.o: kernel/apps/settings.c kernel/apps/settings.h \
 kernel/apps/../../include/jetapi/jetapi.h kernel/apps/../gui/wm.h \
 kernel/apps/../gui/../drivers/console.h kernel/apps/../gui/theme.h \
 kernel/apps/../drivers/console.h kernel/apps/../proc/scheduler.h \
 kernel/apps/../proc/thread.h kernel/apps/../fs/config.h
kernel/apps/settings.h:
kernel/apps/../../include/jetapi/jetapi.h:
kernel/apps/../gui/wm.h:
kernel/apps/../gui/../drivers/console.h:
kernel/apps/../gui/theme.h:
kernel/apps/../drivers/console.h:
kernel/apps/../proc/scheduler.h:
kernel/apps/../proc/thread.h:
kernel/apps/../fs/config.h:
