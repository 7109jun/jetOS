/*
 * JetOS - kernel/fs/perm.c
 * Milestone 34: 파일 권한(소프트 읽기전용 목록).
 * Milestone 46: 진짜 커널 레벨 강제(jetfs_inode_t.flags)로 이전 —
 * 설계 이유는 perm.h 참고. 이 파일은 이제 얇은 위임 계층 +
 * 예전 목록 파일 마이그레이션만 담당한다.
 */

#include "perm.h"
#include "jetfs.h"
#include <stddef.h>

#define PERM_FILE "/system/readonly.txt"
#define PERM_MAX_ENTRIES 16
#define PERM_PATH_CAP 64
#define PERM_BUF_MAX 1024

int perm_is_readonly(const char *path) {
    return jetfs_is_readonly(path);
}

int perm_set_readonly(const char *path, int readonly) {
    return jetfs_set_readonly(path, readonly);
}

/* 예전 형식(/system/readonly.txt, 줄바꿈으로 구분된 경로 목록)을 읽어
 * 새 inode 플래그로 옮긴다. 각 경로가 실제로 존재하고 옮기기에
 * 성공했을 때만 그 줄을 "처리 완료"로 치고, 목록 파일 자체는 전부
 * 끝나면 지운다(다시 부팅해도 또 마이그레이션을 시도하지 않도록). */
void perm_migrate_legacy_list(void) {
    jetfs_inode_type_t t;
    if (!jetfs_stat(PERM_FILE, &t, NULL) || t != JETFS_TYPE_FILE) return; /* 이미 없음 = 마이그레이션 끝났거나 신규 설치 */

    char buf[PERM_BUF_MAX];
    uint64_t got = 0;
    if (!jetfs_read(PERM_FILE, buf, sizeof(buf) - 1, &got)) return;
    buf[got] = '\0';

    char list[PERM_MAX_ENTRIES][PERM_PATH_CAP];
    int n = 0;
    uint64_t i = 0;
    while (i < got && n < PERM_MAX_ENTRIES) {
        int c = 0;
        while (i < got && buf[i] != '\n' && c < PERM_PATH_CAP - 1) list[n][c++] = buf[i++];
        list[n][c] = '\0';
        while (i < got && buf[i] != '\n') i++;
        if (i < got) i++;
        if (c > 0) n++;
    }

    for (int k = 0; k < n; k++) {
        jetfs_set_readonly(list[k], 1); /* 실패해도(파일이 그새 없어졌다든지) 계속 진행 — 마이그레이션은 최선 노력 */
    }
    jetfs_delete(PERM_FILE); /* 다시는 이 경로로 마이그레이션 반복 안 하게 */
}
