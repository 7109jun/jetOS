/*
 * JetOS - kernel/apps/clock.c
 * Milestone 13: 내장 앱 - 시계. CMOS RTC(rtc.c)에서 실시간으로 읽어
 * 창이 다시 그려질 때마다(데스크톱 루프가 계속 wm_draw()를 부르므로
 * 사실상 매 프레임) 최신 시각을 보여준다 — 별도 타이머 스레드 없이도
 * "살아있는" 시계가 된다.
 */

#include <stddef.h>
#include "clock.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../drivers/console.h"
#include "../drivers/rtc.h"
#include "../proc/scheduler.h"
#include "../fs/config.h" /* Milestone 33: 12/24시간제 설정 */

static void put2(char *buf, int off, uint8_t v) {
    buf[off] = (char)('0' + (v / 10) % 10);
    buf[off + 1] = (char)('0' + v % 10);
}

static const char *MONTH_NAMES[13] = {
    "", "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
};

static void clock_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)h; (void)ctx;
    rtc_time_t t;
    rtc_read(&t);

    /* Milestone 33: 설정에 저장된 12/24시간제를 따른다(기본값 24시간제 —
     * config.txt가 없거나 손상돼도 M13 이래의 기존 동작과 동일). */
    int is_24h = config_get_clock_24h();
    uint8_t display_hour = t.hour;
    int is_pm = display_hour >= 12;
    if (!is_24h) {
        display_hour = (uint8_t)(display_hour % 12);
        if (display_hour == 0) display_hour = 12;
    }

    char timebuf[12]; /* "HH:MM:SS" 또는 "HH:MM:SS AM" */
    put2(timebuf, 0, display_hour);
    timebuf[2] = ':';
    put2(timebuf, 3, t.minute);
    timebuf[5] = ':';
    put2(timebuf, 6, t.second);
    if (is_24h) {
        timebuf[8] = '\0';
    } else {
        timebuf[8] = ' ';
        timebuf[9] = is_pm ? 'P' : 'A';
        timebuf[10] = 'M';
        timebuf[11] = '\0';
    }

    dc->cursor_x = (uint32_t)(x + 14);
    dc->cursor_y = (uint32_t)(y + 18);
    console_print(dc, timebuf);

    char datebuf[24];
    int i = 0;
    const char *mon = (t.month >= 1 && t.month <= 12) ? MONTH_NAMES[t.month] : "???";
    for (int k = 0; mon[k]; k++) datebuf[i++] = mon[k];
    datebuf[i++] = ' ';
    if (t.day < 10) datebuf[i++] = '0';
    { char tmp[4]; int tn = 0; uint8_t v = t.day;
      if (v == 0) tmp[tn++] = '0';
      while (v) { tmp[tn++] = (char)('0' + v % 10); v /= 10; }
      for (int k = tn - 1; k >= 0; k--) datebuf[i++] = tmp[k]; }
    datebuf[i++] = ',';
    datebuf[i++] = ' ';
    { int v = t.year; char tmp[6]; int tn = 0;
      if (v == 0) tmp[tn++] = '0';
      while (v) { tmp[tn++] = (char)('0' + v % 10); v /= 10; }
      for (int k = tn - 1; k >= 0; k--) datebuf[i++] = tmp[k]; }
    datebuf[i] = '\0';

    dc->cursor_x = (uint32_t)(x + 14);
    dc->cursor_y = (uint32_t)(y + 40);
    console_print(dc, datebuf);
}

static volatile int g_clock_running = 0;

static void clock_on_close(void *ctx) {
    (void)ctx;
    g_clock_running = 0;
}

static void clock_thread_fn(void *arg) {
    (void)arg;
    g_clock_running = 1;
    JetWindowHandle win = CreateWindowJ("CLOCK", 900, 300, 180, 80, 0x00203045);
    if (win >= 0) {
        wm_set_content_callback(win, clock_content_cb, NULL);
        wm_set_close_callback(win, clock_on_close, NULL);
    }
    while (g_clock_running) {
        scheduler_yield();
    }
}

void clock_launch(void) {
    static int launched = 0;
    if (launched && g_clock_running) return;
    launched = 1;
    CreateThreadJ("clock", clock_thread_fn, NULL);
}
