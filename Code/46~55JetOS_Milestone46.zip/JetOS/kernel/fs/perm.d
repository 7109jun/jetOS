kernel/fs/perm.o: kernel/fs/perm.c kernel/fs/perm.h kernel/fs/jetfs.h
kernel/fs/perm.h:
kernel/fs/jetfs.h:
