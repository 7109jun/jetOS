/* JetOS - kernel/drivers/speaker.c - speaker.h 참고. */
#include "speaker.h"
#include "../hal/x86_asm_shim.h"
#include "../int/pit.h"
#include "../proc/scheduler.h"

#define PIT_CH2_DATA  0x42
#define PIT_CMD       0x43
#define PC_SPEAKER_PORT 0x61

void speaker_on(uint32_t freq_hz) {
    if (freq_hz < 20) freq_hz = 20; /* 너무 낮으면(분주비 오버플로) 가청 최저로 clamp */

    uint32_t divisor = (uint32_t)(PIT_BASE_FREQUENCY / freq_hz);
    if (divisor > 0xFFFF) divisor = 0xFFFF;
    if (divisor < 1) divisor = 1;

    /* 채널2, lobyte/hibyte 접근, 모드3(사각파), 이진 카운트 */
    hal_outb(PIT_CMD, 0xB6);
    hal_outb(PIT_CH2_DATA, (uint8_t)(divisor & 0xFF));
    hal_outb(PIT_CH2_DATA, (uint8_t)((divisor >> 8) & 0xFF));

    uint8_t cur = hal_inb(PC_SPEAKER_PORT);
    if ((cur & 0x03) != 0x03) {
        hal_outb(PC_SPEAKER_PORT, (uint8_t)(cur | 0x03)); /* bit0: 타이머 게이트, bit1: 스피커 데이터 활성 */
    }
}

void speaker_off(void) {
    uint8_t cur = hal_inb(PC_SPEAKER_PORT);
    hal_outb(PC_SPEAKER_PORT, (uint8_t)(cur & ~0x03));
}

static void sleep_ms_yielding(uint32_t ms) {
    /* pit_init()이 설정한 채널0 주파수 기준 tick 수 — 커널이 100Hz로
     * 초기화하는 걸 다른 곳(kernel_entry.c)에서 이미 가정하고 있어
     * 여기서도 동일하게 가정한다(10ms/tick). */
    uint64_t ticks_needed = ms / 10;
    if (ticks_needed == 0) ticks_needed = 1;
    uint64_t deadline = g_timer_ticks + ticks_needed;
    while (g_timer_ticks < deadline) {
        scheduler_yield();
    }
}

void speaker_beep(uint32_t freq_hz, uint32_t duration_ms) {
    if (freq_hz == 0) {
        sleep_ms_yielding(duration_ms);
        return;
    }
    speaker_on(freq_hz);
    sleep_ms_yielding(duration_ms);
    speaker_off();
}

void speaker_play_melody(const speaker_note_t *notes, uint32_t count) {
    for (uint32_t i = 0; i < count; i++) {
        uint32_t dur = notes[i].duration_ms;
        uint32_t gap = dur / 10;
        if (gap > 15) gap = 15;
        if (gap >= dur) gap = 0;
        speaker_beep(notes[i].freq_hz, dur - gap);
        if (gap > 0) sleep_ms_yielding(gap); /* 음 사이 짧은 무음 — 같은 음 반복 시 구분되게 */
    }
}
