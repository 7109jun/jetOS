/*
 * JetOS - kernel/int/exceptions.c
 *
 * 모든 예외 핸들러는 GCC의 x86 `interrupt` 함수 속성으로 작성된 순수
 * C 함수다. 이 속성을 사용하면 컴파일러가 인터럽트 진입/복귀에 필요한
 * 레지스터 저장/복원과 iretq 를 자동으로 생성해 주므로, 핸들러 코드 자체는
 * 단 한 줄의 인라인 어셈블리도 필요로 하지 않는다.
 */

#include "exceptions.h"
#include "../panic.h"
#include "../hal/x86_asm_shim.h"
#include "pic.h"
#include "pit.h"
#include "../proc/scheduler.h"
#include "../drivers/keyboard.h"
#include "../drivers/mouse.h"

__attribute__((interrupt))
void isr_divide_by_zero(struct interrupt_frame *frame) {
    jetos_panic("DIVIDE BY ZERO", 0, frame->ip);
}

__attribute__((interrupt))
void isr_breakpoint(struct interrupt_frame *frame) {
    /* 브레이크포인트는 치명적이지 않다: Milestone 1에서는 로그만 남기고
     * 다음 명령으로 복귀한다 (디버거 지원은 이후 마일스톤 과제). */
    (void)frame;
}

__attribute__((interrupt))
void isr_invalid_opcode(struct interrupt_frame *frame) {
    jetos_panic("INVALID OPCODE", 0, frame->ip);
}

__attribute__((interrupt))
void isr_double_fault(struct interrupt_frame *frame, unsigned long long error_code) {
    jetos_panic("DOUBLE FAULT", error_code, frame->ip);
}

__attribute__((interrupt))
void isr_general_protection(struct interrupt_frame *frame, unsigned long long error_code) {
    jetos_panic("GENERAL PROTECTION FAULT", error_code, frame->ip);
}

__attribute__((interrupt))
void isr_page_fault(struct interrupt_frame *frame, unsigned long long error_code) {
    jetos_panic("PAGE FAULT", error_code, hal_read_cr2());
}

__attribute__((interrupt))
void isr_default_handler(struct interrupt_frame *frame) {
    /* 정의되지 않은 벡터: Milestone 1에서는 무시하고 복귀한다. */
    (void)frame;
}

__attribute__((interrupt))
void isr_timer(struct interrupt_frame *frame) {
    (void)frame;
    g_timer_ticks++;
    /* EOI는 반드시 스케줄러 전환(스택 교체) 이전에 보내야 한다. 그렇지
     * 않으면 이 스레드가 다시 스케줄될 때까지 PIC의 IRQ0 in-service
     * 비트가 해제되지 않아 이후의 모든 타이머 인터럽트가 막혀버린다
     * (교착 상태). */
    pic_send_eoi(0);
    scheduler_tick_from_isr();
}

__attribute__((interrupt))
void isr_keyboard(struct interrupt_frame *frame) {
    (void)frame;
    keyboard_irq_handler();
    pic_send_eoi(1);
}

__attribute__((interrupt))
void isr_mouse(struct interrupt_frame *frame) {
    (void)frame;
    mouse_irq_handler();
    pic_send_eoi(12);
}
