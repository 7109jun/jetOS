#ifndef JETOS_CONSOLE_H
#define JETOS_CONSOLE_H

#include <stdint.h>

/* Milestone 19: 위젯 툴킷/스크롤 계산용으로 노출한 줄 높이(px).
 * console.c의 내부 LINE_ADVANCE와 반드시 같은 값으로 유지할 것. */
#define CONSOLE_LINE_H 18

typedef struct {
    uint32_t *fb;          /* framebuffer 시작 주소 (32bpp) */
    uint32_t width;
    uint32_t height;
    uint32_t pixels_per_scanline;
    uint32_t cursor_x;
    uint32_t cursor_y;
    uint32_t fg_color;
    uint32_t bg_color;
} console_t;

void console_init(console_t *con, uint32_t *fb, uint32_t width, uint32_t height, uint32_t pps);
void console_clear(console_t *con, uint32_t color);
void console_put_pixel(console_t *con, uint32_t x, uint32_t y, uint32_t color);

/* Milestone 23: coverage(0~256, 256=완전 불투명)만큼 color를 그 자리의
 * 실제 프레임버퍼 값과 블렌딩해서 그린다 — 원/별처럼 대각선·곡선
 * 가장자리가 있는 도형을 "픽셀 느낌 없이" 그릴 때 쓴다. coverage<=0이면
 * 아무것도 안 그리고, >=256이면 그냥 단색으로 찍는다(빠른 경로). */
void console_blend_pixel(console_t *con, int x, int y, int coverage, uint32_t color);
void console_fill_rect(console_t *con, uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint32_t color);
void console_putc(console_t *con, char c);
void console_print(console_t *con, const char *s);

#endif
