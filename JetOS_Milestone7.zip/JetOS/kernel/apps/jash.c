/*
 * JetOS - kernel/apps/jash.c
 *
 * jash: JetOS 전용 셸.
 * C#으로 작성된 원본(Jash.cs by 7109jun/jetOS)의 명령어 구조와 기능을
 * JetOS freestanding C로 재구현했다.
 *
 * 원본 → JetOS 대응:
 *   Console.ReadLine()        → keyboard_poll_char() 링버퍼 + 라인 버퍼
 *   Console.WriteLine()       → jash_print() → serial + GUI 콘솔
 *   Process.GetProcesses()    → JetAPI ListThreadsJ()
 *   ReadProcessMemory()       → JetAPI GetSystemInfoJ() (커널 메모리 조회)
 *   HttpClient.GetByteArray() → (Milestone 7: JETFS 파일 읽기로 대체)
 *   Convert.ToBase64String()  → jash_b64_encode() (자체 구현)
 *   Convert.FromBase64String() → jash_b64_decode() (자체 구현)
 */

#include <stddef.h>
#include "jash.h"
#include "../../include/jetapi/jetapi.h"
#include "../drivers/keyboard.h"
#include "../drivers/console.h"
#include "../drivers/serial.h"
#include "../gui/wm.h"
#include "../proc/scheduler.h"
#include "../proc/thread.h"
#include "../fs/jetfs.h"
#include "../fs/vfs.h"
#include "../hal/x86_asm_shim.h"
#include "../exec/pe_loader.h"

/* ============================== 유틸 ============================== */

static void str_copy(char *dst, const char *src, int max) {
    int i = 0;
    for (; i < max - 1 && src && src[i]; i++) dst[i] = src[i];
    dst[i] = '\0';
}

/* static int str_eq_unused(const char *a, const char *b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
} */

static int str_eq_i(const char *a, const char *b) {
    while (*a && *b) {
        char ca = *a >= 'A' && *a <= 'Z' ? (char)(*a + 32) : *a;
        char cb = *b >= 'A' && *b <= 'Z' ? (char)(*b + 32) : *b;
        if (ca != cb) return 0;
        a++; b++;
    }
    return *a == *b;
}

static int str_len(const char *s) { int n = 0; while (s && s[n]) n++; return n; }

static void uint_to_str(uint64_t v, char *buf) {
    char tmp[20]; int t = 0;
    if (v == 0) { buf[0]='0'; buf[1]='\0'; return; }
    while (v > 0) { tmp[t++] = (char)('0' + (v % 10)); v /= 10; }
    int i = 0;
    while (t > 0) buf[i++] = tmp[--t];
    buf[i] = '\0';
}

/* ============================== 출력 ============================== */
/* jash 창 상태 */
static JetWindowHandle g_jash_win = -1;
#define JASH_BUF_MAX 2048
static char g_jash_out[JASH_BUF_MAX];
static int g_jash_out_len = 0;

static void jash_append(const char *s) {
    while (*s && g_jash_out_len < JASH_BUF_MAX - 1) {
        g_jash_out[g_jash_out_len++] = *s++;
    }
    g_jash_out[g_jash_out_len] = '\0';
}

static void jash_println(const char *s) {
    jash_append(s);
    if (g_jash_out_len < JASH_BUF_MAX - 1) g_jash_out[g_jash_out_len++] = '\n';
    g_jash_out[g_jash_out_len] = '\0';
    serial_write(s);
    serial_write("\n");
}

static void jash_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)h; (void)ctx;
    dc->cursor_x = (uint32_t)(x + 8);
    dc->cursor_y = (uint32_t)(y + 8);
    /* 마지막 N줄만 표시 (창 크기에 맞춰) */
    int max_lines = (h - 16) / 14;
    if (max_lines < 1) max_lines = 1;

    /* 줄 수 세기 */
    int total_lines = 1;
    for (int i = 0; i < g_jash_out_len; i++) {
        if (g_jash_out[i] == '\n') total_lines++;
    }

    /* skip_lines만큼 건너뛰고 나머지를 표시 */
    int skip = total_lines - max_lines;
    if (skip < 0) skip = 0;

    int cur_line = 0;
    int i = 0;
    while (i < g_jash_out_len && cur_line < skip) {
        if (g_jash_out[i] == '\n') cur_line++;
        i++;
    }

    /* 표시할 텍스트 출력 */
    while (i < g_jash_out_len) {
        char c = g_jash_out[i++];
        if (c == '\n') {
            dc->cursor_x = (uint32_t)(x + 8);
            dc->cursor_y += 14;
        } else {
            char tmp[2] = {c, 0};
            console_print(dc, tmp);
        }
    }
}

/* ============================== 입력 버퍼 ============================== */
#define INPUT_MAX 256
static char g_input_buf[INPUT_MAX];
static int g_input_len = 0;

/* 화면 하단에 현재 입력 프롬프트 표시 */
static void jash_draw_prompt_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)ctx;
    jash_content_cb(dc, x, y, w, h - 20, NULL);
    /* 프롬프트 줄 */
    dc->cursor_x = (uint32_t)(x + 8);
    dc->cursor_y = (uint32_t)(y + h - 20);
    dc->fg_color = 0x00A0D0FF;
    console_print(dc, "jash> ");
    dc->fg_color = 0x00E0F0FF;
    console_print(dc, g_input_buf);
    dc->fg_color = 0x00E0ECFA; /* 기본 텍스트색 복원 */
}

/* ============================== Base64 (자체 구현) ============================== */
/* 원본 Jash.cs: Convert.ToBase64String / Convert.FromBase64String 대응 */
static const char B64_CHARS[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static void b64_encode(const uint8_t *in, int in_len, char *out) {
    int i = 0, o = 0;
    while (i < in_len) {
        uint32_t b = (uint32_t)in[i++] << 16;
        if (i < in_len) b |= (uint32_t)in[i++] << 8;
        if (i < in_len) b |= (uint32_t)in[i++];
        out[o++] = B64_CHARS[(b >> 18) & 0x3F];
        out[o++] = B64_CHARS[(b >> 12) & 0x3F];
        out[o++] = (i - 1 < in_len || in_len % 3 != 1) ? B64_CHARS[(b >> 6) & 0x3F] : '=';
        out[o++] = (in_len % 3 == 0 || i <= in_len) ? B64_CHARS[b & 0x3F] : '=';
    }
    out[o] = '\0';
}

static int b64_char_val(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
}

static int b64_decode(const char *in, uint8_t *out) {
    int o = 0;
    while (*in) {
        /* 공백 무시 (원본 CleanBase64 대응) */
        char a = *in++; while (a == ' ' || a == '\n' || a == '\r') { a = *in++; }
        char b = *in++; while (b == ' ' || b == '\n' || b == '\r') { b = *in++; }
        char c = *in; if (*in) in++; while (c == ' ' || c == '\n' || c == '\r') { c = *in; if (*in) in++; }
        char d = *in; if (*in) in++; while (d == ' ' || d == '\n' || d == '\r') { d = *in; if (*in) in++; }
        if (!a || !b) break;
        int va = b64_char_val(a), vb = b64_char_val(b);
        int vc = (c && c != '=') ? b64_char_val(c) : 0;
        int vd = (d && d != '=') ? b64_char_val(d) : 0;
        if (va < 0 || vb < 0) break;
        out[o++] = (uint8_t)((va << 2) | (vb >> 4));
        if (c && c != '=') out[o++] = (uint8_t)((vb << 4) | (vc >> 2));
        if (d && d != '=') out[o++] = (uint8_t)((vc << 6) | vd);
    }
    return o;
}

/* ============================== 인수 파싱 (원본 SplitArgs 대응) ============================== */
#define MAX_ARGV 16
static char g_argv[MAX_ARGV][128];
static int g_argc;

static void split_args(const char *line) {
    g_argc = 0;
    int i = 0, in_quote = 0;
    char quote_char = '"';
    char cur[128]; int cur_len = 0;

    while (line[i]) {
        char c = line[i++];
        if (in_quote) {
            if (c == quote_char) { in_quote = 0; }
            else if (cur_len < 127) cur[cur_len++] = c;
        } else {
            if (c == '"' || c == '\'') { in_quote = 1; quote_char = c; }
            else if (c == ' ' || c == '\t') {
                if (cur_len > 0 && g_argc < MAX_ARGV) {
                    cur[cur_len] = '\0';
                    str_copy(g_argv[g_argc++], cur, 128);
                    cur_len = 0;
                }
            } else if (cur_len < 127) cur[cur_len++] = c;
        }
    }
    if (cur_len > 0 && g_argc < MAX_ARGV) {
        cur[cur_len] = '\0';
        str_copy(g_argv[g_argc++], cur, 128);
    }
}

/* ============================== 명령어 ============================== */

static void cmd_help(void) {
    jash_println("jash - JetOS Shell");
    jash_println("");
    jash_println("base64 encode <text>");
    jash_println("base64 decode <base64>");
    jash_println("");
    jash_println("mem list          list all threads/processes");
    jash_println("mem info          system memory statistics");
    jash_println("");
    jash_println("browse <path>     view file contents");
    jash_println("");
    jash_println("run <path.exe>    run a PE32+ executable");
    jash_println("");
    jash_println("exit / quit");
}

static void cmd_base64(void) {
    if (g_argc < 2) { cmd_help(); return; }
    const char *sub = g_argv[1];

    if (str_eq_i(sub, "encode")) {
        /* 나머지 인자들을 공백으로 이어 붙여 텍스트로 만든다 */
        char text[512]; int tlen = 0;
        for (int i = 2; i < g_argc; i++) {
            if (i > 2 && tlen < 510) text[tlen++] = ' ';
            const char *s = g_argv[i];
            while (*s && tlen < 511) text[tlen++] = *s++;
        }
        text[tlen] = '\0';
        char out[700];
        b64_encode((const uint8_t *)text, tlen, out);
        jash_println(out);

    } else if (str_eq_i(sub, "decode")) {
        char b64[512]; int blen = 0;
        for (int i = 2; i < g_argc; i++) {
            const char *s = g_argv[i];
            while (*s && blen < 511) b64[blen++] = *s++;
        }
        b64[blen] = '\0';
        uint8_t out[400]; int outlen = b64_decode(b64, out);
        out[outlen] = '\0';
        jash_println((char *)out);
    } else {
        jash_println("unknown subcommand. try: help");
    }
}

/* 원본 MemCommand(list) 대응: JetOS 스레드 목록 */
typedef struct { int count; } mem_list_ctx_t;
static void mem_list_cb(const char *name, uint32_t id, int state, void *ctx) {
    mem_list_ctx_t *c = (mem_list_ctx_t *)ctx;
    c->count++;
    char line[80];
    const char *states[] = {"READY","RUNNING","BLOCKED","DEAD"};
    const char *st = (state >= 0 && state <= 3) ? states[state] : "?";
    char id_s[12]; uint_to_str(id, id_s);
    int i = 0;
    /* id (8자리 오른쪽 정렬 흉내) */
    int id_len = str_len(id_s);
    for (; i < 8 - id_len; i++) line[i] = ' ';
    str_copy(line + i, id_s, 12); i += id_len;
    line[i++] = ' ';
    str_copy(line + i, name, 24); i += str_len(name);
    line[i++] = ' ';
    str_copy(line + i, st, 8); i += str_len(st);
    line[i] = '\0';
    jash_println(line);
}

static void cmd_mem(void) {
    if (g_argc < 2) { cmd_help(); return; }
    const char *sub = g_argv[1];

    if (str_eq_i(sub, "list")) {
        jash_println("      id name                     state");
        mem_list_ctx_t ctx = {0};
        ListThreadsJ(mem_list_cb, &ctx);
        char c[32]; char n[8]; uint_to_str((uint64_t)ctx.count, n);
        str_copy(c, "total: ", 8); str_copy(c+7, n, 24);
        jash_println(c);

    } else if (str_eq_i(sub, "info")) {
        JetSystemInfo info;
        GetSystemInfoJ(&info);

        char line[80];
        char v[20];

        jash_println("=== JetOS Memory Info ===");
        uint_to_str(info.heap_total_bytes, v);
        str_copy(line, "heap total : ", 14); str_copy(line+13, v, 20); jash_println(line);
        uint_to_str(info.heap_used_bytes, v);
        str_copy(line, "heap used  : ", 14); str_copy(line+13, v, 20); jash_println(line);
        uint_to_str((info.heap_total_bytes - info.heap_used_bytes), v);
        str_copy(line, "heap free  : ", 14); str_copy(line+13, v, 20); jash_println(line);
        uint_to_str(info.pmm_free_pages * 4096, v);
        str_copy(line, "phys free  : ", 14); str_copy(line+13, v, 20); str_copy(line+13+str_len(v), " bytes", 8); jash_println(line);
        uint_to_str(info.timer_ticks, v);
        str_copy(line, "timer ticks: ", 14); str_copy(line+13, v, 20); jash_println(line);

    } else {
        jash_println("unknown subcommand. try: help");
    }
}

/* browse: JETFS 파일 내용 텍스트로 보기 (원본 browse는 HTTP 브라우저,
 * JetOS M7에서는 JETFS 파일 뷰어로 구현 — 네트워킹은 Milestone 7 후반) */
static void cmd_browse(void) {
    if (g_argc < 2) { jash_println("usage: browse <path>"); return; }
    char buf[1024];
    uint32_t sz = 0;
    char real[128];
    const char *rp = vfs_translate(g_argv[1], real, sizeof(real));

    if (jetfs_read(rp, buf, sizeof(buf) - 1, &sz)) {
        buf[sz] = '\0';
        jash_println("--- file contents ---");
        /* 줄 단위로 출력 */
        char line[128]; int li = 0;
        for (uint32_t i = 0; i <= sz; i++) {
            char c = (i < sz) ? buf[i] : '\n';
            if (c == '\n') {
                line[li] = '\0';
                jash_println(line);
                li = 0;
            } else if (li < 127) {
                line[li++] = c;
            }
        }
        jash_println("--- end ---");
    } else {
        jash_println("error: cannot read file (check path and JETFS mount)");
    }
}

/* run: PE32+ 실행파일 실행 */
static void cmd_run(void) {
    if (g_argc < 2) { jash_println("usage: run <path.exe>"); return; }
    int id = pe_execute(g_argv[1], NULL);
    if (id < 0) {
        jash_println("error: failed to launch exe");
    } else {
        jash_println("launched (thread id printed to serial)");
    }
}

/* ============================== REPL ============================== */
int g_jash_running = 0;
static int g_jash_exit_requested = 0;

/* 외부(desktop 이벤트루프)에서 받은 문자를 jash의 입력 큐에 주입한다 */
#define JASH_INJECT_BUF 64
static char g_inject_buf[JASH_INJECT_BUF];
static int g_inject_head = 0, g_inject_tail = 0;

void jash_inject_char(char c) {
    int next = (g_inject_tail + 1) % JASH_INJECT_BUF;
    if (next == g_inject_head) return;
    g_inject_buf[g_inject_tail] = c;
    g_inject_tail = next;
}

static char jash_get_char(void) {
    if (g_inject_head == g_inject_tail) return 0;
    char c = g_inject_buf[g_inject_head];
    g_inject_head = (g_inject_head + 1) % JASH_INJECT_BUF;
    return c;
}

static int dispatch(void) {
    if (g_argc == 0) return 1;
    const char *cmd = g_argv[0];

    if (str_eq_i(cmd, "exit") || str_eq_i(cmd, "quit")) return 0;
    else if (str_eq_i(cmd, "help")) cmd_help();
    else if (str_eq_i(cmd, "base64")) cmd_base64();
    else if (str_eq_i(cmd, "mem") || str_eq_i(cmd, "memory")) cmd_mem();
    else if (str_eq_i(cmd, "browse") || str_eq_i(cmd, "browser")) cmd_browse();
    else if (str_eq_i(cmd, "run")) cmd_run();
    else {
        jash_println("unknown command: try help");
    }
    return 1;
}

void jash_run_once(void) {
    if (!g_jash_running) return;

    char c = jash_get_char();
    if (!c) return;

    if (c == '\n' || c == '\r') {
        /* 명령 실행 */
        jash_append("\n");
        if (g_input_len > 0) {
            g_input_buf[g_input_len] = '\0';
            split_args(g_input_buf);
            if (!dispatch()) {
                g_jash_exit_requested = 1;
            }
        }
        /* 프롬프트 */
        if (!g_jash_exit_requested) jash_append("jash> ");
        g_input_len = 0;
        g_input_buf[0] = '\0';
    } else if (c == '\b') {
        if (g_input_len > 0) {
            g_input_len--;
            g_input_buf[g_input_len] = '\0';
        }
    } else if (c >= 32 && c < 127 && g_input_len < INPUT_MAX - 1) {
        g_input_buf[g_input_len++] = c;
        g_input_buf[g_input_len] = '\0';
    }
}

/* ============================== 시작 ============================== */
static void jash_thread_fn(void *arg) {
    (void)arg;
    g_jash_running = 1;
    g_jash_exit_requested = 0;
    g_input_len = 0;
    g_input_buf[0] = '\0';
    g_jash_out_len = 0;
    g_jash_out[0] = '\0';

    jash_println("jash - JetOS Shell");
    jash_println("commands: help, base64, mem, browse, run, exit");
    jash_append("jash> ");

    wm_set_content_callback(g_jash_win, jash_draw_prompt_cb, NULL);

    while (!g_jash_exit_requested) {
        jash_run_once();
        scheduler_yield();
    }

    g_jash_running = 0;
    jash_println("jash: session ended");
}

void jash_launch(void) {
    static int launched = 0;
    if (launched) return;
    launched = 1;
    g_jash_win = CreateWindowJ("JASH - JetOS Shell", 60, 240, 540, 260, 0x00101820);
    if (g_jash_win >= 0) {
        wm_set_content_callback(g_jash_win, jash_content_cb, NULL);
    }
    CreateThreadJ("jash", jash_thread_fn, NULL);
}
