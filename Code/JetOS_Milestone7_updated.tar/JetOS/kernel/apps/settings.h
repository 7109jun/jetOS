#ifndef JETOS_APP_SETTINGS_H
#define JETOS_APP_SETTINGS_H
void settings_launch(void);
#endif
