#ifndef JETOS_RTL8139_H
#define JETOS_RTL8139_H

#include <stdint.h>

#define RTL8139_MAX_FRAME 1518

/* QEMU가 기본으로 제공하는 가상 NIC(-device rtl8139)를 찾아 초기화한다.
 * 성공하면 1, 장치가 없거나 초기화에 실패하면 0을 반환한다. */
int rtl8139_init(void);

/* 초기화가 성공적으로 끝났는지 여부 */
int rtl8139_available(void);

/* 이 NIC의 MAC 주소(6바이트)를 복사해준다. */
void rtl8139_get_mac(uint8_t mac[6]);

/* 이더넷 프레임(목적지 MAC부터 페이로드까지, FCS 제외) 하나를 그대로
 * 전송한다. 완료(또는 타임아웃)까지 폴링하며 블로킹한다.
 * 성공 시 1, 실패/타임아웃 시 0. */
int rtl8139_send(const void *frame, uint32_t len);

/* 수신 링버퍼에 대기중인 프레임이 있으면 buf에 복사하고 실제 길이를
 * 반환한다(FCS 4바이트 제외). 없으면 0을 반환한다(논블로킹 폴링용). */
uint32_t rtl8139_recv(void *buf, uint32_t buf_size);

#endif
