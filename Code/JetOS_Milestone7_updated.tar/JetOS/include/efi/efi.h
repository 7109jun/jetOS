/*
 * JetOS - include/efi/efi.h
 *
 * 최소한의 UEFI 타입/프로토콜 정의.
 * gnu-efi 등 외부 라이브러리를 사용하지 않고, JetOS 부트로더가 필요로 하는
 * 구조체/함수 포인터만 UEFI 2.x 스펙 순서에 맞춰 직접 선언한다.
 *
 * 주의: EFI_BOOT_SERVICES / EFI_SYSTEM_TABLE 등은 실제 UEFI 펌웨어가 이
 * 레이아웃대로 함수 테이블을 채워 넣는 "ABI"이므로, 필드 순서와 개수를
 * 스펙과 동일하게 유지해야 한다. 여기서 사용하지 않는 필드는 VOID* 로
 * placeholder 처리하되, 개수는 정확히 맞춘다.
 */

#ifndef JETOS_EFI_H
#define JETOS_EFI_H

#include <stdint.h>
#include <stddef.h>

/* ---- 기본 타입 ---- */
typedef uint64_t   UINTN;
typedef int64_t    INTN;
typedef uint8_t     BOOLEAN;
typedef uint8_t     UINT8;
typedef int8_t       INT8;
typedef uint16_t   UINT16;
typedef int16_t      INT16;
typedef uint32_t   UINT32;
typedef int32_t      INT32;
typedef uint64_t   UINT64;
typedef int64_t      INT64;
typedef uint16_t   CHAR16;     /* UEFI 문자열은 UCS-2 */
typedef void          VOID;
typedef UINTN         EFI_STATUS;
typedef VOID*         EFI_HANDLE;
typedef VOID*         EFI_EVENT;
typedef UINT64        EFI_PHYSICAL_ADDRESS;
typedef UINT64        EFI_VIRTUAL_ADDRESS;
typedef UINTN          EFI_TPL;

#define TRUE  1
#define FALSE 0
#define NULL_HANDLE ((EFI_HANDLE)0)

/* x86_64 UEFI는 MS x64 호출 규약을 사용한다.
 * mingw-w64(x86_64-w64-mingw32-gcc)로 빌드하면 기본 호출규약이 이미
 * MS x64 이므로 EFIAPI는 별도 어셈블리 없이 순수 컴파일러 속성으로 처리된다. */
#define EFIAPI

#define EFI_ERROR_BIT   0x8000000000000000ULL
#define EFI_ERROR(x)    (((INTN)(x)) < 0)
#define EFI_SUCCESS             0
#define EFI_LOAD_ERROR           (EFI_ERROR_BIT | 1)
#define EFI_INVALID_PARAMETER    (EFI_ERROR_BIT | 2)
#define EFI_UNSUPPORTED          (EFI_ERROR_BIT | 3)
#define EFI_BAD_BUFFER_SIZE      (EFI_ERROR_BIT | 4)
#define EFI_BUFFER_TOO_SMALL     (EFI_ERROR_BIT | 5)
#define EFI_NOT_FOUND            (EFI_ERROR_BIT | 14)

typedef struct {
    UINT32 Data1;
    UINT16 Data2;
    UINT16 Data3;
    UINT8  Data4[8];
} EFI_GUID;

typedef struct {
    UINT64 Signature;
    UINT32 Revision;
    UINT32 HeaderSize;
    UINT32 CRC32;
    UINT32 Reserved;
} EFI_TABLE_HEADER;

/* ---- Simple Text Output Protocol ---- */
typedef struct EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL;

typedef EFI_STATUS (EFIAPI *EFI_TEXT_RESET)(EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *This, BOOLEAN ExtendedVerification);
typedef EFI_STATUS (EFIAPI *EFI_TEXT_STRING)(EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *This, CHAR16 *String);
typedef EFI_STATUS (EFIAPI *EFI_TEXT_CLEAR_SCREEN)(EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *This);

struct EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL {
    EFI_TEXT_RESET          Reset;
    EFI_TEXT_STRING         OutputString;
    VOID*                   TestString;
    VOID*                   QueryMode;
    VOID*                   SetMode;
    VOID*                   SetAttribute;
    EFI_TEXT_CLEAR_SCREEN   ClearScreen;
    VOID*                   SetCursorPosition;
    VOID*                   EnableCursor;
    VOID*                   Mode;
};

/* ---- Memory ---- */
typedef enum {
    EfiReservedMemoryType,
    EfiLoaderCode,
    EfiLoaderData,
    EfiBootServicesCode,
    EfiBootServicesData,
    EfiRuntimeServicesCode,
    EfiRuntimeServicesData,
    EfiConventionalMemory,
    EfiUnusableMemory,
    EfiACPIReclaimMemory,
    EfiACPIMemoryNVS,
    EfiMemoryMappedIO,
    EfiMemoryMappedIOPortSpace,
    EfiPalCode,
    EfiPersistentMemory,
    EfiMaxMemoryType
} EFI_MEMORY_TYPE;

typedef struct {
    UINT32                Type;
    UINT32                Pad;
    EFI_PHYSICAL_ADDRESS  PhysicalStart;
    EFI_VIRTUAL_ADDRESS   VirtualStart;
    UINT64                NumberOfPages;
    UINT64                Attribute;
} EFI_MEMORY_DESCRIPTOR;

typedef EFI_STATUS (EFIAPI *EFI_GET_MEMORY_MAP)(
    UINTN *MemoryMapSize, EFI_MEMORY_DESCRIPTOR *MemoryMap,
    UINTN *MapKey, UINTN *DescriptorSize, UINT32 *DescriptorVersion);

typedef EFI_STATUS (EFIAPI *EFI_ALLOCATE_POOL)(UINT32 PoolType, UINTN Size, VOID **Buffer);
typedef EFI_STATUS (EFIAPI *EFI_FREE_POOL)(VOID *Buffer);
typedef EFI_STATUS (EFIAPI *EFI_ALLOCATE_PAGES)(UINT32 Type, UINT32 MemoryType, UINTN Pages, EFI_PHYSICAL_ADDRESS *Memory);
typedef EFI_STATUS (EFIAPI *EFI_FREE_PAGES)(EFI_PHYSICAL_ADDRESS Memory, UINTN Pages);
typedef EFI_STATUS (EFIAPI *EFI_EXIT_BOOT_SERVICES)(EFI_HANDLE ImageHandle, UINTN MapKey);
typedef EFI_STATUS (EFIAPI *EFI_LOCATE_PROTOCOL)(EFI_GUID *Protocol, VOID *Registration, VOID **Interface);
typedef EFI_STATUS (EFIAPI *EFI_STALL)(UINTN Microseconds);
typedef EFI_TPL     (EFIAPI *EFI_RAISE_TPL)(EFI_TPL NewTpl);
typedef VOID        (EFIAPI *EFI_RESTORE_TPL)(EFI_TPL OldTpl);
typedef EFI_STATUS (EFIAPI *EFI_HANDLE_PROTOCOL)(EFI_HANDLE Handle, EFI_GUID *Protocol, VOID **Interface);

/* AllocatePages()의 Type 인자 */
#define AllocateAnyPages    0
#define AllocateMaxAddress  1
#define AllocateAddress     2

typedef struct {
    EFI_TABLE_HEADER        Hdr;
    EFI_RAISE_TPL           RaiseTPL;
    EFI_RESTORE_TPL         RestoreTPL;
    EFI_ALLOCATE_PAGES      AllocatePages;
    EFI_FREE_PAGES          FreePages;
    EFI_GET_MEMORY_MAP      GetMemoryMap;
    EFI_ALLOCATE_POOL       AllocatePool;
    EFI_FREE_POOL           FreePool;
    VOID*                   CreateEvent;
    VOID*                   SetTimer;
    VOID*                   WaitForEvent;
    VOID*                   SignalEvent;
    VOID*                   CloseEvent;
    VOID*                   CheckEvent;
    VOID*                   InstallProtocolInterface;
    VOID*                   ReinstallProtocolInterface;
    VOID*                   UninstallProtocolInterface;
    EFI_HANDLE_PROTOCOL     HandleProtocol;
    VOID*                   Reserved;
    VOID*                   RegisterProtocolNotify;
    VOID*                   LocateHandle;
    VOID*                   LocateDevicePath;
    VOID*                   InstallConfigurationTable;
    VOID*                   LoadImage;
    VOID*                   StartImage;
    VOID*                   Exit;
    VOID*                   UnloadImage;
    EFI_EXIT_BOOT_SERVICES  ExitBootServices;
    VOID*                   GetNextMonotonicCount;
    EFI_STALL               Stall;
    VOID*                   SetWatchdogTimer;
    VOID*                   ConnectController;
    VOID*                   DisconnectController;
    VOID*                   OpenProtocol;
    VOID*                   CloseProtocol;
    VOID*                   OpenProtocolInformation;
    VOID*                   ProtocolsPerHandle;
    VOID*                   LocateHandleBuffer;
    EFI_LOCATE_PROTOCOL     LocateProtocol;
    VOID*                   InstallMultipleProtocolInterfaces;
    VOID*                   UninstallMultipleProtocolInterfaces;
    VOID*                   CalculateCrc32;
    VOID*                   CopyMem;
    VOID*                   SetMem;
    VOID*                   CreateEventEx;
} EFI_BOOT_SERVICES;

typedef struct {
    EFI_TABLE_HEADER Hdr;
    VOID* GetTime;
    VOID* SetTime;
    VOID* GetWakeupTime;
    VOID* SetWakeupTime;
    VOID* SetVirtualAddressMap;
    VOID* ConvertPointer;
    VOID* GetVariable;
    VOID* GetNextVariableName;
    VOID* SetVariable;
    VOID* GetNextHighMonotonicCount;
    VOID* ResetSystem;
    VOID* UpdateCapsule;
    VOID* QueryCapsuleCapabilities;
    VOID* QueryVariableInfo;
} EFI_RUNTIME_SERVICES;

typedef struct {
    EFI_GUID VendorGuid;
    VOID *VendorTable;
} EFI_CONFIGURATION_TABLE;

typedef struct {
    EFI_TABLE_HEADER            Hdr;
    CHAR16*                     FirmwareVendor;
    UINT32                      FirmwareRevision;
    EFI_HANDLE                  ConsoleInHandle;
    VOID*                       ConIn;
    EFI_HANDLE                  ConsoleOutHandle;
    EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL* ConOut;
    EFI_HANDLE                  StandardErrorHandle;
    EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL* StdErr;
    EFI_RUNTIME_SERVICES*       RuntimeServices;
    EFI_BOOT_SERVICES*          BootServices;
    UINTN                       NumberOfTableEntries;
    EFI_CONFIGURATION_TABLE*    ConfigurationTable;
} EFI_SYSTEM_TABLE;

/* ---- Graphics Output Protocol (GOP) ---- */
#define EFI_GRAPHICS_OUTPUT_PROTOCOL_GUID \
    { 0x9042a9de, 0x23dc, 0x4a38, { 0x96, 0xfb, 0x7a, 0xde, 0xd0, 0x80, 0x51, 0x6a } }

typedef struct {
    UINT32 RedMask, GreenMask, BlueMask, ReservedMask;
} EFI_PIXEL_BITMASK;

typedef enum {
    PixelRedGreenBlueReserved8BitPerColor,
    PixelBlueGreenRedReserved8BitPerColor,
    PixelBitMask,
    PixelBltOnly,
    PixelFormatMax
} EFI_GRAPHICS_PIXEL_FORMAT;

typedef struct {
    UINT32 Version;
    UINT32 HorizontalResolution;
    UINT32 VerticalResolution;
    EFI_GRAPHICS_PIXEL_FORMAT PixelFormat;
    EFI_PIXEL_BITMASK PixelInformation;
    UINT32 PixelsPerScanLine;
} EFI_GRAPHICS_OUTPUT_MODE_INFORMATION;

typedef struct {
    UINT32 MaxMode;
    UINT32 Mode;
    EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *Info;
    UINTN SizeOfInfo;
    EFI_PHYSICAL_ADDRESS FrameBufferBase;
    UINTN FrameBufferSize;
} EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE;

typedef struct EFI_GRAPHICS_OUTPUT_PROTOCOL EFI_GRAPHICS_OUTPUT_PROTOCOL;

typedef EFI_STATUS (EFIAPI *EFI_GRAPHICS_OUTPUT_PROTOCOL_QUERY_MODE)(
    EFI_GRAPHICS_OUTPUT_PROTOCOL *This, UINT32 ModeNumber,
    UINTN *SizeOfInfo, EFI_GRAPHICS_OUTPUT_MODE_INFORMATION **Info);
typedef EFI_STATUS (EFIAPI *EFI_GRAPHICS_OUTPUT_PROTOCOL_SET_MODE)(
    EFI_GRAPHICS_OUTPUT_PROTOCOL *This, UINT32 ModeNumber);

struct EFI_GRAPHICS_OUTPUT_PROTOCOL {
    EFI_GRAPHICS_OUTPUT_PROTOCOL_QUERY_MODE QueryMode;
    EFI_GRAPHICS_OUTPUT_PROTOCOL_SET_MODE   SetMode;
    VOID*                                   Blt;
    EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE*      Mode;
};

/* ---- Loaded Image Protocol (부트로더 자신의 DeviceHandle을 얻기 위함) ---- */
#define EFI_LOADED_IMAGE_PROTOCOL_GUID \
    { 0x5b1b31a1, 0x9562, 0x11d2, { 0x8e, 0x3f, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b } }

typedef struct {
    UINT32      Revision;
    EFI_HANDLE  ParentHandle;
    EFI_SYSTEM_TABLE *SystemTable;
    EFI_HANDLE  DeviceHandle;
    VOID*       FilePath;
    VOID*       Reserved;
    UINT32      LoadOptionsSize;
    VOID*       LoadOptions;
    VOID*       ImageBase;
    UINT64      ImageSize;
    UINT32      ImageCodeType;
    UINT32      ImageDataType;
    VOID*       Unload;
} EFI_LOADED_IMAGE_PROTOCOL;

/* ---- Simple File System / File Protocol (ESP에서 KERNEL.ELF 읽기용) ---- */
#define EFI_SIMPLE_FILE_SYSTEM_PROTOCOL_GUID \
    { 0x964e5b22, 0x6459, 0x11d2, { 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b } }

typedef struct EFI_FILE_PROTOCOL EFI_FILE_PROTOCOL;

typedef EFI_STATUS (EFIAPI *EFI_FILE_OPEN)(EFI_FILE_PROTOCOL *This, EFI_FILE_PROTOCOL **NewHandle,
                                            CHAR16 *FileName, UINT64 OpenMode, UINT64 Attributes);
typedef EFI_STATUS (EFIAPI *EFI_FILE_CLOSE)(EFI_FILE_PROTOCOL *This);
typedef EFI_STATUS (EFIAPI *EFI_FILE_READ)(EFI_FILE_PROTOCOL *This, UINTN *BufferSize, VOID *Buffer);

struct EFI_FILE_PROTOCOL {
    UINT64          Revision;
    EFI_FILE_OPEN   Open;
    EFI_FILE_CLOSE  Close;
    VOID*           Delete;
    EFI_FILE_READ   Read;
    /* Write 이후 필드는 JetOS 부트로더가 사용하지 않으므로 선언을 생략한다
     * (포인터로만 다루므로 구조체 뒷부분이 없어도 앞부분 오프셋은 안전하다). */
};

typedef struct EFI_SIMPLE_FILE_SYSTEM_PROTOCOL EFI_SIMPLE_FILE_SYSTEM_PROTOCOL;

struct EFI_SIMPLE_FILE_SYSTEM_PROTOCOL {
    UINT64 Revision;
    EFI_STATUS (EFIAPI *OpenVolume)(EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *This, EFI_FILE_PROTOCOL **Root);
};

#define EFI_FILE_MODE_READ  0x0000000000000001ULL

#endif /* JETOS_EFI_H */
