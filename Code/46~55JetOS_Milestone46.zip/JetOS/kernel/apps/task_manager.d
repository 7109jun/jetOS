kernel/apps/task_manager.o: kernel/apps/task_manager.c \
 kernel/apps/task_manager.h kernel/apps/../../include/jetapi/jetapi.h \
 kernel/apps/../gui/wm.h kernel/apps/../gui/../drivers/console.h \
 kernel/apps/../drivers/console.h kernel/apps/../proc/scheduler.h \
 kernel/apps/../proc/thread.h
kernel/apps/task_manager.h:
kernel/apps/../../include/jetapi/jetapi.h:
kernel/apps/../gui/wm.h:
kernel/apps/../gui/../drivers/console.h:
kernel/apps/../drivers/console.h:
kernel/apps/../proc/scheduler.h:
kernel/apps/../proc/thread.h:
