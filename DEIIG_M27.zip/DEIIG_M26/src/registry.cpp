#include "registry.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
namespace fs=std::filesystem; namespace deiig::registry {
static fs::path p(){return fs::current_path()/"DEIIG.registry";}
int init(){if(fs::exists(p()))return 0;std::ofstream f(p());f<<"fmt|vcpkg|fmt\ncatch2|vcpkg|catch2\nrequests|pip|requests\nserde|cargo|serde\n";return f?0:1;}
int search(const std::string&q){init();std::ifstream f(p());std::string l;bool any=false;while(std::getline(f,l))if(l.find(q)!=std::string::npos){std::cout<<l<<"\n";any=true;}return any?0:1;}
int install(const std::string&n){init();std::ifstream f(p());std::string l;while(std::getline(f,l)){auto a=l.find('|');auto b=l.find('|',a+1);if(a!=std::string::npos&&b!=std::string::npos&&l.substr(0,a)==n){std::string mgr=l.substr(a+1,b-a-1),pkg=l.substr(b+1);std::string cmd=mgr=="pip"?"python3 -m pip install "+pkg:mgr=="cargo"?"cargo add "+pkg:mgr=="vcpkg"?"vcpkg install "+pkg:"";if(cmd.empty())return 2;return std::system(cmd.c_str());}}return 1;}
}
