/*
 * JetOS - kernel/fs/jetfs.c
 * JETFS v1 구현. AHCI를 통해 섹터 단위로 블록을 읽고 쓴다.
 */

#include "jetfs.h"
#include "../drivers/ahci.h"
#include "../mm/heap.h"

static int g_mounted = 0;
static int g_drive = 0;
static uint64_t g_lba_offset = 0;
static jetfs_superblock_t g_sb;

#define INODES_PER_BLOCK (JETFS_BLOCK_SIZE / sizeof(jetfs_inode_t))
#define DIRENTS_PER_BLOCK (JETFS_BLOCK_SIZE / sizeof(jetfs_dirent_t))

static int block_read(uint32_t blockno, void *buf) {
    return ahci_read_sectors(g_drive, g_lba_offset + (uint64_t)blockno * JETFS_SECTORS_PER_BLOCK,
                              JETFS_SECTORS_PER_BLOCK, buf);
}
static int block_write(uint32_t blockno, const void *buf) {
    return ahci_write_sectors(g_drive, g_lba_offset + (uint64_t)blockno * JETFS_SECTORS_PER_BLOCK,
                               JETFS_SECTORS_PER_BLOCK, buf);
}

static int str_eq(const char *a, const char *b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}
static void str_copy(char *dst, const char *src, int max) {
    int i = 0;
    for (; i < max - 1 && src[i]; i++) dst[i] = src[i];
    dst[i] = '\0';
}

int jetfs_mount(int drive_index, uint64_t lba_offset) {
    g_drive = drive_index;
    g_lba_offset = lba_offset;

    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(0, buf)) { kfree(buf); return 0; }

    jetfs_superblock_t *sb = (jetfs_superblock_t *)buf;
    if (sb->magic != JETFS_MAGIC) { kfree(buf); return 0; }

    g_sb = *sb;
    g_mounted = 1;
    kfree(buf);
    return 1;
}

/* ---- inode 테이블 I/O ---- */
static int inode_read(uint32_t idx, jetfs_inode_t *out) {
    uint32_t block = g_sb.inode_table_start + idx / INODES_PER_BLOCK;
    uint32_t off = idx % INODES_PER_BLOCK;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(block, buf)) { kfree(buf); return 0; }
    *out = ((jetfs_inode_t *)buf)[off];
    kfree(buf);
    return 1;
}
static int inode_write(uint32_t idx, const jetfs_inode_t *in) {
    uint32_t block = g_sb.inode_table_start + idx / INODES_PER_BLOCK;
    uint32_t off = idx % INODES_PER_BLOCK;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(block, buf)) { kfree(buf); return 0; }
    ((jetfs_inode_t *)buf)[off] = *in;
    int ok = block_write(block, buf);
    kfree(buf);
    return ok;
}

static int inode_alloc(void) {
    jetfs_inode_t tmp;
    for (uint32_t i = 0; i < JETFS_MAX_INODES; i++) {
        if (!inode_read(i, &tmp)) return -1;
        if (!tmp.used) {
            tmp.used = 1;
            tmp.type = JETFS_TYPE_FREE;
            tmp.size = 0;
            tmp.block_count = 0;
            for (int b = 0; b < JETFS_DIRECT_BLOCKS; b++) tmp.block[b] = 0;
            inode_write(i, &tmp);
            return (int)i;
        }
    }
    return -1;
}

/* ---- 데이터 블록 비트맵 ---- */
static int bitmap_alloc_block(void) {
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return -1;

    uint32_t total_data_blocks = g_sb.total_blocks - g_sb.data_start;
    for (uint32_t bit = 0; bit < total_data_blocks; bit++) {
        uint32_t byte_block = g_sb.bitmap_start + (bit / 8) / JETFS_BLOCK_SIZE;
        uint32_t byte_off   = (bit / 8) % JETFS_BLOCK_SIZE;
        if (!block_read(byte_block, buf)) { kfree(buf); return -1; }
        if (!(buf[byte_off] & (1 << (bit % 8)))) {
            buf[byte_off] |= (uint8_t)(1 << (bit % 8));
            if (!block_write(byte_block, buf)) { kfree(buf); return -1; }
            kfree(buf);
            return (int)(g_sb.data_start + bit);
        }
    }
    kfree(buf);
    return -1;
}

static int bitmap_free_block(uint32_t blockno) {
    if (blockno < g_sb.data_start) return 0;
    uint32_t bit = blockno - g_sb.data_start;
    uint32_t byte_block = g_sb.bitmap_start + (bit / 8) / JETFS_BLOCK_SIZE;
    uint32_t byte_off   = (bit / 8) % JETFS_BLOCK_SIZE;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(byte_block, buf)) { kfree(buf); return 0; }
    buf[byte_off] &= (uint8_t)~(1 << (bit % 8));
    int ok = block_write(byte_block, buf);
    kfree(buf);
    return ok;
}

/* ---- 디렉터리 순회 ---- */
static int dir_find(uint32_t dir_inode_idx, const char *name,
                     uint32_t *out_block, uint32_t *out_slot, uint32_t *out_inode) {
    jetfs_inode_t dir;
    if (!inode_read(dir_inode_idx, &dir)) return 0;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    for (uint32_t b = 0; b < dir.block_count; b++) {
        if (!block_read(dir.block[b], buf)) continue;
        jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
        for (uint32_t s = 0; s < DIRENTS_PER_BLOCK; s++) {
            if (ents[s].used && str_eq(ents[s].name, name)) {
                if (out_block) *out_block = dir.block[b];
                if (out_slot) *out_slot = s;
                if (out_inode) *out_inode = ents[s].inode;
                kfree(buf);
                return 1;
            }
        }
    }
    kfree(buf);
    return 0;
}

static int dir_add(uint32_t dir_inode_idx, const char *name, uint32_t inode_idx) {
    jetfs_inode_t dir;
    if (!inode_read(dir_inode_idx, &dir)) return 0;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    for (uint32_t b = 0; b < dir.block_count; b++) {
        if (!block_read(dir.block[b], buf)) continue;
        jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
        for (uint32_t s = 0; s < DIRENTS_PER_BLOCK; s++) {
            if (!ents[s].used) {
                str_copy(ents[s].name, name, JETFS_MAX_NAME);
                ents[s].inode = inode_idx;
                ents[s].used = 1;
                int ok = block_write(dir.block[b], buf);
                kfree(buf);
                return ok;
            }
        }
    }

    /* 기존 블록에 빈 슬롯이 없음 -> 새 블록 추가 */
    if (dir.block_count >= JETFS_DIRECT_BLOCKS) { kfree(buf); return 0; }
    int newblock = bitmap_alloc_block();
    if (newblock < 0) { kfree(buf); return 0; }

    for (int i = 0; i < JETFS_BLOCK_SIZE; i++) buf[i] = 0;
    jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
    str_copy(ents[0].name, name, JETFS_MAX_NAME);
    ents[0].inode = inode_idx;
    ents[0].used = 1;
    if (!block_write((uint32_t)newblock, buf)) { kfree(buf); return 0; }

    dir.block[dir.block_count] = (uint32_t)newblock;
    dir.block_count++;
    inode_write(dir_inode_idx, &dir);
    kfree(buf);
    return 1;
}

static int dir_remove(uint32_t dir_inode_idx, const char *name) {
    uint32_t block, slot, inode_idx;
    if (!dir_find(dir_inode_idx, name, &block, &slot, &inode_idx)) return 0;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(block, buf)) { kfree(buf); return 0; }
    jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
    ents[slot].used = 0;
    int ok = block_write(block, buf);
    kfree(buf);
    return ok;
}

/* ---- 경로 해석: "/a/b/c" -> 부모 디렉터리 inode + 마지막 구성요소 이름 ---- */
static int resolve_parent(const char *path, uint32_t *out_parent_inode, char *out_name) {
    if (!path || path[0] != '/') return 0;
    uint32_t cur = g_sb.root_inode;
    int i = 1;
    char comp[JETFS_MAX_NAME];

    while (path[i]) {
        int c = 0;
        while (path[i] && path[i] != '/' && c < JETFS_MAX_NAME - 1) comp[c++] = path[i++];
        comp[c] = '\0';
        while (path[i] == '/') i++;

        if (!path[i]) { /* comp가 마지막 구성요소 */
            *out_parent_inode = cur;
            str_copy(out_name, comp, JETFS_MAX_NAME);
            return 1;
        }
        uint32_t next_inode;
        if (!dir_find(cur, comp, NULL, NULL, &next_inode)) return 0;
        cur = next_inode;
    }
    return 0; /* 빈 경로 또는 "/" 자체 */
}

static int resolve(const char *path, uint32_t *out_inode) {
    if (str_eq(path, "/")) { *out_inode = g_sb.root_inode; return 1; }
    uint32_t parent;
    char name[JETFS_MAX_NAME];
    if (!resolve_parent(path, &parent, name)) return 0;
    return dir_find(parent, name, NULL, NULL, out_inode);
}

/* ---- 공개 API ---- */
int jetfs_create(const char *path, jetfs_inode_type_t type) {
    if (!g_mounted) return 0;
    uint32_t parent;
    char name[JETFS_MAX_NAME];
    if (!resolve_parent(path, &parent, name)) return 0;

    uint32_t existing;
    if (dir_find(parent, name, NULL, NULL, &existing)) return 0; /* 이미 존재 */

    int new_inode = inode_alloc();
    if (new_inode < 0) return 0;

    jetfs_inode_t inode;
    inode_read((uint32_t)new_inode, &inode);
    inode.type = (uint32_t)type;
    inode.size = 0;
    inode.block_count = 0;
    inode_write((uint32_t)new_inode, &inode);

    return dir_add(parent, name, (uint32_t)new_inode);
}

int jetfs_read(const char *path, void *buffer, uint32_t max_size, uint32_t *out_size) {
    if (!g_mounted) return 0;
    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    if (inode.type != JETFS_TYPE_FILE) return 0;

    uint32_t to_read = inode.size < max_size ? inode.size : max_size;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    uint32_t done = 0;
    for (uint32_t b = 0; b < inode.block_count && done < to_read; b++) {
        if (!block_read(inode.block[b], buf)) { kfree(buf); return 0; }
        uint32_t chunk = to_read - done;
        if (chunk > JETFS_BLOCK_SIZE) chunk = JETFS_BLOCK_SIZE;
        uint8_t *dst = (uint8_t *)buffer + done;
        for (uint32_t k = 0; k < chunk; k++) dst[k] = buf[k];
        done += chunk;
    }
    kfree(buf);
    if (out_size) *out_size = done;
    return 1;
}

int jetfs_write(const char *path, const void *data, uint32_t size) {
    if (!g_mounted) return 0;
    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    if (inode.type != JETFS_TYPE_FILE) return 0;

    uint32_t blocks_needed = (size + JETFS_BLOCK_SIZE - 1) / JETFS_BLOCK_SIZE;
    if (blocks_needed > JETFS_DIRECT_BLOCKS) return 0; /* Milestone 4: 최대 48KB */

    while (inode.block_count < blocks_needed) {
        int nb = bitmap_alloc_block();
        if (nb < 0) return 0;
        inode.block[inode.block_count++] = (uint32_t)nb;
    }
    /* 재작성으로 크기가 줄었으면 남는 블록을 비트맵에서 회수 */
    while (inode.block_count > blocks_needed) {
        inode.block_count--;
        bitmap_free_block(inode.block[inode.block_count]);
        inode.block[inode.block_count] = 0;
    }

    const uint8_t *src = (const uint8_t *)data;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    uint32_t done = 0;
    for (uint32_t b = 0; b < blocks_needed; b++) {
        uint32_t chunk = size - done;
        if (chunk > JETFS_BLOCK_SIZE) chunk = JETFS_BLOCK_SIZE;
        for (uint32_t k = 0; k < JETFS_BLOCK_SIZE; k++) buf[k] = (k < chunk) ? src[done + k] : 0;
        if (!block_write(inode.block[b], buf)) { kfree(buf); return 0; }
        done += chunk;
    }
    kfree(buf);

    inode.size = size;
    return inode_write(idx, &inode);
}

int jetfs_delete(const char *path) {
    if (!g_mounted) return 0;
    uint32_t parent;
    char name[JETFS_MAX_NAME];
    if (!resolve_parent(path, &parent, name)) return 0;

    uint32_t idx;
    if (!dir_find(parent, name, NULL, NULL, &idx)) return 0;

    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;

    /* 데이터 블록 비트맵 회수 (디렉터리도 자신의 dirent 블록을 소유하므로 동일하게 처리) */
    for (uint32_t b = 0; b < inode.block_count; b++) {
        bitmap_free_block(inode.block[b]);
        inode.block[b] = 0;
    }
    inode.block_count = 0;
    inode.size = 0;
    inode.used = 0;
    inode.type = JETFS_TYPE_FREE;
    inode_write(idx, &inode);

    return dir_remove(parent, name);
}

int jetfs_rename(const char *old_path, const char *new_path) {
    if (!g_mounted) return 0;
    uint32_t old_parent, new_parent;
    char old_name[JETFS_MAX_NAME], new_name[JETFS_MAX_NAME];
    if (!resolve_parent(old_path, &old_parent, old_name)) return 0;
    if (!resolve_parent(new_path, &new_parent, new_name)) return 0;

    uint32_t idx;
    if (!dir_find(old_parent, old_name, NULL, NULL, &idx)) return 0;
    if (!dir_remove(old_parent, old_name)) return 0;
    return dir_add(new_parent, new_name, idx);
}

int jetfs_stat(const char *path, jetfs_inode_type_t *out_type, uint32_t *out_size) {
    if (!g_mounted) return 0;
    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    if (out_type) *out_type = (jetfs_inode_type_t)inode.type;
    if (out_size) *out_size = inode.size;
    return 1;
}

int jetfs_list(const char *dir_path, jetfs_list_cb cb, void *ctx) {
    if (!g_mounted) return 0;
    uint32_t dir_idx;
    if (!resolve(dir_path, &dir_idx)) return 0;

    jetfs_inode_t dir;
    if (!inode_read(dir_idx, &dir)) return 0;
    if (dir.type != JETFS_TYPE_DIR) return 0;

    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    for (uint32_t b = 0; b < dir.block_count; b++) {
        if (!block_read(dir.block[b], buf)) continue;
        jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
        for (uint32_t s = 0; s < DIRENTS_PER_BLOCK; s++) {
            if (!ents[s].used) continue;
            jetfs_inode_t child;
            if (!inode_read(ents[s].inode, &child)) continue;
            cb(ents[s].name, (jetfs_inode_type_t)child.type, child.size, ctx);
        }
    }
    kfree(buf);
    return 1;
}
