/*
 * JetOS - kernel/apps/recyclebin_gui.c
 * Milestone 35: 휴지통 GUI. 설계 이유는 recyclebin_gui.h 참고.
 *
 * file_manager.c와 달리 이 앱은 JetAPI를 거치지 않고 kernel/fs/recyclebin.h
 * 를 직접 쓴다 — search.c/settings.c 등 이미 이 프로젝트에 있는 "커널
 * 헤더를 직접 include하는 소형 앱" 관례를 그대로 따른 것이다(모든 앱이
 * 반드시 JetAPI 전용이어야 하는 건 아니다 — file_manager.c/browser.c만
 * 의도적으로 JetAPI 전용 데모로 남아있다).
 */

#include <stddef.h>
#include "recyclebin_gui.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../gui/notify.h"
#include "../drivers/console.h"
#include "../proc/scheduler.h"
#include "../fs/recyclebin.h"

#define RB_MAX_ITEMS 20
#define RB_ROW_H 14
#define RB_TOP_MARGIN 20

typedef struct {
    char short_name[32];
    char original_path[128];
} rb_item_t;

static rb_item_t g_items[RB_MAX_ITEMS];
static int g_item_count = 0;
static int g_selected = -1;
static char g_status[48] = "";
static int g_rb_win = -1;

static void str_copy_local(char *dst, const char *src, int n) {
    int i = 0; for (; src[i] && i < n - 1; i++) dst[i] = src[i];
    dst[i] = '\0';
}

static void rb_collect_cb(const char *short_name, const char *original_path, void *ctx) {
    (void)ctx;
    if (g_item_count >= RB_MAX_ITEMS) return;
    rb_item_t *it = &g_items[g_item_count++];
    str_copy_local(it->short_name, short_name, sizeof(it->short_name));
    str_copy_local(it->original_path, original_path, sizeof(it->original_path));
}

static void rb_reload(void) {
    g_item_count = 0;
    g_selected = -1;
    recyclebin_list(rb_collect_cb, NULL);
}

static void rb_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)ctx;
    dc->cursor_x = (uint32_t)(x + 6); dc->cursor_y = (uint32_t)(y + 4);
    if (g_item_count == 0) {
        console_print(dc, "Recycle bin is empty");
    } else {
        for (int i = 0; i < g_item_count; i++) {
            int ry = y + RB_TOP_MARGIN + i * RB_ROW_H;
            if (ry > y + h - 34) break;
            if (i == g_selected) {
                console_fill_rect(dc, (uint32_t)(x + 2), (uint32_t)(ry - 1), (uint32_t)(w - 4), RB_ROW_H, 0x00405878u);
            }
            dc->cursor_x = (uint32_t)(x + 6); dc->cursor_y = (uint32_t)ry;
            console_print(dc, g_items[i].original_path);
        }
    }

    int status_y = y + h - 30;
    dc->cursor_x = (uint32_t)(x + 6); dc->cursor_y = (uint32_t)status_y;
    dc->fg_color = 0x00A0D0A0u;
    console_print(dc, g_status);
    dc->fg_color = 0x00E0E0E0u;

    static const char *labels[3] = { "Restore", "Purge", "Empty All" };
    int bw = (w - 16) / 3;
    int by = y + h - 16;
    for (int i = 0; i < 3; i++) {
        int bx = x + 8 + i * bw;
        console_fill_rect(dc, (uint32_t)bx, (uint32_t)by, (uint32_t)(bw - 4), 14, 0x00304050u);
        dc->cursor_x = (uint32_t)(bx + 3); dc->cursor_y = (uint32_t)(by + 3);
        console_print(dc, labels[i]);
    }
}

static void rb_set_status(const char *s) { str_copy_local(g_status, s, sizeof(g_status)); }

static void rb_click_cb(int lx, int ly, void *ctx) {
    (void)ctx;
    int fixed_w = 300, fixed_h = 220;
    int by = fixed_h - 16;
    if (ly >= by && ly < by + 14) {
        int bw = (fixed_w - 16) / 3;
        int idx = (lx - 8) / bw;
        if (idx == 0) { /* Restore */
            if (g_selected < 0) { rb_set_status("select an item first"); return; }
            if (recyclebin_restore(g_items[g_selected].short_name)) {
                rb_set_status("restored");
                notify_push("File restored", 2500);
                rb_reload();
            } else rb_set_status("restore failed (path occupied?)");
        } else if (idx == 1) { /* Purge one */
            if (g_selected < 0) { rb_set_status("select an item first"); return; }
            if (recyclebin_purge_one(g_items[g_selected].short_name)) {
                rb_set_status("purged permanently");
                notify_push("File purged", 2500);
                rb_reload();
            } else rb_set_status("purge failed");
        } else if (idx == 2) { /* Empty all */
            int n = recyclebin_empty();
            rb_set_status("recycle bin emptied");
            notify_push("Recycle bin emptied", 2500);
            (void)n;
            rb_reload();
        }
        return;
    }

    if (ly < RB_TOP_MARGIN) return;
    int row = (ly - RB_TOP_MARGIN) / RB_ROW_H;
    if (row < 0 || row >= g_item_count) return;
    g_selected = (g_selected == row) ? -1 : row;
    g_status[0] = '\0';
}

static volatile int g_rb_running = 0;

static void rb_on_close(void *ctx) {
    (void)ctx;
    g_rb_running = 0;
}

static void rb_thread_fn(void *arg) {
    (void)arg;
    g_rb_running = 1;
    rb_reload();
    g_rb_win = CreateWindowJ("RECYCLE BIN", 360, 260, 300, 220, 0x00403030);
    if (g_rb_win >= 0) {
        wm_set_content_callback(g_rb_win, rb_content_cb, NULL);
        wm_set_close_callback(g_rb_win, rb_on_close, NULL);
        wm_set_click_callback(g_rb_win, rb_click_cb, NULL);
    }
    while (g_rb_running) {
        scheduler_yield();
    }
}

void recyclebin_gui_launch(void) {
    static int launched = 0;
    if (launched && g_rb_running) return;
    launched = 1;
    CreateThreadJ("recyclebin", rb_thread_fn, NULL);
}
