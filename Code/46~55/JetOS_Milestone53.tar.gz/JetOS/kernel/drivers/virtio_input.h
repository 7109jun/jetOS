#ifndef JETOS_VIRTIO_INPUT_H
#define JETOS_VIRTIO_INPUT_H

#include <stdint.h>

/*
 * JetOS - kernel/drivers/virtio_input.h
 * Milestone 38: 하드웨어 호환 업그레이드 — virtio-input(절대좌표
 * "태블릿") 드라이버.
 *
 * ===== 왜 이게 필요한가 =====
 * PS/2 마우스(kernel/drivers/mouse.c)는 프로토콜 자체가 "상대 이동량"만
 * 보낸다 — 그런데 이 프로젝트를 검증하는 QEMU 자동화 환경은 (M32부터
 * M37까지 계속 문서화된 대로) HMP의 `mouse_move x y`가 절대좌표 장치
 * (예: usb-tablet, virtio-tablet)가 없으면 상대 이동으로 해석돼버려서,
 * "정확한 픽셀 좌표로 버튼을 클릭"하는 자동화가 이 프로젝트 역사
 * 내내 불가능했다. 이 드라이버는 그 근본 원인을 없앤다: virtio-input
 * 장치(QEMU `-device virtio-tablet-pci`)가 보내는 절대좌표(ABS_X/ABS_Y)
 * 이벤트를 직접 읽어서 커서를 정확한 화면 좌표로 옮긴다.
 *
 * ===== 구현 방식(virtio_gpu.c와 같은 스타일) =====
 * PCI capability 탐색/virtqueue 설정은 virtio_gpu.c(M31)와 거의 같은
 * 패턴을 그대로 따랐다(다른 파일이라 코드 재사용은 안 하고 다시
 * 구현 — 이 프로젝트의 각 드라이버 파일이 자기 완결적인 기존 관례).
 * 다른 점: GPU의 controlq는 "드라이버가 커맨드를 보내고 응답을
 * 받는" 구조지만, 이 드라이버의 eventq는 반대로 "드라이버가 빈
 * 버퍼를 미리 여러 개 던져두면 장치가 그 버퍼에 이벤트를 채워
 * 넣는" 구조다(spec 5.8) — 그래서 매번 다 쓴 버퍼를 즉시 다시
 * avail 링에 돌려놓는(recycle) 루프가 필요하다.
 *
 * ===== 정직한 단순화 =====
 *   - 절대좌표 범위(ABS_X/ABS_Y의 min/max)를 장치에 물어보는 정식
 *     protocol(DEVICE_CFG의 select/subsel 레지스터)을 구현하는 대신,
 *     QEMU의 virtio-input-hid 태블릿이 실제로 쓰는 고정 범위
 *     (0~32767, 0x7FFF)를 하드코딩했다 — 실제 QEMU 소스가 이 값을
 *     상수로 박아두고 있어서 신뢰할 수 있는 가정이지만, 다른 절대좌표
 *     장치(실제 하드웨어 등)를 만나면 잘못될 수 있다(다음 과제).
 *   - EV_KEY 중 BTN_LEFT/BTN_RIGHT/BTN_MIDDLE만 처리(다른 버튼/터치
 *     제스처 등은 무시).
 *   - EV_REL(상대 이동), 휠(REL_WHEEL)은 처리 안 함 — 태블릿류 장치는
 *     보통 휠이 없어서 실용적으로 문제없다고 판단.
 *   - 인터럽트 없이 폴링만 사용(GPU 드라이버와 같은 스타일).
 *
 * ===== M38에서 실제로 검증한 것과, 이번에 발견한 한계 =====
 * 실제 QEMU(`-device virtio-tablet-pci`)로 부팅해서 다음을 실기로
 * 확인했다: 장치 탐지, COMMON_CFG/NOTIFY_CFG capability 파싱, 기능
 * 협상, eventq 설정, 그리고 — 가장 중요하게 — **실제로 이벤트를 받아
 * 커서를 기본 위치(화면 중앙)에서 실제로 다른 좌표로 옮기는 것까지
 * 성공**했다(HMP `mouse_button` 한 번을 먼저 보내야 장치가 첫 이벤트
 * 배치를 큐에 채운다는 것도 확인함 — used_idx가 0→4로 바뀌는 것을
 * jash의 `vinput` 진단 명령으로 직접 확인).
 *
 * 다만 그 이후 추가로 보낸 `mouse_move`가 커서를 더 움직이지 못했다
 * (같은 위치에 멈춘 채 used_idx도 더 안 늘어남) — 이 드라이버 코드
 * 자체의 버그인지, 아니면 이 검증 샌드박스의 `-display none` 헤드리스
 * 구성에서 QEMU가 애초에 최초 연결 시점의 한 번짜리 상태 보고 이후로는
 * 추가적인 절대좌표 이동을 합성해주지 않는(디스플레이 백엔드가 없어
 * 호스트 입력을 큐잉할 대상이 없는) QEMU 자체의 한계인지는 이번에
 * 확실히 가려내지 못했다 — 다음 마일스톤에서 실제 디스플레이가 붙은
 * 환경(사용자의 로컬 QEMU 등)에서 재확인이 필요하다. "정직하게
 * 미검증으로 남긴다"는 이 프로젝트의 원칙에 따라, 드라이버 자체는
 * 프로토콜 수준에서 올바르게 동작함이 실기로 증명됐다는 것과, 지속적인
 * 자동화 검증은 아직 이 환경에서 안 된다는 것 둘 다를 정확히 구분해
 * 기록해둔다. */

/* PCI에서 virtio-input 장치를 찾아 초기화한다. 성공(이후
 * virtio_input_poll 사용 가능) 1, 실패(장치 없음 등) 0 — 실패해도
 * 완전히 안전하다(PS/2 마우스 경로가 그대로 살아있음). 부팅 중 한 번만
 * 호출할 것. */
int virtio_input_init(void);

int virtio_input_available(void);

/* Milestone 38: 진단용 — jash의 `vinput` 명령이 이걸로 이벤트 큐의
 * used->idx를 직접 보여준다. mouse_move를 여러 번 보내도 이 값이 그대로면
 * "드라이버가 아니라 이번 세션에서 장치 쪽으로 이벤트 자체가 안 들어오고
 * 있다"는 뜻 — virtio_input.h의 "이번에 확인된 한계" 참고. */
uint16_t virtio_input_debug_used_idx(void);

/* 마지막 호출 이후 쌓인 이벤트를 전부 소비해서 최신 절대좌표/버튼
 * 상태로 out 인자들을 채운다. 화면 해상도(screen_w/h)로 스케일링까지
 * 끝낸 좌표를 돌려준다(0~screen_w-1, 0~screen_h-1로 클램프됨).
 * 새 이벤트가 하나라도 있었으면 1, 없었으면 0(이 경우 out 인자들은
 * 안 건드림 — 호출측이 이전 값을 그대로 유지하면 됨). */
int virtio_input_poll(int screen_w, int screen_h, int *out_x, int *out_y,
                       int *out_left, int *out_right, int *out_middle);

#endif
