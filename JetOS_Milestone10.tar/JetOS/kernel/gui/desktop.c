/*
 * JetOS - kernel/gui/desktop.c
 * 데스크톱 셸: 마우스로 창을 드래그하고, 시작메뉴를 열고, 키보드로
 * 메모장 창에 타이핑할 수 있는 최소 상호작용 루프.
 */

#include "desktop.h"
#include "wm.h"
#include <stddef.h>
#include "../kernel.h"
#include "../drivers/keyboard.h"
#include "../drivers/mouse.h"
#include "../drivers/serial.h"
#include "../proc/scheduler.h"
#include "../hal/x86_asm_shim.h"
#include "../apps/file_manager.h"
#include "../apps/settings.h"
#include "../apps/task_manager.h"
#include "../apps/jash.h"
#include "../fs/jetfs.h"

#define NOTEPAD_BUF_SIZE 256
#define NOTEPAD_FILE "/notepad.txt"

static char g_notepad_buf[NOTEPAD_BUF_SIZE];
static int g_notepad_len = 0;
static int g_notepad_window = -1;
static int g_shutdown_requested = 0;
static char g_notepad_status[40] = "";

static void str_copy_local(char *dst, const char *src, int dstsz) {
    int i = 0;
    while (src[i] && i < dstsz - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

static void notepad_append(char c) {
    if (c == (char)KEY_F5) { /* 저장 */
        if (jetfs_write(NOTEPAD_FILE, g_notepad_buf, (uint32_t)g_notepad_len)) {
            str_copy_local(g_notepad_status, "[saved to notepad.txt]", sizeof(g_notepad_status));
        } else if (jetfs_create(NOTEPAD_FILE, JETFS_TYPE_FILE) &&
                   jetfs_write(NOTEPAD_FILE, g_notepad_buf, (uint32_t)g_notepad_len)) {
            str_copy_local(g_notepad_status, "[saved to notepad.txt]", sizeof(g_notepad_status));
        } else {
            str_copy_local(g_notepad_status, "[save failed]", sizeof(g_notepad_status));
        }
        return;
    }
    if (c == (char)KEY_F6) { /* 불러오기 */
        uint32_t got = 0;
        if (jetfs_read(NOTEPAD_FILE, g_notepad_buf, NOTEPAD_BUF_SIZE - 1, &got)) {
            g_notepad_len = (int)got;
            g_notepad_buf[g_notepad_len] = '\0';
            str_copy_local(g_notepad_status, "[loaded notepad.txt]", sizeof(g_notepad_status));
        } else {
            str_copy_local(g_notepad_status, "[no saved file]", sizeof(g_notepad_status));
        }
        return;
    }
    if (c == '\b') {
        if (g_notepad_len > 0) g_notepad_len--;
        g_notepad_buf[g_notepad_len] = '\0';
        return;
    }
    if (c == '\n') c = ' ';
    if (c >= 32 && c < 127 && g_notepad_len < NOTEPAD_BUF_SIZE - 1) {
        g_notepad_buf[g_notepad_len++] = c;
        g_notepad_buf[g_notepad_len] = '\0';
    }
}

static void notepad_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)ctx;
    dc->cursor_x = (uint32_t)(x + 10);
    dc->cursor_y = (uint32_t)(y + 10);
    console_print(dc, g_notepad_buf);
    if (g_notepad_status[0]) {
        dc->cursor_x = (uint32_t)(x + 10);
        dc->cursor_y = (uint32_t)(y + h - 16);
        console_print(dc, g_notepad_status);
    }
}

/* Notepad는 별도 스레드가 아니라 desktop 루프 안에서 그려지므로,
 * 닫힐 때는 내용만 비우고 창은 wm_close_window()가 알아서 숨긴다
 * (다시 열 수 있는 시작메뉴 항목은 없음 — Milestone 7 범위에서는
 * 부팅 시 한 번 생성되는 데모 창이기 때문). */
static void notepad_on_close(void *ctx) {
    (void)ctx;
    g_notepad_len = 0;
    g_notepad_buf[0] = '\0';
    g_notepad_status[0] = '\0';
}

void desktop_thread_fn(void *arg) {
    (void)arg;

    wm_init(&g_console);
    keyboard_init();
    mouse_init();

    wm_create_window("ABOUT JETOS", 60, 60, 260, 120, 0x00304050);
    g_notepad_window = wm_create_window("NOTEPAD (F5=save F6=load)", 340, 60, 260, 120, 0x00203040);
    wm_set_content_callback(g_notepad_window, notepad_content_cb, NULL);
    wm_set_close_callback(g_notepad_window, notepad_on_close, NULL);

    serial_write("STAGE: GUI DESKTOP SHELL STARTED (keyboard+mouse+wm)\n");

    int dragging = -1;
    int drag_offset_hit_titlebar = 0;
    int prev_left = 0;
    int prev_right = 0;

    for (;;) {
        char kc = keyboard_poll_char();
        if (kc) {
            /* 키보드 입력은 jash_run_once()가 직접 keyboard_poll_char()를
             * 호출해서 소비한다 — desktop은 jash가 없을 때만 Notepad로 전달 */
            extern int g_jash_running;
            if (!g_jash_running) {
                notepad_append(kc);
            }
            /* jash가 실행중이면 jash_run_once()가 같은 링버퍼에서 소비 —
             * 여기서 다시 poll하면 안 된다. 하지만 우리가 이미 poll해버렸으므로
             * jash에게 직접 전달한다. */
            else {
                extern void jash_inject_char(char c);
                jash_inject_char(kc);
            }
        }

        mouse_event_t ev;
        if (mouse_poll_event(&ev)) {
            int nx, ny;
            wm_get_cursor(&nx, &ny);
            wm_set_cursor(nx + ev.dx, ny + ev.dy);
            wm_get_cursor(&nx, &ny); /* 화면 경계로 보정된 최종 좌표 */

            if (ev.right && !prev_right) {
                /* 우클릭: 컸텍스트 메뉴 열림/닫힘 토글 */
                if (wm_is_context_menu_open()) {
                    wm_close_context_menu();
                } else {
                    int idx = wm_window_at(nx, ny);
                    wm_open_context_menu(nx, ny, idx); /* idx=-1이면 데스크톱 메뉴 */
                }
            } else if (ev.left && !prev_left) {
                if (wm_is_context_menu_open()) {
                    /* 컸텍스트 메뉴가 떠 있는 동안의 좌클릭은 메뉴 항목
                     * 선택(또는 밖까 클릭 시 메뉴 닫기)으로만 처리한다. */
                    int item;
                    if (wm_hit_context_menu_item(nx, ny, &item)) {
                        int target = wm_context_menu_target();
                        if (target == -1) {
                            if (item == 0) { file_manager_launch(); }
                            else if (item == 1) { jash_launch(); }
                            else if (item == 2) { settings_launch(); }
                            else if (item == 3) { task_manager_launch(); }
                        } else {
                            if (item == 0) {
                                wm_close_window(target);
                            } else if (item == 1) {
                                if (wm_is_window_minimized(target)) wm_restore_window(target);
                                else wm_minimize_window(target);
                            }
                        }
                    }
                    wm_close_context_menu();
                } else if (wm_is_start_button_hit(nx, ny)) {
                    wm_set_start_menu_open(1);
                } else {
                    /* 눌림 엣지: 클릭 대상 판별 */
                    int item;
                    if (wm_is_start_menu_item_hit(nx, ny, &item)) {
                        wm_set_start_menu_open(0);
                        if (item == 0) { file_manager_launch(); }
                        else if (item == 1) { jash_launch(); }
                        else if (item == 2) { settings_launch(); }
                        else if (item == 3) { task_manager_launch(); }
                        else if (item == 4) { g_shutdown_requested = 1; }
                    } else {
                        wm_set_start_menu_open(0);
                        int tb_idx = wm_hit_taskbar_window_button(nx, ny);
                        if (tb_idx >= 0) {
                            if (wm_is_window_minimized(tb_idx)) {
                                wm_restore_window(tb_idx);
                            } else {
                                wm_minimize_window(tb_idx);
                            }
                        } else {
                            int idx = wm_window_at(nx, ny);
                            if (idx >= 0) {
                                if (wm_hit_close_button(idx, nx, ny)) {
                                    wm_close_window(idx);
                                } else {
                                    wm_bring_to_front(idx);
                                    if (wm_hit_titlebar(idx, nx, ny)) {
                                        dragging = idx;
                                        drag_offset_hit_titlebar = 1;
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (!ev.left) {
                dragging = -1;
                drag_offset_hit_titlebar = 0;
            } else if (ev.left && dragging >= 0 && drag_offset_hit_titlebar) {
                wm_move_window(dragging, ev.dx, ev.dy);
            }
            prev_left = ev.left;
            prev_right = ev.right;
        }

        wm_draw();
        wm_present();

        if (g_shutdown_requested) {
            g_console.cursor_x = 20; g_console.cursor_y = 20;
            console_fill_rect(&g_console, 0, 0, g_console.width, g_console.height, 0x00000000);
            g_console.cursor_x = 40; g_console.cursor_y = 40;
            console_print(&g_console, "JETOS IS SHUTTING DOWN...");
            serial_write("STAGE: SHUTDOWN REQUESTED FROM START MENU. HALTING.\n");
            for (;;) { hal_hlt(); }
        }

        scheduler_yield();
    }
}
