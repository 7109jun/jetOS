kernel/gui/theme.o: kernel/gui/theme.c kernel/gui/theme.h
kernel/gui/theme.h:
