kernel/exec/elf_loader.o: kernel/exec/elf_loader.c \
 kernel/exec/elf_loader.h kernel/exec/../fs/jetfs.h \
 kernel/exec/../fs/vfs.h kernel/exec/../mm/heap.h kernel/exec/../mm/pmm.h \
 kernel/exec/../mm/../../include/efi/efi.h kernel/exec/../mm/vmm.h \
 kernel/exec/../hal/x86_asm_shim.h kernel/exec/../hal/gdt.h \
 kernel/exec/../proc/thread.h kernel/exec/../proc/scheduler.h \
 kernel/exec/../proc/thread.h kernel/exec/../drivers/serial.h
kernel/exec/elf_loader.h:
kernel/exec/../fs/jetfs.h:
kernel/exec/../fs/vfs.h:
kernel/exec/../mm/heap.h:
kernel/exec/../mm/pmm.h:
kernel/exec/../mm/../../include/efi/efi.h:
kernel/exec/../mm/vmm.h:
kernel/exec/../hal/x86_asm_shim.h:
kernel/exec/../hal/gdt.h:
kernel/exec/../proc/thread.h:
kernel/exec/../proc/scheduler.h:
kernel/exec/../proc/thread.h:
kernel/exec/../drivers/serial.h:
