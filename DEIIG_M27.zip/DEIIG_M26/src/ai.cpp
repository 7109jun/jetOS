#include "ai.hpp"
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <filesystem>
#ifdef _WIN32
#include <windows.h>
#include <winhttp.h>
#endif
namespace fs=std::filesystem; namespace deiig::ai {
static std::string env(const char* n){const char* v=std::getenv(n);return v?v:"";}
static std::string esc(const std::string&s){std::string o;for(unsigned char c:s){switch(c){case '\\':o+="\\\\";break;case '"':o+="\\\"";break;case '\n':o+="\\n";break;case '\r':o+="\\r";break;case '\t':o+="\\t";break;default:o+=char(c);}}return o;}
Config load_config(){Config c{env("DEIIG_AI_URL"),env("DEIIG_AI_KEY"),env("DEIIG_AI_MODEL")}; if(c.url.empty())c.url="https://api.openai.com/v1/chat/completions"; if(c.model.empty())c.model="gpt-4o-mini"; return c;}
#ifndef _WIN32
int ask(const Config&c,const std::string&p,std::string&r){
    std::string payload="{\"model\":\""+esc(c.model)+"\",\"messages\":[{\"role\":\"user\",\"content\":\""+esc(p)+"\"}]}";
    fs::path tmp=fs::temp_directory_path()/"deiig_ai_payload.json", out=fs::temp_directory_path()/"deiig_ai_output.txt"; {std::ofstream f(tmp);f<<payload;}
    std::string cmd="curl -sS -X POST -H 'Content-Type: application/json'"; if(!c.key.empty())cmd+=" -H 'Authorization: Bearer "+c.key+"'"; cmd+=" --data-binary @\""+tmp.string()+"\" \""+c.url+"\" > \""+out.string()+"\"";
    int rc=std::system(cmd.c_str()); if(rc==0){std::ifstream f(out);std::ostringstream ss;ss<<f.rdbuf();r=ss.str();} std::error_code ec;fs::remove(tmp,ec);fs::remove(out,ec);return rc;
}
#else
static std::wstring widen(const std::string&s){int n=MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),nullptr,0);std::wstring w(n,L' ');MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),w.data(),n);return w;}
int ask(const Config&c,const std::string&p,std::string&r){
    URL_COMPONENTSW u{};u.dwStructSize=sizeof(u);std::wstring wu=widen(c.url);wchar_t host[256]{},path[2048]{};u.lpszHostName=host;u.dwHostNameLength=256;u.lpszUrlPath=path;u.dwUrlPathLength=2048;if(!WinHttpCrackUrl(wu.c_str(),0,0,&u))return 2;HINTERNET s=WinHttpOpen(L"DEIIG/1.0",WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,nullptr,nullptr,0);if(!s)return 2;HINTERNET h=WinHttpConnect(s,host,u.nPort,0);if(!h){WinHttpCloseHandle(s);return 2;}DWORD flags=(u.nScheme==INTERNET_SCHEME_HTTPS)?WINHTTP_FLAG_SECURE:0;HINTERNET q=WinHttpOpenRequest(h,L"POST",path,nullptr,WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,flags);if(!q){WinHttpCloseHandle(h);WinHttpCloseHandle(s);return 2;}std::string payload="{\"model\":\""+esc(c.model)+"\",\"messages\":[{\"role\":\"user\",\"content\":\""+esc(p)+"\"}]}";std::wstring headers=L"Content-Type: application/json\r\n";if(!c.key.empty())headers+=L"Authorization: Bearer "+widen(c.key)+L"\r\n";BOOL ok=WinHttpSendRequest(q,headers.c_str(),(DWORD)-1L,(LPVOID)payload.data(),(DWORD)payload.size(),(DWORD)payload.size(),0)&&WinHttpReceiveResponse(q,nullptr);if(ok){DWORD sz=0;while(WinHttpQueryDataAvailable(q,&sz)&&sz){std::string b(sz,'\0');DWORD got=0;WinHttpReadData(q,b.data(),sz,&got);b.resize(got);r+=b;}}WinHttpCloseHandle(q);WinHttpCloseHandle(h);WinHttpCloseHandle(s);return ok?0:2;
}
#endif
}
