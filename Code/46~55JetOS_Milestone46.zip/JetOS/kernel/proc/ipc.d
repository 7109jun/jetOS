kernel/proc/ipc.o: kernel/proc/ipc.c kernel/proc/ipc.h \
 kernel/proc/scheduler.h kernel/proc/thread.h
kernel/proc/ipc.h:
kernel/proc/scheduler.h:
kernel/proc/thread.h:
