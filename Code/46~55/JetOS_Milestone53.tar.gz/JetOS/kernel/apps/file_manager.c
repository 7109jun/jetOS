/*
 * JetOS - kernel/apps/file_manager.c
 * JetAPI만 사용해 작성된 애플리케이션. 커널 내부 구조체를 전혀 알지
 * 못하며, CreateWindowJ / ListDirectoryJ 등 JetAPI만으로 동작한다.
 *
 * Milestone 13: 클릭으로 디렉터리를 드나들 수 있게 되었다.
 * Milestone 35: "10가지 목록" 밖이지만 daily-use OS에 가장 크게 빠져
 * 있던 조각 — 지금까지 이 창은 순수 브라우저였고 파일을 만들거나
 * 지우거나 옮기려면 전부 jash로 나가야 했다. 새 폴더/이름바꾸기/삭제
 * (휴지통으로)/복사/잘라내기·붙여넣기/속성(크기·읽기전용)을 추가해
 * 실제로 파일을 관리할 수 있게 한다.
 *
 * 스코프를 의도적으로 좁힌 부분: 디렉터리 자체는 삭제/이름바꾸기/복사
 * 대상이 아니다 — recyclebin.h가 애초에 "디렉터리는 휴지통 지원 안 함"
 * 이라고 명시하고 있어서(M32), 그 한계를 여기서 우회하지 않았다.
 * 디렉터리는 여전히 클릭하면 그냥 들어가진다(기존 동작 그대로).
 * 복사는 16KB보다 큰 파일은 지원하지 않는다(정적 버퍼 — 이 OS의 파일
 * 대부분이 텍스트/설정 수준 크기라 실용적으로 충분하다고 판단).
 */

#include <stddef.h>
#include "file_manager.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../gui/widget.h"
#include "../drivers/console.h"
#include "../proc/scheduler.h"

#define FM_MAX_ENTRIES 32
#define FM_ROW_H 14
#define FM_TOP_MARGIN 22 /* 경로 표시줄 한 줄 + 여백 */
#define FM_LEFT_MARGIN 8
#define FM_COPY_MAX 16384 /* 복사 지원 최대 파일 크기 */

typedef struct {
    char name[28];
    int is_dir;
    uint32_t size;
} fm_entry_t;

static char g_cwd[192] = "/";
static fm_entry_t g_entries[FM_MAX_ENTRIES];
static int g_entry_count = 0;
static int g_selected_row = -1; /* g_entries 인덱스 — 파일만 선택 가능 */

/* Milestone 35: 잘라내기/복사 클립보드(파일 하나의 전체 경로만 기억) */
#define FM_CLIP_NONE 0
#define FM_CLIP_COPY 1
#define FM_CLIP_CUT 2
static char g_clip_path[192] = "";
static int g_clip_mode = FM_CLIP_NONE;

/* Milestone 35: 새 폴더/이름바꾸기 입력 프롬프트 */
#define FM_PROMPT_NONE 0
#define FM_PROMPT_NEWFOLDER 1
#define FM_PROMPT_RENAME 2
static int g_prompt_mode = FM_PROMPT_NONE;
static widget_textbox_t g_prompt_box;

/* Milestone 35: 속성 오버레이 표시 여부 */
static int g_show_props = 0;

static char g_status[64] = "";

typedef struct {
    console_t *dc;
    int x, y;
} fm_draw_ctx_t;

static int str_eq_local(const char *a, const char *b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static void str_copy_local(char *dst, const char *src, int n) {
    int i = 0; for (; src[i] && i < n - 1; i++) dst[i] = src[i];
    dst[i] = '\0';
}

static void fm_entry_cb(const char *name, int is_dir, uint64_t size, void *ctx) {
    fm_draw_ctx_t *d = (fm_draw_ctx_t *)ctx;
    if (g_entry_count < FM_MAX_ENTRIES) {
        fm_entry_t *e = &g_entries[g_entry_count++];
        str_copy_local(e->name, name, sizeof(e->name));
        e->is_dir = is_dir;
        e->size = (uint32_t)size;
    }
    int row = g_entry_count - 1;
    d->dc->cursor_x = (uint32_t)d->x;
    d->dc->cursor_y = (uint32_t)d->y;
    if (row == g_selected_row) {
        console_fill_rect(d->dc, (uint32_t)(d->x - 2), (uint32_t)(d->y - 1), 260, FM_ROW_H, 0x00405878u);
        d->dc->cursor_x = (uint32_t)d->x; d->dc->cursor_y = (uint32_t)d->y;
    }
    console_print(d->dc, is_dir ? "[DIR] " : "      ");
    console_print(d->dc, name);
    d->y += FM_ROW_H;
}

/* cwd/name을 절대경로로 합친다 (아주 단순한 버전). */
static void fm_join(const char *cwd, const char *name, char *out, int outsz) {
    int i = 0;
    const char *c = cwd;
    while (*c && i < outsz - 1) out[i++] = *c++;
    if (i == 0 || out[i - 1] != '/') { if (i < outsz - 1) out[i++] = '/'; }
    const char *n = name;
    while (*n && i < outsz - 1) out[i++] = *n++;
    out[i] = '\0';
}

static void fm_go_up(void) {
    int len = 0; while (g_cwd[len]) len++;
    if (len <= 1) return; /* 이미 루트 */
    int i = len - 1;
    if (g_cwd[i] == '/') i--; /* 끝 슬래시는 무시 */
    while (i > 0 && g_cwd[i] != '/') i--;
    if (i <= 0) { g_cwd[0] = '/'; g_cwd[1] = '\0'; }
    else { g_cwd[i] = '\0'; }
}

static fm_entry_t *fm_selected(void) {
    if (g_selected_row < 0 || g_selected_row >= g_entry_count) return NULL;
    fm_entry_t *e = &g_entries[g_selected_row];
    if (e->is_dir) return NULL; /* 디렉터리는 선택 대상 아님(주석 참고) */
    return e;
}

static void file_manager_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)ctx;

    dc->cursor_x = (uint32_t)(x + FM_LEFT_MARGIN);
    dc->cursor_y = (uint32_t)(y + 6);
    console_print(dc, g_cwd);

    g_entry_count = 0;
    int draw_y = y + FM_TOP_MARGIN;
    int list_bottom = y + h - 34; /* 상태줄+버튼줄에게 아래쪽을 내어준다 */

    if (!(g_cwd[0] == '/' && g_cwd[1] == '\0')) {
        fm_entry_t *e = &g_entries[g_entry_count++];
        str_copy_local(e->name, "..", sizeof(e->name));
        e->is_dir = 1;
        e->size = 0;
        dc->cursor_x = (uint32_t)(x + FM_LEFT_MARGIN);
        dc->cursor_y = (uint32_t)draw_y;
        console_print(dc, "[DIR] ..");
        draw_y += FM_ROW_H;
    }

    fm_draw_ctx_t d = { dc, x + FM_LEFT_MARGIN, draw_y };
    int had_any = g_entry_count > 0;
    if (!ListDirectoryJ(g_cwd, fm_entry_cb, &d) && !had_any) {
        dc->cursor_x = (uint32_t)(x + FM_LEFT_MARGIN);
        dc->cursor_y = (uint32_t)draw_y;
        console_print(dc, "(empty or no JETFS volume)");
    }
    (void)list_bottom;

    /* ---- 상태/프롬프트 줄 (Milestone 35) ---- */
    int status_y = y + h - 32;
    dc->cursor_x = (uint32_t)(x + FM_LEFT_MARGIN);
    dc->cursor_y = (uint32_t)status_y;
    if (g_prompt_mode == FM_PROMPT_NEWFOLDER) {
        console_print(dc, "New folder name:");
        g_prompt_box.x = x + FM_LEFT_MARGIN;
        g_prompt_box.y = status_y + 12;
        widget_textbox_draw(dc, &g_prompt_box, 1);
    } else if (g_prompt_mode == FM_PROMPT_RENAME) {
        console_print(dc, "Rename to:");
        g_prompt_box.x = x + FM_LEFT_MARGIN;
        g_prompt_box.y = status_y + 12;
        widget_textbox_draw(dc, &g_prompt_box, 1);
    } else {
        dc->fg_color = 0x00A0D0A0u;
        console_print(dc, g_status);
        dc->fg_color = 0x00E0E0E0u;
    }

    /* ---- 액션 버튼 줄 (Milestone 35) ---- */
    if (g_prompt_mode == FM_PROMPT_NONE) {
        static const char *labels[7] = { "New", "Ren", "Del", "Copy", "Cut", "Paste", "Info" };
        int bw = (w - 16) / 7;
        int by = y + h - 16;
        for (int i = 0; i < 7; i++) {
            int bx = x + 8 + i * bw;
            console_fill_rect(dc, (uint32_t)bx, (uint32_t)by, (uint32_t)(bw - 2), 14, 0x00304050u);
            dc->cursor_x = (uint32_t)(bx + 2); dc->cursor_y = (uint32_t)(by + 3);
            console_print(dc, labels[i]);
        }
    }

    /* ---- 속성 오버레이 (Milestone 35) ---- */
    if (g_show_props) {
        fm_entry_t *sel = fm_selected();
        int ox = x + 20, oy = y + 30, ow = w - 40, oh = 70;
        console_fill_rect(dc, (uint32_t)ox, (uint32_t)oy, (uint32_t)ow, (uint32_t)oh, 0x00181828u);
        dc->cursor_x = (uint32_t)(ox + 6); dc->cursor_y = (uint32_t)(oy + 6);
        console_print(dc, "PROPERTIES");
        if (sel) {
            char path[192];
            fm_join(g_cwd, sel->name, path, sizeof(path));
            dc->cursor_x = (uint32_t)(ox + 6); dc->cursor_y = (uint32_t)(oy + 22);
            console_print(dc, sel->name);
            dc->cursor_x = (uint32_t)(ox + 6); dc->cursor_y = (uint32_t)(oy + 36);
            console_print(dc, "size: ");
            char sz[16]; int n = 0; uint32_t v = sel->size;
            if (v == 0) { sz[n++] = '0'; }
            else { char tmp[16]; int t = 0; while (v > 0) { tmp[t++] = (char)('0' + v % 10); v /= 10; } while (t > 0) sz[n++] = tmp[--t]; }
            sz[n] = '\0';
            console_print(dc, sz);
            console_print(dc, " bytes");

            int ro = IsReadOnlyJ(path);
            dc->cursor_x = (uint32_t)(ox + 6); dc->cursor_y = (uint32_t)(oy + 50);
            console_fill_rect(dc, (uint32_t)(ox + 6), (uint32_t)(oy + 50), 90, 14, ro ? 0x00806030u : 0x00304050u);
            dc->cursor_x = (uint32_t)(ox + 10); dc->cursor_y = (uint32_t)(oy + 53);
            console_print(dc, ro ? "READ-ONLY" : "WRITABLE");
        } else {
            dc->cursor_x = (uint32_t)(ox + 6); dc->cursor_y = (uint32_t)(oy + 22);
            console_print(dc, "(no file selected)");
        }
        dc->cursor_x = (uint32_t)(ox + ow - 40); dc->cursor_y = (uint32_t)(oy + 6);
        console_fill_rect(dc, (uint32_t)(ox + ow - 30), (uint32_t)(oy + 4), 22, 14, 0x00602030u);
        dc->cursor_x = (uint32_t)(ox + ow - 26); dc->cursor_y = (uint32_t)(oy + 7);
        console_print(dc, "X");
    }
}

static void fm_set_status(const char *s) {
    str_copy_local(g_status, s, sizeof(g_status));
}

static void fm_refresh_after_op(void) {
    g_selected_row = -1;
}

static void file_manager_click_cb(int local_x, int local_y, void *ctx) {
    (void)ctx;

    /* 속성 오버레이가 떠 있으면 그 안의 클릭만 처리(닫기 X, 읽기전용
     * 토글) — 오버레이 뒤의 목록/버튼은 이 프레임에서 무시. */
    if (g_show_props) {
        /* 오버레이 좌표는 content_cb와 동일한 계산식(ox=20,oy=30,ow=w-40)을
         * 여기서도 반복 — content_cb가 창 크기(w,h)를 안 넘겨주는 클릭
         * 콜백 시그니처 제약 때문에, 창 생성 시 고정한 크기를 그대로 상수로 씀. */
        int ox = 20, oy = 30, ow = 300 - 40;
        if (local_x >= ox + ow - 30 && local_x < ox + ow - 8 && local_y >= oy + 4 && local_y < oy + 18) {
            g_show_props = 0;
            return;
        }
        if (local_x >= ox + 6 && local_x < ox + 96 && local_y >= oy + 50 && local_y < oy + 64) {
            fm_entry_t *sel = fm_selected();
            if (sel) {
                char path[192];
                fm_join(g_cwd, sel->name, path, sizeof(path));
                SetReadOnlyJ(path, !IsReadOnlyJ(path));
            }
        }
        return;
    }

    if (g_prompt_mode != FM_PROMPT_NONE) return; /* 프롬프트 중엔 클릭 무시(Enter/Esc로만 진행) */

    /* 액션 버튼 줄(창 고정 크기 300x240 기준 — content_cb와 동일 상수) */
    int fixed_w = 300, fixed_h = 240;
    int by = fixed_h - 16;
    if (local_y >= by && local_y < by + 14) {
        int bw = (fixed_w - 16) / 7;
        int idx = (local_x - 8) / bw;
        fm_entry_t *sel = fm_selected();
        char path[192];
        if (sel) fm_join(g_cwd, sel->name, path, sizeof(path));

        switch (idx) {
            case 0: /* New folder */
                widget_textbox_init(&g_prompt_box, 0, 0, 250, 16, "");
                g_prompt_mode = FM_PROMPT_NEWFOLDER;
                break;
            case 1: /* Rename */
                if (sel) {
                    widget_textbox_init(&g_prompt_box, 0, 0, 250, 16, sel->name);
                    g_prompt_mode = FM_PROMPT_RENAME;
                } else fm_set_status("select a file first");
                break;
            case 2: /* Delete (recycle bin) */
                if (sel) {
                    if (IsReadOnlyJ(path)) {
                        fm_set_status("read-only - can't delete");
                    } else if (MoveToRecycleBinJ(path)) {
                        fm_set_status("moved to recycle bin");
                        fm_refresh_after_op();
                    } else fm_set_status("delete failed");
                } else fm_set_status("select a file first");
                break;
            case 3: /* Copy */
                if (sel) { str_copy_local(g_clip_path, path, sizeof(g_clip_path)); g_clip_mode = FM_CLIP_COPY; fm_set_status("copied (paste to place)"); }
                else fm_set_status("select a file first");
                break;
            case 4: /* Cut */
                if (sel) { str_copy_local(g_clip_path, path, sizeof(g_clip_path)); g_clip_mode = FM_CLIP_CUT; fm_set_status("cut (paste to move)"); }
                else fm_set_status("select a file first");
                break;
            case 5: /* Paste */
                if (g_clip_mode == FM_CLIP_NONE) {
                    fm_set_status("clipboard empty");
                } else {
                    /* basename만 뽑아 cwd에 붙인다 */
                    int len = 0; while (g_clip_path[len]) len++;
                    int i = len - 1;
                    while (i > 0 && g_clip_path[i - 1] != '/') i--;
                    char dest[192];
                    fm_join(g_cwd, g_clip_path + i, dest, sizeof(dest));
                    if (g_clip_mode == FM_CLIP_CUT) {
                        if (RenameFileJ(g_clip_path, dest)) { fm_set_status("moved"); g_clip_mode = FM_CLIP_NONE; }
                        else fm_set_status("move failed (name exists?)");
                    } else {
                        static char buf[FM_COPY_MAX];
                        uint64_t got = 0;
                        if (!ReadFileJ(g_clip_path, buf, sizeof(buf), &got)) {
                            fm_set_status("copy failed (>16KB or missing)");
                        } else if (!CreateFileJ(dest, 0) || !WriteFileJ(dest, buf, got)) {
                            fm_set_status("copy failed (name exists?)");
                        } else {
                            fm_set_status("pasted");
                        }
                    }
                }
                break;
            case 6: /* Info/Properties */
                if (sel) g_show_props = 1;
                else fm_set_status("select a file first");
                break;
        }
        return;
    }

    if (local_x < FM_LEFT_MARGIN) return;
    if (local_y < FM_TOP_MARGIN) return;
    int row = (local_y - FM_TOP_MARGIN) / FM_ROW_H;
    if (row < 0 || row >= g_entry_count) return;

    fm_entry_t *e = &g_entries[row];
    if (e->is_dir) {
        g_selected_row = -1;
        if (str_eq_local(e->name, "..")) {
            fm_go_up();
        } else {
            char next[192];
            fm_join(g_cwd, e->name, next, sizeof(next));
            str_copy_local(g_cwd, next, sizeof(g_cwd));
        }
    } else {
        g_selected_row = (g_selected_row == row) ? -1 : row; /* 다시 클릭하면 선택 해제 */
        g_status[0] = '\0';
    }
}

static void file_manager_key_cb(char c, void *ctx) {
    (void)ctx;
    if (g_prompt_mode == FM_PROMPT_NONE) return;

    if (c == 27) { /* Esc: 취소 */
        g_prompt_mode = FM_PROMPT_NONE;
        return;
    }
    if (c == '\n' || c == '\r') {
        if (g_prompt_mode == FM_PROMPT_NEWFOLDER) {
            if (g_prompt_box.len > 0) {
                char path[192];
                fm_join(g_cwd, g_prompt_box.buf, path, sizeof(path));
                if (CreateFileJ(path, 1)) fm_set_status("folder created");
                else fm_set_status("create failed (name exists?)");
            }
        } else if (g_prompt_mode == FM_PROMPT_RENAME) {
            fm_entry_t *sel = fm_selected();
            if (sel && g_prompt_box.len > 0) {
                char oldpath[192], newpath[192];
                fm_join(g_cwd, sel->name, oldpath, sizeof(oldpath));
                fm_join(g_cwd, g_prompt_box.buf, newpath, sizeof(newpath));
                if (IsReadOnlyJ(oldpath)) fm_set_status("read-only - can't rename");
                else if (RenameFileJ(oldpath, newpath)) { fm_set_status("renamed"); fm_refresh_after_op(); }
                else fm_set_status("rename failed (name exists?)");
            }
        }
        g_prompt_mode = FM_PROMPT_NONE;
        return;
    }
    widget_textbox_key(&g_prompt_box, c);
}

static volatile int g_fm_running = 0;

static void file_manager_on_close(void *ctx) {
    (void)ctx;
    g_fm_running = 0;
    g_selected_row = -1;
    g_prompt_mode = FM_PROMPT_NONE;
    g_show_props = 0;
    g_clip_mode = FM_CLIP_NONE;
}

static void file_manager_thread_fn(void *arg) {
    (void)arg;
    g_fm_running = 1;
    str_copy_local(g_cwd, "/", sizeof(g_cwd));
    /* Milestone 35: 액션 버튼 줄이 생기면서 창을 키웠다(280x200 -> 300x240).
     * file_manager_click_cb의 버튼줄/오버레이 좌표 계산이 이 크기를
     * 고정 상수로 가정하므로(클릭 콜백은 창 크기를 안 받음), 여기서
     * 크기를 바꾸면 그쪽 상수도 같이 맞춰야 한다. */
    JetWindowHandle win = CreateWindowJ("FILE MANAGER", 620, 60, 300, 240, 0x00304030);
    if (win >= 0) {
        wm_set_content_callback(win, file_manager_content_cb, NULL);
        wm_set_close_callback(win, file_manager_on_close, NULL);
        wm_set_click_callback(win, file_manager_click_cb, NULL);
        wm_set_key_callback(win, file_manager_key_cb, NULL);
    }
    while (g_fm_running) {
        scheduler_yield();
    }
}

void file_manager_launch(void) {
    static int launched = 0;
    if (launched && g_fm_running) return;
    launched = 1;
    CreateThreadJ("file_manager", file_manager_thread_fn, NULL);
}
