/*
 * JetOS - kernel/net/crypto/bignum.c
 * bignum.h 참고. 속도 최적화(몽고메리 축약 등) 없이 "고정폭(256리밈=
 * 8192비트) 원시 배열 + 이진 시프트-뺄셈 나눗셈"으로 정확성 위주로
 * 구현했다. RSA 공개키 연산(작은 지수 e, 1회성 핸드셰이크)에는
 * 이 정도로 충분히 빠르다 — host_test.c에서 알려진 RSA 벡터로 검증.
 */
#include "bignum.h"

#define WIDE_LIMBS (BIGNUM_MAX_LIMBS * 2) /* 곱셈 결과가 두 배 폭이 될 수 있음 */

static void raw_zero(uint32_t *a) {
    for (int i = 0; i < WIDE_LIMBS; i++) a[i] = 0;
}

static void raw_from_bn(uint32_t *a, const bignum_t *b) {
    raw_zero(a);
    for (int i = 0; i < b->nlimbs && i < WIDE_LIMBS; i++) a[i] = b->limb[i];
}

/* limb[0]이 최하위(리틀엔디안 리밈 순서) */
static int raw_cmp(const uint32_t *a, const uint32_t *b) {
    for (int i = WIDE_LIMBS - 1; i >= 0; i--) {
        if (a[i] != b[i]) return (a[i] < b[i]) ? -1 : 1;
    }
    return 0;
}

static void raw_sub_inplace(uint32_t *a, const uint32_t *b) {
    int64_t borrow = 0;
    for (int i = 0; i < WIDE_LIMBS; i++) {
        int64_t d = (int64_t)a[i] - (int64_t)b[i] - borrow;
        if (d < 0) { d += ((int64_t)1 << 32); borrow = 1; } else { borrow = 0; }
        a[i] = (uint32_t)d;
    }
}

static void raw_shl1(uint32_t *a) {
    uint32_t carry = 0;
    for (int i = 0; i < WIDE_LIMBS; i++) {
        uint32_t nc = a[i] >> 31;
        a[i] = (uint32_t)((a[i] << 1) | carry);
        carry = nc;
    }
}

static void raw_shr1(uint32_t *a) {
    uint32_t carry = 0;
    for (int i = WIDE_LIMBS - 1; i >= 0; i--) {
        uint32_t nc = a[i] & 1;
        a[i] = (a[i] >> 1) | (carry << 31);
        carry = nc;
    }
}

static int raw_is_zero(const uint32_t *a) {
    for (int i = 0; i < WIDE_LIMBS; i++) if (a[i]) return 0;
    return 1;
}

static int raw_bitlen(const uint32_t *a) {
    for (int i = WIDE_LIMBS - 1; i >= 0; i--) {
        if (a[i]) {
            uint32_t v = a[i];
            int b = 0;
            while (v) { b++; v >>= 1; }
            return i * 32 + b;
        }
    }
    return 0;
}

static void raw_mul_full(uint32_t *out, const uint32_t *a, const uint32_t *b) {
    /* 스쿨북 O(n^2) 곱셈. out은 WIDE_LIMBS 폭(오버플로 상위 비트는
     * 버림 — modexp 안에서는 피연산자가 항상 mod로 먼저 축약돼 있어
     * mod가 BIGNUM_MAX_LIMBS 이내인 한 곱 결과가 WIDE_LIMBS를 넘지
     * 않는다). 64비트 누산기로 32x32 곱의 캐리를 안전하게 처리. */
    raw_zero(out);
    /* 실제로 값이 있는 리밈 개수까지만 순회해 불필요한 연산을 줄인다 */
    int na = 0, nb = 0;
    for (int i = WIDE_LIMBS / 2 - 1; i >= 0; i--) { if (a[i]) { na = i + 1; break; } }
    for (int i = WIDE_LIMBS / 2 - 1; i >= 0; i--) { if (b[i]) { nb = i + 1; break; } }

    for (int i = 0; i < na; i++) {
        if (a[i] == 0) continue;
        uint64_t carry = 0;
        for (int j = 0; j < nb; j++) {
            int k = i + j;
            if (k >= WIDE_LIMBS) break;
            uint64_t prod = (uint64_t)a[i] * (uint64_t)b[j] + (uint64_t)out[k] + carry;
            out[k] = (uint32_t)prod;
            carry = prod >> 32;
        }
        int k = i + nb;
        while (carry && k < WIDE_LIMBS) {
            uint64_t s = (uint64_t)out[k] + carry;
            out[k] = (uint32_t)s;
            carry = s >> 32;
            k++;
        }
    }
}

/* rem = a mod mod (이진 시프트-뺄셈 나눗셈, 학교에서 배우는 필산과 동일한
 * 원리를 비트 단위로 수행). d를 mod와 a의 비트길이 차이만큼 왼쪽으로
 * 밀어놓고, 위에서부터 한 비트씩 내려오며 뺄 수 있으면 뺀다. */
static void raw_mod(uint32_t *rem, const uint32_t *a, const uint32_t *mod) {
    int abits = raw_bitlen(a);
    int mbits = raw_bitlen(mod);
    if (mbits == 0) { raw_zero(rem); return; }

    for (int i = 0; i < WIDE_LIMBS; i++) rem[i] = a[i];
    if (abits < mbits) return; /* 이미 mod보다 작음 */

    uint32_t d[WIDE_LIMBS];
    for (int i = 0; i < WIDE_LIMBS; i++) d[i] = mod[i];
    int shift = abits - mbits;
    for (int i = 0; i < shift; i++) raw_shl1(d);

    for (int i = 0; i <= shift; i++) {
        if (raw_cmp(rem, d) >= 0) raw_sub_inplace(rem, d);
        raw_shr1(d);
    }
}

void bn_from_bytes_be(bignum_t *r, const uint8_t *buf, size_t len) {
    for (int i = 0; i < BIGNUM_MAX_LIMBS; i++) r->limb[i] = 0;
    /* 뒤(최하위 바이트)부터 4바이트씩 묶어 리밈으로 */
    int limb_idx = 0;
    int64_t i = (int64_t)len - 1;
    while (i >= 0 && limb_idx < BIGNUM_MAX_LIMBS) {
        uint32_t v = 0;
        for (int b = 0; b < 4 && i >= 0; b++, i--) {
            v |= (uint32_t)buf[i] << (b * 8);
        }
        r->limb[limb_idx++] = v;
    }
    int n = 0;
    for (int k = BIGNUM_MAX_LIMBS - 1; k >= 0; k--) { if (r->limb[k]) { n = k + 1; break; } }
    r->nlimbs = n;
}

int bn_to_bytes_be(const bignum_t *a, uint8_t *out, size_t outlen) {
    /* 값이 outlen바이트를 넘치는지 확인 */
    for (size_t i = outlen; i < (size_t)a->nlimbs * 4; i++) {
        /* a->nlimbs*4가 outlen보다 크면 상위 바이트 중 0이 아닌 게 있는지 봐야 하는데,
         * 아래 루프에서 실제로 채우면서 넘치는 바이트를 감지한다. 여기선 스킵. */
        (void)i;
        break;
    }
    for (size_t i = 0; i < outlen; i++) out[i] = 0;
    for (int limb_idx = 0; limb_idx < a->nlimbs; limb_idx++) {
        uint32_t v = a->limb[limb_idx];
        for (int b = 0; b < 4; b++) {
            size_t byte_pos_from_end = (size_t)limb_idx * 4 + b;
            if (byte_pos_from_end >= outlen) {
                if ((uint8_t)(v >> (b * 8))) return 0; /* 넘침 */
                continue;
            }
            out[outlen - 1 - byte_pos_from_end] = (uint8_t)(v >> (b * 8));
        }
    }
    return 1;
}

void bn_from_u32(bignum_t *r, uint32_t v) {
    for (int i = 0; i < BIGNUM_MAX_LIMBS; i++) r->limb[i] = 0;
    r->limb[0] = v;
    r->nlimbs = v ? 1 : 0;
}

int bn_is_zero(const bignum_t *a) { return a->nlimbs == 0; }

int bn_cmp(const bignum_t *a, const bignum_t *b) {
    if (a->nlimbs != b->nlimbs) return (a->nlimbs < b->nlimbs) ? -1 : 1;
    for (int i = a->nlimbs - 1; i >= 0; i--) {
        if (a->limb[i] != b->limb[i]) return (a->limb[i] < b->limb[i]) ? -1 : 1;
    }
    return 0;
}

size_t bn_byte_len(const bignum_t *a) {
    /* Milestone 24: 서명 검증(modexp 결과를 정확한 modulus 바이트 길이로
     * 내보내야 함)에 필요해서 추가. tls.c가 하던 "guess loop"과 동일한
     * 계산을 공용 함수로 뽑아낸 것뿐 — 최상위 0이 아닌 리밈의 실제
     * 바이트 수(선행 0바이트 제거)를 센다. */
    if (a->nlimbs == 0) return 0;
    uint32_t top = a->limb[a->nlimbs - 1];
    size_t top_bytes = 0;
    while (top) { top_bytes++; top >>= 8; }
    if (top_bytes == 0) top_bytes = 1; /* top==0인 경우는 nlimbs 정의상 안 옴 */
    return (size_t)(a->nlimbs - 1) * 4 + top_bytes;
}

static void bn_from_wide(bignum_t *r, const uint32_t *w) {
    for (int i = 0; i < BIGNUM_MAX_LIMBS; i++) r->limb[i] = w[i];
    int n = 0;
    for (int k = BIGNUM_MAX_LIMBS - 1; k >= 0; k--) { if (w[k]) { n = k + 1; break; } }
    r->nlimbs = n;
}

void bn_modexp(bignum_t *r, const bignum_t *base, const bignum_t *exp, const bignum_t *mod) {
    uint32_t wbase[WIDE_LIMBS], wmod[WIDE_LIMBS], wresult[WIDE_LIMBS], wtmp[WIDE_LIMBS];
    raw_from_bn(wmod, mod);
    raw_from_bn(wbase, base);
    raw_mod(wtmp, wbase, wmod); /* base를 미리 mod로 축약 */
    for (int i = 0; i < WIDE_LIMBS; i++) wbase[i] = wtmp[i];

    raw_zero(wresult);
    wresult[0] = 1; /* result = 1 */

    if (raw_is_zero(wmod) || exp->nlimbs == 0) {
        /* mod=0은 정의 불가, exp=0이면 표준적으로 1 (mod>1 가정) */
        bn_from_wide(r, wresult);
        return;
    }

    int exp_bits = exp->nlimbs * 32;
    /* 최상위 실제 비트부터 시작(앞의 0비트 스킵) */
    int started = 0;
    for (int bit = exp_bits - 1; bit >= 0; bit--) {
        int limb_i = bit / 32, bit_i = bit % 32;
        int b = (int)((exp->limb[limb_i] >> bit_i) & 1);
        if (!started) {
            if (!b) continue;
            started = 1;
        }
        /* result = result^2 mod mod */
        raw_mul_full(wtmp, wresult, wresult);
        raw_mod(wresult, wtmp, wmod);
        if (b) {
            raw_mul_full(wtmp, wresult, wbase);
            raw_mod(wresult, wtmp, wmod);
        }
    }

    bn_from_wide(r, wresult);
}
