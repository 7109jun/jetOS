kernel/fs/recyclebin.o: kernel/fs/recyclebin.c kernel/fs/recyclebin.h \
 kernel/fs/jetfs.h
kernel/fs/recyclebin.h:
kernel/fs/jetfs.h:
