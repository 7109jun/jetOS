#ifndef JETOS_JETFS_H
#define JETOS_JETFS_H

#include <stdint.h>

/*
 * JETFS v1 — JetOS 자체 파일시스템.
 *
 * 레이아웃 (블록 크기 4096바이트 = AHCI 섹터 8개):
 *   블록 0        : 슈퍼블록
 *   블록 1..N     : inode 테이블 (고정 크기 배열)
 *   블록 N+1..M   : 데이터 블록 비트맵
 *   블록 M+1..끝  : 데이터 블록
 *
 * 디렉터리는 "데이터 블록에 dirent 배열을 담은 특수 inode"로 표현된다.
 * (Milestone 4 범위의 단순화가 여전히 남아있음: 디렉터리 자체는 직접
 * 블록 12개까지만 사용 — 항목 약 1700개 정도까지 충분하므로 실질적
 * 제약은 아니다.)
 *
 * Milestone 8: 파일(FILE 타입)은 직접 블록 12개에 더해 단일 간접
 * 블록(indirect block) 1개를 지원한다. 간접 블록은 그 자체가 하나의
 * 데이터 블록이며, uint32_t 블록 번호 1024개(4096/4)를 담을 수 있다.
 * 이 단계에서 파일 최대 크기는 (12 + 1024) * 4096 바이트 ≈ 4.2MB.
 *
 * Milestone 22: 이중 간접 블록(double indirect) 추가. 이중 간접
 * 블록도 그 자체가 데이터 블록이며, "간접 블록 번호" 1024개를
 * 담는다 — 즉 이중 간접 블록 하나가 간접 블록 1024개(각각 데이터
 * 블록 1024개)를 가리켜, 이중 간접 경로로만 1024*1024개 블록에
 * 닿을 수 있다. 최종 파일 최대 크기는
 * (12 + 1024 + 1024*1024) * 4096 바이트 ≈ 4.3GB — 디스크 자체
 * 용량(현재 기본 128MB)이 실질적 상한이 되므로, 이제 "파일 하나가
 * 디스크를 거의 다 채울 수 있을 만큼" 커질 수 있다(M20/21 문서에서
 * 128MB로 늘린 기본 디스크 용량과 짝을 이루는 업그레이드).
 */

#define JETFS_MAGIC 0x4A455446u /* "JETF" */
#define JETFS_BLOCK_SIZE 4096
#define JETFS_SECTORS_PER_BLOCK (JETFS_BLOCK_SIZE / 512)
#define JETFS_MAX_INODES 256
#define JETFS_MAX_NAME 28
#define JETFS_DIRECT_BLOCKS 12
#define JETFS_INDIRECT_PTRS (JETFS_BLOCK_SIZE / sizeof(uint32_t)) /* 1024 */
#define JETFS_DOUBLE_INDIRECT_PTRS (JETFS_BLOCK_SIZE / sizeof(uint32_t)) /* 1024개의 "간접 블록 번호" */
#define JETFS_MAX_FILE_BLOCKS (JETFS_DIRECT_BLOCKS + JETFS_INDIRECT_PTRS + \
                               (JETFS_DOUBLE_INDIRECT_PTRS * JETFS_INDIRECT_PTRS))
#define JETFS_ROOT_INODE 0

typedef enum {
    JETFS_TYPE_FREE = 0,
    JETFS_TYPE_FILE = 1,
    JETFS_TYPE_DIR  = 2
} jetfs_inode_type_t;

typedef struct {
    uint32_t magic;
    uint32_t total_blocks;
    uint32_t inode_table_start;
    uint32_t inode_table_blocks;
    uint32_t bitmap_start;
    uint32_t bitmap_blocks;
    uint32_t data_start;
    uint32_t root_inode;
    uint8_t  reserved[JETFS_BLOCK_SIZE - 32];
} jetfs_superblock_t;

typedef struct {
    uint32_t type;       /* jetfs_inode_type_t */
    uint32_t size;        /* 바이트 단위 */
    uint32_t block[JETFS_DIRECT_BLOCKS];
    uint32_t block_count;  /* 디렉터리 전용: 사용중인 직접 블록 개수.
                             * 파일은 size로부터 필요 블록 수를 계산하므로
                             * 이 필드를 사용하지 않는다. */
    uint32_t indirect;     /* 파일 전용: 간접 블록 번호 (0=미할당) */
    uint32_t double_indirect; /* 파일 전용(M22): 이중 간접 블록 번호 (0=미할당) */
    uint32_t used;        /* 0=빈 슬롯, 1=사용중 */
} jetfs_inode_t;

typedef struct {
    char name[JETFS_MAX_NAME];
    uint32_t inode;
    uint32_t used;
} jetfs_dirent_t;

/* drive_index의 lba_offset(섹터 단위)부터 시작하는 디스크 영역을 JETFS로
 * 마운트한다. 이미 mkjetfs로 포맷되어 있어야 한다. 성공 시 1. */
int jetfs_mount(int drive_index, uint64_t lba_offset);

/* 루트 기준 절대 경로("/dir/file" 형태)로 파일을 연다. */
int jetfs_create(const char *path, jetfs_inode_type_t type);
int jetfs_read(const char *path, void *buffer, uint32_t max_size, uint32_t *out_size);
int jetfs_write(const char *path, const void *data, uint32_t size);
int jetfs_delete(const char *path);
int jetfs_rename(const char *old_path, const char *new_path);

/* path의 타입/크기를 조회한다. 존재하지 않으면 0. */
int jetfs_stat(const char *path, jetfs_inode_type_t *out_type, uint32_t *out_size);

/* dir_path 아래 항목 이름들을 콜백으로 순서대로 전달한다. */
typedef void (*jetfs_list_cb)(const char *name, jetfs_inode_type_t type, uint32_t size, void *ctx);
int jetfs_list(const char *dir_path, jetfs_list_cb cb, void *ctx);

#endif
