#ifndef JETOS_APP_FILE_MANAGER_H
#define JETOS_APP_FILE_MANAGER_H
void file_manager_launch(void);
#endif
