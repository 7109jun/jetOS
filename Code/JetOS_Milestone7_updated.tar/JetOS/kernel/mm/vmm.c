/*
 * JetOS - kernel/mm/vmm.c
 * JetOS 자체 PML4/PDPT/PD 를 구성해 하위 4GiB를 2MiB 페이지로 항등
 * 매핑한다. 커널 이미지 자체 정적 배열로 테이블을 확보해 PMM 부트스트랩
 * 순서에 의존하지 않는다.
 */

#include "vmm.h"
#include "../hal/x86_asm_shim.h"

#define PAGE_PRESENT  0x1ULL
#define PAGE_WRITABLE 0x2ULL
#define PAGE_SIZE_2MB 0x80ULL

#define VMM_IDENTITY_GB 4

static uint64_t g_pml4[512] __attribute__((aligned(4096)));
static uint64_t g_pdpt[512] __attribute__((aligned(4096)));
static uint64_t g_pd[VMM_IDENTITY_GB][512] __attribute__((aligned(4096)));

void vmm_init(void) {
    for (int i = 0; i < 512; i++) { g_pml4[i] = 0; g_pdpt[i] = 0; }

    g_pml4[0] = ((uint64_t)&g_pdpt[0]) | PAGE_PRESENT | PAGE_WRITABLE;

    for (int gb = 0; gb < VMM_IDENTITY_GB; gb++) {
        g_pdpt[gb] = ((uint64_t)&g_pd[gb][0]) | PAGE_PRESENT | PAGE_WRITABLE;
        for (int e = 0; e < 512; e++) {
            uint64_t phys = ((uint64_t)gb * 1024ULL * 1024ULL * 1024ULL) +
                             ((uint64_t)e * 2ULL * 1024ULL * 1024ULL);
            g_pd[gb][e] = phys | PAGE_PRESENT | PAGE_WRITABLE | PAGE_SIZE_2MB;
        }
    }

    hal_write_cr3((uint64_t)&g_pml4[0]);
}
