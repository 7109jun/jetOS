#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace deiig::performance {
struct Snapshot {
    double cpu_percent = 0.0;
    std::uint64_t memory_used = 0;
    std::uint64_t memory_total = 0;
    std::uint64_t process_memory = 0;
    std::uint64_t process_threads = 0;
    std::uint64_t disk_total = 0;
    std::uint64_t disk_free = 0;
    std::uint64_t uptime_seconds = 0;
};
Snapshot sample();
std::string format_bytes(std::uint64_t bytes);
void print();
}
