kernel/int/idt.o: kernel/int/idt.c kernel/int/idt.h \
 kernel/int/../hal/x86_asm_shim.h kernel/int/../hal/syscall.h \
 kernel/int/exceptions.h
kernel/int/idt.h:
kernel/int/../hal/x86_asm_shim.h:
kernel/int/../hal/syscall.h:
kernel/int/exceptions.h:
