/*
 * JetOS - kernel/hal/syscall_entry.c
 *
 * ============================== 중요 안내 ==============================
 * context_switch.c, x86_asm_shim.h와 같은 이유로 예외적으로 어셈블리를
 * 포함하는 세 번째(이자 마지막) 파일이다: 시스템콜 진입점은 "지금 CPU
 * 레지스터에 들어있는 값(RAX=번호, RDI/RSI/RDX=인자)을 그대로 C 함수의
 * 인자로 넘겨야" 하는데, GCC의 __attribute__((interrupt))는 예외/인터럽트
 * 프레임(RIP/CS/RFLAGS/RSP/SS)만 넘겨줄 뿐 범용 레지스터에 대한 접근을
 * 보장하지 않는다 — 순수 C만으로는 "그 순간의 RAX 값"을 안정적으로
 * 읽어낼 방법이 없다. 그래서 레지스터를 전부 스택에 push해 C 함수가
 * 읽을 수 있는 구조체로 넘겨주는 이 얇은 트램폴린만 어셈블리로 쓴다.
 *
 * 실제 시스템콜 처리 로직(syscall_dispatch)은 kernel/hal/syscall.c에
 * 100% 순수 C로 있다 — 이 파일이 하는 일은 딱 하나, "레지스터를 저장하고
 * C 함수를 부른 뒤 복원해서 iretq하는 것"뿐이다.
 * =========================================================================
 */

#include "syscall.h"

__attribute__((naked))
void syscall_entry(void) {
    __asm__ volatile (
        "pushq %%rax\n\t"
        "pushq %%rbx\n\t"
        "pushq %%rcx\n\t"
        "pushq %%rdx\n\t"
        "pushq %%rsi\n\t"
        "pushq %%rdi\n\t"
        "pushq %%rbp\n\t"
        "pushq %%r8\n\t"
        "pushq %%r9\n\t"
        "pushq %%r10\n\t"
        "pushq %%r11\n\t"
        "pushq %%r12\n\t"
        "pushq %%r13\n\t"
        "pushq %%r14\n\t"
        "pushq %%r15\n\t"
        "movq %%rsp, %%rdi\n\t"      /* syscall_dispatch(regs) — regs = 현재 RSP */
        "call syscall_dispatch\n\t"
        "popq %%r15\n\t"
        "popq %%r14\n\t"
        "popq %%r13\n\t"
        "popq %%r12\n\t"
        "popq %%r11\n\t"
        "popq %%r10\n\t"
        "popq %%r9\n\t"
        "popq %%r8\n\t"
        "popq %%rbp\n\t"
        "popq %%rdi\n\t"
        "popq %%rsi\n\t"
        "popq %%rdx\n\t"
        "popq %%rcx\n\t"
        "popq %%rbx\n\t"
        "popq %%rax\n\t"
        "iretq\n\t"
        :
        :
        : "memory"
    );
}
