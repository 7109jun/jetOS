# JetOS 개발 현황

> 마지막 업데이트: Milestone 19 완료 시점
> 빌드 환경: x86_64-w64-mingw32-gcc (부트로더) + gcc (커널) + QEMU+OVMF (테스트)
> 검증 방식: 전체 커널 컴파일+링크 통과 확인 + **실제 QEMU 부팅으로 시리얼 로그/스크린샷 확인**
> (Milestone 10부터 샌드박스에 QEMU가 설치되어 실기 검증이 가능해졌고, 이후 모든 마일스톤은
> 반드시 실부팅으로 확인함). Milestone 19의 암호 관련 코드(TLS 스택)는 추가로 **호스트 하네스
> 테스트**(일반 리눅스 gcc로 컴파일해 NIST/RFC 공식 테스트 벡터 및 실제 openssl 인증서와 대조)를
> 거쳤다 — 프로토콜/커널 통합 문제와 암호 알고리즘 자체의 정확성 문제를 분리해서 검증하기 위함.
>
> 이 문서 + 최신 tar 파일(`JetOS_Milestone19.tar`)만 있으면 현재 상태를 전부 파악할 수 있도록 작성했다.

---

## 철학

> **"Windows를 쓰고 싶지만 돈이 없는 사람"**을 위한 OS.
> Windows와 똑같지는 않지만, 처음 켜는 순간 익숙하게 느껴지는 독립적인 무료 OS.
> 외부 OS(Windows/Linux) 코드, DLL, SDK 의존 없음. 전부 JetOS가 직접 구현.
>
> Milestone 15부터는 "겉만 번지르르한 OS"가 아니라 **진짜 OS**를 목표로, Linux의 핵심 설계(프로세스별 주소공간, ELF 실행, 장애 격리)를 참고해 구현했다(오픈소스 참고 — 라이선스 문제 없음, 코드를 그대로 가져온 게 아니라 개념/구조만 참고).
>
> Milestone 19는 M18까지 문서에 "알려진 한계/미완성"으로 명시해뒀던 항목 중 우선순위가 높았던
> 네 가지 — 키보드 포커스 라우팅, 스크롤/위젯 툴킷, 유저 포인터 검증, HTTPS/TLS — 를 한 번에
> 밀어붙인 마일스톤이다. 특히 TLS는 표준 암호 라이브러리(OpenSSL 등)를 전혀 쓰지 않고 SHA-256/
> HMAC/AES-128/RSA(bignum modexp)/X.509 최소 파서/TLS 1.2 상태머신을 전부 직접 구현했다
> ("외부 SDK 의존 없음" 철학을 암호 스택에도 그대로 적용).

---

## 빌드 & 실행 방법

```bash
# 환경 설치 (Debian/Ubuntu)
sudo apt install mingw-w64 qemu-system-x86 ovmf mtools dosfstools make gcc

# 빌드
make                                    # 부트로더(mingw) + 커널(native gcc)
make mkjetfs && ./build/mkjetfs build/jetfs.img 16   # JETFS 데이터 디스크
make esp                                # ESP(FAT32) 이미지 생성
./scripts/run_qemu.sh                   # QEMU+OVMF 부팅 (기본으로 -netdev user -device rtl8139 포함)

# 테스트용 실행파일 준비 (선택)
./scripts/build_test_exe.sh             # PE32+ hello.exe (Win32 MessageBox 테스트, Milestone 9)
./scripts/build_test_native_elf.sh      # 네이티브 ELF 3종(정상/크래시/유저포인터검증 테스트, M15/16/19)
```

산출물: `build/BOOTX64.EFI`, `build/KERNEL.ELF`, `build/esp.img`, `build/jetfs.img`

### TLS 자체 테스트를 QEMU에서 재현하려면
`kernel_entry.c`의 TLS 자체 테스트는 QEMU SLIRP 게이트웨이(`10.0.2.2:8443`)에 실제 TLS 1.2
서버가 떠 있어야 통과한다. 호스트에서 아래처럼 자체서명 인증서 + 파이썬 TLS 서버를 띄운 뒤
QEMU를 부팅하면 된다(둘 다 없으면 이 자체 테스트만 "TIMEOUT"으로 스킵되고 나머지 부팅은 정상 진행):
```bash
openssl req -x509 -newkey rsa:2048 -keyout key.pem -out cert.pem -days 3650 -nodes -subj "/CN=test.jetos.local"
python3 - <<'EOF'
import http.server, ssl
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        body = b"Hello from JetOS TLS test server via real TLS 1.2!\n"
        self.send_response(200); self.send_header("Content-Length", str(len(body))); self.end_headers()
        self.wfile.write(body)
ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ctx.minimum_version = ctx.maximum_version = ssl.TLSVersion.TLSv1_2
ctx.set_ciphers("AES128-SHA256")
ctx.load_cert_chain("cert.pem", "key.pem")
srv = http.server.HTTPServer(("0.0.0.0", 8443), H)
srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
srv.serve_forever()
EOF
```

### 검증 방법론 (향후 개발 시 재사용 권장)
1. **호스트 하네스 테스트**: `kernel/fs/jetfs.c`, `kernel/exec/pe_loader.c`, `kernel/exec/elf_loader.c`처럼 하드웨어 의존이 적은 로직은, `ahci_read/write_sectors`나 `jetfs_read` 등 최하위 I/O 함수만 스텁으로 바꿔치기해서 **일반 리눅스 gcc로 그대로 컴파일**하고 실제 파일/네트워크 캡처와 비교 검증했다. Milestone 19에서는 이 방법론을 암호 프리미티브(`kernel/net/crypto/`)에도 그대로 적용해, SHA-256/HMAC-SHA256/AES-128을 NIST·RFC 공식 테스트 벡터와, RSA(bignum modexp)·X.509 파서·PKCS#1 패딩을 openssl로 직접 생성한 인증서/개인키와 대조 검증했다 — 이 방법으로 AES 키 스케줄 엔디안 버그 1건을 실제 커널에 통합하기 전에 호스트에서 잡았다.
2. **실제 QEMU 부팅 + 시리얼 로그**: `-serial stdio` 또는 `-serial file:...`로 부팅 로그를 받아 `STAGE:`, `=== ... SELF-TEST ===` 마커로 각 단계 성공 여부를 확인. 커널에 각 서브시스템별 "부팅 시 자체 테스트"(NET/TCP/DNS/RING3/유저포인터검증/TLS self-test)가 내장되어 있어, 이미지를 새로 빌드할 때마다 자동으로 회귀 테스트가 된다.
3. **QEMU 모니터 + screendump**: GUI는 `-monitor unix:...,server,nowait -display none`로 띄운 뒤 몬 소켓에 `screendump` 명령을 보내 PPM 캡처 → PNG 변환 → 육안 확인. **주의**: 이 샌드박스 환경에서 QEMU 백그라운드 프로세스는 도구 호출이 끝나면 죽으므로, "부팅 → 조작 → 캡처 → 종료"를 **반드시 한 번의 bash 호출 안에서 전부** 처리해야 한다(TLS 자체 테스트도 마찬가지 — 호스트 TLS 서버 기동과 QEMU 부팅을 같은 호출 안에서 함께 해야 서버가 살아있다). 또한 `mouse_move`의 델타→실제 픽셀 이동 비율이 일정하지 않아 정밀한 좌표 클릭 자동화는 신뢰하기 어려움 — 정적 화면 캡처(부팅 직후 데스크톱 등) 검증 위주로 활용할 것.

---

## 디렉터리 구조 (M19 기준 주요 부분, M18 대비 변경/신규만 표시)

```
JetOS/
├── kernel/
│   ├── hal/
│   │   ├── x86_asm_shim.h    Milestone 19: RDRAND/CPUID/RDTSC 단일명령 헬퍼 추가
│   │   │                        (어셈블리 3파일 원칙 유지 — 새 어셈블리 파일 안 만듦)
│   │   ├── syscall.c/h       Milestone 19: 유저 포인터 검증(syscall_check_user_range/
│   │   │                        _cstr) 추가 — 범위 밖 포인터는 그 스레드만 종료(M16과 동일 원칙)
│   ├── drivers/
│   │   ├── keyboard.c/h      Milestone 19: PgUp/PgDn 스캔코드 추가(스크롤용)
│   ├── gui/
│   │   ├── wm.c/h             Milestone 19: 키보드 포커스 라우팅 API 노출(wm_dispatch_key
│   │   │                        등 — 기존엔 z-order 추적용으로만 내부에 있었음), content_h/
│   │   │                        scroll_y + 스크롤바 렌더링/드래그, PgUp/PgDn 처리
│   │   ├── widget.c/h         Milestone 19 신설: 재사용 가능한 위젯 툴킷
│   │   │                        (버튼/텍스트박스/스크롤 가능 텍스트 렌더러)
│   │   ├── desktop.c/h        Milestone 19: g_jash_running 특수 케이스 제거,
│   │   │                        wm_dispatch_key() 일반 라우팅으로 대체, 스크롤바 드래그 배선
│   ├── net/
│   │   ├── tcp.c/h            Milestone 19: tcp_recv_exact() 추가(TLS 레코드 단위 수신용)
│   │   ├── tls.c/h            Milestone 19 신설: 최소 TLS 1.2 클라이언트
│   │   │                        (TLS_RSA_WITH_AES_128_CBC_SHA256 전용)
│   │   └── crypto/            Milestone 19 신설: 암호 프리미티브(전부 호스트 테스트 벡터로 검증)
│   │       ├── sha256.c/h, hmac_sha256.c/h, aes128.c/h
│   │       ├── bignum.c/h     RSA 공개키 연산용 최소 임의정밀도 정수(modexp)
│   │       ├── der.c/h, x509_min.c/h   X.509에서 RSA 공개키만 뽑는 최소 DER 파서
│   │       ├── rsa_pkcs1.c/h  RSAES-PKCS1-v1_5 공개키 암호화
│   │       ├── tls_prf.c/h    TLS 1.2 PRF(HMAC-SHA256 기반)
│   │       └── rng.c/h        RDRAND 우선, 없으면 RTC/PIT/TSC+SHA-256 폴백(약함, 문서화됨)
│   ├── apps/
│   │   ├── jash.c/h           Milestone 19: `https` 명령 추가, 스크롤 가능한 출력창으로 교체
│   │   └── browser.c/h        Milestone 19: 실제 타이핑 가능한 주소창(GUI 직접 입력 —
│   │                             M18까지의 한계였던 "jash로만 URL 지정 가능" 해소),
│   │                             https:// URL 지원, 스크롤 가능한 페이지 본문
├── tools/testdata/
│   └── test_elf_baduptr.c    Milestone 19 신설: 유저 포인터 검증 자체 테스트용 크래시 프로그램
```
(M18의 나머지 디렉터리 구조는 변경 없음 — 이전 문서 참고)

---

## 마일스톤별 요약 (M19만 추가, M1~18은 이전 문서와 동일)

| # | 제목 | 핵심 내용 |
|---|------|-----------|
| 19 | 포커스 라우팅 + 스크롤/위젯 + 유저포인터검증 + HTTPS | ①키보드 포커스를 클릭/생성 순서로 자동 추적해 일반화(하드코딩 특수케이스 제거) ②재사용 가능한 위젯 툴킷 신설 + 스크롤바(jash 출력창/브라우저 본문 스크롤백 가능) ③시스템콜 인자 포인터가 유저 영역 안인지 검증, 벗어나면 그 프로세스만 종료 ④SHA-256/HMAC/AES-128/bignum-RSA/X.509 최소파서를 전부 직접 구현해 TLS 1.2(RSA-AES128-CBC-SHA256) 클라이언트 완성, 실제 로컬 TLS 서버와 QEMU에서 종단간 핸드셰이크+암호화된 HTTP 왕복 확인 |

---

## 현재 동작하는 전체 기능 목록 (M18 목록 + M19 추가분)

### 하드웨어 / 부팅 / 커널 코어 / 파일시스템 / 네트워킹(평문) / GUI / 애플리케이션 / API 계층
(M18 문서와 동일 — 전부 그대로 유지되고 회귀 없음. Milestone 19 종료 시점에 전체 재확인 완료.)

### Milestone 19 신규
- **키보드 포커스 일반화**: 클릭하거나 새로 연 창이 자동으로 키 입력을 받는다. 여러 텍스트
  입력 창(jash, Notepad, 브라우저 주소창)을 자연스럽게 오가며 쓸 수 있다.
- **스크롤 + 위젯 툴킷**: jash 출력창과 브라우저 본문에 스크롤바(PgUp/PgDn 또는 드래그)가
  생겨 과거 출력/긴 페이지를 다시 볼 수 있다. `kernel/gui/widget.c`에 버튼/텍스트박스/스크롤
  텍스트 렌더러가 재사용 가능한 컴포넌트로 분리됨(이전엔 앱마다 직접 그림).
- **유저 포인터 검증**: 시스템콜에 유저 프로세스 영역 밖 포인터를 넘기면 커널이 그 값을
  들여다보지 않고 해당 스레드만 즉시 종료한다(`/test_elf_baduptr`로 부팅마다 자체 검증).
- **HTTPS(TLS 1.2)**: jash `https <host> <port> </path> [save-to]` 명령과 브라우저 주소창에
  `https://` URL을 직접 타이핑해 실제 암호화된 HTTPS GET이 가능하다. RSA 키교환 +
  AES-128-CBC + HMAC-SHA256(TLS_RSA_WITH_AES_128_CBC_SHA256) 단일 스위트만 지원.

---

## 실제로 발견하고 고친 버그 히스토리 (이어서 기록 — M1~18 목록은 이전 문서 참고)

7. **AES-128 키 스케줄 엔디안 버그** (M19): 키 바이트를 `uint8_t*`로 `uint32_t` 배열에 그대로
   복사한 뒤 그 배열을 워드로 재해석했는데, x86이 리틀엔디안이라 FIPS-197이 요구하는
   빅엔디안 워드 조립과 어긋났다. 호스트 하네스 테스트(FIPS-197 공식 벡터 대조)에서
   "암호화↔복호화 라운드트립은 맞는데 공식 벡터와는 다름"이라는 특징적인 증상으로 발견 —
   두 방향이 서로 반대라 자체 일관성은 있지만 진짜 AES와 다른, 케이스로 남겨둘 만한 버그.
   → 키 확장 시 바이트를 명시적 시프트로 빅엔디안 조립하도록 수정.
8. **TLS ClientHello의 signature_algorithms 확장 누락** (M19): 정적 RSA 키교환 스위트는
   ServerKeyExchange 서명이 필요 없어 RFC상 이 확장이 이론적으로는 선택사항이지만, OpenSSL
   3.x 서버는 이게 없으면 `NO_SUITABLE_SIGNATURE_ALGORITHM` 알림(alert)으로 핸드셰이크
   자체를 거부한다. QEMU 부팅 자체 테스트에서 매번 "Alert 수신 → 핸드셰이크 실패"로 재현됐고,
   호스트에서 파이썬으로 원문 ClientHello 바이트를 재생해 정확한 원인을 확인한 뒤
   `rsa_pkcs1_sha256` 하나만 광고하는 signature_algorithms 확장을 추가해 해결.
9. **SNI에 IP 리터럴 사용 시 거부** (M19): 개발 중 자체 테스트에서 SNI 호스트명 자리에
   `"10.0.2.2"` 같은 IP 주소를 그대로 넣었더니 서버가 거부(RFC 6066은 SNI가 호스트명이어야
   한다고 규정, IP 리터럴은 부적절). → 접속 대상이 점으로 구분된 숫자 4개(IP처럼 보이는
   문자열)면 SNI 확장 자체를 생략하도록 jash/browser/자체테스트 모두 수정.

---

## 알려진 한계 / 미완성 (M19 시점)

### 핵심 미완성 (M18에서 이어짐 — 이번에 다룬 항목은 제거됨)
| 항목 | 현황 |
|------|------|
| 프로세스 유저 영역 크기 | 프로세스당 2MiB 고정 (더 큰 프로그램 못 돌림) |
| 동적 링킹 | 없음 — 정적 링크 ELF/PE만 |
| DNS 기능 | A 레코드만, CNAME 체인 추적/캐싱 없음 |
| 동시 Ring3 프로세스 | CR3 전환은 되지만 아직 "많은 수의 동시 프로세스"로 스트레스 테스트는 안 해봄 |
| fork/exec 모델 | 없음 — `elf_execute()`로 "새 스레드에 새 주소공간 붙여서 즉시 실행"만 가능 |

### TLS/HTTPS 관련 한계 (신규, `tls.h`에도 동일하게 문서화됨 — 정직하게 명시)
| 항목 | 현황 |
|------|------|
| 인증서 신뢰 체인 검증 | 없음 — CA 서명/체인을 확인하지 않는다. 자체서명 인증서도 그냥 접속됨 |
| 호스트명 검증 | 없음 — 인증서의 CN/SAN이 접속 대상 host와 일치하는지 확인 안 함 |
| MITM 방어 | 사실상 없음 — "암호화는 되지만 상대가 누군지는 확인 안 하는" 수준 |
| 지원 스위트 | TLS_RSA_WITH_AES_128_CBC_SHA256 단 하나. ECDHE 계열(타원곡선 필요) 미지원 — RSA 키교환을 막아둔 최신 서버(순방향 비밀성 강제)와는 접속 실패 가능 |
| TLS 버전 | 1.2만. 1.3/1.1/1.0/SSL 미지원 |
| 패딩 오라클 방어 | 없음 — CBC 패딩/MAC 검증이 상수시간이 아니다(non-constant-time memcmp 등) |
| RNG 품질 | RDRAND 있으면 하드웨어 난수, 없으면 RTC/PIT/TSC+SHA-256 폴백(암호학적으로 약함, `rng.h`에 명시) — 실제 보안이 중요한 용도에는 RDRAND 없는 환경에서 쓰면 안 됨 |
| 인증서 체인 | 리프 인증서 하나만 파싱 — 중간 CA 체인이 필요한 실제 사이트는 실패할 수 있음 |

### GUI 미완성 (M18에서 이어짐 — 스크롤/위젯 일부는 이번에 해소)
| 항목 | 현황 |
|------|------|
| 복사/붙여넣기 | 없음 |
| 재사용 가능한 위젯 툴킷 | Milestone 19에서 버튼/텍스트박스/스크롤텍스트가 생겼지만, Settings의 색상 스와치 등 기존 앱들은 아직 새 위젯으로 리팩터링되지 않음(신규 코드부터 적용) |
| 확인 대화상자 | Notepad 닫을 때 "저장 안 하고 닫을까요?" 같은 확인창 없음(제목에 `*` 표시만) |
| MessageBox 진짜 모달 | 포커스 잠금 없음 — 떠 있어도 다른 창 조작 가능 |
| 마우스 휠 스크롤 | PS/2 3바이트 패킷(휠 없음)만 지원 — 스크롤은 PgUp/PgDn 또는 스크롤바 드래그로만 가능, 실제 휠 회전으로는 안 됨 |

### 기타
| 항목 | 현황 |
|------|------|
| 오디오 | 드라이버 없음 |
| Win32 API 커버리지 | 일부만, 다수 미구현(호출하면 no-op) |
| PE 로더 | CRT 의존 EXE는 못 돌림 |

---

## 다음에 해야 할 작업 (우선순위 순 제안)

1. **인증서 검증(신뢰 체인 + 호스트명)** — 지금 TLS의 가장 큰 보안 구멍. CA 루트 저장소를
   어떻게 가져올지(하드코딩할 소수의 루트 CA만? 사용자가 추가?)부터 결정 필요.
2. **ECDHE 지원(순방향 비밀성)** — 타원곡선(P-256 등) 스칼라 곱셈 구현 필요. RSA 키교환만
   지원하는 지금 상태로는 이를 막아둔 최신 서버 다수와 접속 불가.
3. **TLS 1.3** — 최신 서버 다수가 1.2를 완전히 끄기 시작하면 결국 필요.
4. **재사용 가능한 위젯 툴킷 전면 적용** — Settings/File Manager 등 기존 앱을
   `kernel/gui/widget.c`로 리팩터링.
5. **유저 영역 확장 가능하게(brk/mmap 계열)** — 지금 2MiB 고정.
6. **fork/exec 계열 프로세스 모델** — 파이프라인/백그라운드 실행 등.
7. **인증서 체인(중간 CA) 파싱** — 리프 하나만 보는 지금 상태로는 체인이 필요한 사이트 실패.
8. **마우스 휠 지원** — PS/2 IntelliMouse 확장(4바이트 패킷) 드라이버.

---

## 참고: 코드 스타일/설계 원칙 (일관성 유지용)

- **어셈블리는 3개 파일에만**: `kernel/hal/x86_asm_shim.h`(포트I/O, 세그먼트, Ring3 진입,
  RDRAND/CPUID/RDTSC 등 단일 명령급), `kernel/hal/context_switch.c`(스레드 전환),
  `kernel/hal/syscall_entry.c`(시스템콜 트램폴린). Milestone 19에서 RDRAND/CPUID/RDTSC를
  추가할 때도 새 어셈블리 파일을 만들지 않고 이 원칙대로 x86_asm_shim.h에 넣었다.
  그 외는 100% C(필요시 C++/Rust도 허용됨 — 사용자 승인됨, 아직 실제로 쓰진 않음).
- **모든 새 서브시스템은 "부팅 시 자체 테스트"를 kernel_entry.c에 추가**해서, 이미지를 새로
  빌드할 때마다 회귀 여부를 시리얼 로그로 바로 확인할 수 있게 한다(NET/TCP/DNS/RING3/
  유저포인터검증/TLS 자체 테스트가 그 예).
- **암호/프로토콜 코드는 호스트 하네스 테스트를 먼저**: 표준 벡터(NIST/RFC)나 openssl로
  만든 실제 데이터와 대조 검증한 뒤에야 커널에 통합한다 — Milestone 19에서 이 순서 덕분에
  AES 엔디안 버그를 QEMU 디버깅 없이 훨씬 빠르게 잡았다.
- **use-after-free 패턴 주의**: 파일 파서(PE/ELF)에서 `kfree(buf)` 직후 `buf` 내부를
  가리키던 포인터를 쓰지 않는지 항상 재확인할 것 — 이미 2번 발생한 실수 유형.
- **알려진 단순화는 코드 주석에 명시적으로 문서화**하는 관례를 유지한다(왜 단순화했는지,
  다음에 뭘 해야 완전해지는지). TLS의 "인증서 검증 안 함" 같은 보안상 중요한 단순화는
  특히 헤더 파일 최상단에 눈에 띄게 적어둔다.
