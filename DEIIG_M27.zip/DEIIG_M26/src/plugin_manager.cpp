#include "plugin_manager.hpp"
#include <algorithm>
#include <cctype>
#include <cstring>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <utility>

#ifdef _WIN32
#include <windows.h>
#else
#include <dlfcn.h>
#endif

namespace fs = std::filesystem;

struct DeiigPluginHost { void* impl = nullptr; };

namespace deiig {

struct CommandEntry {
    std::string description;
    DeiigCommandHandler handler = nullptr;
    void* user_data = nullptr;
};

struct LoadedPlugin {
#ifdef _WIN32
    HMODULE handle = nullptr;
#else
    void* handle = nullptr;
#endif
    PluginInfo info;
    DeiigPluginApi api{};
    DeiigPluginShutdownFn shutdown = nullptr;
};

struct PluginManager::Impl {
    fs::path project_dir;
    std::vector<PluginInfo> discovered;
    std::vector<LoadedPlugin> loaded;
    std::unordered_map<std::string, CommandEntry> commands;
    DeiigPluginHost host{nullptr};
    void (*log_fn)(const std::string&) = nullptr;
};

static void host_register(DeiigPluginHost* host, const char* name, const char* description,
                          DeiigCommandHandler handler, void* user_data) {
    if (!host || !host->impl || !name || !*name || !handler) return;
    auto* manager = static_cast<PluginManager::Impl*>(host->impl);
    auto* impl = manager;
    impl->commands[name] = CommandEntry{description ? description : "", handler, user_data};
}

static void host_log(DeiigPluginHost* host, const char* message) {
    if (!host || !host->impl) return;
    auto* impl = static_cast<PluginManager::Impl*>(host->impl);
    if (impl->log_fn) impl->log_fn(message ? message : "");
}

static std::vector<std::string> split_args(const std::string& line) {
    std::vector<std::string> out;
    std::string cur;
    bool quote = false;
    char quote_char = 0;
    for (size_t i = 0; i < line.size(); ++i) {
        char c = line[i];
        if (quote) {
            if (c == quote_char) quote = false;
            else if (c == '\\' && i + 1 < line.size()) cur += line[++i];
            else cur += c;
        } else if (c == '\'' || c == '"') {
            quote = true; quote_char = c;
        } else if (std::isspace(static_cast<unsigned char>(c))) {
            if (!cur.empty()) { out.push_back(cur); cur.clear(); }
        } else cur += c;
    }
    if (!cur.empty()) out.push_back(cur);
    return out;
}

static bool extension_is_plugin(const fs::path& p) {
#ifdef _WIN32
    return p.extension() == L".dll";
#else
    return p.extension() == L".so" || p.extension() == L".dylib";
#endif
}

PluginManager::PluginManager() : impl_(new Impl) { impl_->host.impl = impl_; }

PluginManager::~PluginManager() {
    DeiigPluginApi api{};
    api.api_version = DEIIG_PLUGIN_API_VERSION;
    api.host = &impl_->host;
    api.register_command = &host_register;
    api.log = &host_log;
    for (auto it = impl_->loaded.rbegin(); it != impl_->loaded.rend(); ++it) {
        if (it->shutdown) it->shutdown(&api);
#ifdef _WIN32
        if (it->handle) FreeLibrary(it->handle);
#else
        if (it->handle) dlclose(it->handle);
#endif
    }
    delete impl_;
}

void PluginManager::set_project_dir(const fs::path& path) { impl_->project_dir = path; }
void PluginManager::set_log(void (*fn)(const std::string&)) { impl_->log_fn = fn; }
fs::path PluginManager::project_plugin_dir() const { return impl_->project_dir / ".deiig" / "plugins"; }

void PluginManager::discover() {
    impl_->discovered.clear();
    std::vector<fs::path> dirs;
    if (!impl_->project_dir.empty()) dirs.push_back(project_plugin_dir());
#ifndef _WIN32
    if (const char* home = std::getenv("HOME")) dirs.push_back(fs::path(home) / ".deiig" / "plugins");
#else
    if (const char* app = std::getenv("APPDATA")) dirs.push_back(fs::path(app) / "DEIIG" / "plugins");
#endif
    for (const auto& dir : dirs) {
        std::error_code ec;
        if (!fs::is_directory(dir, ec)) continue;
        for (const auto& e : fs::directory_iterator(dir, fs::directory_options::skip_permission_denied, ec)) {
            if (e.is_regular_file(ec) && extension_is_plugin(e.path())) {
                impl_->discovered.push_back(PluginInfo{e.path(), e.path().stem().string(), "", false});
            }
        }
    }
    std::sort(impl_->discovered.begin(), impl_->discovered.end(), [](const auto& a, const auto& b) { return a.path < b.path; });
}

bool PluginManager::load_file(const fs::path& path) {
    if (!fs::exists(path)) return false;
#ifdef _WIN32
    HMODULE handle = LoadLibraryW(path.wstring().c_str());
    if (!handle) return false;
    auto init = reinterpret_cast<DeiigPluginInitFn>(GetProcAddress(handle, "deiig_plugin_init"));
    auto shutdown = reinterpret_cast<DeiigPluginShutdownFn>(GetProcAddress(handle, "deiig_plugin_shutdown"));
#else
    void* handle = dlopen(path.c_str(), RTLD_NOW | RTLD_LOCAL);
    if (!handle) return false;
    auto init = reinterpret_cast<DeiigPluginInitFn>(dlsym(handle, "deiig_plugin_init"));
    auto shutdown = reinterpret_cast<DeiigPluginShutdownFn>(dlsym(handle, "deiig_plugin_shutdown"));
#endif
    if (!init) {
#ifdef _WIN32
        FreeLibrary(handle);
#else
        dlclose(handle);
#endif
        return false;
    }
    LoadedPlugin lp{};
    lp.handle = handle;
    lp.info.path = path;
    lp.info.name = path.stem().string();
    lp.api.api_version = DEIIG_PLUGIN_API_VERSION;
    lp.api.host = &impl_->host;
    lp.api.register_command = &host_register;
    lp.api.log = &host_log;
    lp.shutdown = shutdown;
    const char* result = init(&lp.api);
    if (!result) {
#ifdef _WIN32
        FreeLibrary(handle);
#else
        dlclose(handle);
#endif
        return false;
    }
    lp.info.name = result;
    lp.info.loaded = true;
    impl_->loaded.push_back(std::move(lp));
    for (auto& p : impl_->discovered) if (p.path == path) { p.loaded = true; p.name = result; }
    return true;
}

bool PluginManager::load_all() {
    discover();
    bool ok = true;
    for (const auto& p : impl_->discovered) {
        if (!p.loaded && !load_file(p.path)) {
            ok = false;
            if (impl_->log_fn) impl_->log_fn("Failed to load plugin: " + p.path.string());
        }
    }
    return ok;
}

std::vector<PluginInfo> PluginManager::list() const {
    auto out = impl_->discovered;
    for (auto& p : out) {
        for (const auto& l : impl_->loaded) if (l.info.path == p.path) { p = l.info; break; }
    }
    return out;
}

bool PluginManager::has_command(const std::string& name) const {
    return impl_->commands.find(name) != impl_->commands.end();
}

std::vector<std::string> PluginManager::commands() const {
    std::vector<std::string> out;
    for (const auto& [name, _] : impl_->commands) out.push_back(name);
    std::sort(out.begin(), out.end());
    return out;
}

int PluginManager::invoke(const std::string& command_line) {
    const auto args = split_args(command_line);
    if (args.empty()) return 0;
    auto it = impl_->commands.find(args[0]);
    if (it == impl_->commands.end()) return 127;
    std::vector<const char*> argv;
    argv.reserve(args.size());
    for (const auto& a : args) argv.push_back(a.c_str());
    return it->second.handler(static_cast<int>(argv.size()), argv.data(), it->second.user_data);
}

} // namespace deiig
