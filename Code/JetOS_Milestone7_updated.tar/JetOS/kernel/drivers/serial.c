/*
 * JetOS - kernel/drivers/serial.c
 * COM1 (0x3F8) 16550 UART 시리얼 로깅 드라이버.
 * QEMU에서 -serial stdio 옵션으로 호스트 터미널에 커널 로그가 출력된다.
 */

#include "serial.h"
#include "../hal/x86_asm_shim.h"

#define COM1 0x3F8

void serial_init(void) {
    hal_outb(COM1 + 1, 0x00);    /* 인터럽트 비활성화 */
    hal_outb(COM1 + 3, 0x80);    /* DLAB 설정 (baud rate divisor 접근) */
    hal_outb(COM1 + 0, 0x03);    /* divisor low byte  -> 38400 baud */
    hal_outb(COM1 + 1, 0x00);    /* divisor high byte */
    hal_outb(COM1 + 3, 0x03);    /* 8비트, 패리티 없음, 스톱비트 1 */
    hal_outb(COM1 + 2, 0xC7);    /* FIFO 활성화, 클리어, 14바이트 임계값 */
    hal_outb(COM1 + 4, 0x0B);    /* IRQ 활성화, RTS/DSR 설정 */
}

static int serial_tx_empty(void) {
    return hal_inb(COM1 + 5) & 0x20;
}

void serial_putc(char c) {
    if (c == '\n') serial_putc('\r');
    while (!serial_tx_empty()) { }
    hal_outb(COM1, (uint8_t)c);
}

void serial_write(const char *s) {
    while (*s) {
        serial_putc(*s++);
    }
}

void serial_write_hex64(uint64_t v) {
    const char *digits = "0123456789ABCDEF";
    char buf[19];
    buf[0] = '0'; buf[1] = 'x';
    for (int i = 0; i < 16; i++) {
        buf[2 + i] = digits[(v >> ((15 - i) * 4)) & 0xF];
    }
    buf[18] = '\0';
    serial_write(buf);
}
