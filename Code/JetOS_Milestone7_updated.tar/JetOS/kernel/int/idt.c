/*
 * JetOS - kernel/int/idt.c
 * IDT(Interrupt Descriptor Table) 구성. 개별 예외 핸들러 본문은 순수 C
 * (GCC __attribute__((interrupt)))로 작성되며, IDT 레지스터를 CPU에
 * 적재하는 LIDT 명령 한 줄만 hal/x86_asm_shim.h 를 통해 실행한다.
 */

#include "idt.h"
#include "../hal/x86_asm_shim.h"
#include "exceptions.h"

static idt_entry_t g_idt[256];

void idt_set_gate(int vector, void *handler, uint8_t ist, uint8_t type_attr) {
    uint64_t addr = (uint64_t)handler;
    g_idt[vector].offset_low  = (uint16_t)(addr & 0xFFFF);
    g_idt[vector].selector    = hal_read_cs();
    g_idt[vector].ist         = ist & 0x7;
    g_idt[vector].type_attr   = type_attr;
    g_idt[vector].offset_mid  = (uint16_t)((addr >> 16) & 0xFFFF);
    g_idt[vector].offset_high = (uint32_t)((addr >> 32) & 0xFFFFFFFF);
    g_idt[vector].zero        = 0;
}

#define GATE_PRESENT_INTR64 0x8E

void idt_init(void) {
    for (int i = 0; i < 256; i++) {
        idt_set_gate(i, (void *)isr_default_handler, 0, GATE_PRESENT_INTR64);
    }

    idt_set_gate(0,  (void *)isr_divide_by_zero,   0, GATE_PRESENT_INTR64);
    idt_set_gate(3,  (void *)isr_breakpoint,       0, GATE_PRESENT_INTR64);
    idt_set_gate(6,  (void *)isr_invalid_opcode,   0, GATE_PRESENT_INTR64);
    idt_set_gate(8,  (void *)isr_double_fault,     0, GATE_PRESENT_INTR64);
    idt_set_gate(13, (void *)isr_general_protection, 0, GATE_PRESENT_INTR64);
    idt_set_gate(14, (void *)isr_page_fault,       0, GATE_PRESENT_INTR64);
    idt_set_gate(32, (void *)isr_timer,            0, GATE_PRESENT_INTR64); /* IRQ0 (PIC 리맵 후) */
    idt_set_gate(33, (void *)isr_keyboard,         0, GATE_PRESENT_INTR64); /* IRQ1 */
    idt_set_gate(44, (void *)isr_mouse,            0, GATE_PRESENT_INTR64); /* IRQ12 */

    struct hal_idt_ptr ptr;
    ptr.limit = sizeof(g_idt) - 1;
    ptr.base  = (uint64_t)&g_idt[0];
    hal_lidt(&ptr);
}
