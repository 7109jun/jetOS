#ifndef JETOS_THEME_H
#define JETOS_THEME_H

#include <stdint.h>

/* JetOS 디자인 시스템
 * Windows와 "동일하게 보이지는 않지만 즉시 익숙한" 비주얼 언어.
 * 목표: 어두운 배경 + 차분한 액센트 컬러 + 명확한 계층 구조 */

#define THEME_DESKTOP_BG      0x00101820  /* 매우 어두운 청회색 */
#define THEME_TASKBAR_BG      0x00141C28  /* 작업표시줄 */
#define THEME_TASKBAR_BORDER  0x00243040  /* 작업표시줄 상단 선 */

/* 창 */
#define THEME_WIN_TITLE_ACTIVE    0x00243858  /* 활성 타이틀바 */
#define THEME_WIN_TITLE_INACTIVE  0x001A2432  /* 비활성 타이틀바 */
#define THEME_WIN_TITLE_TEXT      0x00E8F0F8  /* 타이틀바 텍스트 */
#define THEME_WIN_BORDER          0x00304858  /* 창 테두리 */
#define THEME_WIN_CLIENT          0x001A2230  /* 창 본문 배경 */

/* 시작 버튼 */
#define THEME_START_NORMAL        0x00243060
#define THEME_START_TEXT          0x00C8D8F8

/* 시작 메뉴 */
#define THEME_MENU_BG             0x00182030
#define THEME_MENU_ITEM_HOVER     0x00304060
#define THEME_MENU_TEXT           0x00D8E8F8
#define THEME_MENU_SEPARATOR      0x00283848

/* 텍스트 */
#define THEME_TEXT_PRIMARY        0x00E0ECFA
#define THEME_TEXT_SECONDARY      0x0090A8C0
#define THEME_TEXT_HIGHLIGHT      0x0060C0FF

/* 강조색 */
#define THEME_ACCENT_BLUE         0x003070C0
#define THEME_ACCENT_HOVER        0x004090E0

/* 커서 */
#define THEME_CURSOR_COLOR        0x00F0F8FF

/* 작업표시줄 버튼 (창 목록) */
#define THEME_TASKBAR_BTN_NORMAL  0x001C2840
#define THEME_TASKBAR_BTN_ACTIVE  0x00304868

#endif
