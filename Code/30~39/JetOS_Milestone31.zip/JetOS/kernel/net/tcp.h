#ifndef JETOS_TCP_H
#define JETOS_TCP_H

#include <stdint.h>

/*
 * JetOS - kernel/net/tcp.h
 *
 * Milestone 11: 최소 TCP 클라이언트 구현.
 *
 * 알려진 단순화(자유 OS 개발 문서에 늘 있는 종류의 것들):
 *   - 동시에 하나의 연결만 지원한다 (전역 상태 하나).
 *   - 재전송 타이머/혼잡 제어 없음 — 각 세그먼트를 보내고 ACK를
 *     기다리다 타임아웃되면 그냥 실패로 친다(정지-대기, 재시도 없음).
 *   - 들어오는 세그먼트가 기대한 seq와 다르면(순서가 어긋나면) 그냥
 *     버린다 — 재조립 큐가 없다. 지연이 적은 로컬/가상 네트워크에서는
 *     실질적으로 문제되지 않지만, 실제 인터넷 장거리 구간에서는 손실이
 *     생기면 멈출 수 있다.
 *   - 우리가 먼저 연결을 여는 클라이언트 역할만 지원 (리슨 없음).
 *
 * 이 정도로도 HTTP/1.0 GET 요청-응답 하나를 주고받기엔 충분하다.
 */

int tcp_connect(uint32_t dst_ip, uint16_t dst_port, uint32_t timeout_ticks);
int tcp_send(const void *data, uint32_t len, uint32_t timeout_ticks);

/* 연결이 끊길 때까지(FIN 수신) 계속 받아서 buf에 채운다.
 * 반환값: 실제로 받은 바이트 수(버퍼가 꽉 차거나 FIN을 받으면 멈춤). */
uint32_t tcp_recv_until_close(void *buf, uint32_t buf_size, uint32_t timeout_ticks);

/* 정확히 want_len 바이트가 모일 때까지 기다린다(연결은 유지). TLS 등
 * "받고 나서도 같은 연결로 계속 주고받는" 프로토콜용. 반환값은 실제로
 * 받은 바이트 수 — want_len보다 작으면 FIN/RST/타임아웃으로 못 채운
 * 것이니 호출측이 판단해야 한다. */
uint32_t tcp_recv_exact(void *buf, uint32_t want_len, uint32_t timeout_ticks);

void tcp_close(void);

#endif
