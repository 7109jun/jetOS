/*
 * JetOS - kernel/apps/file_manager.c
 * JetAPI만 사용해 작성된 첫 "진짜" 애플리케이션. 커널 내부 구조체를
 * 전혀 알지 못하며, CreateWindowJ / ListDirectoryJ 만으로 동작한다.
 */

#include <stddef.h>
#include "file_manager.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../drivers/console.h"
#include "../proc/scheduler.h"

typedef struct {
    console_t *dc;
    int x, y;
} fm_draw_ctx_t;

static void fm_entry_cb(const char *name, int is_dir, uint32_t size, void *ctx) {
    fm_draw_ctx_t *d = (fm_draw_ctx_t *)ctx;
    d->dc->cursor_x = (uint32_t)d->x;
    d->dc->cursor_y = (uint32_t)d->y;
    console_print(d->dc, is_dir ? "DIR " : "FILE ");
    console_print(d->dc, name);
    (void)size;
    d->y += 14;
}

static void file_manager_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)h; (void)ctx;
    fm_draw_ctx_t d = { dc, x + 8, y + 8 };
    if (!ListDirectoryJ(":>/", fm_entry_cb, &d)) {
        dc->cursor_x = (uint32_t)(x + 8);
        dc->cursor_y = (uint32_t)(y + 8);
        console_print(dc, "NO JETFS VOLUME MOUNTED");
    }
}

static volatile int g_fm_running = 0;

static void file_manager_on_close(void *ctx) {
    (void)ctx;
    g_fm_running = 0;
}

static void file_manager_thread_fn(void *arg) {
    (void)arg;
    g_fm_running = 1;
    JetWindowHandle win = CreateWindowJ("FILE MANAGER", 620, 60, 260, 160, 0x00304030);
    if (win >= 0) {
        wm_set_content_callback(win, file_manager_content_cb, NULL);
        wm_set_close_callback(win, file_manager_on_close, NULL);
    }
    while (g_fm_running) {
        scheduler_yield();
    }
}

void file_manager_launch(void) {
    static int launched = 0;
    if (launched && g_fm_running) return;
    launched = 1;
    CreateThreadJ("file_manager", file_manager_thread_fn, NULL);
}
