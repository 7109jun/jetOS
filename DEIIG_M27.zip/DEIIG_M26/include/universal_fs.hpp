#pragma once

#include <cstddef>
#include <filesystem>
#include <string>
#include <vector>

namespace deiig::ufs {

enum class Kind {
    Unknown,
    Text,
    Source,
    Json,
    Markdown,
    Image,
    Archive,
    Executable,
    Database,
    DiggCode,
    Binary
};

struct Info {
    std::filesystem::path path;
    std::string name;
    std::string extension;
    std::string mime;
    Kind kind = Kind::Unknown;
    std::uintmax_t size = 0;
    bool regular = false;
    bool directory = false;
    bool readable_text = false;
};

std::string kind_name(Kind kind);
std::string mime_type(Kind kind);
Info inspect(const std::filesystem::path& path);
std::string hex_dump(const std::filesystem::path& path, std::size_t max_bytes = 256);
std::string preview_text(const std::filesystem::path& path, std::size_t max_bytes = 8192);
std::vector<std::filesystem::path> related_files(const std::filesystem::path& path);
bool is_probably_text(const std::filesystem::path& path, std::size_t sample_bytes = 4096);

} // namespace deiig::ufs
