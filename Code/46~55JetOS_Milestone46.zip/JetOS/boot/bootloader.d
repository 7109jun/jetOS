boot/bootloader.o: boot/bootloader.c boot/../include/efi/efi.h \
 boot/../include/jetos/boot_info.h boot/../include/jetos/../efi/efi.h \
 boot/elf_loader.h
boot/../include/efi/efi.h:
boot/../include/jetos/boot_info.h:
boot/../include/jetos/../efi/efi.h:
boot/elf_loader.h:
