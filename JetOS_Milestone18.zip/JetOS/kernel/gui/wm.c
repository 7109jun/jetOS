/*
 * JetOS - kernel/gui/wm.c
 * 윈도우 매니저 + 렌더러. Milestone 7에서 디자인 시스템을 전면 적용해
 * 더 Windows답게 느껴지는 비주얼로 개선했다.
 */

#include "wm.h"
#include "theme.h"
#include "../mm/heap.h"
#include "../int/pit.h"
#include "../drivers/rtc.h"
#include <stddef.h>

#define START_MENU_ITEMS 7
static const char *START_MENU_LABELS[START_MENU_ITEMS] = {
    "File Manager", "Terminal", "Settings", "Task Manager", "Clock", "Browser", "Shutdown"
};

static console_t *g_front = NULL;
static console_t g_back;
static console_t *g_con = NULL;

static wm_window_t g_windows[WM_MAX_WINDOWS];
static int g_order[WM_MAX_WINDOWS];
static int g_window_count = 0;
static int g_focused_idx = -1;

static int g_cursor_x = 0, g_cursor_y = 0;
static int g_start_menu_open = 0;

/* 우클릭 컨텍스트 메뉴 상태 */
static int g_ctx_menu_open = 0;
static int g_ctx_menu_x = 0, g_ctx_menu_y = 0;
static int g_ctx_menu_target = -1; /* -1 = 데스크톱 메뉴, 그 외 = 창 idx */
#define CTX_MENU_W 130
#define DESKTOP_CTX_ITEMS 6  /* File Manager / Terminal / Settings / Task Manager / Clock / Browser */
#define WINDOW_CTX_ITEMS 2   /* Close / Minimize|Restore */

#define START_BTN_W 80
#define MENU_ITEM_H 22
#define TASKBAR_LABEL_W 130
#define BORDER_SZ 2

void wm_init(console_t *con) {
    g_front = con;
    uint32_t *backbuf = (uint32_t *)kmalloc((size_t)con->width * con->height * 4);
    console_init(&g_back, backbuf, con->width, con->height, con->width);
    g_con = &g_back;
    g_window_count = 0;
    g_focused_idx = -1;
    for (int i = 0; i < WM_MAX_WINDOWS; i++) { g_windows[i].used = 0; g_order[i] = -1; }
    g_cursor_x = (int)con->width / 2;
    g_cursor_y = (int)con->height / 2;
    g_start_menu_open = 0;
    g_ctx_menu_open = 0;
    g_ctx_menu_target = -1;
}

int wm_create_window(const char *title, int x, int y, int w, int h, uint32_t color) {
    if (g_window_count >= WM_MAX_WINDOWS) return -1;
    int idx = g_window_count++;
    wm_window_t *win = &g_windows[idx];
    win->x = x; win->y = y; win->w = w; win->h = h;
    win->color = color;
    win->visible = 1;
    win->minimized = 0;
    win->closed = 0;
    win->used = 1;
    win->content_cb = NULL;
    win->content_ctx = NULL;
    win->close_cb = NULL;
    win->close_ctx = NULL;
    win->click_cb = NULL;
    win->click_ctx = NULL;
    win->win32_style = 0;
    int i = 0;
    for (; i < 31 && title[i]; i++) win->title[i] = title[i];
    win->title[i] = '\0';
    g_order[idx] = idx;
    g_focused_idx = idx;
    return idx;
}

void wm_bring_to_front(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    int pos = -1;
    for (int i = 0; i < g_window_count; i++) if (g_order[i] == idx) { pos = i; break; }
    if (pos < 0) return;
    for (int i = pos; i < g_window_count - 1; i++) g_order[i] = g_order[i + 1];
    g_order[g_window_count - 1] = idx;
    g_focused_idx = idx;
}

void wm_move_window(int idx, int dx, int dy) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].x += dx;
    g_windows[idx].y += dy;
}

#define WM_MIN_WIDTH 140
#define WM_MIN_HEIGHT 80

void wm_resize_window(int idx, int dw, int dh) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    int nw = w->w + dw;
    int nh = w->h + dh;
    if (nw < WM_MIN_WIDTH) nw = WM_MIN_WIDTH;
    if (nh < WM_MIN_HEIGHT) nh = WM_MIN_HEIGHT;
    if (g_con) {
        if ((uint32_t)(w->x + nw) > g_con->width) nw = (int)g_con->width - w->x;
        if ((uint32_t)(w->y + WM_TITLEBAR_H + nh) > g_con->height - WM_TASKBAR_H)
            nh = (int)(g_con->height - WM_TASKBAR_H) - w->y - WM_TITLEBAR_H;
    }
    w->w = nw;
    w->h = nh;
}

int wm_hit_resize_handle(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    int hx = w->x + w->w - 10;
    int hy = w->y + WM_TITLEBAR_H + w->h - 10;
    return (x >= hx && x < hx + 10 && y >= hy && y < hy + 10);
}

int wm_window_at(int x, int y) {
    for (int i = g_window_count - 1; i >= 0; i--) {
        int idx = g_order[i];
        wm_window_t *w = &g_windows[idx];
        if (!w->visible || w->minimized || w->closed) continue;
        if (x >= w->x - BORDER_SZ && x < w->x + w->w + BORDER_SZ &&
            y >= w->y && y < w->y + w->h + WM_TITLEBAR_H) {
            return idx;
        }
    }
    return -1;
}

int wm_hit_titlebar(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    return (x >= w->x && x < w->x + w->w && y >= w->y && y < w->y + WM_TITLEBAR_H);
}

int wm_hit_close_button(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    int bx = w->x + w->w - 18;
    int by = w->y + 3;
    return (x >= bx && x < bx + 14 && y >= by && y < by + 12);
}

int wm_hit_maximize_button(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    int bx = w->x + w->w - 18 - 16;
    int by = w->y + 3;
    return (x >= bx && x < bx + 14 && y >= by && y < by + 12);
}

int wm_hit_minimize_button(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    int bx = w->x + w->w - 18 - 32;
    int by = w->y + 3;
    return (x >= bx && x < bx + 14 && y >= by && y < by + 12);
}

void wm_toggle_maximize(int idx) {
    if (idx < 0 || idx >= g_window_count || !g_con) return;
    wm_window_t *w = &g_windows[idx];
    if (w->maximized) {
        w->x = w->saved_x; w->y = w->saved_y; w->w = w->saved_w; w->h = w->saved_h;
        w->maximized = 0;
    } else {
        w->saved_x = w->x; w->saved_y = w->y; w->saved_w = w->w; w->saved_h = w->h;
        w->x = 4; w->y = 4;
        w->w = (int)g_con->width - 8;
        w->h = (int)(g_con->height - WM_TASKBAR_H) - WM_TITLEBAR_H - 8;
        w->maximized = 1;
    }
}

void wm_close_window(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    if (w->closed) return;
    w->visible = 0;
    w->minimized = 0;
    w->closed = 1;
    if (w->close_cb) w->close_cb(w->close_ctx);
    if (g_focused_idx == idx) {
        g_focused_idx = -1;
        for (int i = g_window_count - 1; i >= 0; i--) {
            int oi = g_order[i];
            if (!g_windows[oi].closed) { g_focused_idx = oi; break; }
        }
    }
}

void wm_minimize_window(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    if (w->closed) return;
    w->minimized = 1;
    w->visible = 0;
    if (g_focused_idx == idx) {
        g_focused_idx = -1;
        for (int i = g_window_count - 1; i >= 0; i--) {
            int oi = g_order[i];
            if (!g_windows[oi].closed && !g_windows[oi].minimized) { g_focused_idx = oi; break; }
        }
    }
}

void wm_restore_window(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    if (w->closed) return;
    w->minimized = 0;
    w->visible = 1;
    wm_bring_to_front(idx);
}

int wm_is_window_minimized(int idx) {
    if (idx < 0 || idx >= g_window_count) return 0;
    return g_windows[idx].minimized;
}

int wm_hit_taskbar_window_button(int x, int y) {
    if (!g_con) return -1;
    int tbY = (int)g_con->height - WM_TASKBAR_H;
    if (y < tbY + 2 || y >= tbY + WM_TASKBAR_H - 2) return -1;
    int tx = START_BTN_W + 4;
    for (int i = 0; i < g_window_count; i++) {
        int idx = g_order[i];
        wm_window_t *w = &g_windows[idx];
        if (w->closed) continue;
        if (x >= tx && x < tx + TASKBAR_LABEL_W - 4) return idx;
        tx += TASKBAR_LABEL_W;
    }
    return -1;
}

void wm_get_window_bounds(int idx, int *x, int *y, int *w, int *h) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *win = &g_windows[idx];
    if (x) *x = win->x;
    if (y) *y = win->y;
    if (w) *w = win->w;
    if (h) *h = win->h;
}

void wm_set_content_callback(int idx, wm_content_draw_fn cb, void *ctx) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].content_cb = cb;
    g_windows[idx].content_ctx = ctx;
}

void wm_set_close_callback(int idx, wm_close_fn cb, void *ctx) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].close_cb = cb;
    g_windows[idx].close_ctx = ctx;
}

void wm_set_click_callback(int idx, wm_click_fn cb, void *ctx) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].click_cb = cb;
    g_windows[idx].click_ctx = ctx;
}

int wm_dispatch_click(int screen_x, int screen_y) {
    int idx = wm_window_at(screen_x, screen_y);
    if (idx < 0) return 0;
    wm_window_t *w = &g_windows[idx];
    if (!w->click_cb) return 0;
    int content_y0 = w->y + WM_TITLEBAR_H;
    if (screen_x < w->x || screen_x >= w->x + w->w) return 0;
    if (screen_y < content_y0 || screen_y >= content_y0 + w->h) return 0;
    w->click_cb(screen_x - w->x, screen_y - content_y0, w->click_ctx);
    return 1;
}

void wm_set_win32_style(int idx, int enabled) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].win32_style = enabled;
}

void wm_set_title(int idx, const char *title) {
    if (idx < 0 || idx >= g_window_count || !title) return;
    int i = 0;
    for (; title[i] && i < (int)sizeof(g_windows[idx].title) - 1; i++) {
        g_windows[idx].title[i] = title[i];
    }
    g_windows[idx].title[i] = '\0';
}

void wm_set_cursor(int x, int y) {
    if (!g_con) return;
    if (x < 0) x = 0; if (y < 0) y = 0;
    if (x >= (int)g_con->width) x = (int)g_con->width - 1;
    if (y >= (int)g_con->height) y = (int)g_con->height - 1;
    g_cursor_x = x; g_cursor_y = y;
}

void wm_get_cursor(int *x, int *y) {
    if (x) *x = g_cursor_x;
    if (y) *y = g_cursor_y;
}

void wm_set_start_menu_open(int open) { g_start_menu_open = open; }

int wm_is_start_button_hit(int x, int y) {
    if (!g_con) return 0;
    int ty = (int)g_con->height - WM_TASKBAR_H;
    return (x >= 0 && x < START_BTN_W && y >= ty && y < (int)g_con->height);
}

int wm_is_start_menu_item_hit(int x, int y, int *out_item_index) {
    if (!g_con || !g_start_menu_open) return 0;
    int ty = (int)g_con->height - WM_TASKBAR_H;
    int menu_h = START_MENU_ITEMS * MENU_ITEM_H + 4;
    int menu_y = ty - menu_h;
    if (x < 0 || x >= START_BTN_W + 80) return 0;
    if (y < menu_y || y >= ty) return 0;
    int item = (y - menu_y - 2) / MENU_ITEM_H;
    if (item < 0 || item >= START_MENU_ITEMS) return 0;
    if (out_item_index) *out_item_index = item;
    return 1;
}

/* ---- 우클릭 컨텍스트 메뉴 ---- */
static int ctx_menu_item_count(void) {
    return (g_ctx_menu_target == -1) ? DESKTOP_CTX_ITEMS : WINDOW_CTX_ITEMS;
}

void wm_open_context_menu(int x, int y, int window_idx) {
    if (!g_con) return;
    g_ctx_menu_open = 1;
    g_ctx_menu_target = window_idx;
    g_ctx_menu_x = x;
    g_ctx_menu_y = y;
    /* 화면 밖으로 나가지 않도록 보정 */
    int menu_h = ctx_menu_item_count() * MENU_ITEM_H + 4;
    if (g_ctx_menu_x + CTX_MENU_W > (int)g_con->width) g_ctx_menu_x = (int)g_con->width - CTX_MENU_W;
    if (g_ctx_menu_y + menu_h > (int)g_con->height - WM_TASKBAR_H)
        g_ctx_menu_y = (int)g_con->height - WM_TASKBAR_H - menu_h;
    if (g_ctx_menu_x < 0) g_ctx_menu_x = 0;
    if (g_ctx_menu_y < 0) g_ctx_menu_y = 0;
    g_start_menu_open = 0;
}

void wm_close_context_menu(void) { g_ctx_menu_open = 0; g_ctx_menu_target = -1; }
int  wm_is_context_menu_open(void) { return g_ctx_menu_open; }
int  wm_context_menu_target(void) { return g_ctx_menu_target; }

int wm_hit_context_menu(int x, int y) {
    if (!g_ctx_menu_open) return 0;
    int menu_h = ctx_menu_item_count() * MENU_ITEM_H + 4;
    return (x >= g_ctx_menu_x && x < g_ctx_menu_x + CTX_MENU_W &&
            y >= g_ctx_menu_y && y < g_ctx_menu_y + menu_h);
}

int wm_hit_context_menu_item(int x, int y, int *out_item_index) {
    if (!wm_hit_context_menu(x, y)) return 0;
    int item = (y - g_ctx_menu_y - 2) / MENU_ITEM_H;
    int n = ctx_menu_item_count();
    if (item < 0 || item >= n) return 0;
    if (out_item_index) *out_item_index = item;
    return 1;
}

/* ---- 렌더링 헬퍼 ---- */
static void fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint32_t c) {
    console_fill_rect(g_con, x, y, w, h, c);
}

static void hline(int x, int y, int w, uint32_t c) {
    if (y < 0 || y >= (int)g_con->height) return;
    for (int i = 0; i < w; i++) {
        if (x + i >= 0 && x + i < (int)g_con->width)
            console_put_pixel(g_con, (uint32_t)(x + i), (uint32_t)y, c);
    }
}

static void vline(int x, int y, int h, uint32_t c) {
    if (x < 0 || x >= (int)g_con->width) return;
    for (int i = 0; i < h; i++) {
        if (y + i >= 0 && y + i < (int)g_con->height)
            console_put_pixel(g_con, (uint32_t)x, (uint32_t)(y + i), c);
    }
}

static void draw_text(int x, int y, const char *s, uint32_t color) {
    if (!s || !g_con) return;
    g_con->cursor_x = (uint32_t)x;
    g_con->cursor_y = (uint32_t)y;
    uint32_t saved = g_con->fg_color;
    g_con->fg_color = color;
    console_print(g_con, s);
    g_con->fg_color = saved;
}

/* Milestone 17: 단색 배경 대신 세로 그라디언트 벽지. 2픽셀 밴드로
 * 그려서(fill 호출 수를 줄여) 매 프레임 다시 그려도 가볍다. */
static void draw_wallpaper(void) {
    uint32_t w = g_con->width, h = g_con->height;
    if (h == 0) return;
    for (uint32_t y = 0; y < h; y += 2) {
        uint32_t t = (y * 28) / h; /* 0~28 정도의 밝기 변화 */
        uint32_t r = 0x08 + t / 3;
        uint32_t g = 0x0E + t / 3;
        uint32_t b = 0x18 + t;
        uint32_t color = (r << 16) | (g << 8) | b;
        fill(0, y, w, 2, color);
    }
}

/* ---- 데스크톱 아이콘 (Milestone 17) ---- */
#define DESKTOP_ICON_COUNT 6
#define ICON_CELL_H 68
#define ICON_BOX 32
#define ICON_X 20

typedef struct { const char *label; int kind; } desktop_icon_def_t;
static const desktop_icon_def_t DESKTOP_ICONS[DESKTOP_ICON_COUNT] = {
    { "File Mgr",  0 },
    { "Terminal",  1 },
    { "Settings",  2 },
    { "Task Mgr",  3 },
    { "Clock",     4 },
    { "Browser",   5 },
};

static void icon_rect(int i, int *x, int *y) {
    *x = ICON_X;
    *y = 20 + i * ICON_CELL_H;
}

static void draw_icon_glyph(int x, int y, int kind) {
    uint32_t line = 0x00D8E4F0;
    switch (kind) {
        case 0: /* File Manager: 폴더 */
            fill((uint32_t)x, (uint32_t)(y + 6), 6, 4, 0x00E0B84A);
            fill((uint32_t)x, (uint32_t)(y + 10), ICON_BOX, ICON_BOX - 14, 0x00F0C860);
            hline(x, y + 10, ICON_BOX, 0x00A07830);
            hline(x, y + ICON_BOX - 4, ICON_BOX, 0x00A07830);
            break;
        case 1: /* Terminal: 검은 박스 + ">_" */
            fill((uint32_t)x, (uint32_t)y, ICON_BOX, ICON_BOX, 0x00101820);
            hline(x, y, ICON_BOX, line); hline(x, y + ICON_BOX - 1, ICON_BOX, line);
            vline(x, y, ICON_BOX, line); vline(x + ICON_BOX - 1, y, ICON_BOX, line);
            draw_text(x + 4, y + 12, ">_", 0x0040FF80);
            break;
        case 2: /* Settings: 톱니(다이아몬드로 단순화) */
            for (int i = 0; i < ICON_BOX / 2; i++) {
                hline(x + ICON_BOX / 2 - i, y + i, i * 2, 0x00A0B0C0);
                hline(x + ICON_BOX / 2 - i, y + ICON_BOX - 1 - i, i * 2, 0x00A0B0C0);
            }
            fill((uint32_t)(x + ICON_BOX / 2 - 4), (uint32_t)(y + ICON_BOX / 2 - 4), 8, 8, 0x00303840);
            break;
        case 3: /* Task Manager: 막대그래프 */
            fill((uint32_t)(x + 2), (uint32_t)(y + ICON_BOX - 10), 5, 10, 0x006090E0);
            fill((uint32_t)(x + 10), (uint32_t)(y + ICON_BOX - 18), 5, 18, 0x0060C090);
            fill((uint32_t)(x + 18), (uint32_t)(y + ICON_BOX - 14), 5, 14, 0x00E0A050);
            fill((uint32_t)(x + 26), (uint32_t)(y + ICON_BOX - 22), 5, 22, 0x00E06060);
            break;
        case 4: /* Clock: 원형(팔각 근사) + 바늘 */
            fill((uint32_t)(x + 6), (uint32_t)(y + 2), ICON_BOX - 12, ICON_BOX - 4, 0x00E8E8E8);
            fill((uint32_t)(x + 2), (uint32_t)(y + 6), ICON_BOX - 4, ICON_BOX - 12, 0x00E8E8E8);
            vline(x + ICON_BOX / 2, y + 6, ICON_BOX / 2 - 6, 0x00202020);
            hline(x + ICON_BOX / 2, y + ICON_BOX / 2, 7, 0x00202020);
            break;
        case 5: /* Browser: 지구본(원 + 가로/세로 선) */
            fill((uint32_t)(x + 6), (uint32_t)(y + 2), ICON_BOX - 12, ICON_BOX - 4, 0x004090D0);
            fill((uint32_t)(x + 2), (uint32_t)(y + 6), ICON_BOX - 4, ICON_BOX - 12, 0x004090D0);
            hline(x + 3, y + ICON_BOX / 2, ICON_BOX - 6, 0x0020608F);
            vline(x + ICON_BOX / 2, y + 3, ICON_BOX - 6, 0x0020608F);
            break;
    }
}

static void draw_desktop_icons(void) {
    for (int i = 0; i < DESKTOP_ICON_COUNT; i++) {
        int x, y; icon_rect(i, &x, &y);
        draw_icon_glyph(x, y, DESKTOP_ICONS[i].kind);
        /* 라벨: 아이콘 중앙 정렬 근사(짧은 라벨이라 좌측 정렬로도 충분히 붙어보임) */
        draw_text(x - 4, y + ICON_BOX + 4, DESKTOP_ICONS[i].label, THEME_TEXT_SECONDARY);
    }
}

/* 더블클릭 판정: 같은 아이콘을 짧은 시간(400ms=40틱) 안에 두 번 클릭하면
 * 그 아이콘 인덱스를 반환하고 상태를 리셋한다. 아니면 -1(아직 첫
 * 클릭으로만 기록). 데스크톱 빈 곳을 클릭했을 때만 desktop.c가 이
 * 함수를 부른다. */
static int g_icon_armed = -1;
static uint64_t g_icon_armed_tick = 0;

int wm_desktop_icon_hit(int x, int y) {
    for (int i = 0; i < DESKTOP_ICON_COUNT; i++) {
        int ix, iy; icon_rect(i, &ix, &iy);
        if (x >= ix - 6 && x < ix + ICON_BOX + 6 && y >= iy - 2 && y < iy + ICON_BOX + 16) return i;
    }
    return -1;
}

int wm_desktop_icon_double_click(int x, int y) {
    int idx = wm_desktop_icon_hit(x, y);
    if (idx < 0) { g_icon_armed = -1; return -1; }
    uint64_t now = g_timer_ticks;
    if (g_icon_armed == idx && (now - g_icon_armed_tick) < 40) {
        g_icon_armed = -1;
        return idx;
    }
    g_icon_armed = idx;
    g_icon_armed_tick = now;
    return -1;
}

/* 타이틀바 그라데이션 효과: 위→아래로 점점 어두워지는 2단 그라데이션 */
static void draw_titlebar_gradient(int x, int y, int w, uint32_t base) {
    int h = WM_TITLEBAR_H;
    for (int row = 0; row < h; row++) {
        /* base에서 row가 늘어날수록 R/G/B 각 채널을 약간씩 어둡게 */
        int dim = (row * 30) / h;
        uint32_t r = ((base >> 16) & 0xFF);
        uint32_t g = ((base >> 8) & 0xFF);
        uint32_t b = ((base) & 0xFF);
        r = (r > dim) ? r - dim : 0;
        g = (g > dim) ? g - dim : 0;
        b = (b > dim) ? b - dim : 0;
        uint32_t c = (r << 16) | (g << 8) | b;
        for (int col = 0; col < w; col++) {
            console_put_pixel(g_con, (uint32_t)(x + col), (uint32_t)(y + row), c);
        }
    }
}

/* 창 X 버튼 (닫기) */
static void draw_close_btn(int wx, int wy, int ww) {
    int bx = wx + ww - 18;
    int by = wy + 3;
    fill((uint32_t)bx, (uint32_t)by, 14, 12, 0x00803030);
    /* 작은 X */
    console_put_pixel(g_con, (uint32_t)(bx+3),(uint32_t)(by+2), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+4),(uint32_t)(by+3), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+5),(uint32_t)(by+4), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+6),(uint32_t)(by+5), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+7),(uint32_t)(by+4), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+8),(uint32_t)(by+3), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+9),(uint32_t)(by+2), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+9),(uint32_t)(by+8), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+8),(uint32_t)(by+7), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+7),(uint32_t)(by+6), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+5),(uint32_t)(by+6), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+4),(uint32_t)(by+7), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+3),(uint32_t)(by+8), 0x00FFFFFF);
}

/* JetOS 스타일 창의 최소화(_)/최대화(o)/복원(r) 버튼. offset_from_close는
 * 닫기 버튼 왼쪽으로 몇 픽셀 떨어졌는지(16=최소화, 32=최대화 위치). */
static void draw_min_max_btn(int wx, int wy, int ww, int offset_from_close, char glyph) {
    int bx = wx + ww - 18 - offset_from_close;
    int by = wy + 3;
    fill((uint32_t)bx, (uint32_t)by, 14, 12, 0x00304050);
    hline(bx, by, 14, 0x00405868);
    hline(bx, by + 11, 14, 0x00203040);
    uint32_t c = 0x00D8E8F8;
    if (glyph == '_') {
        hline(bx + 3, by + 8, 8, c);
    } else if (glyph == 'o') {
        hline(bx + 3, by + 3, 8, c); hline(bx + 3, by + 8, 8, c);
        vline(bx + 3, by + 3, 6, c); vline(bx + 10, by + 3, 6, c);
    } else { /* 'r' = 복원(작은 겹친 사각형) */
        hline(bx + 3, by + 2, 6, c); vline(bx + 3, by + 2, 5, c); vline(bx + 8, by + 2, 5, c); hline(bx+3,by+6,6,c);
        hline(bx + 5, by + 5, 6, c); vline(bx + 5, by + 5, 4, c); vline(bx + 10, by + 5, 4, c); hline(bx+5,by+8,6,c);
    }
}

/* ---- Win32(PE EXE) 스타일 창 렌더링: 클래식 Windows 95/98 느낌 ----
 * CreateWindowA()로 만들어진 창(win32_style=1)은 JetOS 고유의 어두운
 * 청회색 테마 대신, 밝은 회색 3D 베벨 + 네이비 타이틀바로 그린다 —
 * "익숙한 Windows 느낌"을 위해 Win32 호환 레이어가 만든 창임을
 * 시각적으로도 구분해준다. */
#define WIN32_FACE       0x00C0C0C0u /* 표준 버튼/배경 회색 */
#define WIN32_HIGHLIGHT  0x00FFFFFFu /* 베벨 밝은 쪽 */
#define WIN32_SHADOW     0x00808080u /* 베벨 어두운 쪽 */
#define WIN32_DARKSHADOW 0x00404040u
#define WIN32_TITLE_ACTIVE   0x00000080u /* 네이비 */
#define WIN32_TITLE_INACTIVE 0x00808080u

static void win32_bevel_rect(int x, int y, int w, int h, int raised) {
    uint32_t top_left = raised ? WIN32_HIGHLIGHT : WIN32_DARKSHADOW;
    uint32_t bot_right = raised ? WIN32_DARKSHADOW : WIN32_HIGHLIGHT;
    hline(x, y, w, top_left);
    vline(x, y, h, top_left);
    hline(x, y + h - 1, w, bot_right);
    vline(x + w - 1, y, h, bot_right);
}

static void win32_titlebar_button(int x, int y, char glyph) {
    /* 14x12짜리 작은 버튼 (최소화/최대화/닫기 공용 모양), glyph는
     * '_'(최소화), 'o'(최대화), 'x'(닫기)로 간단히 표시 */
    fill((uint32_t)x, (uint32_t)y, 14, 12, WIN32_FACE);
    win32_bevel_rect(x, y, 14, 12, 1);
    uint32_t c = 0x00000000;
    if (glyph == '_') {
        hline(x + 3, y + 8, 8, c);
    } else if (glyph == 'o') {
        hline(x + 3, y + 3, 8, c);
        hline(x + 3, y + 8, 8, c);
        vline(x + 3, y + 3, 6, c);
        vline(x + 10, y + 3, 6, c);
    } else { /* 'x' */
        for (int i = 0; i < 7; i++) {
            console_put_pixel(g_con, (uint32_t)(x + 3 + i), (uint32_t)(y + 2 + i), c);
            console_put_pixel(g_con, (uint32_t)(x + 3 + i), (uint32_t)(y + 8 - i), c);
        }
    }
}

static void draw_win32_window(wm_window_t *w, int focused) {
    int fx = w->x, fy = w->y, fw = w->w, fh = w->h + WM_TITLEBAR_H;

    /* 바깥 3D 베벨(창 전체 프레임) */
    fill((uint32_t)(fx - 2), (uint32_t)(fy - 2), fw + 4, fh + 4, WIN32_FACE);
    win32_bevel_rect(fx - 2, fy - 2, fw + 4, fh + 4, 1);
    win32_bevel_rect(fx - 1, fy - 1, fw + 2, fh + 2, 1);

    /* 타이틀바 */
    uint32_t tcolor = focused ? WIN32_TITLE_ACTIVE : WIN32_TITLE_INACTIVE;
    fill((uint32_t)fx, (uint32_t)fy, fw, WM_TITLEBAR_H, tcolor);
    draw_text(fx + 4, fy + 5, w->title, 0x00FFFFFF);

    /* 최소화/최대화/닫기 버튼 3개 (오른쪽 정렬) — 실제 클릭 판정은
     * wm_hit_close_button()이 쓰는 위치(맨 오른쪽 X)와 맞춰둔다 */
    int bx = fx + fw - 18 - 1;
    win32_titlebar_button(bx, fy + 3, 'x');
    win32_titlebar_button(bx - 16, fy + 3, 'o');
    win32_titlebar_button(bx - 32, fy + 3, '_');

    /* 클라이언트 영역: 안쪽으로 살짝 파인 베벨 + 밝은 회색 배경 */
    int cy = fy + WM_TITLEBAR_H;
    fill((uint32_t)fx, (uint32_t)cy, fw, w->h, WIN32_FACE);
    win32_bevel_rect(fx, cy, fw, w->h, 0);

    /* 크기 조절 손잡이 */
    {
        int gx = fx + fw - 8, gy = cy + w->h - 8;
        for (int k = 0; k < 3; k++) {
            hline(gx + k * 2, gy + 6 - k * 2, 2, WIN32_DARKSHADOW);
        }
    }
}

/* 마우스 커서 (화살표 모양, 11x11) */
static void draw_cursor(void) {    int cx = g_cursor_x, cy = g_cursor_y;
    uint32_t c  = THEME_CURSOR_COLOR;
    uint32_t cs = 0x00000000; /* 그림자 (순수 검정 테두리) */
    /* 외곽선 */
    for (int i = 0; i < 10; i++) {
        console_put_pixel(g_con, (uint32_t)(cx), (uint32_t)(cy+i), cs);
        console_put_pixel(g_con, (uint32_t)(cx+1), (uint32_t)(cy+i+1), cs);
    }
    /* 채우기 */
    for (int i = 0; i < 8; i++) {
        console_put_pixel(g_con, (uint32_t)(cx+1), (uint32_t)(cy+1+i), c);
    }
    console_put_pixel(g_con, (uint32_t)(cx+2), (uint32_t)(cy+2), c);
    console_put_pixel(g_con, (uint32_t)(cx+2), (uint32_t)(cy+3), c);
    console_put_pixel(g_con, (uint32_t)(cx+3), (uint32_t)(cy+3), c);
    console_put_pixel(g_con, (uint32_t)(cx+3), (uint32_t)(cy+4), c);
    console_put_pixel(g_con, (uint32_t)(cx+2), (uint32_t)(cy+5), c);
    console_put_pixel(g_con, (uint32_t)(cx+3), (uint32_t)(cy+5), c);
    console_put_pixel(g_con, (uint32_t)(cx+4), (uint32_t)(cy+4), c);
    console_put_pixel(g_con, (uint32_t)(cx+5), (uint32_t)(cy+3), c);
}

void wm_draw(void) {
    if (!g_con) return;

    /* 데스크탑 배경 — Milestone 17: 단색 대신 은은한 대각선 그라디언트
     * 벽지. 매 프레임 다시 그리지만 단순한 픽셀 연산이라 비용은 작다. */
    draw_wallpaper();
    draw_desktop_icons();

    /* 창 렌더링 (뒤→앞) */
    for (int i = 0; i < g_window_count; i++) {
        wm_window_t *w = &g_windows[g_order[i]];
        if (!w->visible) continue;
        int focused = (g_order[i] == g_focused_idx);
        uint32_t title_color = focused ? theme_title_active() : THEME_WIN_TITLE_INACTIVE;

        if (w->win32_style) {
            draw_win32_window(w, focused);
            if (w->content_cb) {
                w->content_cb(g_con, w->x, w->y + WM_TITLEBAR_H, w->w, w->h, w->content_ctx);
            }
            continue;
        }

        /* 창 바깥 테두리 */
        hline(w->x - BORDER_SZ, w->y - BORDER_SZ, w->w + BORDER_SZ * 2 + 1, THEME_WIN_BORDER);
        hline(w->x - BORDER_SZ, w->y + WM_TITLEBAR_H + w->h + BORDER_SZ, w->w + BORDER_SZ * 2 + 1, THEME_WIN_BORDER);
        vline(w->x - BORDER_SZ, w->y, w->h + WM_TITLEBAR_H + BORDER_SZ, THEME_WIN_BORDER);
        vline(w->x + w->w + BORDER_SZ - 1, w->y, w->h + WM_TITLEBAR_H + BORDER_SZ, THEME_WIN_BORDER);

        /* 타이틀바 (그라데이션) */
        draw_titlebar_gradient(w->x, w->y, w->w, title_color);

        /* 타이틀바 하단 구분선 */
        hline(w->x, w->y + WM_TITLEBAR_H - 1, w->w, THEME_WIN_BORDER);

        /* 타이틀 텍스트 */
        draw_text(w->x + 8, w->y + 5, w->title, THEME_WIN_TITLE_TEXT);

        /* 닫기 버튼 */
        draw_close_btn(w->x, w->y, w->w);
        /* 최소화/최대화 버튼 (Milestone 18) */
        draw_min_max_btn(w->x, w->y, w->w, 16, '_'); /* 최소화 */
        draw_min_max_btn(w->x, w->y, w->w, 32, w->maximized ? 'r' : 'o'); /* 최대화/복원 */

        /* 창 본문 */
        fill((uint32_t)w->x, (uint32_t)(w->y + WM_TITLEBAR_H),
              (uint32_t)w->w, (uint32_t)w->h, THEME_WIN_CLIENT);

        /* 내용 콜백 */
        if (w->content_cb) {
            w->content_cb(g_con, w->x, w->y + WM_TITLEBAR_H, w->w, w->h, w->content_ctx);
        }

        /* 크기 조절 손잡이(우하단 대각선 3줄) — Milestone 17 */
        {
            int gx = w->x + w->w - 8, gy = w->y + WM_TITLEBAR_H + w->h - 8;
            for (int k = 0; k < 3; k++) {
                hline(gx + k * 2, gy + 6 - k * 2, 2, THEME_WIN_BORDER);
            }
        }
    }

    /* 작업표시줄 */
    int tbY = (int)g_con->height - WM_TASKBAR_H;
    fill(0, (uint32_t)tbY, g_con->width, WM_TASKBAR_H, THEME_TASKBAR_BG);
    hline(0, tbY, (int)g_con->width, THEME_TASKBAR_BORDER); /* 상단 구분선 */

    /* 작업표시줄 시계 (Milestone 17) — 오른쪽 끝에 항상 표시 */
    {
        rtc_time_t t;
        rtc_read(&t);
        char clk[6];
        clk[0] = (char)('0' + (t.hour / 10) % 10);
        clk[1] = (char)('0' + t.hour % 10);
        clk[2] = ':';
        clk[3] = (char)('0' + (t.minute / 10) % 10);
        clk[4] = (char)('0' + t.minute % 10);
        clk[5] = '\0';
        int clk_w = 5 * 12; /* 대략적인 폭(5글자 * 폰트 advance 근사치) */
        draw_text((int)g_con->width - clk_w - 12, tbY + 6, clk, THEME_TEXT_HIGHLIGHT);
    }

    /* 시작 버튼 */
    fill(0, (uint32_t)tbY + 2, START_BTN_W - 4, WM_TASKBAR_H - 4, THEME_START_NORMAL);
    hline(0, tbY + 2, START_BTN_W - 4, theme_accent());
    hline(0, tbY + WM_TASKBAR_H - 3, START_BTN_W - 4, theme_accent());
    draw_text(8, tbY + 6, "START", THEME_START_TEXT);

    /* 창 목록 버튼 */
    int tx = START_BTN_W + 4;
    for (int i = 0; i < g_window_count; i++) {
        wm_window_t *w = &g_windows[g_order[i]];
        if (w->closed) continue;
        int active = (g_order[i] == g_focused_idx) && !w->minimized;
        uint32_t btn_c = active ? theme_taskbar_active() : THEME_TASKBAR_BTN_NORMAL;
        fill((uint32_t)tx, (uint32_t)(tbY + 2), TASKBAR_LABEL_W - 4, WM_TASKBAR_H - 4, btn_c);
        if (active) hline(tx, tbY + 2, TASKBAR_LABEL_W - 4, theme_accent());
        draw_text(tx + 6, tbY + 7, w->title, active ? THEME_TEXT_HIGHLIGHT : THEME_TEXT_SECONDARY);
        tx += TASKBAR_LABEL_W;
    }

    /* 시작 메뉴 */
    if (g_start_menu_open) {
        int menu_w = START_BTN_W + 80;
        int menu_h = START_MENU_ITEMS * MENU_ITEM_H + 4;
        int menu_y = tbY - menu_h;
        fill(0, (uint32_t)menu_y, (uint32_t)menu_w, (uint32_t)menu_h, THEME_MENU_BG);
        hline(0, menu_y, menu_w, THEME_WIN_BORDER);
        vline(menu_w - 1, menu_y, menu_h, THEME_WIN_BORDER);
        for (int i = 0; i < START_MENU_ITEMS; i++) {
            int item_y = menu_y + 2 + i * MENU_ITEM_H;
            if (i == START_MENU_ITEMS - 1) { /* SHUTDOWN 앞에 구분선 */
                hline(4, item_y - 1, menu_w - 8, THEME_MENU_SEPARATOR);
            }
            draw_text(10, item_y + 5, START_MENU_LABELS[i], THEME_MENU_TEXT);
        }
    }

    /* 우클릭 컨텍스트 메뉴 */
    if (g_ctx_menu_open) {
        int n = ctx_menu_item_count();
        int menu_h = n * MENU_ITEM_H + 4;
        fill((uint32_t)g_ctx_menu_x, (uint32_t)g_ctx_menu_y, CTX_MENU_W, (uint32_t)menu_h, THEME_MENU_BG);
        hline(g_ctx_menu_x, g_ctx_menu_y, CTX_MENU_W, THEME_WIN_BORDER);
        vline(g_ctx_menu_x + CTX_MENU_W - 1, g_ctx_menu_y, menu_h, THEME_WIN_BORDER);
        vline(g_ctx_menu_x, g_ctx_menu_y, menu_h, THEME_WIN_BORDER);
        hline(g_ctx_menu_x, g_ctx_menu_y + menu_h - 1, CTX_MENU_W, THEME_WIN_BORDER);
        if (g_ctx_menu_target == -1) {
            for (int i = 0; i < DESKTOP_CTX_ITEMS; i++) {
                int item_y = g_ctx_menu_y + 2 + i * MENU_ITEM_H;
                draw_text(g_ctx_menu_x + 8, item_y + 5, START_MENU_LABELS[i], THEME_MENU_TEXT);
            }
        } else {
            int minimized = (g_ctx_menu_target >= 0 && g_ctx_menu_target < g_window_count)
                             ? g_windows[g_ctx_menu_target].minimized : 0;
            const char *labels[WINDOW_CTX_ITEMS] = { "Close", minimized ? "Restore" : "Minimize" };
            for (int i = 0; i < WINDOW_CTX_ITEMS; i++) {
                int item_y = g_ctx_menu_y + 2 + i * MENU_ITEM_H;
                draw_text(g_ctx_menu_x + 8, item_y + 5, labels[i], THEME_MENU_TEXT);
            }
        }
    }

    draw_cursor();
}

void wm_present(void) {
    if (!g_front || !g_con || !g_con->fb || !g_front->fb) return;
    uint32_t total = g_front->width * g_front->height;
    for (uint32_t i = 0; i < total; i++) g_front->fb[i] = g_con->fb[i];
}

console_t *wm_get_draw_console(void) { return g_con; }
