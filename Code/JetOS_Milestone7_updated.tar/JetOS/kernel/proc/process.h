#ifndef JETOS_PROCESS_H
#define JETOS_PROCESS_H

#include "thread.h"

#define PROCESS_NAME_MAX 32
#define PROCESS_MAX_THREADS 8

/* Milestone 3의 process_t는 스레드를 묶는 "논리적 컨테이너"다.
 * 아직 별도의 주소공간(페이지 테이블)이나 사용자 모드(Ring 3) 격리는
 * 없다 — 모든 스레드는 커널과 같은 주소공간/특권 레벨에서 동작한다.
 * 진짜 프로세스 격리(Process Isolation)는 사용자 모드가 도입되는
 * 이후 마일스톤 과제다. */
typedef struct {
    uint32_t id;
    char name[PROCESS_NAME_MAX];
    thread_t *threads[PROCESS_MAX_THREADS];
    int thread_count;
} process_t;

process_t *process_create(const char *name);
thread_t  *process_spawn_thread(process_t *proc, const char *name,
                                 void (*entry)(void *arg), void *arg);

#endif
