/*
 * JetOS - kernel/net/net.c
 * Milestone 10: 최소 네트워킹 스택 구현. net.h 설명 참고.
 */

#include "net.h"
#include "../drivers/rtl8139.h"
#include "../drivers/serial.h"
#include "../int/pit.h"
#include "../proc/scheduler.h"

/* ---- 바이트 순서 변환 (x86은 리틀엔디안, 네트워크는 빅엔디안) ---- */
static uint16_t net_htons(uint16_t v) { return (uint16_t)((v << 8) | (v >> 8)); }
static uint32_t net_htonl(uint32_t v) {
    return ((v & 0x000000FFu) << 24) | ((v & 0x0000FF00u) << 8) |
           ((v & 0x00FF0000u) >> 8)  | ((v & 0xFF000000u) >> 24);
}
#define net_ntohs net_htons
#define net_ntohl net_htonl

/* ---- 프레임 포맷 (전부 네트워크 바이트 순서 필드) ---- */
#pragma pack(push, 1)
typedef struct {
    uint8_t dst_mac[6];
    uint8_t src_mac[6];
    uint16_t ethertype;
} eth_header_t;

#define ETHERTYPE_ARP  0x0806
#define ETHERTYPE_IPV4 0x0800

typedef struct {
    uint16_t htype, ptype;
    uint8_t hlen, plen;
    uint16_t oper;
    uint8_t sha[6];
    uint32_t spa;
    uint8_t tha[6];
    uint32_t tpa;
} arp_packet_t;

#define ARP_OP_REQUEST 1
#define ARP_OP_REPLY   2

typedef struct {
    uint8_t ver_ihl;
    uint8_t tos;
    uint16_t total_len;
    uint16_t id;
    uint16_t flags_frag;
    uint8_t ttl;
    uint8_t protocol;
    uint16_t checksum;
    uint32_t src_ip;
    uint32_t dst_ip;
} ipv4_header_t;

#define IP_PROTO_ICMP 1
#define IP_PROTO_TCP  6
#define IP_PROTO_UDP  17

typedef struct {
    uint8_t type;
    uint8_t code;
    uint16_t checksum;
    uint16_t id;
    uint16_t seq;
} icmp_header_t;

#define ICMP_TYPE_ECHO_REQUEST 8
#define ICMP_TYPE_ECHO_REPLY   0
#pragma pack(pop)

static uint16_t inet_checksum(const void *data, uint32_t len) {
    const uint8_t *p = (const uint8_t *)data;
    uint32_t sum = 0;
    while (len > 1) {
        sum += (uint32_t)((p[0] << 8) | p[1]);
        p += 2; len -= 2;
    }
    if (len == 1) sum += (uint32_t)(p[0] << 8);
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    return (uint16_t)~sum;
}

/* ---- ARP 캐시 ---- */
#define ARP_CACHE_SIZE 16
typedef struct { int used; uint32_t ip; uint8_t mac[6]; } arp_entry_t;
static arp_entry_t g_arp_cache[ARP_CACHE_SIZE];

static int arp_cache_find(uint32_t ip, uint8_t out_mac[6]) {
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (g_arp_cache[i].used && g_arp_cache[i].ip == ip) {
            for (int k = 0; k < 6; k++) out_mac[k] = g_arp_cache[i].mac[k];
            return 1;
        }
    }
    return 0;
}
static void arp_cache_put(uint32_t ip, const uint8_t mac[6]) {
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (g_arp_cache[i].used && g_arp_cache[i].ip == ip) {
            for (int k = 0; k < 6; k++) g_arp_cache[i].mac[k] = mac[k];
            return;
        }
    }
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (!g_arp_cache[i].used) {
            g_arp_cache[i].used = 1;
            g_arp_cache[i].ip = ip;
            for (int k = 0; k < 6; k++) g_arp_cache[i].mac[k] = mac[k];
            return;
        }
    }
    /* 캐시가 꽉 찼으면 0번 슬롯을 덮어쓴다 (단순 정책) */
    g_arp_cache[0].used = 1;
    g_arp_cache[0].ip = ip;
    for (int k = 0; k < 6; k++) g_arp_cache[0].mac[k] = mac[k];
}

/* 마지막으로 수신한 ICMP echo reply 기록 (net_ping()의 대기 루프가 확인) */
static volatile int g_last_echo_reply_valid = 0;
static volatile uint32_t g_last_echo_reply_src = 0;
static volatile uint16_t g_last_echo_reply_id = 0;
static volatile uint16_t g_last_echo_reply_seq = 0;

static uint8_t g_mac[6];
static int g_initialized = 0;

int net_init(void) {
    if (!rtl8139_init()) { g_initialized = 0; return 0; }
    rtl8139_get_mac(g_mac);
    for (int i = 0; i < ARP_CACHE_SIZE; i++) g_arp_cache[i].used = 0;
    g_initialized = 1;

    serial_write("STAGE: NET INIT OK (RTL8139), MAC=");
    for (int i = 0; i < 6; i++) {
        static const char hex[] = "0123456789ABCDEF";
        char buf[3] = { hex[g_mac[i] >> 4], hex[g_mac[i] & 0xF], '\0' };
        serial_write(buf);
        if (i < 5) serial_write(":");
    }
    serial_write("\n");
    return 1;
}

int net_available(void) { return g_initialized; }
void net_get_mac(uint8_t mac[6]) { for (int i = 0; i < 6; i++) mac[i] = g_mac[i]; }
uint32_t net_get_ip(void) { return NET_MY_IP; }
uint32_t net_get_gateway(void) { return NET_GATEWAY_IP; }

void net_ip_to_str(uint32_t ip, char *buf) {
    uint8_t a = (uint8_t)(ip >> 24), b = (uint8_t)(ip >> 16), c = (uint8_t)(ip >> 8), d = (uint8_t)ip;
    int pos = 0;
    uint8_t parts[4] = { a, b, c, d };
    for (int p = 0; p < 4; p++) {
        uint8_t v = parts[p];
        char tmp[4]; int tn = 0;
        if (v == 0) tmp[tn++] = '0';
        while (v) { tmp[tn++] = (char)('0' + (v % 10)); v /= 10; }
        for (int i = tn - 1; i >= 0; i--) buf[pos++] = tmp[i];
        if (p < 3) buf[pos++] = '.';
    }
    buf[pos] = '\0';
}

uint32_t net_str_to_ip(const char *s) {
    uint32_t parts[4] = {0,0,0,0};
    int part = 0, have_digit = 0;
    for (const char *p = s; ; p++) {
        if (*p >= '0' && *p <= '9') {
            parts[part] = parts[part] * 10 + (uint32_t)(*p - '0');
            have_digit = 1;
        } else if (*p == '.') {
            if (!have_digit || part >= 3) return 0;
            part++;
            have_digit = 0;
        } else if (*p == '\0') {
            break;
        } else {
            return 0;
        }
    }
    if (part != 3 || !have_digit) return 0;
    for (int i = 0; i < 4; i++) if (parts[i] > 255) return 0;
    return (parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3];
}

static const uint8_t BCAST_MAC[6] = { 0xFF,0xFF,0xFF,0xFF,0xFF,0xFF };

static void send_arp_request(uint32_t target_ip) {
    uint8_t frame[sizeof(eth_header_t) + sizeof(arp_packet_t)];
    eth_header_t *eth = (eth_header_t *)frame;
    arp_packet_t *arp = (arp_packet_t *)(frame + sizeof(eth_header_t));

    for (int i = 0; i < 6; i++) eth->dst_mac[i] = BCAST_MAC[i];
    for (int i = 0; i < 6; i++) eth->src_mac[i] = g_mac[i];
    eth->ethertype = net_htons(ETHERTYPE_ARP);

    arp->htype = net_htons(1);
    arp->ptype = net_htons(ETHERTYPE_IPV4);
    arp->hlen = 6; arp->plen = 4;
    arp->oper = net_htons(ARP_OP_REQUEST);
    for (int i = 0; i < 6; i++) arp->sha[i] = g_mac[i];
    arp->spa = net_htonl(NET_MY_IP);
    for (int i = 0; i < 6; i++) arp->tha[i] = 0;
    arp->tpa = net_htonl(target_ip);

    rtl8139_send(frame, sizeof(frame));
}

static void send_arp_reply(const uint8_t dst_mac[6], uint32_t dst_ip) {
    uint8_t frame[sizeof(eth_header_t) + sizeof(arp_packet_t)];
    eth_header_t *eth = (eth_header_t *)frame;
    arp_packet_t *arp = (arp_packet_t *)(frame + sizeof(eth_header_t));

    for (int i = 0; i < 6; i++) eth->dst_mac[i] = dst_mac[i];
    for (int i = 0; i < 6; i++) eth->src_mac[i] = g_mac[i];
    eth->ethertype = net_htons(ETHERTYPE_ARP);

    arp->htype = net_htons(1);
    arp->ptype = net_htons(ETHERTYPE_IPV4);
    arp->hlen = 6; arp->plen = 4;
    arp->oper = net_htons(ARP_OP_REPLY);
    for (int i = 0; i < 6; i++) arp->sha[i] = g_mac[i];
    arp->spa = net_htonl(NET_MY_IP);
    for (int i = 0; i < 6; i++) arp->tha[i] = dst_mac[i];
    arp->tpa = net_htonl(dst_ip);

    rtl8139_send(frame, sizeof(frame));
}

int net_ip_send(uint32_t dst_ip, uint8_t protocol, const void *payload, uint32_t len) {
    if (!g_initialized) return 0;
    uint32_t frame_len = (uint32_t)sizeof(eth_header_t) + (uint32_t)sizeof(ipv4_header_t) + len;
    if (frame_len > RTL8139_MAX_FRAME) return 0;

    /* 같은 서브넷이면 목적지를 직접, 아니면 게이트웨이를 ARP로 찾는다
     * (JetOS는 라우팅 테이블이 없으므로 "다른 서브넷 = 무조건 게이트웨이"). */
    uint32_t next_hop = ((dst_ip & NET_NETMASK) == (NET_MY_IP & NET_NETMASK)) ? dst_ip : NET_GATEWAY_IP;
    uint8_t dst_mac[6];
    if (!net_arp_resolve(next_hop, dst_mac, 300)) return 0;

    uint8_t frame[RTL8139_MAX_FRAME];
    eth_header_t *eth = (eth_header_t *)frame;
    ipv4_header_t *ip = (ipv4_header_t *)(frame + sizeof(eth_header_t));
    uint8_t *ip_payload = (uint8_t *)ip + sizeof(ipv4_header_t);

    for (int i = 0; i < 6; i++) eth->dst_mac[i] = dst_mac[i];
    for (int i = 0; i < 6; i++) eth->src_mac[i] = g_mac[i];
    eth->ethertype = net_htons(ETHERTYPE_IPV4);

    static uint16_t ip_id_counter = 0;
    ip->ver_ihl = 0x45;
    ip->tos = 0;
    ip->total_len = net_htons((uint16_t)(sizeof(ipv4_header_t) + len));
    ip->id = net_htons(++ip_id_counter);
    ip->flags_frag = 0;
    ip->ttl = 64;
    ip->protocol = protocol;
    ip->checksum = 0;
    ip->src_ip = net_htonl(NET_MY_IP);
    ip->dst_ip = net_htonl(dst_ip);
    ip->checksum = net_htons(inet_checksum(ip, sizeof(ipv4_header_t)));

    const uint8_t *src = (const uint8_t *)payload;
    for (uint32_t i = 0; i < len; i++) ip_payload[i] = src[i];

    return rtl8139_send(frame, frame_len);
}

static void handle_arp(const uint8_t *payload, uint32_t len, const uint8_t src_mac[6]) {
    (void)src_mac;
    if (len < sizeof(arp_packet_t)) return;
    const arp_packet_t *arp = (const arp_packet_t *)payload;
    uint16_t oper = net_ntohs(arp->oper);
    uint32_t spa = net_ntohl(arp->spa);
    uint32_t tpa = net_ntohl(arp->tpa);

    if (oper == ARP_OP_REPLY) {
        arp_cache_put(spa, arp->sha);
        return;
    }
    if (oper == ARP_OP_REQUEST && tpa == NET_MY_IP) {
        arp_cache_put(spa, arp->sha); /* 요청자 주소도 캐시해두면 이후 통신에 유용 */
        send_arp_reply(arp->sha, spa);
    }
}

static void send_icmp_echo_reply(uint32_t dst_ip, const uint8_t dst_mac[6],
                                  uint16_t id, uint16_t seq,
                                  const uint8_t *icmp_payload, uint32_t icmp_payload_len) {
    uint32_t icmp_total = (uint32_t)sizeof(icmp_header_t) + icmp_payload_len;
    uint32_t ip_total = (uint32_t)sizeof(ipv4_header_t) + icmp_total;
    uint32_t frame_len = (uint32_t)sizeof(eth_header_t) + ip_total;
    if (frame_len > RTL8139_MAX_FRAME) return;

    uint8_t frame[RTL8139_MAX_FRAME];
    eth_header_t *eth = (eth_header_t *)frame;
    ipv4_header_t *ip = (ipv4_header_t *)(frame + sizeof(eth_header_t));
    icmp_header_t *icmp = (icmp_header_t *)((uint8_t *)ip + sizeof(ipv4_header_t));
    uint8_t *payload = (uint8_t *)icmp + sizeof(icmp_header_t);

    for (int i = 0; i < 6; i++) eth->dst_mac[i] = dst_mac[i];
    for (int i = 0; i < 6; i++) eth->src_mac[i] = g_mac[i];
    eth->ethertype = net_htons(ETHERTYPE_IPV4);

    ip->ver_ihl = 0x45;
    ip->tos = 0;
    ip->total_len = net_htons((uint16_t)ip_total);
    ip->id = net_htons(0);
    ip->flags_frag = 0;
    ip->ttl = 64;
    ip->protocol = IP_PROTO_ICMP;
    ip->checksum = 0;
    ip->src_ip = net_htonl(NET_MY_IP);
    ip->dst_ip = net_htonl(dst_ip);
    ip->checksum = net_htons(inet_checksum(ip, sizeof(ipv4_header_t)));

    icmp->type = ICMP_TYPE_ECHO_REPLY;
    icmp->code = 0;
    icmp->checksum = 0;
    icmp->id = id;   /* 이미 네트워크 바이트 순서로 받은 값을 그대로 되돌려줌 */
    icmp->seq = seq;
    for (uint32_t i = 0; i < icmp_payload_len; i++) payload[i] = icmp_payload[i];
    icmp->checksum = net_htons(inet_checksum(icmp, icmp_total));

    rtl8139_send(frame, frame_len);
}

static void handle_ipv4(const uint8_t *payload, uint32_t len, const uint8_t src_mac[6]) {
    if (len < sizeof(ipv4_header_t)) return;
    const ipv4_header_t *ip = (const ipv4_header_t *)payload;
    uint8_t ihl = (uint8_t)((ip->ver_ihl & 0x0F) * 4);
    if (ihl < sizeof(ipv4_header_t) || len < ihl) return;
    uint32_t dst_ip = net_ntohl(ip->dst_ip);
    uint32_t src_ip = net_ntohl(ip->src_ip);
    if (dst_ip != NET_MY_IP) return; /* 우리 앞으로 온 게 아니면 무시 (라우팅 없음) */

    if (ip->protocol == IP_PROTO_ICMP) {
        uint32_t icmp_len = len - ihl;
        if (icmp_len < sizeof(icmp_header_t)) return;
        const icmp_header_t *icmp = (const icmp_header_t *)(payload + ihl);

        if (icmp->type == ICMP_TYPE_ECHO_REQUEST) {
            uint32_t data_len = icmp_len - sizeof(icmp_header_t);
            send_icmp_echo_reply(src_ip, src_mac, icmp->id, icmp->seq,
                                  (const uint8_t *)icmp + sizeof(icmp_header_t), data_len);
        } else if (icmp->type == ICMP_TYPE_ECHO_REPLY) {
            g_last_echo_reply_valid = 1;
            g_last_echo_reply_src = src_ip;
            g_last_echo_reply_id = icmp->id;
            g_last_echo_reply_seq = icmp->seq;
        }
    } else if (ip->protocol == IP_PROTO_TCP) {
        tcp_on_ip_packet(src_ip, payload + ihl, len - ihl);
    } else if (ip->protocol == IP_PROTO_UDP) {
        udp_on_ip_packet(src_ip, payload + ihl, len - ihl);
    }
}

void net_poll(void) {
    if (!g_initialized) return;
    uint8_t buf[RTL8139_MAX_FRAME];
    /* 방어적 상한: rtl8139_recv()가 어떤 이유로든(다른 트래픽이 많거나,
     * 오프셋 계산에 경계 사례가 있거나) 매번 0이 아닌 길이를 계속
     * 반환하면 이 함수가 영원히 리턴하지 않아 호출자(tcp_connect 등의
     * 데드라인 루프)까지 통째로 멈춰버린다. scheduler.c의 pick_next()가
     * 쓰는 것과 같은 "가드 카운터" 패턴으로 한 번의 net_poll() 호출이
     * 처리하는 프레임 수를 제한해, 무슨 일이 있어도 반드시 호출자에게
     * 제어를 돌려준다. */
    for (int guard = 0; guard < 64; guard++) {
        uint32_t len = rtl8139_recv(buf, sizeof(buf));
        if (len == 0) break;
        if (len < sizeof(eth_header_t)) continue;

        eth_header_t *eth = (eth_header_t *)buf;
        uint16_t ethertype = net_ntohs(eth->ethertype);
        const uint8_t *payload = buf + sizeof(eth_header_t);
        uint32_t payload_len = len - sizeof(eth_header_t);

        if (ethertype == ETHERTYPE_ARP) {
            handle_arp(payload, payload_len, eth->src_mac);
        } else if (ethertype == ETHERTYPE_IPV4) {
            handle_ipv4(payload, payload_len, eth->src_mac);
        }
    }
}

int net_arp_resolve(uint32_t ip, uint8_t out_mac[6], uint32_t timeout_ticks) {
    if (!g_initialized) return 0;
    if (arp_cache_find(ip, out_mac)) return 1;

    send_arp_request(ip);
    uint64_t deadline = g_timer_ticks + timeout_ticks;
    uint64_t last_retry = g_timer_ticks;
    while (g_timer_ticks < deadline) {
        net_poll();
        if (arp_cache_find(ip, out_mac)) return 1;
        /* 대략 5틱(50ms)마다 요청 재전송 (초기 브로드캐스트가 유실될 수 있음) */
        if (g_timer_ticks - last_retry >= 5) {
            send_arp_request(ip);
            last_retry = g_timer_ticks;
        }
        scheduler_yield();
    }
    return 0;
}

int net_ping(uint32_t ip, uint32_t timeout_ticks, uint32_t *out_rtt_ticks) {
    if (!g_initialized) return 0;

    uint8_t dst_mac[6];
    if (!net_arp_resolve(ip, dst_mac, timeout_ticks)) return 0;

    static uint16_t seq_counter = 0;
    uint16_t id = net_htons(0x4A54); /* "JT" */
    uint16_t seq = net_htons(++seq_counter);
    const char payload_str[] = "JetOS-ping";
    uint32_t payload_len = (uint32_t)(sizeof(payload_str) - 1);

    uint32_t icmp_total = (uint32_t)sizeof(icmp_header_t) + payload_len;
    uint32_t ip_total = (uint32_t)sizeof(ipv4_header_t) + icmp_total;
    uint32_t frame_len = (uint32_t)sizeof(eth_header_t) + ip_total;

    uint8_t frame[128];
    eth_header_t *eth = (eth_header_t *)frame;
    ipv4_header_t *ip_hdr = (ipv4_header_t *)(frame + sizeof(eth_header_t));
    icmp_header_t *icmp = (icmp_header_t *)((uint8_t *)ip_hdr + sizeof(ipv4_header_t));
    uint8_t *payload = (uint8_t *)icmp + sizeof(icmp_header_t);

    for (int i = 0; i < 6; i++) eth->dst_mac[i] = dst_mac[i];
    for (int i = 0; i < 6; i++) eth->src_mac[i] = g_mac[i];
    eth->ethertype = net_htons(ETHERTYPE_IPV4);

    ip_hdr->ver_ihl = 0x45;
    ip_hdr->tos = 0;
    ip_hdr->total_len = net_htons((uint16_t)ip_total);
    ip_hdr->id = net_htons(1);
    ip_hdr->flags_frag = 0;
    ip_hdr->ttl = 64;
    ip_hdr->protocol = IP_PROTO_ICMP;
    ip_hdr->checksum = 0;
    ip_hdr->src_ip = net_htonl(NET_MY_IP);
    ip_hdr->dst_ip = net_htonl(ip);
    ip_hdr->checksum = net_htons(inet_checksum(ip_hdr, sizeof(ipv4_header_t)));

    icmp->type = ICMP_TYPE_ECHO_REQUEST;
    icmp->code = 0;
    icmp->checksum = 0;
    icmp->id = id;
    icmp->seq = seq;
    for (uint32_t i = 0; i < payload_len; i++) payload[i] = (uint8_t)payload_str[i];
    icmp->checksum = net_htons(inet_checksum(icmp, icmp_total));

    g_last_echo_reply_valid = 0;
    uint64_t send_tick = g_timer_ticks;
    if (!rtl8139_send(frame, frame_len)) return 0;

    uint64_t deadline = send_tick + timeout_ticks;
    while (g_timer_ticks < deadline) {
        net_poll();
        if (g_last_echo_reply_valid &&
            g_last_echo_reply_src == ip &&
            g_last_echo_reply_id == id &&
            g_last_echo_reply_seq == seq) {
            if (out_rtt_ticks) *out_rtt_ticks = (uint32_t)(g_timer_ticks - send_tick);
            return 1;
        }
        scheduler_yield();
    }
    return 0;
}
