#ifndef JETOS_WIN32_COMPAT_H
#define JETOS_WIN32_COMPAT_H

/*
 * JetOS Win32 호환 레이어 (씨앗 단계, Milestone 6).
 *
 * Windows 개발자가 익숙한 함수 이름/시그니처를 그대로 제공하지만,
 * Microsoft의 Windows.h/SDK/DLL은 전혀 사용하지 않는다 — 아래 타입과
 * 함수는 전부 JetOS가 직접 정의/구현했으며, 내부적으로는 전부 JetAPI
 * (CreateWindowJ, WriteFileJ 등)로 위임(delegate)된다.
 *
 * Wine이 리눅스에서 하는 것과 같은 접근이다: "Windows처럼 보이는 API
 * 표면"을 자체 구현으로 재현하는 것이지, Windows 코드를 가져다 쓰는
 * 것이 아니다.
 *
 * 지금 단계(Milestone 6)의 목표는 실제 .exe 실행(PE 로더 + 전체 WinAPI
 * 표면적)이 아니라, "이런 방향으로 확장 가능한 API 표면이 이미
 * 존재한다"는 것을 증명하는 것이다. PE 로더 + 더 많은 API는 GUI/JetAPI가
 * 안정화된 이후 마일스톤에서 본격적으로 확장한다.
 */

#include <stdint.h>

typedef int32_t  BOOL;
typedef uint32_t DWORD;
typedef void*    LPVOID;
typedef const void* LPCVOID;
typedef const char* LPCSTR;
typedef void*    HANDLE;
typedef HANDLE   HWND;

#define TRUE  1
#define FALSE 0
#define NULL_HANDLE ((HANDLE)0)  /* NOLINT: efi.h에도 동명 매크로 존재, 동일 값이므로 무해 */

#define MEM_COMMIT  0x1000
#define PAGE_READWRITE 0x04

/* 실제 CreateWindowExA 시그니처를 단순화했다 (부모/스타일/메뉴 등은
 * Milestone 6에서는 무시되고, 위치/크기/제목만 사용된다). */
HWND CreateWindowA(LPCSTR title, int x, int y, int w, int h, DWORD color_as_style_placeholder);

int MessageBoxA(HWND owner, LPCSTR text, LPCSTR title, DWORD type);

HANDLE CreateFileA(LPCSTR path, DWORD desired_access, DWORD share_mode,
                    void *security_attrs, DWORD creation_disposition,
                    DWORD flags, HANDLE template_file);
BOOL ReadFile(HANDLE file, LPVOID buffer, DWORD bytes_to_read, DWORD *bytes_read, void *overlapped);
BOOL WriteFile(HANDLE file, LPCVOID buffer, DWORD bytes_to_write, DWORD *bytes_written, void *overlapped);
BOOL CloseHandle(HANDLE h);

LPVOID VirtualAlloc(LPVOID addr, uint32_t size, DWORD alloc_type, DWORD protect);
BOOL VirtualFree(LPVOID addr, uint32_t size, DWORD free_type);

__attribute__((noreturn)) void ExitProcess(DWORD exit_code);

#endif
