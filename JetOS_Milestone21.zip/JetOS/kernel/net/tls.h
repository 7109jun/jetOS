#ifndef JETOS_TLS_H
#define JETOS_TLS_H

/*
 * JetOS - kernel/net/tls.h
 * Milestone 19: 최소 TLS 1.2 클라이언트. tcp.c 위에 얹혀서 실제
 * HTTPS 사이트에 (인증서 신뢰 체인 검증 없이) 접속할 수 있게 한다.
 *
 * 지원 범위 (의도적으로 좁게 잡음):
 *   - TLS 1.2만. TLS 1.3/1.1/1.0/SSL은 지원하지 않는다.
 *   - 암호모음(cipher suite) 단 하나: TLS_RSA_WITH_AES_128_CBC_SHA256
 *     (0x003C). RSA 키교환(순방향 비밀성 없음) + AES-128-CBC +
 *     HMAC-SHA256. ECDHE 계열은 타원곡선 연산이 필요해 구현하지
 *     않았다 — 그래서 RSA 키교환을 막아둔 최신 서버와는 접속이 안
 *     될 수 있다(알려진 한계).
 *   - SNI(Server Name Indication) 확장은 보낸다(이름 기반 가상호스팅
 *     서버 다수와 접속하려면 사실상 필수).
 *
 * 알려진 한계(x509_min.h와 동일한 맥락 — 정직하게 문서화):
 *   - 인증서 체인/CA 신뢰 검증을 하지 않는다.
 *   - 호스트명 검증(SAN/CN과 접속 대상 host 일치)을 하지 않는다.
 *   - CBC MAC 검증/패딩 검사가 상수시간이 아니다(타이밍 사이드채널
 *     이론적으로 가능 — 패딩 오라클 공격류에 대한 방어 없음).
 *   즉 "암호화 자체는 되지만 서버 신원을 확인하지 않고, 사이드채널
 *   방어도 없는" 수준 — 실사용 브라우저급 보안이 아니라 "평문 HTTP보다
 *   낫고, HTTPS 사이트 텍스트를 실제로 받아볼 수 있는" 학습/실험용
 *   구현이다. jash/browser는 접속 시 이 사실을 사용자에게 알린다.
 */

#include <stdint.h>

/* dst_ip로 TCP 연결 후 TLS 핸드셰이크까지 완료한다. sni_host는
 * ClientHello의 server_name 확장에 넣을 호스트명(NULL이면 생략).
 * 성공 1, 실패(TCP 실패/핸드셰이크 실패/RSA 아닌 인증서 등) 0. */
int tls_connect(const char *sni_host, uint32_t dst_ip, uint16_t dst_port, uint32_t timeout_ticks);

int tls_send(const void *data, uint32_t len, uint32_t timeout_ticks);

/* 서버가 연결을 닫을 때(close_notify 또는 TCP FIN)까지 애플리케이션
 * 데이터를 복호화해서 buf에 채운다. 반환값은 실제로 채운 바이트 수. */
uint32_t tls_recv_until_close(void *buf, uint32_t buf_size, uint32_t timeout_ticks);

void tls_close(void);

#endif
