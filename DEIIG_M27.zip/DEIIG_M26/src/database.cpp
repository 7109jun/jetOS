#include "database.hpp"

#include <algorithm>
#include <cctype>
#include <optional>
#include <fstream>
#include <iomanip>
#include <sstream>

namespace deiig::database {
namespace fs = std::filesystem;

static std::string hex_encode(const std::string& value) {
    static constexpr char hex[] = "0123456789ABCDEF";
    std::string out;
    out.reserve(value.size() * 2);
    for (unsigned char c : value) {
        out.push_back(hex[c >> 4]);
        out.push_back(hex[c & 0x0F]);
    }
    return out;
}

static bool hex_decode(const std::string& value, std::string& out) {
    if (value.size() % 2 != 0) return false;
    out.clear();
    out.reserve(value.size() / 2);
    auto nibble = [](char c) -> int {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        return -1;
    };
    for (std::size_t i = 0; i < value.size(); i += 2) {
        const int hi = nibble(value[i]);
        const int lo = nibble(value[i + 1]);
        if (hi < 0 || lo < 0) return false;
        out.push_back(static_cast<char>((hi << 4) | lo));
    }
    return true;
}

static std::vector<std::string> split(const std::string& line, char delimiter) {
    std::vector<std::string> out;
    std::string current;
    for (char c : line) {
        if (c == delimiter) {
            out.push_back(current);
            current.clear();
        } else {
            current.push_back(c);
        }
    }
    out.push_back(current);
    return out;
}

static bool valid_identifier(const std::string& value) {
    if (value.empty()) return false;
    auto is_start = [](unsigned char c) { return std::isalpha(c) || c == '_'; };
    auto is_body = [](unsigned char c) { return std::isalnum(c) || c == '_'; };
    if (!is_start(static_cast<unsigned char>(value.front()))) return false;
    return std::all_of(value.begin() + 1, value.end(), [&](char c) { return is_body(static_cast<unsigned char>(c)); });
}

static bool unique_columns(const std::vector<std::string>& columns) {
    std::vector<std::string> copy = columns;
    std::sort(copy.begin(), copy.end());
    return std::adjacent_find(copy.begin(), copy.end()) == copy.end();
}

bool load(const fs::path& path, Database& db, std::string& error) {
    db.tables.clear();
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        if (!fs::exists(path)) return true;
        error = "cannot open database";
        return false;
    }

    std::string line;
    Table* current = nullptr;
    bool header_seen = false;
    while (std::getline(input, line)) {
        if (line.empty()) continue;
        if (!header_seen) {
            if (line != "DEIIGDB 1") {
                error = "invalid database header";
                return false;
            }
            header_seen = true;
            continue;
        }
        if (line.rfind("TABLE|", 0) == 0) {
            const auto parts = split(line, '|');
            if (parts.size() != 2) { error = "invalid TABLE record"; return false; }
            std::string table_name;
            if (!hex_decode(parts[1], table_name)) { error = "invalid table name encoding"; return false; }
            db.tables.push_back({table_name, {}, {}});
            current = &db.tables.back();
            continue;
        }
        if (!current) { error = "record before TABLE"; return false; }
        if (line.rfind("COLUMNS|", 0) == 0) {
            const auto parts = split(line, '|');
            current->columns.clear();
            for (std::size_t i = 1; i < parts.size(); ++i) {
                std::string col;
                if (!hex_decode(parts[i], col)) { error = "invalid column encoding"; return false; }
                current->columns.push_back({col});
            }
            continue;
        }
        if (line.rfind("ROW|", 0) == 0) {
            const auto parts = split(line, '|');
            std::vector<std::string> row;
            for (std::size_t i = 1; i < parts.size(); ++i) {
                std::string value;
                if (!hex_decode(parts[i], value)) { error = "invalid row encoding"; return false; }
                row.push_back(value);
            }
            if (row.size() != current->columns.size()) { error = "row/column count mismatch"; return false; }
            current->rows.push_back(std::move(row));
            continue;
        }
        error = "unknown database record";
        return false;
    }
    if (!header_seen) {
        error = "empty database file";
        return false;
    }
    return true;
}

bool save(const fs::path& path, const Database& db, std::string& error) {
    std::error_code ec;
    if (!path.parent_path().empty()) fs::create_directories(path.parent_path(), ec);
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output) { error = "cannot write database"; return false; }

    output << "DEIIGDB 1\n";
    for (const auto& table : db.tables) {
        output << "TABLE|" << hex_encode(table.name) << '\n';
        output << "COLUMNS";
        for (const auto& col : table.columns) output << '|' << hex_encode(col.name);
        output << '\n';
        for (const auto& row : table.rows) {
            output << "ROW";
            for (const auto& value : row) output << '|' << hex_encode(value);
            output << '\n';
        }
    }
    if (!output.good()) { error = "database write failed"; return false; }
    return true;
}

Table* find_table(Database& db, const std::string& name) {
    for (auto& table : db.tables) if (table.name == name) return &table;
    return nullptr;
}

const Table* find_table(const Database& db, const std::string& name) {
    for (const auto& table : db.tables) if (table.name == name) return &table;
    return nullptr;
}

bool create_table(Database& db, const std::string& name, const std::vector<std::string>& columns, std::string& error) {
    if (!valid_identifier(name)) { error = "invalid table name"; return false; }
    if (columns.empty()) { error = "table needs at least one column"; return false; }
    if (!std::all_of(columns.begin(), columns.end(), [](const std::string& c) { return valid_identifier(c); })) {
        error = "invalid column name";
        return false;
    }
    if (!unique_columns(columns)) { error = "duplicate column name"; return false; }
    if (find_table(db, name)) { error = "table already exists"; return false; }
    Table table;
    table.name = name;
    for (const auto& column : columns) table.columns.push_back({column});
    db.tables.push_back(std::move(table));
    return true;
}

bool drop_table(Database& db, const std::string& name, std::string& error) {
    const auto it = std::find_if(db.tables.begin(), db.tables.end(), [&](const Table& t) { return t.name == name; });
    if (it == db.tables.end()) { error = "table not found"; return false; }
    db.tables.erase(it);
    return true;
}

bool insert_row(Database& db, const std::string& table, const std::vector<std::string>& values, std::string& error) {
    Table* t = find_table(db, table);
    if (!t) { error = "table not found"; return false; }
    if (values.size() != t->columns.size()) { error = "expected " + std::to_string(t->columns.size()) + " values"; return false; }
    t->rows.push_back(values);
    return true;
}

bool update_cell(Database& db, const std::string& table, std::size_t row, const std::string& column, const std::string& value, std::string& error) {
    Table* t = find_table(db, table);
    if (!t) { error = "table not found"; return false; }
    if (row >= t->rows.size()) { error = "row out of range"; return false; }
    const auto it = std::find_if(t->columns.begin(), t->columns.end(), [&](const Column& c) { return c.name == column; });
    if (it == t->columns.end()) { error = "column not found"; return false; }
    const auto index = static_cast<std::size_t>(std::distance(t->columns.begin(), it));
    t->rows[row][index] = value;
    return true;
}

bool delete_row(Database& db, const std::string& table, std::size_t row, std::string& error) {
    Table* t = find_table(db, table);
    if (!t) { error = "table not found"; return false; }
    if (row >= t->rows.size()) { error = "row out of range"; return false; }
    t->rows.erase(t->rows.begin() + static_cast<std::ptrdiff_t>(row));
    return true;
}

std::vector<std::vector<std::string>> select_rows(const Database& db, const std::string& table, const std::string& where_column, const std::string& where_value) {
    const Table* t = find_table(db, table);
    if (!t) return {};
    std::optional<std::size_t> where_index;
    if (!where_column.empty()) {
        for (std::size_t i = 0; i < t->columns.size(); ++i) {
            if (t->columns[i].name == where_column) { where_index = i; break; }
        }
        if (!where_index) return {};
    }
    std::vector<std::vector<std::string>> rows;
    for (const auto& row : t->rows) {
        if (where_index && row[*where_index] != where_value) continue;
        rows.push_back(row);
    }
    return rows;
}

std::string format_table(const Table& table) {
    std::vector<std::size_t> widths;
    for (const auto& c : table.columns) widths.push_back(c.name.size());
    for (const auto& row : table.rows) {
        for (std::size_t i = 0; i < row.size(); ++i) widths[i] = std::max(widths[i], row[i].size());
    }
    std::ostringstream out;
    auto border = [&] {
        out << '+';
        for (const auto w : widths) out << std::string(w + 2, '-') << '+';
        out << '\n';
    };
    border();
    out << '|';
    for (std::size_t i = 0; i < table.columns.size(); ++i) out << ' ' << std::left << std::setw(static_cast<int>(widths[i])) << table.columns[i].name << " |";
    out << '\n';
    border();
    for (const auto& row : table.rows) {
        out << '|';
        for (std::size_t i = 0; i < row.size(); ++i) out << ' ' << std::left << std::setw(static_cast<int>(widths[i])) << row[i] << " |";
        out << '\n';
    }
    border();
    out << table.rows.size() << " row(s)\n";
    return out.str();
}

} // namespace deiig::database
