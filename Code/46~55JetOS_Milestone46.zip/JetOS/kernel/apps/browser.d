kernel/apps/browser.o: kernel/apps/browser.c kernel/apps/browser.h \
 kernel/apps/../../include/jetapi/jetapi.h kernel/apps/../gui/wm.h \
 kernel/apps/../gui/../drivers/console.h kernel/apps/../gui/widget.h \
 kernel/apps/../drivers/console.h kernel/apps/../drivers/keyboard.h \
 kernel/apps/../proc/scheduler.h kernel/apps/../proc/thread.h \
 kernel/apps/../mm/heap.h kernel/apps/../net/net.h \
 kernel/apps/../net/tcp.h kernel/apps/../net/dns.h \
 kernel/apps/../net/tls.h
kernel/apps/browser.h:
kernel/apps/../../include/jetapi/jetapi.h:
kernel/apps/../gui/wm.h:
kernel/apps/../gui/../drivers/console.h:
kernel/apps/../gui/widget.h:
kernel/apps/../drivers/console.h:
kernel/apps/../drivers/keyboard.h:
kernel/apps/../proc/scheduler.h:
kernel/apps/../proc/thread.h:
kernel/apps/../mm/heap.h:
kernel/apps/../net/net.h:
kernel/apps/../net/tcp.h:
kernel/apps/../net/dns.h:
kernel/apps/../net/tls.h:
