kernel/net/crypto/der.o: kernel/net/crypto/der.c kernel/net/crypto/der.h
kernel/net/crypto/der.h:
