/*
 * JetOS - kernel/compat/msvcrt.c (Milestone 50)
 * msvcrt.h에 선언된 함수들의 구현. win32.c와 마찬가지로 전부 ms_abi.
 */

#include "msvcrt.h"
#include "../mm/heap.h"
#include "../drivers/serial.h"
#include "../proc/thread.h"
#include "../fs/jetfs.h" /* Milestone 51: 진짜 파일 스트림 */

/* Milestone 50: __iob_func 설계는 msvcrt.h 상단 주석 참고 — 실제
 * Windows _iobuf 레이아웃을 흉내낼 필요가 전혀 없다(포인터 값 비교만
 * 하므로). 인덱스 0/1/2 = stdin/stdout/stderr, 그 외 슬롯은 안 씀. */
static jetos_FILE g_iob[3];

/* ---- Milestone 51: 진짜 파일 스트림 ----
 * jetfs_read/jetfs_write가 "한 번에 통째로"만 지원해서(스트리밍 API
 * 아님 — jetfs.h 참고), fopen 시점에 파일 전체를 메모리에 올리고
 * fclose 시점에 통째로 다시 쓴다. 큰 파일에는 안 맞지만(정직한 한계),
 * 설정 파일 등 절대다수의 "평범한 프로그램" 시나리오는 충분히 커버.
 */
#define FMODE_READ 0
#define FMODE_WRITE 1

typedef struct {
    char path[128];
    uint8_t *buf;
    uint64_t size;   /* 현재 논리적 내용 길이 */
    uint64_t cap;    /* buf에 할당된 바이트 수 */
    uint64_t pos;
    int mode;
    int eof;
    int dirty;
} real_file_t;

static int is_console_file(jetos_FILE *f) {
    return f == &g_iob[0] || f == &g_iob[1] || f == &g_iob[2];
}

static void real_file_ensure_cap(real_file_t *rf, uint64_t need) {
    if (need <= rf->cap) return;
    uint64_t new_cap = rf->cap ? rf->cap * 2 : 4096;
    while (new_cap < need) new_cap *= 2;
    uint8_t *nb = (uint8_t *)kmalloc((uint32_t)new_cap);
    if (rf->buf) {
        for (uint64_t i = 0; i < rf->size; i++) nb[i] = rf->buf[i];
        kfree(rf->buf);
    }
    rf->buf = nb;
    rf->cap = new_cap;
}

void msvcrt_init(void) {
    for (int i = 0; i < 3; i++) {
        uint8_t *b = g_iob[i]._opaque;
        for (int k = 0; k < 48; k++) b[k] = 0;
    }
}

/* Milestone 50 (수정): 이 mingw 툴체인이 실제로 만드는 코드는
 * "__iob_func"라는 이름으로 임포트하면서도 UCRT의 __acrt_iob_func처럼
 * 정수 인덱스 인자를 넘겨 바로 그 인덱스의 FILE*를 반환받는 방식으로
 * 호출한다(`mov ecx,1; call __iob_func`처럼 — 레거시 "인자 없이 배열
 * 베이스 반환" 관례가 아니었다). 실제 실행 후 fputc가 정확한 문자
 * 개수만큼 불렸는데도 아무 것도 출력되지 않는 문제를 커널 디버그
 * 트레이스로 직접 잡아서 알아낸 것 — 처음엔 인자 없는 구버전 시그니처로
 * 짰다가 이 실기 확인으로 고쳤다. 범위를 벗어난 인덱스는 stdout으로
 * 방어적으로 클램프. */
jetos_FILE *WINAPI __iob_func(int index) {
    if (index < 0 || index > 2) index = 1;
    return &g_iob[index];
}

/* Milestone 50: PE 쪽은 아직(M44의 ELF argv 작업과 달리) 진짜 커맨드
 * 라인을 pe_execute까지 못 받는다 — win32.c의 GetCommandLineA와 같은
 * 이유로 정직하게 프로그램 이름 하나만 있는 최소 argv를 준다. 이거면
 * "argv[0]만 보는" 절대다수의 간단한 프로그램은 문제없이 main()에
 * 진입할 수 있다. */
static char g_argv0[] = "program.exe";
static char *g_argv[2] = { g_argv0, (char *)0 };
static char *g_envp[1] = { (char *)0 };
char **g_win32_initenv = g_envp; /* Milestone 50: __initenv 데이터 임포트 대상 — msvcrt.h 주석 참고 */

int WINAPI __getmainargs(int *argc, char ***argv, char ***envp,
                          int do_wildcard, void *startinfo) {
    (void)do_wildcard; (void)startinfo;
    /* Milestone 52: jash의 run이 실제로 넘긴 인자가 있으면 그걸 쓰고,
     * 없으면(예: kernel_entry.c의 부팅 자체테스트처럼 pe_execute(path,
     * NULL)로 부른 경우) 프로그램 이름 하나짜리 최소 argv로 안전하게
     * 대체한다. */
    char **real_argv;
    int real_argc = win32_get_argv(&real_argv);
    if (argc) *argc = real_argc > 0 ? real_argc : 1;
    if (argv) *argv = real_argc > 0 ? real_argv : g_argv;
    if (envp) *envp = g_envp;
    return 0;
}

int WINAPI __set_app_type(int type) { (void)type; return 0; }
int WINAPI __setusermatherr(void *handler) { (void)handler; return 0; }
static int g_mb_cur_max = 1; /* Milestone 50: 멀티바이트 로케일 미지원 — 항상 1(순수 ASCII) */
int *WINAPI ___mb_cur_max_func(void) { return &g_mb_cur_max; }
static unsigned int g_codepage = 1252; /* Windows-1252(서구) 기본값 — 정직한 한계: 로케일 전환 미지원 */
unsigned int *WINAPI ___lc_codepage_func(void) { return &g_codepage; }

void WINAPI _amsg_exit(int code) {
    serial_write("[msvcrt] _amsg_exit code=");
    serial_write_hex64((uint64_t)code);
    serial_write("\n");
    thread_exit();
}
static int g_commode = 0;
int *WINAPI _commode(void) { return &g_commode; }
static int g_errno = 0;
int *WINAPI _errno(void) { return &g_errno; }
static int g_fmode = 0;
int *WINAPI _fmode(void) { return &g_fmode; }

/* Milestone 50: mingw CRT 시작 코드가 _initterm(begin,end)으로 함수
 * 포인터 배열(초기화 구간 — 예: C++ 전역 생성자)을 순서대로 호출한다.
 * 배열 안에 NULL 항목은 건너뛴다 — 진짜 mainCRTStartup과 동일한 관례. */
void WINAPI _initterm(void **begin, void **end) {
    typedef void (*init_fn)(void);
    for (void **p = begin; p < end; p++) {
        if (*p) ((init_fn)(*p))();
    }
}
void WINAPI _lock(int locknum) { (void)locknum; /* 단일 스레드 프로세스 가정 — 잠글 것 없음 */ }
void WINAPI _unlock(int locknum) { (void)locknum; }

/* Milestone 53: 진짜 atexit 핸들러 실행. _onexit로 등록된 함수들을
 * 프로세스가 정상 종료(exit() 경유)될 때 등록 역순(LIFO — 실제
 * MSVCRT 관례와 동일)으로 실제 호출한다. atexit()는 mingw 헤더에서
 * 보통 _onexit를 부르는 작은 정적 함수로 컴파일되므로 별도 임포트가
 * 없는 경우가 많다 — 그래서 _onexit만 제대로 구현하면 atexit도
 * 자동으로 동작한다. C++ 전역 객체 소멸자가 흔히 이 경로로
 * 등록된다. */
#define MAX_ATEXIT 16
static void (*g_atexit_fns[MAX_ATEXIT])(void);
static int g_atexit_count = 0;

void *WINAPI _onexit(void *fn) {
    if (!fn || g_atexit_count >= MAX_ATEXIT) return (void *)0;
    g_atexit_fns[g_atexit_count++] = (void (*)(void))fn;
    return fn; /* 성공 시 등록한 함수 자신을 그대로 돌려주는 게 진짜 _onexit 관례 */
}

void WINAPI _cexit(void) {
    for (int i = g_atexit_count - 1; i >= 0; i--) {
        if (g_atexit_fns[i]) g_atexit_fns[i]();
    }
    g_atexit_count = 0;
}

__attribute__((noreturn)) void WINAPI abort(void) {
    serial_write("[msvcrt] abort() called\n");
    thread_exit();
    for (;;) {} /* thread_exit이 진짜 noreturn이 아닐 경우를 대비한 안전망 */
}
__attribute__((noreturn)) void WINAPI exit(int code) {
    _cexit(); /* Milestone 53: 등록된 atexit/_onexit 핸들러를 실제 종료 전에 실행 */
    serial_write("[msvcrt] exit(");
    serial_write_hex64((uint64_t)code);
    serial_write(")\n");
    thread_exit();
    for (;;) {}
}

void *WINAPI calloc(uint32_t count, uint32_t size) {
    uint32_t total = count * size; /* Milestone 50: 정직한 한계 — 오버플로 검사 없음(단순 데모 스코프) */
    void *p = kmalloc(total);
    if (p) {
        uint8_t *b = (uint8_t *)p;
        for (uint32_t i = 0; i < total; i++) b[i] = 0;
    }
    return p;
}
void *WINAPI malloc(uint32_t size) { return kmalloc(size); }
void WINAPI free(void *p) { if (p) kfree(p); }

void *WINAPI msvcrt_memcpy(void *dst, const void *src, uint32_t n) {
    uint8_t *d = (uint8_t *)dst; const uint8_t *s = (const uint8_t *)src;
    for (uint32_t i = 0; i < n; i++) d[i] = s[i];
    return dst;
}
void *WINAPI msvcrt_memset(void *dst, int val, uint32_t n) {
    uint8_t *d = (uint8_t *)dst;
    for (uint32_t i = 0; i < n; i++) d[i] = (uint8_t)val;
    return dst;
}
uint32_t WINAPI strlen(const char *s) {
    uint32_t n = 0;
    while (s[n]) n++;
    return n;
}
int WINAPI strncmp(const char *a, const char *b, uint32_t n) {
    for (uint32_t i = 0; i < n; i++) {
        if (a[i] != b[i]) return (int)(unsigned char)a[i] - (int)(unsigned char)b[i];
        if (!a[i]) return 0;
    }
    return 0;
}
char *WINAPI strerror(int err) {
    (void)err;
    return "(strerror not implemented on JetOS)"; /* 정직한 한계 — errno별 메시지 테이블 없음 */
}
uint32_t WINAPI wcslen(const uint16_t *s) {
    uint32_t n = 0;
    while (s[n]) n++;
    return n;
}
void *WINAPI signal(int sig, void *handler) { (void)sig; (void)handler; return (void *)0; /* 시그널 없음 — 항상 "이전 핸들러 없음" */ }
void *WINAPI localeconv(void) { return (void *)0; /* 로케일 세부정보 없음 — NULL(호출자가 널 체크 안 하면 위험하지만 흔한 사용처는 아님) */ }

/* ---- printf 계열 ----
 * Milestone 50: 폭(width)/0-패딩까지는 지원하고, 정밀도(precision)와
 * 왼쪽 정렬(-)은 스코프 밖으로 남긴다(정직한 한계) — 가장 흔한
 * "%d", "%5d", "%02d", "%s", "%x" 패턴은 전부 커버된다. */
static void out_char(jetos_FILE *stream, char c, int *count) {
    if (stream == &g_iob[1] || stream == &g_iob[2]) { serial_putc(c); (*count)++; return; }
    /* Milestone 51: fprintf가 진짜 파일 스트림에도 쓸 수 있어야 한다 —
     * fwrite와 같은 성장 버퍼 로직을 여기서도 그대로 재사용. */
    real_file_t *rf = (real_file_t *)stream;
    if (rf && rf->mode == FMODE_WRITE) {
        real_file_ensure_cap(rf, rf->pos + 1);
        rf->buf[rf->pos++] = (uint8_t)c;
        if (rf->pos > rf->size) rf->size = rf->pos;
        rf->dirty = 1;
    }
    (*count)++;
}
static void out_str(jetos_FILE *stream, const char *s, int *count) {
    while (*s) out_char(stream, *s++, count);
}
static void out_uint(jetos_FILE *stream, uint64_t v, int base, int upper,
                      int width, int zero_pad, int *count) {
    char buf[24];
    static const char *digits_lo = "0123456789abcdef";
    static const char *digits_hi = "0123456789ABCDEF";
    const char *digits = upper ? digits_hi : digits_lo;
    int n = 0;
    if (v == 0) buf[n++] = '0';
    while (v > 0) { buf[n++] = digits[v % (unsigned)base]; v /= (unsigned)base; }
    for (int pad = n; pad < width; pad++) out_char(stream, zero_pad ? '0' : ' ', count);
    while (n > 0) out_char(stream, buf[--n], count);
}
static void out_int(jetos_FILE *stream, int64_t v, int width, int zero_pad, int *count) {
    if (v < 0) {
        out_char(stream, '-', count);
        out_uint(stream, (uint64_t)(-v), 10, 0, width > 0 ? width - 1 : 0, zero_pad, count);
    } else {
        out_uint(stream, (uint64_t)v, 10, 0, width, zero_pad, count);
    }
}

int WINAPI vfprintf(jetos_FILE *stream, const char *fmt, va_list args) {
    int count = 0;
    for (const char *p = fmt; *p; p++) {
        if (*p != '%') { out_char(stream, *p, &count); continue; }
        p++;
        if (*p == '\0') break;
        if (*p == '%') { out_char(stream, '%', &count); continue; }

        int zero_pad = 0, width = 0, long_count = 0;
        if (*p == '0') { zero_pad = 1; p++; }
        while (*p >= '0' && *p <= '9') { width = width * 10 + (*p - '0'); p++; }
        while (*p == 'l') { long_count++; p++; } /* Windows LLP64: %l == %(no l), %ll == 8바이트 */

        switch (*p) {
            case 'd': case 'i': {
                int64_t v = long_count >= 2 ? va_arg(args, long long) : va_arg(args, int);
                out_int(stream, v, width, zero_pad, &count);
                break;
            }
            case 'u': {
                uint64_t v = long_count >= 2 ? va_arg(args, unsigned long long) : va_arg(args, unsigned int);
                out_uint(stream, v, 10, 0, width, zero_pad, &count);
                break;
            }
            case 'x': case 'X': {
                uint64_t v = long_count >= 2 ? va_arg(args, unsigned long long) : va_arg(args, unsigned int);
                out_uint(stream, v, 16, *p == 'X', width, zero_pad, &count);
                break;
            }
            case 'o': {
                uint64_t v = long_count >= 2 ? va_arg(args, unsigned long long) : va_arg(args, unsigned int);
                out_uint(stream, v, 8, 0, width, zero_pad, &count);
                break;
            }
            case 'c': {
                char c = (char)va_arg(args, int);
                out_char(stream, c, &count);
                break;
            }
            case 's': {
                const char *s = va_arg(args, const char *);
                out_str(stream, s ? s : "(null)", &count);
                break;
            }
            case 'p': {
                uint64_t v = (uint64_t)(uintptr_t)va_arg(args, void *);
                out_str(stream, "0x", &count);
                out_uint(stream, v, 16, 0, 16, 1, &count);
                break;
            }
            default:
                out_char(stream, '%', &count);
                out_char(stream, *p, &count);
                break;
        }
    }
    return count;
}

int WINAPI fprintf(jetos_FILE *stream, const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    int r = vfprintf(stream, fmt, args);
    va_end(args);
    return r;
}

int WINAPI fputc(int c, jetos_FILE *stream) {
    int count = 0;
    out_char(stream, (char)c, &count);
    return c;
}

uint32_t WINAPI fwrite(const void *ptr, uint32_t size, uint32_t count, jetos_FILE *stream) {
    const uint8_t *b = (const uint8_t *)ptr;
    uint32_t total = size * count;
    if (is_console_file(stream)) {
        int c = 0;
        for (uint32_t i = 0; i < total; i++) out_char(stream, (char)b[i], &c);
        return count;
    }
    real_file_t *rf = (real_file_t *)stream;
    if (!rf || rf->mode == FMODE_READ) return 0;
    real_file_ensure_cap(rf, rf->pos + total);
    for (uint32_t i = 0; i < total; i++) rf->buf[rf->pos + i] = b[i];
    rf->pos += total;
    if (rf->pos > rf->size) rf->size = rf->pos;
    rf->dirty = 1;
    return count;
}

jetos_FILE *WINAPI fopen(LPCSTR path, LPCSTR mode) {
    if (!path || !mode) return NULL;
    int is_write = (mode[0] == 'w');
    int is_append = (mode[0] == 'a');
    int is_read = (mode[0] == 'r');

    real_file_t *rf = (real_file_t *)kmalloc(sizeof(real_file_t));
    if (!rf) return NULL;
    rf->buf = NULL; rf->size = 0; rf->cap = 0; rf->pos = 0; rf->eof = 0; rf->dirty = 0;
    int i = 0; for (; path[i] && i < 127; i++) rf->path[i] = path[i]; rf->path[i] = '\0';

    if (is_read) {
        uint64_t fsize = 0;
        jetfs_inode_type_t t;
        if (!jetfs_stat(rf->path, &t, &fsize) || t != JETFS_TYPE_FILE) { kfree(rf); return NULL; }
        real_file_ensure_cap(rf, fsize > 0 ? fsize : 1);
        uint64_t got = 0;
        jetfs_read(rf->path, rf->buf, fsize, &got);
        rf->size = got;
        rf->mode = FMODE_READ;
        return (jetos_FILE *)rf;
    }

    if (is_write || is_append) {
        jetfs_inode_type_t t; uint64_t fsize = 0;
        int exists = jetfs_stat(rf->path, &t, &fsize);
        if (!exists) jetfs_create(rf->path, JETFS_TYPE_FILE);
        if (is_append && exists) {
            real_file_ensure_cap(rf, fsize > 0 ? fsize : 1);
            uint64_t got = 0;
            jetfs_read(rf->path, rf->buf, fsize, &got);
            rf->size = got;
            rf->pos = got; /* 이어쓰기는 끝에서 시작 */
        }
        rf->mode = FMODE_WRITE;
        return (jetos_FILE *)rf;
    }

    kfree(rf);
    return NULL; /* 알 수 없는 모드 — 정직한 한계: "r+"/"w+" 등 갱신 모드는 미지원 */
}

int WINAPI fclose(jetos_FILE *stream) {
    if (is_console_file(stream)) return 0; /* 콘솔은 닫을 수 없음 — 조용히 성공 취급 */
    real_file_t *rf = (real_file_t *)stream;
    if (!rf) return -1;
    if (rf->mode == FMODE_WRITE && rf->dirty) {
        jetfs_write(rf->path, rf->buf, rf->size);
    }
    if (rf->buf) kfree(rf->buf);
    kfree(rf);
    return 0;
}

uint32_t WINAPI fread(void *ptr, uint32_t size, uint32_t count, jetos_FILE *stream) {
    if (is_console_file(stream)) return 0; /* 콘솔에서 읽기는 ReadConsoleA 몫 — 정직한 한계 */
    real_file_t *rf = (real_file_t *)stream;
    if (!rf || rf->mode != FMODE_READ) return 0;
    uint64_t want = (uint64_t)size * count;
    uint64_t avail = rf->pos < rf->size ? rf->size - rf->pos : 0;
    uint64_t actual = want < avail ? want : avail;
    uint8_t *d = (uint8_t *)ptr;
    for (uint64_t i = 0; i < actual; i++) d[i] = rf->buf[rf->pos + i];
    rf->pos += actual;
    if (actual < want) rf->eof = 1;
    return size ? (uint32_t)(actual / size) : 0;
}

int WINAPI feof(jetos_FILE *stream) {
    if (is_console_file(stream)) return 0;
    real_file_t *rf = (real_file_t *)stream;
    return rf ? rf->eof : 1;
}

char *WINAPI fgets(char *buf, int n, jetos_FILE *stream) {
    if (is_console_file(stream) || n <= 0) return NULL; /* 콘솔 라인 입력은 ReadConsoleA 몫 */
    real_file_t *rf = (real_file_t *)stream;
    if (!rf || rf->mode != FMODE_READ) return NULL;
    if (rf->pos >= rf->size) { rf->eof = 1; return NULL; }
    int i = 0;
    while (i < n - 1 && rf->pos < rf->size) {
        char c = (char)rf->buf[rf->pos++];
        buf[i++] = c;
        if (c == '\n') break;
    }
    buf[i] = '\0';
    if (rf->pos >= rf->size) rf->eof = 1;
    return buf;
}

int WINAPI fputs(const char *s, jetos_FILE *stream) {
    uint32_t n = strlen(s);
    return (int)fwrite(s, 1, n, stream);
}

int WINAPI fflush(jetos_FILE *stream) {
    if (is_console_file(stream) || !stream) return 0;
    real_file_t *rf = (real_file_t *)stream;
    if (rf->mode == FMODE_WRITE && rf->dirty) {
        jetfs_write(rf->path, rf->buf, rf->size);
        rf->dirty = 0;
    }
    return 0;
}

WINAPI void *__C_specific_handler(void) {
    /* Milestone 50: 정직한 한계 — 진짜 SEH(구조적 예외 처리) 언와인딩은
     * 구현하지 않는다. 크래시 없는 직선 실행 경로의 프로그램은 이
     * 함수를 아예 호출하지 않고 임포트 슬롯만 채워지면 되므로(unwind
     * 정보 테이블이 이 주소를 가리키기만 하면 링크/로드는 문제없음)
     * 대부분의 간단한 프로그램은 이걸로 충분하다. 실제로 예외가
     * 발생하는 코드는 지원 범위 밖 — 페이지 폴트로 이어질 수 있다. */
    return (void *)0;
}

/* ---- KERNEL32 쪽 CRT 초기화 동반 함수들 ---- */
void WINAPI InitializeCriticalSection(void *cs) { (void)cs; /* 단일 스레드 프로세스 가정 */ }
void WINAPI EnterCriticalSection(void *cs) { (void)cs; }
void WINAPI LeaveCriticalSection(void *cs) { (void)cs; }
void WINAPI DeleteCriticalSection(void *cs) { (void)cs; }
void *WINAPI TlsGetValue(DWORD index) { (void)index; return (void *)0; /* TLS 슬롯 미지원 */ }
BOOL WINAPI VirtualProtect(LPVOID addr, uint32_t size, DWORD new_protect, DWORD *old_protect) {
    (void)addr; (void)size; (void)new_protect;
    if (old_protect) *old_protect = PAGE_READWRITE; /* 우리 힙은 전부 RW라 항상 이렇게 답해도 거짓말이 아님 */
    return TRUE;
}
uint32_t WINAPI VirtualQuery(LPCVOID addr, void *info, uint32_t len) { (void)addr; (void)info; (void)len; return 0; }
void *WINAPI SetUnhandledExceptionFilter(void *filter) { (void)filter; return (void *)0; }

int WINAPI MultiByteToWideChar(int codepage, DWORD flags, LPCSTR src, int src_len,
                                uint16_t *dst, int dst_len) {
    (void)codepage; (void)flags;
    /* Milestone 50: 정직한 한계 — 진짜 코드페이지 변환이 아니라 ASCII
     * 바이트를 그대로 zero-extend한 값이다(0-127 범위에서만 정확함).
     * 실제 유니코드/동아시아 코드페이지는 스코프 밖. */
    int n = src_len;
    if (n < 0) { n = 0; while (src[n]) n++; n++; } /* -1이면 널 종단까지(널 포함) */
    if (!dst) return n;
    int copy = n < dst_len ? n : dst_len;
    for (int i = 0; i < copy; i++) dst[i] = (uint16_t)(uint8_t)src[i];
    return copy;
}
int WINAPI WideCharToMultiByte(int codepage, DWORD flags, const uint16_t *src, int src_len,
                                char *dst, int dst_len, LPCSTR default_char, BOOL *used_default) {
    (void)codepage; (void)flags; (void)default_char; (void)used_default;
    int n = src_len;
    if (n < 0) { n = 0; while (src[n]) n++; n++; }
    if (!dst) return n;
    int copy = n < dst_len ? n : dst_len;
    for (int i = 0; i < copy; i++) dst[i] = (char)(src[i] & 0xFF); /* ASCII 범위만 정확 */
    return copy;
}
BOOL WINAPI IsDBCSLeadByteEx(int codepage, uint8_t test_char) {
    (void)codepage; (void)test_char;
    return FALSE; /* DBCS(일본어/중국어 등) 코드페이지 미지원 — 항상 "리드바이트 아님" */
}
