/*
 * JetOS - kernel/kernel_entry.c
 *
 * Milestone 1: Serial Logging / Screen Output / Basic Exception Handling
 *              / UEFI Memory Detection
 * Milestone 2: Physical Memory Manager / Virtual Memory Manager / Kernel
 *              Heap / PIC 리맵 / PIT 타이머 인터럽트
 * Milestone 3: Process / Thread / 라운드로빈 스케줄러(선점형+협조형) / IPC
 */

#include "kernel_entry.h"
#include "kernel.h"
#include "drivers/serial.h"
#include "drivers/console.h"
#include "mm/memmap.h"
#include "mm/pmm.h"
#include "mm/vmm.h"
#include "mm/heap.h"
#include "int/idt.h"
#include "int/pic.h"
#include "int/pit.h"
#include "hal/x86_asm_shim.h"
#include "proc/thread.h"
#include "proc/scheduler.h"
#include "proc/process.h"
#include "proc/ipc.h"
#include "drivers/ahci.h"
#include "fs/jetfs.h"
#include "fs/vfs.h"
#include "shell/terminal.h"
#include "gui/desktop.h"

console_t g_console;

static void log_both(console_t *con, const char *msg) {
    console_print(con, msg);
    serial_write(msg);
}

static void serial_write_uint(uint64_t v) {
    char tmp[20]; int t = 0;
    if (v == 0) { serial_putc('0'); return; }
    while (v > 0) { tmp[t++] = (char)('0' + (v % 10)); v /= 10; }
    while (t > 0) serial_putc(tmp[--t]);
}

/* ===== Milestone 3 데모: 스레드/스케줄러/IPC 동작 증명 ===== */

static volatile int g_demo_remaining = 0;
static ipc_channel_t g_demo_channel;

static void worker_thread_fn(void *arg) {
    const char *label = (const char *)arg;
    for (int i = 1; i <= 5; i++) {
        serial_write("  [thread ");
        serial_write(label);
        serial_write("] iteration ");
        serial_write_uint((uint64_t)i);
        serial_write("\n");
        scheduler_yield(); /* 협조적 양보 (타이머 선점과 별개로도 전환됨을 증명) */
    }
    g_demo_remaining--;
}

static void producer_thread_fn(void *arg) {
    (void)arg;
    for (uint64_t i = 1; i <= 3; i++) {
        serial_write("  [producer] sending ");
        serial_write_uint(i);
        serial_write("\n");
        ipc_send(&g_demo_channel, i * 100);
    }
    g_demo_remaining--;
}

static void consumer_thread_fn(void *arg) {
    (void)arg;
    for (int i = 0; i < 3; i++) {
        uint64_t msg = ipc_receive(&g_demo_channel);
        serial_write("  [consumer] received ");
        serial_write_uint(msg);
        serial_write("\n");
    }
    g_demo_remaining--;
}

static void idle_thread_fn(void *arg) {
    (void)arg;
    for (;;) {
        if (g_demo_remaining == 0) {
            g_demo_remaining = -1; /* 한 번만 출력되도록 sentinel 처리 */
            serial_write("\n=== MILESTONE 3 DEMO COMPLETE (SCHEDULER/THREADS/IPC VERIFIED) ===\n");
            serial_write("=== DESKTOP SHELL(GUI) IS NOW THE ACTIVE FOREGROUND ===\n\n");
        }
        /* zombie reaping: idle은 다른 스레드가 할 일이 없을 때만 실행되므로
         * 여기서 죽은 스레드의 스택/구조체를 안전하게 회수한다. */
        scheduler_reap_dead();
        hal_hlt();
    }
}

void kernel_entry(jetos_boot_info_t *boot_info) {
    /* ---- Milestone 1 : Serial Logging ---- */
    serial_init();
    serial_write("\n=== JETOS KERNEL - MILESTONE 1+2+3 ===\n");
    serial_write("STAGE: KERNEL ENTRY OK (loaded from separate KERNEL.ELF)\n");

    /* ---- Milestone 1 : Screen Output ---- */
    console_init(&g_console, (uint32_t *)boot_info->framebuffer_base,
                 boot_info->width, boot_info->height, boot_info->pixels_per_scanline);
    console_clear(&g_console, g_console.bg_color);
    g_console.cursor_x = 20; g_console.cursor_y = 20;
    log_both(&g_console, "JETOS MILESTONE 4");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "BOOT: OK  (KERNEL.ELF)");

    /* ---- Milestone 1 : Basic Exception Handling (IDT) ---- */
    idt_init();
    serial_write("STAGE: IDT / EXCEPTION HANDLING OK\n");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "IDT: OK");

    /* ---- Milestone 1 : UEFI Memory Detection ---- */
    jetos_memory_summary_t mem;
    memmap_summarize(boot_info->memory_map, boot_info->memory_map_size,
                      boot_info->memory_map_descriptor_size, &mem);
    serial_write("STAGE: UEFI MEMORY MAP PARSED (usable pages=");
    serial_write_uint(mem.usable_pages);
    serial_write(")\n");

    /* ---- Milestone 2 : Physical Memory Manager ---- */
    pmm_init(boot_info->memory_map, boot_info->memory_map_size,
              boot_info->memory_map_descriptor_size);
    pmm_stats_t pstats;
    pmm_get_stats(&pstats);
    serial_write("STAGE: PMM INIT OK  free=");
    serial_write_uint(pstats.free_pages);
    serial_write(" used=");
    serial_write_uint(pstats.used_pages);
    serial_write(" (pages)\n");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "PMM: OK");

    /* ---- Milestone 2 : Virtual Memory Manager ---- */
    vmm_init();
    serial_write("STAGE: VMM INIT OK  (CR3 = JetOS PML4, 0-4GiB identity mapped)\n");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "VMM: OK");

    /* ---- Milestone 2 : Kernel Heap ---- */
    heap_init(64);
    heap_stats_t hstats;
    heap_get_stats(&hstats);
    serial_write("STAGE: HEAP INIT OK  total=");
    serial_write_uint(hstats.total_bytes);
    serial_write(" bytes\n");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "HEAP: OK");

    /* ---- Milestone 2 : Interrupts / Timer (PIC 리맵 + PIT) ---- */
    pic_remap();
    for (int i = 0; i < 16; i++) pic_mask_irq((uint8_t)i);
    pit_init(100); /* 100Hz */
    pic_unmask_irq(0);  /* 타이머 */
    pic_unmask_irq(1);  /* 키보드 */
    pic_unmask_irq(2);  /* PIC2(슬레이브) 캐스케이드 라인 — 이걸 마스크한 채로 두면
                          * IRQ8~15(마우스 IRQ12 포함)가 절대 CPU까지 전달되지 않는다 */
    /* IRQ12(마우스)는 여기서 미리 풀지 않는다 — mouse_init()이 초기화
     * ACK 교환 도중의 경쟁 상태를 피하기 위해 자체적으로 마스크/언마스크를
     * 관리한다 (kernel/drivers/mouse.c 참고). */
    serial_write("STAGE: PIC REMAP + PIT(100Hz) + KBD/MOUSE IRQ READY\n");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "TIMER: READY");

    /* ---- Milestone 3 : Process / Thread / Scheduler / IPC ---- */
    scheduler_init();
    ipc_channel_init(&g_demo_channel);

    process_t *proc = process_create("jetos_demo");
    process_spawn_thread(proc, "idle", idle_thread_fn, NULL);
    process_spawn_thread(proc, "A", worker_thread_fn, (void *)"A");
    process_spawn_thread(proc, "B", worker_thread_fn, (void *)"B");
    process_spawn_thread(proc, "C", worker_thread_fn, (void *)"C");
    process_spawn_thread(proc, "producer", producer_thread_fn, NULL);
    process_spawn_thread(proc, "consumer", consumer_thread_fn, NULL);
    process_spawn_thread(proc, "desktop", desktop_thread_fn, NULL);
    g_demo_remaining = 5; /* A,B,C,producer,consumer (idle/desktop 제외) */

    serial_write("STAGE: SCHEDULER + ");
    serial_write_uint((uint64_t)proc->thread_count);
    serial_write(" THREADS CREATED. ENABLING INTERRUPTS + STARTING MULTITASKING.\n");
    g_console.cursor_x = 20; g_console.cursor_y += 20;
    console_print(&g_console, "SCHEDULER: STARTING");

    hal_sti(); /* 이 시점부터 타이머 선점이 시작된다 */

    /* ---- Milestone 4 : Storage (AHCI) 최초 검증 ----
     * JetOS 자체 파일시스템을 얹기 전에, AHCI 드라이버가 실제로 디스크의
     * 섹터를 정확히 읽어오는지부터 검증한다. 부팅에 사용된 ESP(FAT32)
     * 디스크의 LBA0(부트섹터)을 읽어, FAT32 규격상 항상 마지막 2바이트에
     * 있어야 하는 부트 시그니처 0x55 0xAA를 직접 확인한다. */
    serial_write("STAGE: AHCI INIT...\n");
    int ahci_drives = ahci_init();
    if (ahci_drives > 0) {
        serial_write("STAGE: AHCI INIT OK, drives=");
        serial_write_uint((uint64_t)ahci_drives);
        serial_write("\n");
        uint8_t *sector0 = (uint8_t *)kmalloc(512);
        if (sector0 && ahci_read_sectors(0, 0, 1, sector0)) {
            serial_write("STAGE: AHCI READ LBA0 OK. boot signature = ");
            serial_write_hex64(sector0[510]);
            serial_write(" ");
            serial_write_hex64(sector0[511]);
            serial_write(sector0[510] == 0x55 && sector0[511] == 0xAA ?
                         " (VALID 0x55AA)\n" : " (UNEXPECTED)\n");
            g_console.cursor_x = 20; g_console.cursor_y += 20;
            console_print(&g_console, "AHCI: OK");
        } else {
            serial_write("STAGE: AHCI READ FAILED\n");
        }
        kfree(sector0);
    } else {
        serial_write("STAGE: AHCI INIT FAILED (no controller/drive found)\n");
    }

    /* ---- Milestone 4 : JETFS 파일시스템 + 논리 네임스페이스 + 터미널 ----
     * drive 1이 있으면(테스트에서 mkjetfs로 포맷한 두 번째 디스크) JETFS로
     * 마운트하고, 논리 네임스페이스(:> 등)를 거쳐 터미널 데모 스크립트를
     * 실행해 실제 파일 생성/쓰기/읽기/이름변경/삭제를 증명한다. */
    if (ahci_drives >= 2) {
        if (jetfs_mount(1, 0)) {
            serial_write("STAGE: JETFS MOUNT OK (drive 1)\n");
            g_console.cursor_x = 20; g_console.cursor_y += 20;
            console_print(&g_console, "JETFS: MOUNTED");

            char real_path[64];
            const char *p = vfs_translate(":>/docs", real_path, sizeof(real_path));
            serial_write("STAGE: NAMESPACE ':>/docs' -> '");
            serial_write(p);
            serial_write("'\n");

            terminal_run_demo_script();
            g_console.cursor_x = 20; g_console.cursor_y += 20;
            console_print(&g_console, "TERMINAL DEMO: OK");
        } else {
            serial_write("STAGE: JETFS MOUNT FAILED (drive 1 not JETFS-formatted?)\n");
        }
    } else {
        serial_write("STAGE: JETFS SKIPPED (no second drive attached for data volume)\n");
    }

    scheduler_start(); /* 반환하지 않음: 첫 스레드로 전환 */

    /* 여기 도달하면 안 됨 (안전망) */
    for (;;) { hal_hlt(); }
}
