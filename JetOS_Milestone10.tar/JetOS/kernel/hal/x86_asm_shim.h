/*
 * JetOS - kernel/hal/x86_asm_shim.h
 *
 * ============================== 중요 안내 ==============================
 * JetOS의 설계 원칙은 "Assembly 사용 금지"이다. 커널의 모든 로직(부팅
 * 시퀀스, 메모리 관리, 인터럽트 처리 로직, 콘솔, 드라이버 등)은 100% C로
 * 작성되어 있으며 실제로 그렇다 (이 파일 외 어떤 .c 파일에도 인라인
 * 어셈블리가 없다).
 *
 * 다만 x86_64 아키텍처에는 C 언어 자체로는 절대 표현할 수 없는 소수의
 * "단일 CPU 명령어"가 존재한다 (포트 입출력 IN/OUT, IDT 레지스터 적재
 * LIDT, 인터럽트 비활성화 CLI, CPU 정지 HLT). 이것은 GCC를 포함한 어떤
 * C 컴파일러로도 우회할 수 없는 x86 하드웨어 자체의 제약이며, Linux
 * 커널을 포함한 세상의 모든 "C로 작성된" x86 커널이 동일한 이유로 이런
 * 한 줄짜리 명령어들만은 예외적으로 인라인 어셈블리를 사용한다.
 *
 * 이 파일은 그런 원자적 명령어들만을 이 한 곳에 격리하기 위해 존재
 * 한다. 이 파일을 제외한 JetOS의 어떤 코드도 어셈블리를 포함하지 않으며,
 * 커널의 실질적인 로직(정책, 자료구조, 알고리즘)은 전부 순수 C로
 * 작성되어 있다. 즉 이 파일은 "어셈블리로 프로그래밍"하는 것이 아니라
 * C가 표현 못하는 CPU 명령어에 대한 얇은 포팅 계층(HAL)이다.
 * =========================================================================
 */

#ifndef JETOS_X86_ASM_SHIM_H
#define JETOS_X86_ASM_SHIM_H

#include <stdint.h>

/* 포트 I/O - 16550 UART 등 레거시 장치는 MMIO가 아닌 포트 I/O를 사용한다 */
static inline void hal_outb(uint16_t port, uint8_t val) {
    __asm__ volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}
static inline uint8_t hal_inb(uint16_t port) {
    uint8_t ret;
    __asm__ volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}
/* PCI 설정공간 접근(0xCF8/0xCFC)은 32비트 포트 I/O를 사용한다 */
static inline void hal_outl(uint16_t port, uint32_t val) {
    __asm__ volatile ("outl %0, %1" : : "a"(val), "Nd"(port));
}
static inline uint32_t hal_inl(uint16_t port) {
    uint32_t ret;
    __asm__ volatile ("inl %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

/* IDT 레지스터 적재 */
struct hal_idt_ptr {
    uint16_t limit;
    uint64_t base;
} __attribute__((packed));

static inline void hal_lidt(struct hal_idt_ptr *p) {
    /* "memory" 클로버 필수: 이 명령이 p가 가리키는 메모리를 "읽는다"는
     * 사실을 컴파일러에게 알리지 않으면, 최적화 단계에서 p의 필드에
     * 대한 이전 대입문들이 "아무도 안 읽는 죽은 코드"로 오인되어
     * 제거될 수 있다 (실제로 이 버그로 인해 IDT 리밋이 0으로 로드되어
     * 트리플 폴트가 발생했었다). */
    __asm__ volatile ("lidt (%0)" : : "r"(p) : "memory");
}
static inline void hal_sidt(struct hal_idt_ptr *p) {
    __asm__ volatile ("sidt (%0)" : : "r"(p) : "memory");
}

/* 인터럽트 제어 (memory 클로버: 인터럽트 활성/비활성화 전후로 메모리
 * 접근 순서가 재배치되지 않도록 컴파일러 최적화 장벽 역할도 겸한다) */
static inline void hal_cli(void) { __asm__ volatile ("cli" ::: "memory"); }
static inline void hal_sti(void) { __asm__ volatile ("sti" ::: "memory"); }

/* CPU 정지 (전원 관리용, 무한루프 대체) */
static inline void hal_hlt(void) { __asm__ volatile ("hlt" ::: "memory"); }

/* Page Fault 발생 시 어떤 주소에서 발생했는지는 CR2 레지스터에 담긴다 */
static inline uint64_t hal_read_cr2(void) {
    uint64_t val;
    __asm__ volatile ("mov %%cr2, %0" : "=r"(val));
    return val;
}

/* IDT 게이트에 넣을 코드 세그먼트 셀렉터는 현재 CS 레지스터 값을 그대로
 * 재사용한다 (UEFI가 이미 구성해 둔 64비트 코드 세그먼트) */
static inline uint16_t hal_read_cs(void) {
    uint16_t val;
    __asm__ volatile ("mov %%cs, %0" : "=r"(val));
    return val;
}

/* Virtual Memory Manager가 자체 페이지 테이블을 적용하기 위해 CR3에
 * PML4 물리주소를 적재/조회한다. TLB 플러시는 mov-to-cr3 자체가 수행한다. */
static inline void hal_write_cr3(uint64_t pml4_phys) {
    __asm__ volatile ("mov %0, %%cr3" : : "r"(pml4_phys) : "memory");
}
static inline uint64_t hal_read_cr3(void) {
    uint64_t val;
    __asm__ volatile ("mov %%cr3, %0" : "=r"(val));
    return val;
}

/* 16비트 포트 I/O — RTL8139 등 일부 레지스터(IMR/ISR/CAPR 등)는
 * 16비트 폭으로 접근한다. */
static inline void hal_outw(uint16_t port, uint16_t val) {
    __asm__ volatile ("outw %0, %1" : : "a"(val), "Nd"(port));
}
static inline uint16_t hal_inw(uint16_t port) {
    uint16_t ret;
    __asm__ volatile ("inw %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

#endif /* JETOS_X86_ASM_SHIM_H */
