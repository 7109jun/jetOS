/* JetOS 네이티브 ELF 테스트 프로그램(Milestone 36). libc/CRT 없음 —
 * JetOS의 int $0x80 syscall ABI를 직접 사용해 새로 추가된 파일 I/O
 * 시스템콜(SYS_OPEN/READ/WRITE_FD/CLOSE)을 실제로 행사한다.
 * "파일에 쓰고 -> 닫고 -> 다시 열어서 읽어서 -> 쓴 내용과 같은지"까지
 * 실제 JETFS 위에서 검증하는 왕복 테스트. */

static long jsyscall(long num, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile (
        "int $0x80"
        : "=a"(ret)
        : "a"(num), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory"
    );
    return ret;
}

#define SYS_WRITE    0
#define SYS_EXIT     1
#define SYS_GETTICK  2
#define SYS_BRK      3
#define SYS_OPEN     4
#define SYS_READ     5
#define SYS_WRITE_FD 6
#define SYS_CLOSE    7

static int streq(const char *a, const char *b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

void _start(void) {
    static const char path[] = "/m36_fileio_test.txt";
    static const char payload[] = "Hello from SYS_WRITE_FD, round-tripped through real JETFS!";
    static char readback[128];

    jsyscall(SYS_WRITE, (long)"[test] opening for write...\n", 0, 0);
    long fd_w = jsyscall(SYS_OPEN, (long)path, 1 /* write */, 0);
    if (fd_w < 0) {
        jsyscall(SYS_WRITE, (long)"[test] FAIL: open(write) returned -1\n", 0, 0);
        jsyscall(SYS_EXIT, 1, 0, 0);
    }

    long wrote = jsyscall(SYS_WRITE_FD, fd_w, (long)payload, sizeof(payload) - 1);
    if (wrote != (long)(sizeof(payload) - 1)) {
        jsyscall(SYS_WRITE, (long)"[test] FAIL: SYS_WRITE_FD short/failed write\n", 0, 0);
        jsyscall(SYS_EXIT, 1, 0, 0);
    }
    jsyscall(SYS_CLOSE, fd_w, 0, 0);
    jsyscall(SYS_WRITE, (long)"[test] wrote + closed OK\n", 0, 0);

    long fd_r = jsyscall(SYS_OPEN, (long)path, 0 /* read */, 0);
    if (fd_r < 0) {
        jsyscall(SYS_WRITE, (long)"[test] FAIL: open(read) returned -1\n", 0, 0);
        jsyscall(SYS_EXIT, 1, 0, 0);
    }

    long got = jsyscall(SYS_READ, fd_r, (long)readback, sizeof(readback) - 1);
    readback[got] = '\0';
    jsyscall(SYS_CLOSE, fd_r, 0, 0);

    jsyscall(SYS_WRITE, (long)"[test] read back: ", 0, 0);
    jsyscall(SYS_WRITE, (long)readback, 0, 0);
    jsyscall(SYS_WRITE, (long)"\n", 0, 0);

    if (got == (long)(sizeof(payload) - 1) && streq(readback, payload)) {
        jsyscall(SYS_WRITE, (long)"[test] PASS: file I/O round-trip matched exactly\n", 0, 0);
    } else {
        jsyscall(SYS_WRITE, (long)"[test] FAIL: round-trip mismatch\n", 0, 0);
        jsyscall(SYS_EXIT, 1, 0, 0);
    }

    /* 두 번째 SYS_WRITE_FD 호출이 실제로 "이어붙이기"인지도 확인 */
    long fd_w2 = jsyscall(SYS_OPEN, (long)path, 1, 0);
    static const char more[] = " MORE.";
    jsyscall(SYS_WRITE_FD, fd_w2, (long)more, sizeof(more) - 1);
    jsyscall(SYS_CLOSE, fd_w2, 0, 0);

    long fd_r2 = jsyscall(SYS_OPEN, (long)path, 0, 0);
    static char readback2[128];
    long got2 = jsyscall(SYS_READ, fd_r2, (long)readback2, sizeof(readback2) - 1);
    readback2[got2] = '\0';
    jsyscall(SYS_CLOSE, fd_r2, 0, 0);
    jsyscall(SYS_WRITE, (long)"[test] after append: ", 0, 0);
    jsyscall(SYS_WRITE, (long)readback2, 0, 0);
    jsyscall(SYS_WRITE, (long)"\n", 0, 0);

    static const char expect_len_msg[] = "[test] PASS: append grew the file correctly\n";
    static const char expect_len_fail[] = "[test] FAIL: append did not grow file as expected\n";
    if (got2 == got + (long)(sizeof(more) - 1)) {
        jsyscall(SYS_WRITE, (long)expect_len_msg, 0, 0);
    } else {
        jsyscall(SYS_WRITE, (long)expect_len_fail, 0, 0);
        jsyscall(SYS_EXIT, 1, 0, 0);
    }

    jsyscall(SYS_EXIT, 0, 0, 0);
    for (;;) { }
}
