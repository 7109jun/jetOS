kernel/apps/run_dialog.o: kernel/apps/run_dialog.c \
 kernel/apps/run_dialog.h kernel/apps/../../include/jetapi/jetapi.h \
 kernel/apps/../gui/wm.h kernel/apps/../gui/../drivers/console.h \
 kernel/apps/../gui/widget.h kernel/apps/../drivers/console.h \
 kernel/apps/../proc/scheduler.h kernel/apps/../proc/thread.h \
 kernel/apps/../fs/jetfs.h kernel/apps/../exec/elf_loader.h \
 kernel/apps/../exec/pe_loader.h
kernel/apps/run_dialog.h:
kernel/apps/../../include/jetapi/jetapi.h:
kernel/apps/../gui/wm.h:
kernel/apps/../gui/../drivers/console.h:
kernel/apps/../gui/widget.h:
kernel/apps/../drivers/console.h:
kernel/apps/../proc/scheduler.h:
kernel/apps/../proc/thread.h:
kernel/apps/../fs/jetfs.h:
kernel/apps/../exec/elf_loader.h:
kernel/apps/../exec/pe_loader.h:
