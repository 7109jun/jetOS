#ifndef JETOS_PERM_H
#define JETOS_PERM_H

/*
 * JetOS - kernel/fs/perm.h
 * Milestone 34: 파일 권한/접근 제어 ("10가지 목록" 4번) — 최소 구현.
 *
 * JETFS/FAT32 둘 다 온디스크 inode에 소유자·권한 비트가 없다(M32
 * 문서의 "알려진 한계" 그대로). 이번 마일스톤에서 온디스크 포맷을
 * 확장(inode에 필드 추가)하는 대신, 경로 목록을 별도 파일
 * (/system/readonly.txt, 한 줄에 경로 하나)로 관리하는 소프트웨어
 * 레벨 방식을 택했다 — 이유:
 *   1) inode 구조체를 바꾸면 기존 이미지와의 온디스크 호환이 깨진다
 *      (mkjetfs로 새로 포맷해야 함) — M22/M23이 그랬던 것처럼 정당화될
 *      수도 있지만, 이번엔 "재부팅해도 남는 최소한의 보호"가 목표라
     *  굳이 포맷을 건드릴 필요가 없었다.
 *   2) 강제(enforcement)는 jetfs.c 안이 아니라 각 호출부(jash의
 *      rm/write, notepad 저장, file_manager 삭제)에서 저장/삭제
 *      직전에 이 모듈에 물어보는 방식이다 — "정말로 못 쓰게 막는다"는
 *      커널 레벨 강제가 아니라 "실수로 지우거나 덮어쓰는 걸 막는"
 *      수준의 최소 보호라는 걸 정직하게 문서화해둔다(악의적인 코드가
 *      이 모듈을 거치지 않고 jetfs_write를 직접 부르면 우회된다).
 */

/* path가 읽기 전용으로 표시돼 있으면 1, 아니면(표시 안 됐거나 목록
 * 파일 자체가 없으면) 0. */
int perm_is_readonly(const char *path);

/* path를 읽기 전용(1)으로 표시하거나 해제(0)한다. 즉시
 * /system/readonly.txt에 저장. 성공 시 1, 실패 시 0. */
int perm_set_readonly(const char *path, int readonly);

#endif
