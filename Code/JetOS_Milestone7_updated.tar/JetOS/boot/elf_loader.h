#ifndef JETOS_ELF_LOADER_H
#define JETOS_ELF_LOADER_H

#include "../include/efi/efi.h"

/* ESP의 "\KERNEL.ELF" 를 읽어 PT_LOAD 세그먼트를 물리주소(p_paddr)에
 * 그대로 적재하고, 성공 시 ELF 진입점 주소를 반환한다.
 * 실패하면 0을 반환한다. */
uint64_t elf_load_kernel(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable);

#endif
