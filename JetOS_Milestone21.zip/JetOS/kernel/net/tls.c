/*
 * JetOS - kernel/net/tls.c
 * tls.h 참고. TLS_RSA_WITH_AES_128_CBC_SHA256 하나만 지원하는 최소
 * TLS 1.2 클라이언트. 암호 프리미티브(SHA-256/HMAC/AES/bignum/x509/
 * PRF/RNG)는 kernel/net/crypto/ 아래 각 파일 — 전부 host_test.c로
 * 알려진 벡터와 대조 검증했다(문서의 "호스트 하네스 테스트" 방법론).
 */
#include "tls.h"
#include "tcp.h"
#include "dns.h"
#include "crypto/sha256.h"
#include "crypto/hmac_sha256.h"
#include "crypto/aes128.h"
#include "crypto/bignum.h"
#include "crypto/x509_min.h"
#include "crypto/rsa_pkcs1.h"
#include "crypto/tls_prf.h"
#include "crypto/rng.h"
#include "../drivers/serial.h"
#include <stddef.h>

#define TLS_CONTENT_CHANGE_CIPHER 20
#define TLS_CONTENT_ALERT         21
#define TLS_CONTENT_HANDSHAKE     22
#define TLS_CONTENT_APPDATA       23

#define HS_CLIENT_HELLO        1
#define HS_SERVER_HELLO        2
#define HS_CERTIFICATE        11
#define HS_SERVER_HELLO_DONE  14
#define HS_CLIENT_KEY_EXCHANGE 16
#define HS_FINISHED            20

#define MAX_RECORD 16384
#define MAX_RSA_BYTES 512 /* 4096비트 키까지 */

/* ===== 연결 상태 ===== */
static int g_active = 0;
static int g_client_cipher_active = 0;
static int g_server_cipher_active = 0;
static uint64_t g_client_seq = 0;
static uint64_t g_server_seq = 0;

static aes128_ctx_t g_client_enc_ctx, g_server_dec_ctx;
static uint8_t g_client_mac_key[32];
static uint8_t g_server_mac_key[32];

static sha256_ctx_t g_hs_hash; /* 모든 핸드셰이크 메시지 바이트의 누적 해시 */
static uint8_t g_client_random[32];
static uint8_t g_server_random[32];
static uint8_t g_master_secret[48];

/* 현재 소비 중인 수신 레코드(핸드셰이크 스트림 재조립용) */
static uint8_t g_rx_buf[MAX_RECORD];
static size_t g_rx_len = 0, g_rx_pos = 0;

static void hexdump_status(const char *msg) {
    serial_write("[TLS] "); serial_write(msg); serial_write("\n");
}

/* ---------- 레코드 계층 ---------- */

static int send_record_raw(uint8_t type, const uint8_t *payload, size_t len) {
    uint8_t hdr[5];
    hdr[0] = type;
    hdr[1] = 3; hdr[2] = 3; /* TLS 1.2 */
    hdr[3] = (uint8_t)(len >> 8);
    hdr[4] = (uint8_t)(len);

    uint8_t buf[5 + MAX_RECORD];
    if (len > MAX_RECORD) return 0;
    for (int i = 0; i < 5; i++) buf[i] = hdr[i];
    for (size_t i = 0; i < len; i++) buf[5 + i] = payload[i];
    return tcp_send(buf, (uint32_t)(5 + len), 300);
}

/* MAC용 8바이트 빅엔디안 시퀀스 번호 */
static void put_seq(uint8_t *out, uint64_t seq) {
    for (int i = 0; i < 8; i++) out[7 - i] = (uint8_t)(seq >> (i * 8));
}

static int send_record(uint8_t type, const uint8_t *content, size_t clen) {
    if (!g_client_cipher_active) {
        return send_record_raw(type, content, clen);
    }

    uint8_t mac_input[13 + MAX_RECORD];
    size_t mi = 0;
    put_seq(mac_input, g_client_seq); mi += 8;
    mac_input[mi++] = type;
    mac_input[mi++] = 3; mac_input[mi++] = 3;
    mac_input[mi++] = (uint8_t)(clen >> 8);
    mac_input[mi++] = (uint8_t)(clen);
    for (size_t i = 0; i < clen; i++) mac_input[mi + i] = content[i];
    mi += clen;

    uint8_t mac[32];
    hmac_sha256(g_client_mac_key, 32, mac_input, mi, mac);

    /* content || MAC || padding || padding_length */
    size_t unpadded = clen + 32;
    size_t pad_len = (16 - ((unpadded + 1) % 16)) % 16;
    size_t total = unpadded + pad_len + 1;

    uint8_t plain[MAX_RECORD];
    size_t p = 0;
    for (size_t i = 0; i < clen; i++) plain[p++] = content[i];
    for (int i = 0; i < 32; i++) plain[p++] = mac[i];
    for (size_t i = 0; i < pad_len; i++) plain[p++] = (uint8_t)pad_len;
    plain[p++] = (uint8_t)pad_len;

    uint8_t iv[16];
    rng_bytes(iv, 16);

    uint8_t cipher[MAX_RECORD];
    aes128_cbc_encrypt(&g_client_enc_ctx, iv, plain, cipher, total);

    uint8_t fragment[16 + MAX_RECORD];
    for (int i = 0; i < 16; i++) fragment[i] = iv[i];
    for (size_t i = 0; i < total; i++) fragment[16 + i] = cipher[i];

    g_client_seq++;
    return send_record_raw(type, fragment, 16 + total);
}

/* 핸드셰이크 메시지를 보내면서 동시에 누적 해시에 반영 */
static int send_handshake(uint8_t hs_type, const uint8_t *body, size_t body_len) {
    uint8_t msg[4 + MAX_RECORD];
    msg[0] = hs_type;
    msg[1] = (uint8_t)(body_len >> 16);
    msg[2] = (uint8_t)(body_len >> 8);
    msg[3] = (uint8_t)(body_len);
    for (size_t i = 0; i < body_len; i++) msg[4 + i] = body[i];
    sha256_update(&g_hs_hash, msg, 4 + body_len);
    return send_record(TLS_CONTENT_HANDSHAKE, msg, 4 + body_len);
}

/* 원시 레코드 하나를 받아 g_rx_buf에 채운다(복호화까지 완료된 평문).
 * ChangeCipherSpec은 여기서 플래그만 뒤집고 내부적으로 계속 다음
 * 레코드를 기다린다 — 호출측은 Handshake/Alert/AppData만 본다. */
static int fill_next_record(uint8_t *out_type, uint32_t timeout_ticks) {
    for (;;) {
        uint8_t hdr[5];
        if (tcp_recv_exact(hdr, 5, timeout_ticks) != 5) return 0;
        uint8_t type = hdr[0];
        size_t len = ((size_t)hdr[3] << 8) | hdr[4];
        if (len > MAX_RECORD) return 0;

        uint8_t raw[MAX_RECORD];
        if (tcp_recv_exact(raw, (uint32_t)len, timeout_ticks) != len) return 0;

        if (g_server_cipher_active) {
            if (len < 16 + 32 + 1) return 0; /* IV + 최소 MAC+패딩길이바이트 */
            const uint8_t *iv = raw;
            const uint8_t *ciphertext = raw + 16;
            size_t cipher_len = len - 16;
            if (cipher_len % 16 != 0) return 0;

            uint8_t plain[MAX_RECORD];
            aes128_cbc_decrypt(&g_server_dec_ctx, iv, ciphertext, plain, cipher_len);

            uint8_t pad_len = plain[cipher_len - 1];
            if ((size_t)pad_len + 1 > cipher_len) return 0;
            /* 알려진 한계(tls.h 참고): 패딩 바이트 값 검증이 상수시간이
             * 아니다 — 패딩 오라클류 사이드채널 방어는 없음. */
            size_t content_and_mac_len = cipher_len - pad_len - 1;
            if (content_and_mac_len < 32) return 0;
            size_t content_len = content_and_mac_len - 32;
            const uint8_t *content = plain;
            const uint8_t *mac_recv = plain + content_len;

            uint8_t mac_input[13 + MAX_RECORD];
            size_t mi = 0;
            put_seq(mac_input, g_server_seq); mi += 8;
            mac_input[mi++] = type;
            mac_input[mi++] = 3; mac_input[mi++] = 3;
            mac_input[mi++] = (uint8_t)(content_len >> 8);
            mac_input[mi++] = (uint8_t)(content_len);
            for (size_t i = 0; i < content_len; i++) mac_input[mi + i] = content[i];
            mi += content_len;

            uint8_t mac_calc[32];
            hmac_sha256(g_server_mac_key, 32, mac_input, mi, mac_calc);
            int mac_ok = (memcmp(mac_calc, mac_recv, 32) == 0);
            g_server_seq++;
            if (!mac_ok) { hexdump_status("MAC mismatch on received record — aborting"); return 0; }

            for (size_t i = 0; i < content_len; i++) g_rx_buf[i] = content[i];
            g_rx_len = content_len;
        } else {
            for (size_t i = 0; i < len; i++) g_rx_buf[i] = raw[i];
            g_rx_len = len;
        }
        g_rx_pos = 0;

        if (type == TLS_CONTENT_CHANGE_CIPHER) {
            g_server_cipher_active = 1;
            g_server_seq = 0; /* ChangeCipherSpec 이후 시퀀스 번호 리셋(RFC 5246) */
            continue; /* 이 레코드 자체는 상위로 넘기지 않고 다음 레코드를 계속 기다림 */
        }
        if (type == TLS_CONTENT_HANDSHAKE) {
            sha256_update(&g_hs_hash, g_rx_buf, g_rx_len);
        }
        if (type == TLS_CONTENT_ALERT) {
            hexdump_status("received Alert record — aborting");
            return 0;
        }
        *out_type = type;
        return 1;
    }
}

static int hs_read_bytes(uint8_t *out, size_t n, uint32_t timeout_ticks) {
    while (n > 0) {
        if (g_rx_pos >= g_rx_len) {
            uint8_t type;
            if (!fill_next_record(&type, timeout_ticks)) return 0;
            if (type != TLS_CONTENT_HANDSHAKE) return 0;
        }
        size_t avail = g_rx_len - g_rx_pos;
        size_t take = avail < n ? avail : n;
        for (size_t i = 0; i < take; i++) out[i] = g_rx_buf[g_rx_pos + i];
        g_rx_pos += take;
        out += take;
        n -= take;
    }
    return 1;
}

/* ---------- 핸드셰이크 ---------- */

int tls_connect(const char *sni_host, uint32_t dst_ip, uint16_t dst_port, uint32_t timeout_ticks) {
    g_active = 0;
    g_client_cipher_active = 0;
    g_server_cipher_active = 0;
    g_client_seq = 0;
    g_server_seq = 0;
    g_rx_len = 0; g_rx_pos = 0;
    sha256_init(&g_hs_hash);

    if (!tcp_connect(dst_ip, dst_port, timeout_ticks)) {
        hexdump_status("TCP connect failed");
        return 0;
    }

    /* ---- ClientHello ---- */
    rng_bytes(g_client_random, 32);
    int sni_len = 0;
    if (sni_host) { while (sni_host[sni_len]) sni_len++; }

    uint8_t body[512];
    size_t b = 0;
    body[b++] = 3; body[b++] = 3; /* client_version = TLS 1.2 */
    for (int i = 0; i < 32; i++) body[b++] = g_client_random[i];
    body[b++] = 0; /* session_id length = 0 */
    body[b++] = 0; body[b++] = 2; /* cipher_suites length = 2 */
    body[b++] = 0x00; body[b++] = 0x3C; /* TLS_RSA_WITH_AES_128_CBC_SHA256 */
    body[b++] = 1; body[b++] = 0; /* compression_methods: [null] */

    size_t ext_start = b;
    b += 2; /* extensions total length 자리 — 나중에 채움 */

    /* signature_algorithms 확장 (RFC 5246 7.4.1.4.1). 정적 RSA 키교환
     * 스위트는 ServerKeyExchange 서명이 필요 없어 이론상 선택사항이지만,
     * OpenSSL 3.x는 이게 없으면 "NO_SUITABLE_SIGNATURE_ALGORITHM"로
     * 거부한다(실제로 겪은 문제 — 재현/수정 기록: kernel_entry.c
     * TLS 자체테스트로 로컬 서버에 접속 시 이 확장 누락으로 매번
     * 핸드셰이크 실패했었다). rsa_pkcs1_sha256만 광고해도 충분하다. */
    body[b++] = 0x00; body[b++] = 0x0d; /* extension type = signature_algorithms */
    body[b++] = 0x00; body[b++] = 0x04; /* extension_data length = 4 */
    body[b++] = 0x00; body[b++] = 0x02; /* supported_signature_algorithms length = 2 */
    body[b++] = 0x04; body[b++] = 0x01; /* {sha256, rsa} = rsa_pkcs1_sha256 */

    if (sni_len > 0) {
        body[b++] = 0x00; body[b++] = 0x00; /* extension type = server_name */
        size_t ext_len_pos = b; b += 2;
        size_t list_len_pos = b; b += 2;
        body[b++] = 0x00; /* name_type = host_name */
        body[b++] = (uint8_t)(sni_len >> 8); body[b++] = (uint8_t)sni_len;
        for (int i = 0; i < sni_len; i++) body[b++] = (uint8_t)sni_host[i];
        size_t list_len = b - (list_len_pos + 2);
        body[list_len_pos] = (uint8_t)(list_len >> 8); body[list_len_pos + 1] = (uint8_t)list_len;
        size_t ext_len = b - (ext_len_pos + 2);
        body[ext_len_pos] = (uint8_t)(ext_len >> 8); body[ext_len_pos + 1] = (uint8_t)ext_len;
    }
    size_t total_ext_len = b - (ext_start + 2);
    body[ext_start] = (uint8_t)(total_ext_len >> 8);
    body[ext_start + 1] = (uint8_t)(total_ext_len);

    if (!send_handshake(HS_CLIENT_HELLO, body, b)) { hexdump_status("send ClientHello failed"); tcp_close(); return 0; }

    /* ---- ServerHello ---- */
    uint8_t hs_hdr[4];
    if (!hs_read_bytes(hs_hdr, 4, timeout_ticks)) { hexdump_status("recv ServerHello header failed"); tcp_close(); return 0; }
    if (hs_hdr[0] != HS_SERVER_HELLO) { hexdump_status("expected ServerHello"); tcp_close(); return 0; }
    size_t sh_len = ((size_t)hs_hdr[1] << 16) | ((size_t)hs_hdr[2] << 8) | hs_hdr[3];
    uint8_t sh_body[256];
    if (sh_len > sizeof(sh_body) || !hs_read_bytes(sh_body, sh_len, timeout_ticks)) {
        hexdump_status("recv ServerHello body failed"); tcp_close(); return 0;
    }
    /* sh_body: version(2) random(32) session_id_len(1) session_id(*) cipher_suite(2) compression(1) [extensions...] */
    for (int i = 0; i < 32; i++) g_server_random[i] = sh_body[2 + i];
    uint8_t sess_len = sh_body[34];
    size_t off = 35 + sess_len;
    uint16_t chosen_suite = (uint16_t)((sh_body[off] << 8) | sh_body[off + 1]);
    if (chosen_suite != 0x003C) {
        hexdump_status("server chose unsupported cipher suite (RSA-AES128-CBC-SHA256 only)");
        tcp_close(); return 0;
    }

    /* ---- Certificate ---- */
    if (!hs_read_bytes(hs_hdr, 4, timeout_ticks)) { hexdump_status("recv Certificate header failed"); tcp_close(); return 0; }
    if (hs_hdr[0] != HS_CERTIFICATE) { hexdump_status("expected Certificate"); tcp_close(); return 0; }
    size_t cert_msg_len = ((size_t)hs_hdr[1] << 16) | ((size_t)hs_hdr[2] << 8) | hs_hdr[3];
    static uint8_t cert_msg[MAX_RECORD];
    if (cert_msg_len > sizeof(cert_msg) || !hs_read_bytes(cert_msg, cert_msg_len, timeout_ticks)) {
        hexdump_status("recv Certificate body failed"); tcp_close(); return 0;
    }
    /* cert_msg: certificate_list_len(3) then repeated { cert_len(3) cert_der(*) } — 첫 번째(리프)만 사용 */
    if (cert_msg_len < 6) { hexdump_status("Certificate message too short"); tcp_close(); return 0; }
    size_t leaf_len = ((size_t)cert_msg[3] << 16) | ((size_t)cert_msg[4] << 8) | cert_msg[5];
    if (6 + leaf_len > cert_msg_len) { hexdump_status("Certificate length mismatch"); tcp_close(); return 0; }

    bignum_t server_n, server_e;
    if (!x509_extract_rsa_pubkey(cert_msg + 6, leaf_len, &server_n, &server_e)) {
        hexdump_status("failed to extract RSA public key from certificate (non-RSA cert?)");
        tcp_close(); return 0;
    }

    /* ---- ServerHelloDone ---- */
    if (!hs_read_bytes(hs_hdr, 4, timeout_ticks)) { hexdump_status("recv ServerHelloDone header failed"); tcp_close(); return 0; }
    if (hs_hdr[0] != HS_SERVER_HELLO_DONE) { hexdump_status("expected ServerHelloDone"); tcp_close(); return 0; }
    /* body_len은 항상 0이라 굳이 안 읽어도 되지만, 명세상 있을 수도 있으니 스킵 */
    size_t shd_len = ((size_t)hs_hdr[1] << 16) | ((size_t)hs_hdr[2] << 8) | hs_hdr[3];
    if (shd_len > 0) {
        uint8_t tmp[64];
        if (shd_len > sizeof(tmp) || !hs_read_bytes(tmp, shd_len, timeout_ticks)) { tcp_close(); return 0; }
    }

    /* ---- ClientKeyExchange: RSA(premaster) ---- */
    uint8_t modulus_buf[MAX_RSA_BYTES];
    size_t modulus_bytes = 0;
    for (int i = BIGNUM_MAX_LIMBS - 1; i >= 0; i--) { if (server_n.limb[i]) { modulus_bytes = ((size_t)i + 1) * 4; break; } }
    /* 정확한 바이트 길이(선행 0 제거)로 다시 계산 */
    {
        uint8_t tmp[MAX_RSA_BYTES];
        size_t guess = modulus_bytes;
        while (guess > 0 && !bn_to_bytes_be(&server_n, tmp, guess)) guess++;
        modulus_bytes = guess;
        for (size_t i = 0; i < modulus_bytes; i++) modulus_buf[i] = tmp[i];
    }
    if (modulus_bytes == 0 || modulus_bytes > MAX_RSA_BYTES) { hexdump_status("bad RSA modulus size"); tcp_close(); return 0; }

    uint8_t premaster[48];
    premaster[0] = 3; premaster[1] = 3; /* client_version */
    rng_bytes(premaster + 2, 46);

    uint8_t encrypted_pm[MAX_RSA_BYTES];
    if (!rsa_pkcs1_encrypt(&server_n, &server_e, premaster, 48, encrypted_pm, modulus_bytes)) {
        hexdump_status("RSA encrypt of premaster failed"); tcp_close(); return 0;
    }

    uint8_t cke_body[2 + MAX_RSA_BYTES];
    cke_body[0] = (uint8_t)(modulus_bytes >> 8);
    cke_body[1] = (uint8_t)(modulus_bytes);
    for (size_t i = 0; i < modulus_bytes; i++) cke_body[2 + i] = encrypted_pm[i];
    if (!send_handshake(HS_CLIENT_KEY_EXCHANGE, cke_body, 2 + modulus_bytes)) {
        hexdump_status("send ClientKeyExchange failed"); tcp_close(); return 0;
    }

    /* ---- 키 유도 (RFC 5246 6.3/8.1) ---- */
    uint8_t seed_cr_sr[64];
    for (int i = 0; i < 32; i++) seed_cr_sr[i] = g_client_random[i];
    for (int i = 0; i < 32; i++) seed_cr_sr[32 + i] = g_server_random[i];
    tls_prf(premaster, 48, "master secret", seed_cr_sr, 64, g_master_secret, 48);

    uint8_t seed_sr_cr[64];
    for (int i = 0; i < 32; i++) seed_sr_cr[i] = g_server_random[i];
    for (int i = 0; i < 32; i++) seed_sr_cr[32 + i] = g_client_random[i];
    uint8_t key_block[2 * 32 + 2 * 16]; /* MAC키(32+32) + AES키(16+16). explicit IV라 IV블록 없음 */
    tls_prf(g_master_secret, 48, "key expansion", seed_sr_cr, 64, key_block, sizeof(key_block));

    for (int i = 0; i < 32; i++) g_client_mac_key[i] = key_block[i];
    for (int i = 0; i < 32; i++) g_server_mac_key[i] = key_block[32 + i];
    aes128_init(&g_client_enc_ctx, key_block + 64);
    aes128_init(&g_server_dec_ctx, key_block + 80);

    /* ---- ChangeCipherSpec + Finished ---- */
    uint8_t ccs = 0x01;
    if (!send_record_raw(TLS_CONTENT_CHANGE_CIPHER, &ccs, 1)) { hexdump_status("send ChangeCipherSpec failed"); tcp_close(); return 0; }
    g_client_cipher_active = 1;

    uint8_t hs_hash_snapshot[32];
    {
        sha256_ctx_t copy = g_hs_hash; /* Finished는 "이 메시지 이전까지"의 해시를 씀 */
        sha256_final(&copy, hs_hash_snapshot);
    }
    uint8_t client_verify[12];
    tls_prf(g_master_secret, 48, "client finished", hs_hash_snapshot, 32, client_verify, 12);
    if (!send_handshake(HS_FINISHED, client_verify, 12)) { hexdump_status("send Finished failed"); tcp_close(); return 0; }

    /* 서버 Finished 검증에 쓸 해시 = ClientHello..클라이언트 Finished까지
     * (서버 Finished 자신은 제외해야 함). send_handshake() 직후,
     * 즉 서버 응답을 아직 읽기 전인 지금 시점에 반드시 스냅샷을
     * 떠둬야 한다 — 이후 fill_next_record()가 서버 Finished를 받으면서
     * g_hs_hash를 계속 갱신해버리기 때문. */
    uint8_t hs_hash_before_server_fin[32];
    {
        sha256_ctx_t copy = g_hs_hash;
        sha256_final(&copy, hs_hash_before_server_fin);
    }

    /* ---- 서버의 ChangeCipherSpec + Finished 수신 ---- */
    if (!hs_read_bytes(hs_hdr, 4, timeout_ticks)) { hexdump_status("recv server Finished header failed"); tcp_close(); return 0; }
    if (hs_hdr[0] != HS_FINISHED) { hexdump_status("expected server Finished"); tcp_close(); return 0; }
    size_t fin_len = ((size_t)hs_hdr[1] << 16) | ((size_t)hs_hdr[2] << 8) | hs_hdr[3];
    uint8_t server_verify_recv[32];
    if (fin_len > sizeof(server_verify_recv) || !hs_read_bytes(server_verify_recv, fin_len, timeout_ticks)) {
        hexdump_status("recv server Finished body failed"); tcp_close(); return 0;
    }

    uint8_t server_verify_expect[12];
    tls_prf(g_master_secret, 48, "server finished", hs_hash_before_server_fin, 32, server_verify_expect, 12);
    if (memcmp(server_verify_expect, server_verify_recv, 12) != 0) {
        hexdump_status("server Finished verify_data mismatch — handshake failed");
        tcp_close(); return 0;
    }

    g_active = 1;
    hexdump_status("handshake complete");
    return 1;
}

int tls_send(const void *data, uint32_t len, uint32_t timeout_ticks) {
    (void)timeout_ticks;
    if (!g_active) return 0;
    const uint8_t *p = (const uint8_t *)data;
    uint32_t sent = 0;
    while (sent < len) {
        uint32_t chunk = len - sent;
        if (chunk > MAX_RECORD - 64) chunk = MAX_RECORD - 64; /* MAC+패딩 여유 */
        if (!send_record(TLS_CONTENT_APPDATA, p + sent, chunk)) return 0;
        sent += chunk;
    }
    return 1;
}

uint32_t tls_recv_until_close(void *buf, uint32_t buf_size, uint32_t timeout_ticks) {
    if (!g_active) return 0;
    uint8_t *out = (uint8_t *)buf;
    uint32_t total = 0;
    while (total < buf_size) {
        uint8_t type;
        if (!fill_next_record(&type, timeout_ticks)) break; /* FIN/RST/타임아웃/close_notify 등 */
        if (type != TLS_CONTENT_APPDATA) continue; /* 다른 타입은 무시하고 계속 */
        size_t take = g_rx_len - g_rx_pos;
        if (total + take > buf_size) take = buf_size - total;
        for (size_t i = 0; i < take; i++) out[total + i] = g_rx_buf[g_rx_pos + i];
        g_rx_pos += take;
        total += (uint32_t)take;
    }
    return total;
}

void tls_close(void) {
    g_active = 0;
    tcp_close();
}
