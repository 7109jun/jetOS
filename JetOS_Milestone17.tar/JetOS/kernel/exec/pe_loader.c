/*
 * JetOS - kernel/exec/pe_loader.c
 *
 * PE32+ (.exe) 로더.
 *
 * 구현 참고:
 *   - Wine: dlls/ntdll/loader.c (LdrLoadDll, LdrpMapImage)
 *   - ReactOS: dll/ntdll/ldr/ldrutils.c
 *   - PECOFF 스펙: PE Format (Microsoft Docs)
 *
 * 위 소스들의 코드를 복사한 것이 아니라, 같은 알고리즘(PE 헤더 파싱 →
 * 섹션 적재 → 재배치 → IAT 연결 → 진입점 호출)을 JetOS freestanding C로
 * 독립적으로 재구현한 것이다.
 */

#include "pe_loader.h"
#include "../fs/jetfs.h"
#include "../fs/vfs.h"
#include "../mm/heap.h"
#include "../mm/pmm.h"
#include "../proc/thread.h"
#include "../proc/scheduler.h"
#include "../compat/win32.h"
#include "../drivers/serial.h"
#include <stddef.h>

/* ---- PE 구조체 (PECOFF 스펙 §§3-4) ---- */
#define PE_SIG     0x00004550  /* "PE\0\0" */
#define MZ_SIG     0x5A4D
#define PE32PLUS   0x020B
#define IMAGE_FILE_MACHINE_AMD64 0x8664

#define IMAGE_SCN_MEM_WRITE  0x80000000
#define IMAGE_SCN_CNT_CODE   0x00000020
#define IMAGE_REL_BASED_DIR64 10
#define IMAGE_REL_BASED_HIGHLOW 3

typedef struct { uint16_t e_magic; uint8_t pad[58]; uint32_t e_lfanew; } dos_header_t;

typedef struct {
    uint16_t Machine, NumberOfSections;
    uint32_t TimeDateStamp, PointerToSymbolTable, NumberOfSymbols;
    uint16_t SizeOfOptionalHeader, Characteristics;
} coff_header_t;

typedef struct {
    uint16_t Magic;
    uint8_t  MajorLinkerVersion, MinorLinkerVersion;
    uint32_t SizeOfCode, SizeOfInitializedData, SizeOfUninitializedData;
    uint32_t AddressOfEntryPoint, BaseOfCode;
    uint64_t ImageBase;
    uint32_t SectionAlignment, FileAlignment;
    uint16_t MajorOS, MinorOS, MajorImage, MinorImage, MajorSubsystem, MinorSubsystem;
    uint32_t Win32VersionValue, SizeOfImage, SizeOfHeaders, CheckSum;
    uint16_t Subsystem, DllCharacteristics;
    uint64_t SizeOfStackReserve, SizeOfStackCommit, SizeOfHeapReserve, SizeOfHeapCommit;
    uint32_t LoaderFlags, NumberOfRvaAndSizes;
} optional_header64_t;

typedef struct { uint32_t VirtualAddress, Size; } data_directory_t;

#define IMAGE_DIRECTORY_ENTRY_IMPORT 1
#define IMAGE_DIRECTORY_ENTRY_BASERELOC 5

typedef struct {
    char Name[8];
    uint32_t VirtualSize, VirtualAddress, SizeOfRawData, PointerToRawData;
    uint32_t PointerToRelocations, PointerToLinenumbers;
    uint16_t NumberOfRelocations, NumberOfLinenumbers;
    uint32_t Characteristics;
} section_header_t;

typedef struct {
    uint32_t OriginalFirstThunk, TimeDateStamp, ForwarderChain;
    uint32_t Name, FirstThunk;
} import_descriptor_t;

/* ---- 문자열 헬퍼 ---- */
static int str_eq_i(const char *a, const char *b) {
    while (*a && *b) {
        char ca = *a, cb = *b;
        if (ca >= 'A' && ca <= 'Z') ca += 32;
        if (cb >= 'A' && cb <= 'Z') cb += 32;
        if (ca != cb) return 0;
        a++; b++;
    }
    return *a == *b;
}

/* ---- Win32 스텁 함수 테이블 ----
 * JetOS가 직접 구현한 win32.h 함수들을 이름으로 찾아 IAT에 채워 넣는다.
 * 구현이 없는 함수는 null_stub으로 처리해 EXE가 쓰려고 하면 0을 반환한다. */
typedef struct { const char *name; void *fn; } win32_stub_t;

static DWORD null_stub(void) { return 0; }

static const win32_stub_t g_win32_stubs[] = {
    { "CreateWindowA",       (void *)CreateWindowA },
    { "MessageBoxA",         (void *)MessageBoxA },
    { "CreateFileA",         (void *)CreateFileA },
    { "ReadFile",            (void *)ReadFile },
    { "WriteFile",           (void *)WriteFile },
    { "CloseHandle",         (void *)CloseHandle },
    { "GetFileSize",         (void *)GetFileSize },
    { "VirtualAlloc",        (void *)VirtualAlloc },
    { "VirtualFree",         (void *)VirtualFree },
    { "GetStdHandle",        (void *)GetStdHandle },
    { "lstrlenA",            (void *)lstrlenA },
    { "Sleep",               (void *)Sleep },
    { "ExitProcess",         (void *)ExitProcess },
};
#define WIN32_STUB_COUNT (sizeof(g_win32_stubs)/sizeof(g_win32_stubs[0]))

/* 위 표에 없는 이름은 이름 그대로 unresolved_imports에 기록하고
 * null_stub으로 채운다 (그 자체는 ms_abi 시그니처가 필요 없다 —
 * 인자를 전혀 건드리지 않고 0만 반환하므로 어떤 호출 규약으로
 * 불려도 안전하다). */
static void *find_stub(const char *name, pe_load_result_t *result) {
    for (unsigned i = 0; i < WIN32_STUB_COUNT; i++) {
        if (str_eq_i(g_win32_stubs[i].name, name)) return g_win32_stubs[i].fn;
    }
    if (result->unresolved_count < PE_MAX_UNRESOLVED_IMPORTS) {
        int idx = result->unresolved_count++;
        int i = 0;
        while (name[i] && i < PE_UNRESOLVED_NAME_LEN - 1) { result->unresolved_imports[idx][i] = name[i]; i++; }
        result->unresolved_imports[idx][i] = '\0';
    } else {
        result->unresolved_truncated = 1;
    }
    return (void *)null_stub;
}

/* ---- 메모리 접근 헬퍼 ---- */
static void mem_copy(void *dst, const void *src, uint32_t n) {
    uint8_t *d = (uint8_t *)dst; const uint8_t *s = (const uint8_t *)src;
    for (uint32_t i = 0; i < n; i++) d[i] = s[i];
}
static void mem_zero(void *dst, uint32_t n) {
    uint8_t *d = (uint8_t *)dst;
    for (uint32_t i = 0; i < n; i++) d[i] = 0;
}

/* ---- 진입점 ---- */
void pe_load(const char *path, pe_load_result_t *result) {
    result->error_code = -1;
    result->error_msg = "unknown error";
    result->entry_point = 0;
    result->image_base = 0;
    result->unresolved_count = 0;
    result->unresolved_truncated = 0;

    /* 1. JETFS에서 파일 읽기 */
    char real[128];
    const char *rp = vfs_translate(path, real, sizeof(real));

    uint32_t file_size = 0;
    /* 먼저 크기 파악을 위해 큰 임시 버퍼로 읽기를 시도한다.
     * (jetfs_read는 max_size 초과분을 잘라내고, out_size에 실제 크기를 씀) */
    const uint32_t MAX_EXE_SIZE = 4 * 1024 * 1024; /* 최대 4MB */
    uint8_t *filebuf = (uint8_t *)kmalloc(MAX_EXE_SIZE);
    if (!filebuf) { result->error_msg = "out of memory (file buffer)"; return; }

    if (!jetfs_read(rp, filebuf, MAX_EXE_SIZE, &file_size) || file_size < 64) {
        kfree(filebuf);
        result->error_msg = "file not found or too small";
        return;
    }

    /* 2. MZ → PE 헤더 검증 */
    dos_header_t *dos = (dos_header_t *)filebuf;
    if (dos->e_magic != MZ_SIG || dos->e_lfanew + sizeof(coff_header_t) > file_size) {
        kfree(filebuf); result->error_msg = "not a valid MZ/PE file"; return;
    }

    uint32_t pe_off = dos->e_lfanew;
    uint32_t *pe_sig = (uint32_t *)(filebuf + pe_off);
    if (*pe_sig != PE_SIG) { kfree(filebuf); result->error_msg = "missing PE signature"; return; }

    coff_header_t *coff = (coff_header_t *)(filebuf + pe_off + 4);
    if (coff->Machine != IMAGE_FILE_MACHINE_AMD64) {
        kfree(filebuf); result->error_msg = "not x64 PE"; return;
    }

    optional_header64_t *opt = (optional_header64_t *)(filebuf + pe_off + 4 + sizeof(coff_header_t));
    if (opt->Magic != PE32PLUS) { kfree(filebuf); result->error_msg = "not PE32+ (64-bit)"; return; }

    /* 3. 이미지 메모리 확보 */
    uint32_t image_size = opt->SizeOfImage;
    uint64_t preferred_base = opt->ImageBase;
    uint32_t entry_point_rva = opt->AddressOfEntryPoint; /* filebuf가 해제되기 전에
                                                           * 미리 값을 복사해둔다
                                                           * (opt는 filebuf 안을 가리키므로
                                                           * kfree(filebuf) 이후 이 값을
                                                           * 그대로 참조하면 use-after-free). */

    /* 힙에서 이미지 크기 + 페이지 정렬 패딩만큼 할당한다 (간단하지만 충분함).
     * 실제 주소가 preferred_base와 다를 수 있으므로 재배치 테이블을 적용한다. */
    uint8_t *image = (uint8_t *)kmalloc(image_size + 4096);
    if (!image) { kfree(filebuf); result->error_msg = "out of memory (image)"; return; }

    /* 4096 정렬 */
    uintptr_t image_addr = ((uintptr_t)image + 4095) & ~(uintptr_t)4095;
    uint8_t *base = (uint8_t *)image_addr;
    mem_zero(base, image_size);

    /* 4. 헤더 복사 */
    mem_copy(base, filebuf, opt->SizeOfHeaders);

    /* 5. 섹션 적재 */
    uint32_t sec_off = pe_off + 4 + sizeof(coff_header_t) + coff->SizeOfOptionalHeader;
    section_header_t *sections = (section_header_t *)(filebuf + sec_off);

    for (uint16_t s = 0; s < coff->NumberOfSections; s++) {
        section_header_t *sec = &sections[s];
        if (sec->VirtualAddress + sec->VirtualSize > image_size) continue;
        if (sec->SizeOfRawData > 0 &&
            sec->PointerToRawData + sec->SizeOfRawData <= file_size) {
            mem_copy(base + sec->VirtualAddress,
                     filebuf + sec->PointerToRawData,
                     sec->SizeOfRawData);
        }
    }

    /* 6. 재배치 (Relocation) */
    if (opt->NumberOfRvaAndSizes > IMAGE_DIRECTORY_ENTRY_BASERELOC) {
        data_directory_t *dd = (data_directory_t *)(opt + 1);
        data_directory_t *reloc_dir = &dd[IMAGE_DIRECTORY_ENTRY_BASERELOC];
        int64_t delta = (int64_t)image_addr - (int64_t)preferred_base;

        if (delta != 0 && reloc_dir->VirtualAddress && reloc_dir->Size) {
            uint8_t *reloc_ptr = base + reloc_dir->VirtualAddress;
            uint8_t *reloc_end = reloc_ptr + reloc_dir->Size;

            while (reloc_ptr < reloc_end) {
                uint32_t page_rva = *(uint32_t *)reloc_ptr;
                uint32_t block_size = *(uint32_t *)(reloc_ptr + 4);
                if (!block_size) break;
                uint16_t *entries = (uint16_t *)(reloc_ptr + 8);
                uint32_t entry_count = (block_size - 8) / 2;

                for (uint32_t e = 0; e < entry_count; e++) {
                    uint16_t entry = entries[e];
                    uint8_t type = (uint8_t)(entry >> 12);
                    uint32_t off = entry & 0xFFF;
                    uint64_t *target = (uint64_t *)(base + page_rva + off);

                    if (type == IMAGE_REL_BASED_DIR64) {
                        *target += (uint64_t)delta;
                    } else if (type == IMAGE_REL_BASED_HIGHLOW) {
                        uint32_t *t32 = (uint32_t *)target;
                        *t32 += (uint32_t)delta;
                    }
                }
                reloc_ptr += block_size;
            }
        }
    }

    /* 7. Import Address Table(IAT) 연결 */
    if (opt->NumberOfRvaAndSizes > IMAGE_DIRECTORY_ENTRY_IMPORT) {
        data_directory_t *dd = (data_directory_t *)(opt + 1);
        data_directory_t *imp_dir = &dd[IMAGE_DIRECTORY_ENTRY_IMPORT];

        if (imp_dir->VirtualAddress && imp_dir->Size) {
            import_descriptor_t *desc = (import_descriptor_t *)(base + imp_dir->VirtualAddress);

            while (desc->Name) {
                /* 어떤 DLL에서 임포트하든 JetOS Win32 스텁 테이블에서 이름으로 찾는다.
                 * 아직 KERNEL32.DLL 이외의 DLL을 구분하지 않는다 — 같은 스텁 풀을
                 * 공유한다 (Milestone 7 단순화). */
                uint64_t *iat = (uint64_t *)(base + desc->FirstThunk);
                uint64_t *int_ = desc->OriginalFirstThunk ?
                    (uint64_t *)(base + desc->OriginalFirstThunk) : iat;

                while (*int_) {
                    uint64_t thunk = *int_;
                    const char *func_name = NULL;

                    if (thunk & 0x8000000000000000ULL) {
                        /* ordinal 임포트: 이름 없음 → null_stub */
                        *iat = (uint64_t)(uintptr_t)null_stub;
                    } else {
                        /* 이름 임포트: Hint(2바이트) + Name 문자열 */
                        func_name = (const char *)(base + thunk + 2);
                        *iat = (uint64_t)(uintptr_t)find_stub(func_name, result);
                        serial_write("PE IAT: ");
                        serial_write(func_name ? func_name : "(ordinal)");
                        serial_write(" -> ");
                        serial_write(*iat == (uint64_t)(uintptr_t)null_stub ?
                                     "null_stub\n" : "OK\n");
                    }
                    iat++; int_++;
                }
                desc++;
            }
        }
    }

    kfree(filebuf);

    result->error_code = 0;
    result->error_msg = NULL;
    result->image_base = (uint64_t)image_addr;
    result->entry_point = (uint64_t)(image_addr + entry_point_rva);

    serial_write("PE LOAD OK: entry=");
    serial_write_hex64(result->entry_point);
    serial_write(" base=");
    serial_write_hex64(result->image_base);
    serial_write("\n");
}

/* ---- EXE 스레드 컨텍스트 ---- */
typedef struct {
    char path[128];
} exe_run_ctx_t;

typedef int (*pe_entry_fn)(void) __attribute__((ms_abi));

static void exe_thread_fn(void *arg) {
    exe_run_ctx_t *ctx = (exe_run_ctx_t *)arg;

    serial_write("PE EXECUTE: loading ");
    serial_write(ctx->path);
    serial_write("\n");

    pe_load_result_t res;
    pe_load(ctx->path, &res);

    if (res.error_code != 0) {
        serial_write("PE LOAD FAILED: ");
        serial_write(res.error_msg ? res.error_msg : "?");
        serial_write("\n");
        kfree(ctx);
        thread_exit();
    }

    if (res.unresolved_count > 0) {
        serial_write("PE WARNING: unresolved imports (called as no-op):");
        for (int i = 0; i < res.unresolved_count; i++) {
            serial_write(" ");
            serial_write(res.unresolved_imports[i]);
        }
        if (res.unresolved_truncated) serial_write(" ...");
        serial_write("\n");
    }

    pe_entry_fn entry = (pe_entry_fn)(uintptr_t)res.entry_point;
    int ret = entry();
    serial_write("PE EXIT code=");
    serial_write_hex64((uint64_t)ret);
    serial_write("\n");

    kfree(ctx);
    thread_exit();
}

int pe_execute(const char *path, const char *cmdline) {
    (void)cmdline;
    exe_run_ctx_t *ctx = (exe_run_ctx_t *)kmalloc(sizeof(exe_run_ctx_t));
    if (!ctx) return -1;

    int i = 0;
    while (path[i] && i < 127) { ctx->path[i] = path[i]; i++; }
    ctx->path[i] = '\0';

    thread_t *t = thread_create("exe", exe_thread_fn, ctx);
    return t ? (int)t->id : -1;
}
