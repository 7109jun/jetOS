/*
 * JetOS - kernel/hal/context_switch.c
 *
 * ============================== 중요 안내 ==============================
 * 이 파일은 hal/x86_asm_shim.h 와 같은 이유로 예외적으로 어셈블리를
 * 포함한다: 스레드 전환(콘텍스트 스위치)은 "현재 실행 흐름을 저장하고
 * 완전히 다른 실행 흐름으로 옮겨가는" 동작이며, C 언어의 함수 호출은
 * 언제나 "호출한 지점으로 돌아온다"는 전제를 갖고 있어 이 동작 자체를
 * 표현할 방법이 없다. 모든 "C로 작성된" 커널(xv6, Linux 초기 버전 등)이
 * 동일한 이유로 콘텍스트 스위치 루틴만은 어셈블리로 작성한다.
 *
 * 스위칭 정책, 어떤 스레드를 다음에 실행할지 고르는 스케줄링 알고리즘,
 * 스레드 자료구조, IPC 등 그 외 모든 로직은 kernel/proc/ 이하에 100%
 * 순수 C로 작성되어 있다. 이 파일이 하는 일은 딱 하나 —
 * "현재 callee-saved 레지스터를 스택에 저장하고, RSP를 교체하고,
 * 새 스택에서 callee-saved 레지스터를 복원한 뒤 ret 하는 것" 뿐이다.
 *
 * __attribute__((naked))를 사용해 컴파일러가 자체 프롤로그/에필로그를
 * 생성하지 않도록 한다 (그렇지 않으면 컴파일러가 삽입하는 코드가 우리가
 * 수동으로 조작하는 RSP와 충돌할 수 있다).
 * =========================================================================
 */

#include "context_switch.h"

__attribute__((naked))
void switch_context(uint64_t *old_rsp_out, uint64_t new_rsp) {
    __asm__ volatile (
        /* SysV ABI: old_rsp_out = %rdi, new_rsp = %rsi */
        "pushq %%rbp\n\t"
        "pushq %%rbx\n\t"
        "pushq %%r12\n\t"
        "pushq %%r13\n\t"
        "pushq %%r14\n\t"
        "pushq %%r15\n\t"
        "movq %%rsp, (%%rdi)\n\t"   /* *old_rsp_out = 현재 RSP */
        "movq %%rsi, %%rsp\n\t"     /* RSP = new_rsp (다른 스레드의 스택으로 이동) */
        "popq %%r15\n\t"
        "popq %%r14\n\t"
        "popq %%r13\n\t"
        "popq %%r12\n\t"
        "popq %%rbx\n\t"
        "popq %%rbp\n\t"
        "ret\n\t"
        :
        :
        : "memory"
    );
}
