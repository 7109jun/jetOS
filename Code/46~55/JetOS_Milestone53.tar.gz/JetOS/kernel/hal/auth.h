#ifndef JETOS_AUTH_H
#define JETOS_AUTH_H

#include <stdint.h>

/*
 * JetOS - kernel/hal/auth.h
 * Milestone 34: 사용자 계정 / 로그인 ("10가지 목록" 3번, 단일 사용자).
 * Milestone 48: 진짜 다중 사용자 — 계정 여러 개를 /system/users.txt에
 * "uid:username\n<sha256 hex 64자>" 형식으로 저장하고, 로그인/su가
 * 실제로 scheduler_current()->uid를 바꿔서 kernel/fs/jetfs.c의 파일
 * 소유권 검사에 반영되게 한다(비밀번호 원문은 저장 안 함 —
 * kernel/net/crypto/sha256.c를 TLS 스택과 그대로 공유해서 재구현하지
 * 않았다). 최초로 만들어지는 계정이 uid 0(root/관리자, 모든 파일에
 * 대한 소유권 검사를 우회)이 되고, 이후 계정은 useradd로 1,2,3...을
 * 받는다.
 *
 * 정직한 한계(문서화): 솔트(salt)도 없고 KDF(bcrypt/scrypt 류의 느린
 * 해시)도 아닌 단순 SHA-256 1회 해시라, "진짜 로그인 시스템"이라기보단
 * "부팅하면 그냥 바로 데스크톱"이라는 가장 기본적인 문제를 없애는 최소
 * 구현이다 — 오프라인 사전공격에 취약함을 그대로 남겨둔다(power.h의
 * "실기 미보장" 같은 정직한 한계 표기 전통을 따름). 계정 복구/비밀번호
 * 변경/계정 삭제 UI도 없음. 파일 권한도 rwx 비트가 아니라 "소유자+root만
 * 쓰기 가능, 읽기는 전체 허용"이라는 가장 단순한 모델(jetfs.h 참고).
 */

/* 부팅 시 데스크톱이 실제로 열리기 전에 1회 호출: 계정이 없으면 생성
 * 화면을, 있으면 로그인 화면을 g_console에 직접 그리고 통과할 때까지
 * 블로킹한다. JETFS가 마운트 안 됐으면(두 번째 드라이브 없음 등) 조용히
 * 건너뛴다 — 계정을 저장할 곳이 없는데 강제하면 그냥 못 들어가는 것과
 * 같으므로, 기존 "JETFS SKIPPED" 관례를 따른다. */
void auth_run_gate(void);

/* Milestone 35: 화면 잠금. 계정이 있으면 g_console에 잠금 화면을 그리고
 * 올바른 비밀번호가 입력될 때까지 블로킹한다(내부적으로 auth_run_gate의
 * 로그인 루프와 거의 동일한 코드 경로 재사용). 계정이 없으면(부팅 시
 * JETFS가 없어 게이트 자체를 건너뛴 경우) 잠글 이유가 없으므로 즉시
 * 반환한다. desktop.c의 메인 루프가 자기 자신의 스레드 안에서 동기적으로
 * 호출해야 한다 — auth_run_gate()가 wm_init 이전에 그랬던 것과 같은
 * 이유로, "그리는 스레드가 곧 이 함수를 호출한 스레드"여야 다른 그리기와
 * 겹치지 않는다. */
void auth_lock_screen(void);

/* Milestone 48: uid로 사용자 이름을 조회한다(jash의 whoami/ls -l류가
 * 쓸 수 있게). 못 찾으면 0. */
int auth_username_for_uid(uint32_t uid, char *out, int cap);

/* 새 계정을 만든다. 호출한 스레드가 root(uid 0)가 아니면 실패
 * (-1) — Unix에서 useradd가 root 전용인 것과 같은 이유, 검사는
 * 이 함수 내부에서 강제한다(호출측이 깜빡해도 우회 불가). 성공 시
 * 새로 배정된 uid(항상 기존 최대 uid + 1), 실패 시 -1(권한 없음,
 * 이름 중복, 계정 테이블 꽉 참, 빈 이름/비밀번호 등). */
int auth_add_user(const char *name, const char *pw);

/* 지금 스레드를 다른 계정으로 전환한다("su") — 비밀번호만 맞으면
 * 누구나 다른 계정으로 전환 가능(권한 상승 자체가 su의 목적이므로
 * root 여부는 검사하지 않음). 성공 시 1이고 scheduler_current()->uid가
 * 그 계정의 uid로 바뀐다. 실패(계정 없음/비밀번호 틀림) 시 0. */
int auth_switch_user(const char *name, const char *pw);

#endif
