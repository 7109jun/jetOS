#pragma once
#include <string>
namespace deiig::security { bool command_allowed(const std::string&cmd); int set_mode(const std::string&mode); std::string mode(); }
