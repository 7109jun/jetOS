#ifndef JETOS_X509_MIN_H
#define JETOS_X509_MIN_H

/*
 * JetOS - kernel/net/crypto/x509_min.h
 * Milestone 19: X.509 인증서에서 RSA 공개키(modulus, exponent)만
 * 뽑아내는 최소 파서. 알려진 단순화(문서화):
 *   - 서명 검증을 하지 않는다(발급자 체인/CA 신뢰 검증 없음).
 *   - 유효기간(notBefore/notAfter) 검사 없음.
 *   - 호스트명(subject CN/SAN)과 접속 대상 host 일치 검증 없음.
 * 즉 "암호화는 되지만 서버 신원은 확인하지 않는" MITM에 취약한
 * 상태 — 이게 진짜 트러스트 체인을 갖춘 브라우저급 TLS와의 차이다.
 * jash/browser에는 이 사실을 접속 시 경고로 명시한다.
 */

#include <stdint.h>
#include <stddef.h>
#include "bignum.h"

/* DER 인코딩된 X.509 인증서(들 중 첫 번째, 즉 리프 인증서) buf에서
 * RSA 공개키(modulus n, exponent e)를 뽑아낸다. 성공 1, 실패(RSA가
 * 아니거나 파싱 실패) 0. */
int x509_extract_rsa_pubkey(const uint8_t *der, size_t der_len, bignum_t *out_n, bignum_t *out_e);

#endif
