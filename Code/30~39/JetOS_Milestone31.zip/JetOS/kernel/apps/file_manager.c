/*
 * JetOS - kernel/apps/file_manager.c
 * JetAPI만 사용해 작성된 애플리케이션. 커널 내부 구조체를 전혀 알지
 * 못하며, CreateWindowJ / ListDirectoryJ 만으로 동작한다.
 *
 * Milestone 13: 클릭으로 디렉터리를 드나들 수 있게 되었다 — 창의
 * 콘텐츠 영역 클릭을 wm이 로컬 좌표로 넘겨주면(wm_set_click_callback),
 * 마지막으로 그렸던 목록에서 그 좌표에 해당하는 행을 찾아 디렉터리면
 * cwd를 갱신한다("더블클릭"이 아니라 "클릭 한 번"으로 단순화 — 아직
 * 클릭 타이밍(더블클릭 판별)은 구현되어 있지 않다).
 */

#include <stddef.h>
#include "file_manager.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../drivers/console.h"
#include "../proc/scheduler.h"

#define FM_MAX_ENTRIES 32
#define FM_ROW_H 14
#define FM_TOP_MARGIN 22 /* 경로 표시줄 한 줄 + 여백 */
#define FM_LEFT_MARGIN 8

typedef struct {
    char name[28];
    int is_dir;
    uint32_t size;
} fm_entry_t;

static char g_cwd[192] = "/";
static fm_entry_t g_entries[FM_MAX_ENTRIES];
static int g_entry_count = 0;

typedef struct {
    console_t *dc;
    int x, y;
} fm_draw_ctx_t;

static int str_eq_local(const char *a, const char *b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static void str_copy_local(char *dst, const char *src, int n) {
    int i = 0; for (; src[i] && i < n - 1; i++) dst[i] = src[i];
    dst[i] = '\0';
}

static void fm_entry_cb(const char *name, int is_dir, uint64_t size, void *ctx) {
    fm_draw_ctx_t *d = (fm_draw_ctx_t *)ctx;
    if (g_entry_count < FM_MAX_ENTRIES) {
        fm_entry_t *e = &g_entries[g_entry_count++];
        str_copy_local(e->name, name, sizeof(e->name));
        e->is_dir = is_dir;
        e->size = size;
    }
    d->dc->cursor_x = (uint32_t)d->x;
    d->dc->cursor_y = (uint32_t)d->y;
    console_print(d->dc, is_dir ? "[DIR] " : "      ");
    console_print(d->dc, name);
    d->y += FM_ROW_H;
}

/* cwd/name을 절대경로로 합친다 (아주 단순한 버전 — jash의
 * path_resolve만큼 "."/".."을 전부 지원하지는 않는다; "위로 가기"는
 * fm_go_up()이 별도로 처리한다). */
static void fm_join(const char *cwd, const char *name, char *out, int outsz) {
    int i = 0;
    const char *c = cwd;
    while (*c && i < outsz - 1) out[i++] = *c++;
    if (i == 0 || out[i - 1] != '/') { if (i < outsz - 1) out[i++] = '/'; }
    const char *n = name;
    while (*n && i < outsz - 1) out[i++] = *n++;
    out[i] = '\0';
}

static void fm_go_up(void) {
    int len = 0; while (g_cwd[len]) len++;
    if (len <= 1) return; /* 이미 루트 */
    int i = len - 1;
    if (g_cwd[i] == '/') i--; /* 끝 슬래시는 무시 */
    while (i > 0 && g_cwd[i] != '/') i--;
    if (i <= 0) { g_cwd[0] = '/'; g_cwd[1] = '\0'; }
    else { g_cwd[i] = '\0'; }
}

static void file_manager_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)h; (void)ctx;

    dc->cursor_x = (uint32_t)(x + FM_LEFT_MARGIN);
    dc->cursor_y = (uint32_t)(y + 6);
    console_print(dc, g_cwd);

    g_entry_count = 0;
    int draw_y = y + FM_TOP_MARGIN;

    /* 루트가 아니면 맨 위에 "위로 가기" 항목을 하나 끼워넣는다 —
     * ListDirectoryJ는 실제 dirent만 주므로 이건 합성 항목이다. */
    if (!(g_cwd[0] == '/' && g_cwd[1] == '\0')) {
        fm_entry_t *e = &g_entries[g_entry_count++];
        str_copy_local(e->name, "..", sizeof(e->name));
        e->is_dir = 1;
        e->size = 0;
        dc->cursor_x = (uint32_t)(x + FM_LEFT_MARGIN);
        dc->cursor_y = (uint32_t)draw_y;
        console_print(dc, "[DIR] ..");
        draw_y += FM_ROW_H;
    }

    fm_draw_ctx_t d = { dc, x + FM_LEFT_MARGIN, draw_y };
    int had_any = g_entry_count > 0; /* ".."가 있으면 빈 디렉터리라도 "empty" 메시지 안 뜨게 */
    if (!ListDirectoryJ(g_cwd, fm_entry_cb, &d) && !had_any) {
        dc->cursor_x = (uint32_t)(x + FM_LEFT_MARGIN);
        dc->cursor_y = (uint32_t)draw_y;
        console_print(dc, "(empty or no JETFS volume)");
    }
}

static void file_manager_click_cb(int local_x, int local_y, void *ctx) {
    (void)ctx;
    if (local_x < FM_LEFT_MARGIN) return;
    if (local_y < FM_TOP_MARGIN) return;
    int row = (local_y - FM_TOP_MARGIN) / FM_ROW_H;
    if (row < 0 || row >= g_entry_count) return;

    fm_entry_t *e = &g_entries[row];
    if (e->is_dir) {
        if (str_eq_local(e->name, "..")) {
            fm_go_up();
        } else {
            char next[192];
            fm_join(g_cwd, e->name, next, sizeof(next));
            str_copy_local(g_cwd, next, sizeof(g_cwd));
        }
    }
    /* 파일 클릭은 아직 별다른 동작 없음(미리보기는 향후 과제) */
}

static volatile int g_fm_running = 0;

static void file_manager_on_close(void *ctx) {
    (void)ctx;
    g_fm_running = 0;
}

static void file_manager_thread_fn(void *arg) {
    (void)arg;
    g_fm_running = 1;
    str_copy_local(g_cwd, "/", sizeof(g_cwd));
    JetWindowHandle win = CreateWindowJ("FILE MANAGER", 620, 60, 280, 200, 0x00304030);
    if (win >= 0) {
        wm_set_content_callback(win, file_manager_content_cb, NULL);
        wm_set_close_callback(win, file_manager_on_close, NULL);
        wm_set_click_callback(win, file_manager_click_cb, NULL);
    }
    while (g_fm_running) {
        scheduler_yield();
    }
}

void file_manager_launch(void) {
    static int launched = 0;
    if (launched && g_fm_running) return;
    launched = 1;
    CreateThreadJ("file_manager", file_manager_thread_fn, NULL);
}
