#include "browser.hpp"
#include <cstdlib>
#include <string>
#ifdef _WIN32
#include <windows.h>
#endif
namespace deiig::browser {
static std::string enc(const std::string& s){std::string o; const char* h="0123456789ABCDEF"; for(unsigned char c:s){if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.'||c=='~')o+=char(c);else if(c==' ')o+='+';else{o+='%';o+=h[c>>4];o+=h[c&15];}} return o;}
int open(const std::string& url){
#ifdef _WIN32
    HINSTANCE r=ShellExecuteA(nullptr,"open",url.c_str(),nullptr,nullptr,SW_SHOWNORMAL); return ((INT_PTR)r<=32)?1:0;
#else
    return std::system((std::string("xdg-open \"")+url+"\" >/dev/null 2>&1 &").c_str());
#endif
}
int search(const std::string& engine,const std::string& q){std::string base=engine=="bing"?"https://www.bing.com/search?q=":"https://www.google.com/search?q=";return open(base+enc(q));}
}
