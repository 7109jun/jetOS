kernel/hal/gdt.o: kernel/hal/gdt.c kernel/hal/gdt.h \
 kernel/hal/x86_asm_shim.h
kernel/hal/gdt.h:
kernel/hal/x86_asm_shim.h:
