#ifndef JETOS_PANIC_H
#define JETOS_PANIC_H

#include <stdint.h>

/* 커널 패닉: 화면(빨간 배경)+시리얼에 원인을 출력하고 CPU를 정지시킨다. */
void jetos_panic(const char *reason, uint64_t code, uint64_t addr);

#endif
