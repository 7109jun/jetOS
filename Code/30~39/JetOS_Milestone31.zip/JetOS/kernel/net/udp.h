#ifndef JETOS_UDP_H
#define JETOS_UDP_H

#include <stdint.h>

/*
 * JetOS - kernel/net/udp.h
 * 최소 UDP 구현. 연결 개념이 없으므로 상태 머신도 없다 — 그냥
 * 데이터그램을 보내고, "가장 최근에 특정 로컬 포트로 수신된 데이터그램
 * 하나"를 기억해뒀다가 폴링으로 가져가는 단순한 모델이다(DNS 클라이언트
 * 등 "보내고 하나 받으면 끝"인 용도에 충분).
 */

/* dst_ip:dst_port로 UDP 데이터그램을 보낸다. src_port는 우리 쪽 포트. */
int udp_send(uint32_t dst_ip, uint16_t dst_port, uint16_t src_port, const void *data, uint32_t len);

/* local_port로 수신되는 데이터그램을 기다린다(내부적으로 net_poll 반복
 * 호출). 성공 시 실제 길이 반환, 타임아웃 시 0. out_src_ip/out_src_port에
 * 보낸 쪽 정보도 채워준다(NULL이면 무시). */
uint32_t udp_recv(uint16_t local_port, void *buf, uint32_t buf_size,
                   uint32_t *out_src_ip, uint16_t *out_src_port, uint32_t timeout_ticks);

#endif
