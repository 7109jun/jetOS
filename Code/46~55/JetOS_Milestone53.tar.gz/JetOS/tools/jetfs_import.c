/*
 * JetOS - tools/jetfs_import.c
 *
 * mkjetfs로 포맷된 JETFS 이미지에, 호스트(리눅스) 파일을 그대로 복사해
 * 넣는 도구. 커널의 kernel/fs/jetfs.c를 그대로 재사용하므로(같은
 * 온디스크 레이아웃 로직) mkjetfs.c와 마찬가지로 커널과 100% 호환되는
 * 파일이 만들어진다. ahci_read_sectors/write_sectors만 파일 I/O로
 * 대체한다 — 이게 사실상 jetfs.c를 "호스트에서 실행"시키는 전부다.
 *
 * 사용법: jetfs_import <jetfs이미지> <넣을 로컬파일> <JETFS 내 경로>
 * 예:     jetfs_import build/jetfs.img /tmp/hello.exe /hello.exe
 *
 * 대상 경로가 이미 존재하면 덮어쓴다(내용만 새로 write).
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "../kernel/fs/jetfs.h"

static FILE *g_disk;

/* ---- 커널이 기대하는 저수준 의존성을 호스트 파일 I/O로 대체 ---- */
int ahci_read_sectors(int drive_index, uint64_t lba, uint32_t count, void *buffer) {
    (void)drive_index;
    if (fseek(g_disk, (long)(lba * 512), SEEK_SET) != 0) return 0;
    return fread(buffer, 512, count, g_disk) == count;
}
int ahci_write_sectors(int drive_index, uint64_t lba, uint32_t count, const void *buffer) {
    (void)drive_index;
    if (fseek(g_disk, (long)(lba * 512), SEEK_SET) != 0) return 0;
    size_t n = fwrite(buffer, 512, count, g_disk);
    fflush(g_disk);
    return n == count;
}
void *kmalloc(size_t n) { return malloc(n); }
void kfree(void *p) { free(p); }

/* Milestone 48: jetfs.c가 소유권 검사를 위해 scheduler_current()->uid를
 * 읽는다. 이 호스트 도구엔 진짜 스케줄러/스레드가 없으므로 "항상
 * NULL"을 돌려준다 — kernel/fs/jetfs.c의 current_uid()는 NULL이면
 * JETFS_ROOT_UID(0)로 취급하도록 이미 짜여 있어서, 이 도구로 넣는
 * 파일은 전부 root 소유가 된다(딱 맞는 동작 — mkjetfs가 만드는 루트
 * 디렉터리도 root 소유인 것과 일관됨). thread_t는 정의만 필요하고
 * 실제로 역참조되지 않으므로(항상 NULL 반환) 빈 타입으로 전방
 * 선언한다. */
typedef struct thread_t thread_t;
thread_t *scheduler_current(void) { return NULL; }

int main(int argc, char **argv) {
    if (argc != 4) {
        fprintf(stderr, "사용법: %s <jetfs이미지> <로컬파일> <JETFS내경로>\n", argv[0]);
        fprintf(stderr, "예:     %s build/jetfs.img /tmp/hello.exe /hello.exe\n", argv[0]);
        return 1;
    }
    const char *image_path = argv[1];
    const char *local_path = argv[2];
    const char *jetfs_path = argv[3];
    if (jetfs_path[0] != '/') { fprintf(stderr, "JETFS 경로는 '/'로 시작해야 합니다.\n"); return 1; }

    g_disk = fopen(image_path, "r+b");
    if (!g_disk) { perror("fopen(image)"); return 1; }

    if (!jetfs_mount(0, 0)) { fprintf(stderr, "jetfs_mount 실패 (mkjetfs로 먼저 포맷했나요?)\n"); return 1; }

    FILE *lf = fopen(local_path, "rb");
    if (!lf) { perror("fopen(local file)"); return 1; }
    fseek(lf, 0, SEEK_END);
    long lsize = ftell(lf);
    fseek(lf, 0, SEEK_SET);
    if (lsize < 0) { fprintf(stderr, "로컬 파일 크기 확인 실패\n"); return 1; }
    if ((uint32_t)lsize > JETFS_MAX_FILE_BLOCKS * JETFS_BLOCK_SIZE) {
        fprintf(stderr, "파일이 JETFS 최대 크기(%lu바이트)를 초과합니다: %ld바이트\n",
                (unsigned long)(JETFS_MAX_FILE_BLOCKS * JETFS_BLOCK_SIZE), lsize);
        return 1;
    }
    uint8_t *buf = (uint8_t *)malloc((size_t)lsize);
    if (fread(buf, 1, (size_t)lsize, lf) != (size_t)lsize) { fprintf(stderr, "로컬 파일 읽기 실패\n"); return 1; }
    fclose(lf);

    jetfs_inode_type_t existing_type;
    if (!jetfs_stat(jetfs_path, &existing_type, NULL)) {
        if (!jetfs_create(jetfs_path, JETFS_TYPE_FILE)) {
            fprintf(stderr, "jetfs_create 실패 (부모 디렉터리가 없을 수 있습니다)\n");
            return 1;
        }
    } else if (existing_type != JETFS_TYPE_FILE) {
        fprintf(stderr, "대상 경로가 이미 디렉터리로 존재합니다.\n");
        return 1;
    }

    if (!jetfs_write(jetfs_path, buf, (uint32_t)lsize)) {
        fprintf(stderr, "jetfs_write 실패\n");
        return 1;
    }

    free(buf);
    fclose(g_disk);

    printf("복사 완료: %s (%ld바이트) -> %s (JETFS 내부)\n", local_path, lsize, jetfs_path);
    return 0;
}
