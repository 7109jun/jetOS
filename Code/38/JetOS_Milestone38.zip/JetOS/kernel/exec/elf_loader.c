/*
 * JetOS - kernel/exec/elf_loader.c
 * elf_loader.h 참고.
 */
#include "elf_loader.h"
#include "../fs/jetfs.h"
#include "../fs/vfs.h"
#include "../mm/heap.h"
#include "../mm/pmm.h"
#include "../mm/vmm.h"
#include "../hal/x86_asm_shim.h"
#include "../hal/gdt.h"
#include "../proc/thread.h"
#include "../proc/scheduler.h"
#include "../drivers/serial.h"
#include <stddef.h>

#pragma pack(push, 1)
typedef struct {
    uint8_t  e_ident[16];
    uint16_t e_type;
    uint16_t e_machine;
    uint32_t e_version;
    uint64_t e_entry;
    uint64_t e_phoff;
    uint64_t e_shoff;
    uint32_t e_flags;
    uint16_t e_ehsize;
    uint16_t e_phentsize;
    uint16_t e_phnum;
    uint16_t e_shentsize;
    uint16_t e_shnum;
    uint16_t e_shstrndx;
} elf64_header_t;

typedef struct {
    uint32_t p_type;
    uint32_t p_flags;
    uint64_t p_offset;
    uint64_t p_vaddr;
    uint64_t p_paddr;
    uint64_t p_filesz;
    uint64_t p_memsz;
    uint64_t p_align;
} elf64_phdr_t;
#pragma pack(pop)

#define ET_EXEC 2
#define EM_X86_64 62
#define PT_LOAD 1
#define PF_X 1
#define PF_W 2

#define ELF_STAGING_BUF_SIZE (256 * 1024)
#define USER_STACK_PAGES 4 /* 16KB 스택 */

void elf_load(const char *path, elf_load_result_t *result) {
    result->error_code = -1;
    result->error_msg = "unknown error";
    result->pml4_phys = 0;
    result->entry_point = 0;
    result->user_stack_top = 0;

    char real_path[192];
    const char *p = vfs_translate(path, real_path, sizeof(real_path));

    uint8_t *filebuf = (uint8_t *)kmalloc(ELF_STAGING_BUF_SIZE);
    if (!filebuf) { result->error_msg = "메모리 부족(파일 버퍼)"; return; }

    uint64_t filesize = 0;
    if (!jetfs_read(p, filebuf, ELF_STAGING_BUF_SIZE, &filesize) || filesize < sizeof(elf64_header_t)) {
        kfree(filebuf);
        result->error_msg = "파일을 읽을 수 없음";
        return;
    }

    elf64_header_t *eh = (elf64_header_t *)filebuf;
    if (eh->e_ident[0] != 0x7F || eh->e_ident[1] != 'E' || eh->e_ident[2] != 'L' || eh->e_ident[3] != 'F') {
        kfree(filebuf); result->error_msg = "ELF 매직 불일치"; return;
    }
    if (eh->e_ident[4] != 2) { kfree(filebuf); result->error_msg = "64비트 ELF가 아님"; return; }
    if (eh->e_ident[5] != 1) { kfree(filebuf); result->error_msg = "리틀엔디안 ELF가 아님"; return; }
    if (eh->e_machine != EM_X86_64) { kfree(filebuf); result->error_msg = "x86-64용이 아님"; return; }
    if (eh->e_type != ET_EXEC) { kfree(filebuf); result->error_msg = "정적 실행파일(ET_EXEC)만 지원 (PIE 불가)"; return; }
    if (eh->e_phoff + (uint64_t)eh->e_phnum * eh->e_phentsize > filesize) {
        kfree(filebuf); result->error_msg = "프로그램 헤더가 파일 범위를 벗어남"; return;
    }

    uint64_t pml4 = vmm_create_process_address_space();
    if (!pml4) { kfree(filebuf); result->error_msg = "주소공간 생성 실패"; return; }

    uint64_t user_base = vmm_user_virt_base();
    uint64_t user_size = vmm_user_region_size();

    const elf64_phdr_t *phdrs = (const elf64_phdr_t *)(filebuf + eh->e_phoff);
    uint64_t highest_seg_end = user_base; /* Milestone 20: SYS_BRK 시작점 계산용 */
    for (uint16_t i = 0; i < eh->e_phnum; i++) {
        const elf64_phdr_t *ph = &phdrs[i];
        if (ph->p_type != PT_LOAD) continue;
        if (ph->p_vaddr < user_base || ph->p_vaddr + ph->p_memsz > user_base + user_size) {
            kfree(filebuf);
            result->error_msg = "세그먼트가 유저 영역(vmm_user_virt_base 기준 2MiB) 범위를 벗어남";
            return;
        }
        if (ph->p_offset + ph->p_filesz > filesize) {
            kfree(filebuf); result->error_msg = "세그먼트 데이터가 파일 범위를 벗어남"; return;
        }

        int writable = (ph->p_flags & PF_W) != 0;
        uint64_t seg_start = ph->p_vaddr & ~0xFFFULL;
        uint64_t seg_end = (ph->p_vaddr + ph->p_memsz + 0xFFFULL) & ~0xFFFULL;

        for (uint64_t page_va = seg_start; page_va < seg_end; page_va += PMM_PAGE_SIZE) {
            uint64_t phys = pmm_alloc_page();
            if (!phys) { kfree(filebuf); result->error_msg = "물리 페이지 할당 실패"; return; }
            uint8_t *dst = (uint8_t *)phys; /* 커널은 항상 항등매핑으로 볼 수 있음 */
            for (int k = 0; k < 4096; k++) dst[k] = 0;

            /* 이 페이지와 겹치는 파일 데이터 범위를 계산해서 복사 */
            uint64_t page_end = page_va + 4096;
            uint64_t file_region_start = ph->p_vaddr;
            uint64_t file_region_end = ph->p_vaddr + ph->p_filesz;
            uint64_t copy_start = page_va > file_region_start ? page_va : file_region_start;
            uint64_t copy_end = page_end < file_region_end ? page_end : file_region_end;
            if (copy_start < copy_end) {
                uint64_t file_off = ph->p_offset + (copy_start - ph->p_vaddr);
                uint64_t page_off = copy_start - page_va;
                uint64_t len = copy_end - copy_start;
                for (uint64_t k = 0; k < len; k++) dst[page_off + k] = filebuf[file_off + k];
            }

            if (!vmm_map_user_page(pml4, page_va, phys, writable)) {
                kfree(filebuf); result->error_msg = "페이지 매핑 실패"; return;
            }
        }
        uint64_t seg_end_va = ph->p_vaddr + ph->p_memsz;
        if (seg_end_va > highest_seg_end) highest_seg_end = seg_end_va;
    }

    /* 유저 스택: 유저 영역 맨 끝에서 아래로 USER_STACK_PAGES개 */
    uint64_t stack_top_va = user_base + user_size;
    uint64_t stack_bottom_va = stack_top_va - (uint64_t)USER_STACK_PAGES * PMM_PAGE_SIZE;
    for (uint64_t page_va = stack_bottom_va; page_va < stack_top_va; page_va += PMM_PAGE_SIZE) {
        uint64_t phys = pmm_alloc_page();
        if (!phys) { kfree(filebuf); result->error_msg = "스택 페이지 할당 실패"; return; }
        uint8_t *dst = (uint8_t *)phys;
        for (int k = 0; k < 4096; k++) dst[k] = 0;
        if (!vmm_map_user_page(pml4, page_va, phys, 1)) {
            kfree(filebuf); result->error_msg = "스택 매핑 실패"; return;
        }
    }

    if (eh->e_entry < user_base || eh->e_entry >= user_base + user_size) {
        kfree(filebuf); result->error_msg = "진입점이 유저 영역 밖"; return;
    }

    uint64_t entry_point = eh->e_entry; /* filebuf 해제 전에 미리 복사 (use-after-free 방지) */
    kfree(filebuf);

    result->error_code = 0;
    result->error_msg = NULL;
    result->pml4_phys = pml4;
    result->entry_point = entry_point;
    result->user_stack_top = (stack_top_va - 16) & ~0xFULL; /* 16바이트 정렬, SysV ABI 관례 */
    result->initial_brk = (highest_seg_end + 0xFFFULL) & ~0xFFFULL; /* 페이지 정렬 */
}

__attribute__((noreturn))
void elf_run(const elf_load_result_t *result) {
    hal_write_cr3(result->pml4_phys);
    hal_enter_user_mode(result->entry_point, result->user_stack_top,
                         GDT_SEL_USER_CODE, GDT_SEL_USER_DATA);
}

typedef struct { char path[192]; void (*stdout_sink)(const char *s); } elf_exec_ctx_t;

static void elf_exec_thread_fn(void *arg) {
    elf_exec_ctx_t *ctx = (elf_exec_ctx_t *)arg;
    elf_load_result_t res;
    elf_load(ctx->path, &res);
    if (res.error_code != 0) {
        serial_write("[elf] load failed: ");
        serial_write(res.error_msg ? res.error_msg : "?");
        serial_write("\n");
        kfree(ctx);
        thread_exit();
    }
    /* Milestone 37: 이 프로그램의 SYS_WRITE 출력을 어디로도 더 보낼지
     * 결정 — elf_run()으로 넘어가 유저 코드가 뛰기 전에 지금의(=바로
     * 이 스레드) thread_t에 훅을 걸어둔다. */
    scheduler_current()->stdout_sink = ctx->stdout_sink;
    kfree(ctx);
    /* Milestone 16: 이 스레드가 나중에(타이머 선점 등으로) 잠깐
     * 쉬었다가 다시 스케줄될 때도 자기 프로세스의 주소공간으로 정확히
     * 돌아오도록, 지금 실행중인 스레드(=바로 나 자신)에 이 pml4를
     * 등록해둔다. 이래야 여러 유저 프로세스가 동시에 떠 있어도
     * 스케줄러가 서로의 메모리를 침범하지 않고 정확히 전환해준다. */
    thread_set_address_space(scheduler_current(), res.pml4_phys);
    thread_set_user_brk(scheduler_current(), res.initial_brk); /* Milestone 20 */
    elf_run(&res); /* noreturn */
}

int elf_execute_ex(const char *path, void (*stdout_sink)(const char *s)) {
    elf_exec_ctx_t *ctx = (elf_exec_ctx_t *)kmalloc(sizeof(elf_exec_ctx_t));
    if (!ctx) return 0;
    int i = 0; for (; path[i] && i < (int)sizeof(ctx->path) - 1; i++) ctx->path[i] = path[i];
    ctx->path[i] = '\0';
    ctx->stdout_sink = stdout_sink;
    thread_create("elf_proc", elf_exec_thread_fn, ctx);
    return 1;
}

int elf_execute(const char *path) {
    return elf_execute_ex(path, NULL);
}
