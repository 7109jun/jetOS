#ifndef JETOS_APP_BROWSER_H
#define JETOS_APP_BROWSER_H

/* JetOS - kernel/apps/browser.h
 * Milestone 18: 최소 GUI 웹 브라우저. Milestone 11/12에서 만든 TCP/DNS
 * 스택(kernel/net/)을 그대로 써서 실제 HTTP GET을 하고, 아주 단순한
 * HTML 태그 제거만 거쳐 창에 텍스트로 보여준다 — 진짜 레이아웃/CSS
 * 렌더링은 없다(그건 훨씬 더 큰 과제).
 */

/* 시작메뉴/아이콘에서 바로 실행 — 데모용 기본 페이지를 불러온다. */
void browser_launch(void);

/* jash "browser" 명령 등에서 특정 주소로 바로 열 때 사용.
 * host는 IP 리터럴("10.0.2.2") 또는 도메인 이름("example.com") 둘 다 가능
 * (내부적으로 dns_resolve 사용). */
void browser_launch_url(const char *host, int port, const char *path);

#endif
