kernel/hal/power.o: kernel/hal/power.c kernel/hal/power.h \
 kernel/hal/x86_asm_shim.h kernel/hal/../drivers/serial.h
kernel/hal/power.h:
kernel/hal/x86_asm_shim.h:
kernel/hal/../drivers/serial.h:
