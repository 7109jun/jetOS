/* JetOS 네이티브 ELF 테스트 프로그램. libc/CRT 전혀 없음 — JetOS의
 * int $0x80 시스템콜 ABI(kernel/hal/syscall.h)를 직접 사용한다.
 * 링크 주소는 JetOS의 vmm_user_virt_base()(4GiB)에 고정한다. */

static long jsyscall(long num, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile (
        "int $0x80"
        : "=a"(ret)
        : "a"(num), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory"
    );
    return ret;
}

#define SYS_WRITE 0
#define SYS_EXIT  1
#define SYS_GETTICK 2

void _start(void) {
    static const char msg[] =
        "Hello from a REAL native ELF process, isolated address space, JetOS syscalls!\n";
    jsyscall(SYS_WRITE, (long)msg, 0, 0);

    long tick = jsyscall(SYS_GETTICK, 0, 0, 0);
    static char buf[64];
    int i = 0;
    const char *pre = "tick=";
    for (int k = 0; pre[k]; k++) buf[i++] = pre[k];
    char digits[24]; int dn = 0;
    if (tick == 0) digits[dn++] = '0';
    long v = tick;
    while (v) { digits[dn++] = (char)('0' + (v % 10)); v /= 10; }
    for (int k = dn - 1; k >= 0; k--) buf[i++] = digits[k];
    buf[i++] = '\n';
    buf[i] = '\0';
    jsyscall(SYS_WRITE, (long)buf, 0, 0);

    jsyscall(SYS_EXIT, 0, 0, 0);
    for (;;) { }
}
