kernel/gui/wm.o: kernel/gui/wm.c kernel/gui/wm.h \
 kernel/gui/../drivers/console.h kernel/gui/theme.h kernel/gui/notify.h \
 kernel/gui/../gfx/direxj.h kernel/gui/../gfx/../drivers/console.h \
 kernel/gui/../mm/heap.h kernel/gui/../int/pit.h \
 kernel/gui/../drivers/rtc.h kernel/gui/../drivers/keyboard.h \
 kernel/gui/../net/net.h
kernel/gui/wm.h:
kernel/gui/../drivers/console.h:
kernel/gui/theme.h:
kernel/gui/notify.h:
kernel/gui/../gfx/direxj.h:
kernel/gui/../gfx/../drivers/console.h:
kernel/gui/../mm/heap.h:
kernel/gui/../int/pit.h:
kernel/gui/../drivers/rtc.h:
kernel/gui/../drivers/keyboard.h:
kernel/gui/../net/net.h:
