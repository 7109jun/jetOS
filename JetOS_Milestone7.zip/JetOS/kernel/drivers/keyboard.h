#ifndef JETOS_KEYBOARD_H
#define JETOS_KEYBOARD_H

#include <stdint.h>

void keyboard_init(void);

/* IRQ1 핸들러(순수 C)에서 호출된다. 포트 0x60에서 스캔코드를 읽어
 * 내부 링버퍼에 ASCII로 변환해 채운다. */
void keyboard_irq_handler(void);

/* 링버퍼에서 문자 하나를 꺼낸다. 없으면 0을 반환한다(논블로킹). */
char keyboard_poll_char(void);

#endif
