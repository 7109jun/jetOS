kernel/net/crypto/bignum.o: kernel/net/crypto/bignum.c \
 kernel/net/crypto/bignum.h
kernel/net/crypto/bignum.h:
