#ifndef JETOS_RNG_H
#define JETOS_RNG_H

/*
 * JetOS - kernel/net/crypto/rng.h
 * Milestone 19: TLS 핸드셰이크 난수(ClientHello.random, pre-master
 * secret의 46바이트, RSA PKCS#1 패딩용 논스, 레코드별 explicit IV)에
 * 쓰는 난수 소스.
 *
 * 알려진 한계(정직하게 문서화): RDRAND를 지원하는 CPU(QEMU 기본값
 * 포함 대부분의 현대 x86_64)에서는 하드웨어 난수를 그대로 쓴다.
 * RDRAND가 없는 환경에서는 RTC 시각+PIT 틱+RDTSC를 SHA-256으로 섞는
 * 소프트웨어 폴백을 쓰는데, 이건 진짜 암호학적으로 안전한 엔트로피가
 * 아니다(예측 가능한 시스템 상태에 의존) — 이 폴백 경로로는 실제
 * 보안이 필요한 용도에 쓰면 안 된다는 뜻. 지금 목표(로컬/실험적
 * HTTPS 접속 데모)에는 RDRAND가 있는 QEMU/실기 환경을 전제로 하되,
 * 없는 환경에서도 "그냥 실패하지 않고 동작은 하게" 폴백을 둔 것뿐.
 */

#include <stdint.h>
#include <stddef.h>

void rng_bytes(uint8_t *out, size_t len);

#endif
