#ifndef JETOS_RECYCLEBIN_H
#define JETOS_RECYCLEBIN_H

#include <stdint.h>

/*
 * JetOS - kernel/fs/recyclebin.h
 * Milestone 32: 휴지통 — JETFS 위에 얹은 "되돌릴 수 있는 삭제".
 *
 * 설계: JETFS는 이미 임의 경로 사이의 jetfs_rename을 지원하니, "삭제"를
 * 실제로는 /.recyclebin/ 아래로 옮기는 것으로 구현한다. 원래 경로는
 * /.recyclebin/index.txt에 한 줄씩("짧은이름\t원래경로\n") 기록해둔다 —
 * JETFS_MAX_NAME이 28자뿐이라 원래 경로(예: "/docs/notes/2024/report.txt")
 * 를 파일 이름 자체로는 못 담아서, 실제 파일은 "item0007" 같은 짧은
 * 이름으로 옮겨두고 원래 경로는 별도 인덱스에 텍스트로 저장하는 방식을
 * 택했다.
 *
 * 알려진 단순화:
 *   - 인덱스가 순수 텍스트라 항목이 아주 많아지면(수백~수천) 선형 탐색이라
 *     느려질 수 있다 — 휴지통 용도로는 충분하다고 판단.
 *   - 디렉터리를 통째로 휴지통에 넣는 건 지원 안 함(파일만).
 *   - 재부팅해도 인덱스 자체(JETFS 파일)는 남지만, 짧은 이름을 만드는
 *     카운터는 세션마다 인덱스의 현재 줄 수를 다시 세어 이어간다(파일
 *     자체에 카운터를 따로 저장하지 않음 — 단순화, 실제로 문제되는
 *     경우는 없다: 매번 "현재 몇 줄인지"로 다음 번호를 정하므로 항상
 *     유일한 이름이 나온다).
 */

/* path(절대경로)의 파일을 휴지통으로 옮긴다(즉시 삭제 대신). 성공 1,
 * 실패(파일 없음/휴지통 디렉터리를 못 만듦 등) 0. */
int recyclebin_delete(const char *path);

/* 휴지통에 있는 short_name(recyclebin_list_cb로 받은 이름) 항목을 원래
 * 있던 경로로 되돌린다. 원래 경로에 이미 파일이 생겼으면 실패(덮어쓰지
 * 않음 — 안전을 위해). 성공 1, 실패 0. */
int recyclebin_restore(const char *short_name);

/* short_name 항목 하나를 완전히(복구 불가능하게) 지운다. */
int recyclebin_purge_one(const char *short_name);

/* 휴지통을 통째로 비운다(전부 완전 삭제). 실제로 지운 개수를 반환. */
int recyclebin_empty(void);

typedef void (*recyclebin_list_cb)(const char *short_name, const char *original_path, void *ctx);
/* 휴지통 항목을 순서대로 콜백으로 전달한다. 항목 개수를 반환. */
int recyclebin_list(recyclebin_list_cb cb, void *ctx);

#endif
