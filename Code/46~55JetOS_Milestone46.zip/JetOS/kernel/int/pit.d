kernel/int/pit.o: kernel/int/pit.c kernel/int/pit.h \
 kernel/int/../hal/x86_asm_shim.h
kernel/int/pit.h:
kernel/int/../hal/x86_asm_shim.h:
