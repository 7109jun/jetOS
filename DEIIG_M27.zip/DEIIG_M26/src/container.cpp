#include "container.hpp"
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstdio>

namespace fs = std::filesystem;
namespace deiig::container {

static std::string trim(std::string s) {
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r' || s.back() == ' ' || s.back() == '\t')) s.pop_back();
    size_t i = 0;
    while (i < s.size() && (s[i] == ' ' || s[i] == '\t')) ++i;
    return s.substr(i);
}

static std::string capture(const std::string& cmd) {
    std::string out;
#ifdef _WIN32
    std::string full = cmd + " 2>nul";
    FILE* f = _popen(full.c_str(), "r");
#else
    std::string full = cmd + " 2>/dev/null";
    FILE* f = popen(full.c_str(), "r");
#endif
    if (!f) return {};
    char buf[256];
    while (fgets(buf, sizeof(buf), f)) out += buf;
#ifdef _WIN32
    _pclose(f);
#else
    pclose(f);
#endif
    return trim(out);
}

Status detect() {
    const std::string dv = capture("docker --version");
    if (!dv.empty()) return {Runtime::Docker, true, dv};
    const std::string pv = capture("podman --version");
    if (!pv.empty()) return {Runtime::Podman, true, pv};
    return {};
}

std::string runtime_name(Runtime r) {
    switch (r) {
        case Runtime::Docker: return "docker";
        case Runtime::Podman: return "podman";
        default: return "none";
    }
}

std::string config_file(const fs::path& project_dir) {
    return (project_dir / ".deiig" / "container.profile").string();
}

std::string quote(const std::string& value) {
#ifdef _WIN32
    std::string out = "\"";
    for (char c : value) {
        if (c == '"') out += "\\\"";
        else out += c;
    }
    out += '"';
    return out;
#else
    std::string out = "'";
    for (char c : value) {
        if (c == '\'') out += "'\\''";
        else out += c;
    }
    out += '\'';
    return out;
#endif
}

std::string command_prefix(const Status& status) {
    return runtime_name(status.runtime);
}

static int run_shell(const fs::path& project_dir, const std::string& cmd) {
    const auto old = fs::current_path();
    std::error_code ec;
    fs::current_path(project_dir, ec);
    if (ec) return 2;
    const int rc = std::system(cmd.c_str());
    fs::current_path(old, ec);
    return rc;
}

static bool ensure_runtime(const Status& s) {
    if (s.available) return true;
    std::fprintf(stderr, "DEIIG: Docker or Podman was not found.\n");
    return false;
}

int init_project(const fs::path& project_dir, const std::string& image, const std::string& workdir) {
    std::error_code ec;
    fs::create_directories(project_dir / ".deiig", ec);
    std::ofstream f(config_file(project_dir), std::ios::trunc);
    if (!f) return 2;
    f << "DEIIG-CONTAINER 1\n";
    f << "runtime=auto\n";
    f << "image=" << image << "\n";
    f << "workdir=" << workdir << "\n";
    f << "context=.\n";
    f << "file=Containerfile\n";
    if (!fs::exists(project_dir / "Containerfile")) {
        std::ofstream cf(project_dir / "Containerfile", std::ios::trunc);
        if (!cf) return 2;
        cf << "FROM " << image << "\n";
        cf << "WORKDIR " << workdir << "\n";
        cf << "COPY . .\n";
    }
    return f.good() ? 0 : 2;
}

int build(const fs::path& project_dir, const std::string& tag, const std::string& context, const std::string& dockerfile) {
    const auto s = detect();
    if (!ensure_runtime(s)) return 127;
    const std::string cmd = command_prefix(s) + " build -t " + quote(tag) + " -f " + quote(dockerfile) + " " + quote(context);
    return run_shell(project_dir, cmd);
}

int run(const fs::path& project_dir, const std::string& image, const std::vector<std::string>& args, const std::string& name) {
    const auto s = detect();
    if (!ensure_runtime(s)) return 127;
    std::ostringstream cmd;
    cmd << command_prefix(s) << " run --rm -it";
    if (!name.empty()) cmd << " --name " << quote(name);
    cmd << ' ' << quote(image);
    for (const auto& a : args) cmd << ' ' << quote(a);
    return run_shell(project_dir, cmd.str());
}

int exec(const fs::path& project_dir, const std::string& container, const std::vector<std::string>& command) {
    const auto s = detect();
    if (!ensure_runtime(s)) return 127;
    std::ostringstream cmd;
    cmd << command_prefix(s) << " exec -it " << quote(container);
    for (const auto& part : command) cmd << ' ' << quote(part);
    return run_shell(project_dir, cmd.str());
}

int stop(const fs::path& project_dir, const std::string& container) {
    const auto s = detect();
    if (!ensure_runtime(s)) return 127;
    return run_shell(project_dir, command_prefix(s) + " stop " + quote(container));
}

int remove(const fs::path& project_dir, const std::string& container) {
    const auto s = detect();
    if (!ensure_runtime(s)) return 127;
    return run_shell(project_dir, command_prefix(s) + " rm -f " + quote(container));
}

int logs(const fs::path& project_dir, const std::string& container, bool follow) {
    const auto s = detect();
    if (!ensure_runtime(s)) return 127;
    return run_shell(project_dir, command_prefix(s) + " logs" + (follow ? " -f " : " ") + quote(container));
}

int images(const fs::path& project_dir) {
    const auto s = detect();
    if (!ensure_runtime(s)) return 127;
    return run_shell(project_dir, command_prefix(s) + " images");
}

int ps(const fs::path& project_dir, bool all) {
    const auto s = detect();
    if (!ensure_runtime(s)) return 127;
    return run_shell(project_dir, command_prefix(s) + " ps" + (all ? " -a" : ""));
}

int pull(const fs::path& project_dir, const std::string& image) {
    const auto s = detect();
    if (!ensure_runtime(s)) return 127;
    return run_shell(project_dir, command_prefix(s) + " pull " + quote(image));
}

} // namespace deiig::container
