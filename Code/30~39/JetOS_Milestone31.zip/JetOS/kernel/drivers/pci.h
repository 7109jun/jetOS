#ifndef JETOS_PCI_H
#define JETOS_PCI_H

#include <stdint.h>

typedef struct {
    uint8_t bus, slot, func;
    uint16_t vendor_id, device_id;
    uint8_t class_code, subclass, prog_if;
    uint32_t bar[6];
} pci_device_t;

uint32_t pci_config_read32(uint8_t bus, uint8_t slot, uint8_t func, uint8_t offset);
void pci_config_write32(uint8_t bus, uint8_t slot, uint8_t func, uint8_t offset, uint32_t value);

/* class=0x01(Mass Storage) subclass=0x06(SATA) prog_if=0x01(AHCI) 장치를 찾는다.
 * 찾으면 1, 못 찾으면 0을 반환한다. */
int pci_find_ahci_controller(pci_device_t *out);

/* vendor_id/device_id가 정확히 일치하는 첫 장치를 찾는다 (NIC 등
 * 특정 칩셋을 지정해서 찾을 때 사용). 찾으면 1, 못 찾으면 0. */
int pci_find_device(uint16_t vendor_id, uint16_t device_id, pci_device_t *out);

#endif
