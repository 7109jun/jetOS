#ifndef JETOS_X509_TRUST_H
#define JETOS_X509_TRUST_H

/*
 * JetOS - kernel/net/crypto/x509_trust.h
 * Milestone 24: 신뢰 루트 CA 저장소 + 인증서 체인 검증.
 *
 * 설계: 브라우저들이 흔히 쓰는 "OS/브라우저에 내장된 수백 개의 루트 CA
 * 번들"을 커널 이미지에 통째로 박아넣는 대신, JETFS의 한 파일
 * (기본 경로 /system/certs/roots.der — DER 인코딩된 루트 인증서를
 * 그냥 이어붙인 것)에서 부팅 후 필요할 때 읽어들인다. 이유:
 *   1) 이 프로젝트 철학(큰 정적 버퍼로 커널 이미지를 불리지 않는다,
 *      M22 버그 15/M23 버그 17 참고)과 맞는다 — 사용자가 실제로
 *      필요한 루트 CA만 골라서 JETFS에 넣으면 된다.
 *   2) JETFS라는 이미 있는 인프라(jetfs_read)를 그대로 재사용한다.
 * 알려진 한계: 저장소 파일이 없거나 비어있으면 신뢰할 루트가 0개이므로
 * 모든 TLS 접속의 체인 검증이 실패한다(즉 "기본적으로 아무도 신뢰
 * 안 함" — fail-closed. 조용히 MITM에 열려있는 것보다 훨씬 안전한
 * 기본값이라고 판단). 사용자가 신뢰할 루트 CA의 DER 파일들을 준비해
 * usbimport 등으로 /system/certs/roots.der에 넣어야 실제 HTTPS
 * 사이트에 접속할 수 있다.
 *
 * Milestone 25: 루트 자체는 basicConstraints/keyUsage를 검사하지 않는다
 * — 사용자가 명시적으로 로컬 저장소에 넣었다는 사실 자체가 신뢰의
 * 근거이기 때문(브라우저가 수동으로 가져온 신뢰 앵커를 다루는 방식과
 * 동일). chain[] 안의 중간 인증서들에 대해서만 basicConstraints
 * cA:TRUE/keyUsage keyCertSign/pathLenConstraint를 엄격히 검사한다.
 */

#include <stdint.h>
#include <stddef.h>
#include "x509_min.h"

#define X509_TRUST_MAX_ROOTS 16
#define X509_TRUST_MAX_CHAIN 6

/* path(예: "/system/certs/roots.der")에서 이어붙은 DER 루트 인증서들을
 * 읽어 파싱해 둔다. 실패(파일 없음 등)해도 신뢰 루트 0개로 취급되고
 * 이후 x509_verify_chain은 항상 실패(fail-closed)한다. 반환값은 실제로
 * 파싱에 성공한 루트 개수. */
int x509_trust_load(const char *path);

int x509_trust_count(void);

/* chain[0]=리프...chain[chain_len-1]=서버가 보낸 마지막 인증서인 배열을
 * 검증한다:
 *   1) 모든 인증서의 유효기간이 now를 포함하는지
 *   2) chain[i]가 chain[i+1]의 공개키로 서명됐고 issuer/subject가
 *      바이트 단위로 이어지는지(리프->중간->중간...), 그리고 M25부터는
 *      chain[i+1](서명자)이 실제로 basicConstraints cA:TRUE인 CA
 *      인증서이고(없으면 무조건 거부), keyUsage가 있다면 keyCertSign
 *      비트가 서 있고, pathLenConstraint를 위반하지 않는지까지 확인
 *   3) 마지막 인증서의 issuer가 신뢰 저장소의 루트 중 하나의 subject와
 *      일치하고, 그 루트의 공개키로 실제 서명 검증이 되는지(서버가
 *      루트 자체를 보냈든 안 보냈든 동일하게 처리됨)
 *   4) (M26) 리프 인증서에 extendedKeyUsage가 있다면 serverAuth(또는
 *      anyExtendedKeyUsage)를 포함하는지
 * 성공(신뢰 가능) 1, 실패 0(fail_reason에 사람이 읽을 한국어 실패
 * 사유 문자열 포인터를 채움 — NULL 전달 가능). */
int x509_verify_chain(const x509_cert_t *chain, int chain_len, uint64_t now, const char **fail_reason);

#endif
