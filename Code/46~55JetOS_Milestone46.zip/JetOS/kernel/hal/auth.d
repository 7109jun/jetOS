kernel/hal/auth.o: kernel/hal/auth.c kernel/hal/auth.h \
 kernel/hal/../kernel.h kernel/hal/../drivers/console.h \
 kernel/hal/../fs/jetfs.h kernel/hal/../net/crypto/sha256.h \
 kernel/hal/../drivers/keyboard.h kernel/hal/../drivers/console.h \
 kernel/hal/../drivers/serial.h kernel/hal/../proc/scheduler.h \
 kernel/hal/../proc/thread.h
kernel/hal/auth.h:
kernel/hal/../kernel.h:
kernel/hal/../drivers/console.h:
kernel/hal/../fs/jetfs.h:
kernel/hal/../net/crypto/sha256.h:
kernel/hal/../drivers/keyboard.h:
kernel/hal/../drivers/console.h:
kernel/hal/../drivers/serial.h:
kernel/hal/../proc/scheduler.h:
kernel/hal/../proc/thread.h:
