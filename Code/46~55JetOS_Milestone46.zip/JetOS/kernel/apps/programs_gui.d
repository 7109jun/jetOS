kernel/apps/programs_gui.o: kernel/apps/programs_gui.c \
 kernel/apps/programs_gui.h kernel/apps/../../include/jetapi/jetapi.h \
 kernel/apps/../gui/wm.h kernel/apps/../gui/../drivers/console.h \
 kernel/apps/../gui/notify.h kernel/apps/../drivers/console.h \
 kernel/apps/../proc/scheduler.h kernel/apps/../proc/thread.h \
 kernel/apps/../fs/programs.h kernel/apps/../fs/jetfs.h \
 kernel/apps/../exec/elf_loader.h kernel/apps/../exec/pe_loader.h
kernel/apps/programs_gui.h:
kernel/apps/../../include/jetapi/jetapi.h:
kernel/apps/../gui/wm.h:
kernel/apps/../gui/../drivers/console.h:
kernel/apps/../gui/notify.h:
kernel/apps/../drivers/console.h:
kernel/apps/../proc/scheduler.h:
kernel/apps/../proc/thread.h:
kernel/apps/../fs/programs.h:
kernel/apps/../fs/jetfs.h:
kernel/apps/../exec/elf_loader.h:
kernel/apps/../exec/pe_loader.h:
