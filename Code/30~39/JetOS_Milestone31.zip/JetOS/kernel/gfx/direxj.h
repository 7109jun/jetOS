#ifndef JETOS_DIREXJ_H
#define JETOS_DIREXJ_H

/*
 * JetOS - kernel/gfx/direxj.h
 * Milestone 29: DirexJ — "Windows 7 수준" 목표를 뒷받침하는 작은 렌더링
 * 라이브러리. 이름은 DirectX에서 따왔지만, 정직하게 미리 밝혀둔다:
 *
 * **이 커널에는 GPU 드라이버가 없다.** UEFI GOP가 부팅 시 넘겨준 선형
 * 프레임버퍼(포인터 하나)에 CPU가 직접 픽셀을 쓰는 순수 소프트웨어
 * 렌더링이 전부다(M1부터 지금까지 쭉 그래왔다). VirtIO-GPU나 실제
 * GPU 드라이버를 새로 쓰는 건 이 프로젝트 하나 마일스톤으로 감당할
 * 규모가 아니라서(커널 전체 규모에 맞먹는 별도 서브시스템) 스코프에서
 * 뺐다 — "DirexJ가 GPU를 가속한다"는 건 사실이 아니다.
 *
 * 대신 이름의 절반("Direx")은 지금 있는 것 — CPU 소프트웨어 렌더링 —
 * 을 최적화하고 정리하는 데 썼다:
 *   1) **CPU 최적화**: `dj_present_diff` — 매 프레임 백버퍼 전체를
 *      무조건 프레임버퍼(MMIO)에 통째로 복사하던 `wm_present()`를,
 *      실제로 바뀐 픽셀만 쓰도록 바꿨다. 화면 대부분이 안 바뀌는
 *      프레임(커서만 움직였다거나)에서 MMIO 쓰기 횟수가 크게 준다.
 *   2) **더 자연스러운 렌더링**: M23/M26에서 각 그리기 함수마다 따로
 *      구현했던 안티에일리어싱 수학(원형 가장자리의 isqrt 거리 기반
 *      블렌딩, 다각형의 삼각형 supersampling)을 한 곳으로 모았다 —
 *      중복 제거뿐 아니라, 앞으로 새 그리기 함수를 추가할 때마다 같은
 *      수학을 또 베껴 쓰지 않고 이 라이브러리를 바로 쓸 수 있게 됐다.
 *
 * "GPU"라는 이름값에 비해 소박하다는 걸 알지만, 없는 걸 있다고
 * 포장하지 않는 게 이 프로젝트의 원칙이다(각 마일스톤 문서의 "알려진
 * 한계" 절 참고).
 */

#include <stdint.h>
#include "../drivers/console.h"

/* 정수 제곱근(뉴턴법). 안티에일리어싱 거리 계산에 쓴다 — n을 8.8
 * 고정소수점(즉 실제 거리*256)으로 넘기면 결과도 같은 스케일로
 * 나온다(호출측 관례는 각 사용처 주석 참고, M23부터 쓰던 방식 그대로). */
uint32_t dj_isqrt(uint64_t n);

/* 반지름 r의 원을 단색으로, 가장자리는 isqrt 거리 기반 서브픽셀
 * 블렌딩으로 매끄럽게 채운다(M23의 배경화면 태양에 쓴 기법을 단색
 * 전용으로 일반화). 그라디언트가 필요한 경우(예: 위치별로 색이
 * 달라지는 태양)는 이 함수로 안 되니 직접 dj_isqrt를 써서 구현할 것 —
 * draw_wallpaper()의 태양이 그런 경우라 이 함수를 안 쓴다. */
void dj_fill_circle_aa(console_t *con, int cx, int cy, int r, uint32_t color);

/* 점 (px,py)가 삼각형 (ax,ay)-(bx,by)-(cx,cy) 안에 있는지(경계 포함)
 * 부호 있는 면적 셋의 부호 일치로 판정한다. */
int dj_point_in_triangle(int px, int py, int ax, int ay, int bx, int by, int cx, int cy);

/* 픽셀당 4x4(POLY_SS x POLY_SS) 서브샘플로 여러 삼각형의 합집합을
 * supersampling 안티에일리어싱으로 채운다(M26의 별/스피커 나팔부에
 * 쓴 기법). tris[i] = {ax,ay,bx,by,cx,cy}, 좌표는 DJ_POLY_F배(=8배)
 * 확대된 정수(서브픽셀 중심을 부동소수점 없이 표현하기 위함 — 호출측이
 * 실제 픽셀좌표*DJ_POLY_F를 넣어야 한다). bbox는 실제 픽셀좌표 그대로. */
#define DJ_POLY_SS 4
#define DJ_POLY_F  (DJ_POLY_SS * 2)
void dj_fill_triangle_union_aa(console_t *con, const int tris[][6], int tri_count,
                                int bbox_min_x, int bbox_min_y, int bbox_max_x, int bbox_max_y,
                                uint32_t color);

/* back(방금 그려진 백버퍼)을 front(실제 프레임버퍼, MMIO)로 옮긴다 —
 * 다만 값이 바뀐 픽셀만 실제로 쓴다(같은 값을 매번 다시 써서 MMIO
 * 대역폭을 낭비하지 않도록). 최종적으로 front의 내용은 무조건
 * back과 완전히 같아진다(결과는 예전의 "통째로 복사"와 동일 — 쓰기
 * 횟수만 줄었을 뿐 시각적 차이는 없음). front/back 크기가 다르면
 * 아무것도 하지 않는다.
 * Milestone 31: virtio_gpu_init()이 성공해서 실제 GPU 장치가 있으면,
 * 바뀐 픽셀들의 바운딩 박스를 계산해 virtio_gpu_present()로 그 영역만
 * GPU에 "여기 바뀌었다"고 알린다(TRANSFER_TO_HOST_2D+RESOURCE_FLUSH).
 * GPU가 없으면(virtio_gpu_available()==0) 이 단계는 그냥 건너뛴다 —
 * M29 그대로 CPU가 프레임버퍼에 직접 쓰는 것만으로 화면에 반영됨. */
void dj_present_diff(console_t *front, console_t *back);

#endif
