/*
 * JetOS - examples/hello.c
 * Milestone 30: JCC로 컴파일해서 실제 JetOS(Ring3 격리 프로세스)에서
 * 돌리는 데모 프로그램. print_int는 examples/prelude.c를 그대로
 * 복사해 붙였다(jcc에 전처리기가 없어서 #include가 안 됨 — prelude.c
 * 주석 참고).
 *
 * 빌드:
 *   make jcc
 *   ./build/jcc examples/hello.c /tmp/hello.elf
 *
 * JetOS에 넣어서 실행:
 *   make mkjetfs && ./build/mkjetfs build/jetfs.img 128
 *   make jetfs_import
 *   ./build/jetfs_import build/jetfs.img /tmp/hello.elf /hello.elf
 *   make esp && ./scripts/run_qemu.sh
 *   (jash에서) run /hello.elf
 */

void print_int(int n) {
    char buf[12];
    char out[13];
    int i;
    int j;
    int neg;
    neg = 0;
    if (n < 0) { neg = 1; n = -n; }
    i = 0;
    if (n == 0) { buf[i] = '0'; i = i + 1; }
    while (n > 0) {
        buf[i] = (n % 10) + '0';
        n = n / 10;
        i = i + 1;
    }
    if (neg) { buf[i] = '-'; i = i + 1; }
    j = 0;
    while (i > 0) {
        i = i - 1;
        out[j] = buf[i];
        j = j + 1;
    }
    out[j] = 0;
    _write(out);
}

int fib(int n) {
    if (n < 2) return n;
    return fib(n - 1) + fib(n - 2);
}

int main() {
    _write("Hello from JCC running natively on JetOS!\n");
    _write("fib(0..9): ");
    int i;
    for (i = 0; i < 10; i = i + 1) {
        print_int(fib(i));
        _write(" ");
    }
    _write("\n");
    return 0;
}
