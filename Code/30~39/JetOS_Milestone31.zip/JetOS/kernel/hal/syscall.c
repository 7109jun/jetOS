/*
 * JetOS - kernel/hal/syscall.c
 * syscall.h 참고. syscall_entry.c(어셈블리 트램폴린)가 레지스터를 저장한
 * 뒤 이 함수를 부른다 — 여기서부터는 100% 순수 C.
 */
#include "syscall.h"
#include "../drivers/serial.h"
#include "../int/pit.h"
#include "../proc/thread.h"
#include "../proc/scheduler.h"
#include "../mm/vmm.h"
#include "../mm/pmm.h"

/* Milestone 19: 유저 포인터 검증. 현재 스레드가 프로세스 주소공간에
 * 묶여 있지 않으면(cr3==0, 공유 커널 주소공간) 유저 영역이라는 개념
 * 자체가 없으므로 무조건 거부한다 — 시스템콜은 Ring3(유저 프로세스)
 * 에서만 오는 게 정상이라 이 경로를 타면 이미 뭔가 잘못된 것이다. */
int syscall_check_user_range(const void *ptr, uint64_t len) {
    thread_t *cur = scheduler_current();
    if (!cur || cur->cr3 == 0) return 0;

    uint64_t base = vmm_user_virt_base();
    uint64_t size = vmm_user_region_size();
    uint64_t p = (uint64_t)ptr;

    if (len == 0) return (p >= base && p <= base + size);
    if (p < base) return 0;
    /* p + len 오버플로 방지: len이 남은 영역보다 크면 거부 (뺄셈으로
     * 비교해 p+len 오버플로 자체를 계산하지 않는다) */
    if (p - base > size - len) return 0;
    return 1;
}

int64_t syscall_check_user_cstr(const char *ptr, uint64_t max_len) {
    thread_t *cur = scheduler_current();
    if (!cur || cur->cr3 == 0) return -1;

    uint64_t base = vmm_user_virt_base();
    uint64_t size = vmm_user_region_size();
    uint64_t p = (uint64_t)ptr;
    if (p < base || p >= base + size) return -1;

    uint64_t max_reachable = (base + size) - p; /* 유저 영역 끝까지 남은 바이트 */
    uint64_t limit = (max_len < max_reachable) ? max_len : max_reachable;

    for (uint64_t i = 0; i < limit; i++) {
        if (ptr[i] == '\0') return (int64_t)i;
    }
    return -1; /* limit 안에 NUL 없음 — 잘렸거나 악의적으로 긴 문자열 */
}

void syscall_dispatch(syscall_regs_t *regs) {
    switch (regs->rax) {
        case SYS_WRITE: {
            const char *s = (const char *)regs->rdi;
            int64_t slen = syscall_check_user_cstr(s, 4096);
            if (slen < 0) {
                serial_write("[syscall] SYS_WRITE: invalid user pointer — killing thread\n");
                thread_exit(); /* Milestone 16과 동일한 원칙: 그 프로세스만 종료, 커널은 계속 */
            }
            serial_write(s);
            regs->rax = 0;
            break;
        }
        case SYS_GETTICK: {
            regs->rax = g_timer_ticks;
            break;
        }
        case SYS_BRK: {
            thread_t *cur = scheduler_current();
            uint64_t requested = regs->rdi;
            if (!cur || cur->cr3 == 0) { regs->rax = 0; break; } /* 커널 스레드에서 올 일 없음(방어적) */

            if (requested == 0) { regs->rax = cur->user_brk; break; } /* 조회 */

            uint64_t cur_brk = cur->user_brk;
            uint64_t base = vmm_user_virt_base();
            uint64_t cap = base + vmm_user_region_size();

            if (requested <= cur_brk) { regs->rax = cur_brk; break; } /* 축소 미지원 — 단순화(syscall.h 참고) */
            if (requested > cap) { regs->rax = cur_brk; break; } /* 유저 영역 상한 초과 — 실패, brk 그대로 */

            uint64_t new_brk_aligned = (requested + 0xFFFULL) & ~0xFFFULL;
            uint64_t page_va = cur_brk;
            int ok = 1;
            while (page_va < new_brk_aligned) {
                uint64_t phys = pmm_alloc_page();
                if (!phys) { ok = 0; break; } /* 물리 메모리 부족 — 여기까지 매핑된 건 그대로 두고 중단 */
                uint8_t *dst = (uint8_t *)phys; /* 커널은 항등매핑이라 바로 접근 가능 */
                for (int k = 0; k < 4096; k++) dst[k] = 0;
                if (!vmm_map_user_page(cur->cr3, page_va, phys, 1)) { ok = 0; break; }
                page_va += 4096;
            }
            cur->user_brk = page_va; /* 일부만 성공했어도 거기까지는 유효 — 진행분 반영 */
            (void)ok;
            regs->rax = cur->user_brk;
            break;
        }
        case SYS_EXIT: {
            thread_exit(); /* 돌아오지 않음 */
            break;
        }
        default: {
            serial_write("[syscall] unknown syscall number\n");
            regs->rax = (uint64_t)-1;
            break;
        }
    }
}
