kernel/net/crypto/sha256.o: kernel/net/crypto/sha256.c \
 kernel/net/crypto/sha256.h
kernel/net/crypto/sha256.h:
