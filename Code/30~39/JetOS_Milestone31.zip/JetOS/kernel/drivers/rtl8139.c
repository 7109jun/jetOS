/*
 * JetOS - kernel/drivers/rtl8139.c
 *
 * Realtek RTL8139 이더넷 컨트롤러 드라이버. QEMU가 `-device rtl8139`로
 * 기본 제공하는 가상 NIC이 정확히 이 칩을 흉내내므로, 별도 드라이버
 * 없이 QEMU 환경에서 실제 패킷 송수신을 실증할 수 있다.
 *
 * AHCI 드라이버와 동일한 설계 철학: 인터럽트 없이 순수 폴링 방식.
 * 레지스터는 전부 포트 I/O(BAR0)로 접근한다 — MMIO(BAR1)도 지원하는
 * 칩이지만, 포트 I/O 쪽이 더 단순하고 이미 hal_inX/outX가 있다.
 */

#include "rtl8139.h"
#include "pci.h"
#include "../hal/x86_asm_shim.h"
#include "../mm/pmm.h"

/* ---- 레지스터 오프셋 (BAR0 기준) ---- */
#define REG_MAC0        0x00 /* 6바이트 MAC 주소 */
#define REG_RBSTART     0x30 /* 수신 버퍼 물리주소 (4바이트) */
#define REG_CMD         0x37 /* 커맨드 레지스터 (1바이트) */
#define REG_CAPR        0x38 /* 현재 읽기 포인터 (2바이트) */
#define REG_CBA         0x3A /* NIC이 실제로 DMA를 마친 현재 쓰기 위치 (2바이트, 읽기 전용) */
#define REG_IMR         0x3C /* 인터럽트 마스크 (2바이트, 사용 안 함 — 폴링) */
#define REG_ISR         0x3E /* 인터럽트 상태 (2바이트) */
#define REG_TCR         0x40 /* 송신 설정 (4바이트) */
#define REG_RCR         0x44 /* 수신 설정 (4바이트) */
#define REG_CONFIG1     0x52 /* 전원 관리 (1바이트) */
#define REG_TSAD0       0x20 /* 송신 디스크립터 0~3 물리주소, 각 4바이트 간격 */
#define REG_TSD0        0x10 /* 송신 디스크립터 0~3 상태/길이, 각 4바이트 간격 */

#define CMD_RESET   0x10
#define CMD_RX_EN   0x08
#define CMD_TX_EN   0x04
#define CMD_BUF_EMPTY 0x01

#define RCR_AAP  (1 << 0) /* accept all packets (promiscuous) */
#define RCR_APM  (1 << 1) /* accept physical match */
#define RCR_AM   (1 << 2) /* accept multicast */
#define RCR_AB   (1 << 3) /* accept broadcast */
#define RCR_WRAP (1 << 7) /* 수신 버퍼 경계에서 패킷이 잘리지 않게 함 */
#define RCR_MXDMA_UNLIMITED (0x7 << 8)
#define RCR_RBLEN_8K (0x0 << 11) /* 8K+16바이트 버퍼 */

#define TSD_OWN  (1u << 13) /* 1=NIC이 전송을 마치고 소유권을 반환함 */
#define TSD_TOK  (1u << 15) /* 전송 성공 */

#define RX_STATUS_ROK (1u << 0) /* Receive OK — 이 비트가 서기 전에 헤더를
                                  * 읽으면 NIC의 DMA가 아직 다 안 끝난
                                  * "torn read" 상태를 잡을 수 있다 */

#define RX_BUF_PADDING 1536 /* WRAP 옵션 사용 시 버퍼 끝 너머로 밀려 쓸 수 있어 여유분 필요 */
#define RX_BUF_LOGICAL_SIZE 8192
#define RX_BUF_TOTAL_SIZE (RX_BUF_LOGICAL_SIZE + 16 + RX_BUF_PADDING)

#define TX_BUF_SIZE 1536
#define TX_DESC_COUNT 4

static int g_available = 0;
static uint16_t g_io_base = 0;
static uint8_t g_mac[6];

static uint8_t *g_rx_buf = NULL;   /* 가상=물리 (0~4GiB 항등 매핑) */
static uint32_t g_rx_offset = 0;   /* 다음에 읽을 위치 (버퍼 내 오프셋) */

static uint8_t *g_tx_buf[TX_DESC_COUNT];
static int g_tx_next = 0;

int rtl8139_available(void) { return g_available; }

void rtl8139_get_mac(uint8_t mac[6]) {
    for (int i = 0; i < 6; i++) mac[i] = g_mac[i];
}

static void enable_pci_bus_master_io(pci_device_t *dev) {
    /* 오프셋 0x04 = Command(16bit, 하위)/Status(16bit, 상위) 조합 레지스터.
     * bit0=I/O Space Enable, bit2=Bus Master Enable(DMA 허용) */
    uint32_t cmd_status = pci_config_read32(dev->bus, dev->slot, dev->func, 0x04);
    cmd_status |= 0x0005; /* I/O space + bus master */
    pci_config_write32(dev->bus, dev->slot, dev->func, 0x04, cmd_status);
}

int rtl8139_init(void) {
    pci_device_t dev;
    /* Realtek 벤더 0x10EC, RTL8139 계열 디바이스 ID 0x8139 */
    if (!pci_find_device(0x10EC, 0x8139, &dev)) {
        g_available = 0;
        return 0;
    }

    enable_pci_bus_master_io(&dev);

    /* BAR0 하위 2비트는 "이 BAR가 I/O 공간이다"라는 플래그(0x1)이므로
     * 마스킹해서 실제 베이스 포트만 취한다. */
    g_io_base = (uint16_t)(dev.bar[0] & ~0x3u);
    if (g_io_base == 0) { g_available = 0; return 0; }

    /* 전원 관리 해제(wake up) */
    hal_outb((uint16_t)(g_io_base + REG_CONFIG1), 0x00);

    /* 소프트 리셋 — RST 비트는 리셋 완료 시 하드웨어가 스스로 0으로 내림 */
    hal_outb((uint16_t)(g_io_base + REG_CMD), CMD_RESET);
    for (int i = 0; i < 1000000; i++) {
        if ((hal_inb((uint16_t)(g_io_base + REG_CMD)) & CMD_RESET) == 0) break;
    }

    /* MAC 주소 읽기 (레지스터 0x00~0x05) */
    for (int i = 0; i < 6; i++) {
        g_mac[i] = hal_inb((uint16_t)(g_io_base + REG_MAC0 + i));
    }

    /* 수신 버퍼 확보 (물리적으로 연속된 페이지들, 항등 매핑이므로
     * 물리주소를 그대로 포인터로 사용 가능) */
    uint64_t rx_pages = (RX_BUF_TOTAL_SIZE + 4095) / 4096;
    uint64_t rx_phys = pmm_alloc_pages(rx_pages);
    if (rx_phys == 0) { g_available = 0; return 0; }
    g_rx_buf = (uint8_t *)(uintptr_t)rx_phys;
    g_rx_offset = 0;

    hal_outl((uint16_t)(g_io_base + REG_RBSTART), (uint32_t)rx_phys);

    /* 송신 버퍼 4개(디스크립터당 1개) */
    for (int i = 0; i < TX_DESC_COUNT; i++) {
        uint64_t tx_phys = pmm_alloc_pages(1); /* 4096 >= TX_BUF_SIZE */
        if (tx_phys == 0) { g_available = 0; return 0; }
        g_tx_buf[i] = (uint8_t *)(uintptr_t)tx_phys;
        hal_outl((uint16_t)(g_io_base + REG_TSAD0 + i * 4), (uint32_t)tx_phys);
    }
    g_tx_next = 0;

    /* 인터럽트는 쓰지 않지만, 상태 레지스터에 낀 잔여 비트를 깨끗이 지운다 */
    hal_outw((uint16_t)(g_io_base + REG_ISR), 0xFFFF);
    hal_outw((uint16_t)(g_io_base + REG_IMR), 0x0000);

    /* 수신 설정: 모든 유니캐스트(내 MAC)/브로드캐스트/멀티캐스트 허용,
     * WRAP으로 버퍼 경계 문제 방지, DMA 버스트 무제한 */
    hal_outl((uint16_t)(g_io_base + REG_RCR),
             RCR_AAP | RCR_APM | RCR_AM | RCR_AB | RCR_WRAP | RCR_MXDMA_UNLIMITED | RCR_RBLEN_8K);

    /* 송신 설정: DMA 버스트 무제한 (그 외 기본값) */
    hal_outl((uint16_t)(g_io_base + REG_TCR), RCR_MXDMA_UNLIMITED);

    /* 송수신 활성화 */
    hal_outb((uint16_t)(g_io_base + REG_CMD), CMD_RX_EN | CMD_TX_EN);

    g_available = 1;
    return 1;
}

int rtl8139_send(const void *frame, uint32_t len) {
    if (!g_available) return 0;
    if (len > TX_BUF_SIZE) return 0;
    if (len < 60) len = 60; /* 이더넷 최소 프레임 길이(FCS 제외 60바이트) */

    int slot = g_tx_next;
    g_tx_next = (g_tx_next + 1) % TX_DESC_COUNT;

    /* 이전에 이 슬롯을 썼다면 완료(OWN=1)될 때까지 대기 */
    uint32_t timeout = 200000;
    while (timeout--) {
        uint32_t status = hal_inl((uint16_t)(g_io_base + REG_TSD0 + slot * 4));
        if (status & TSD_OWN) break;
    }

    uint8_t *dst = g_tx_buf[slot];
    const uint8_t *src = (const uint8_t *)frame;
    for (uint32_t i = 0; i < len; i++) dst[i] = src[i];

    /* 길이 필드(하위 13비트)에 쓰면 하드웨어가 즉시 전송을 시작한다.
     * (OWN 비트는 하드웨어가 알아서 0으로 내렸다가 완료 시 다시 1로 올림) */
    hal_outl((uint16_t)(g_io_base + REG_TSD0 + slot * 4), len & 0x1FFF);

    timeout = 200000;
    while (timeout--) {
        uint32_t status = hal_inl((uint16_t)(g_io_base + REG_TSD0 + slot * 4));
        if (status & TSD_TOK) return 1;
        if (status & TSD_OWN) { /* 소유권은 돌아왔는데 TOK가 없으면 전송 실패(충돌 등) */
            return (status & TSD_TOK) ? 1 : 0;
        }
    }
    return 0; /* 타임아웃 */
}

uint32_t rtl8139_recv(void *buf, uint32_t buf_size) {
    if (!g_available) return 0;

    /* CMD 레지스터의 BUFE(BufferEmpty) 비트가 1이면 대기중인 패킷 없음 */
    if (hal_inb((uint16_t)(g_io_base + REG_CMD)) & CMD_BUF_EMPTY) return 0;

    /* 수신 버퍼 포맷: [status:2][length:2(FCS 포함)][payload...] */
    uint16_t rx_status = *(uint16_t *)(g_rx_buf + g_rx_offset);
    uint16_t rx_len     = *(uint16_t *)(g_rx_buf + g_rx_offset + 2);

    /* ROK(Receive OK) 비트가 아직 안 섰거나 길이가 말이 안 되면, NIC의
     * DMA가 헤더를 쓰는 도중일 수 있다("torn read"). g_rx_offset/CAPR을
     * 건드리지 않고 그냥 0을 반환해서 다음 net_poll() 호출 때 같은
     * 위치를 다시 확인하게 한다 — 이 검사가 없으면 길이가 잘못
     * 읽혀(예: 아직 0으로 남아있는 필드) 오프셋이 엉뚱하게 전진해버려
     * 뒤이어 오는 진짜 패킷의 헤더를 잘못된 위치에서 읽는 문제가
     * 실제로 발생했다(TCP 시퀀스 번호가 같은 패킷을 두 번 다르게
     * 읽는 것처럼 보이는 현상으로 나타남). */
    if (!(rx_status & RX_STATUS_ROK) || rx_len < 4 || rx_len > (RTL8139_MAX_FRAME + 4)) {
        return 0;
    }

    /* 추가 검증: NIC이 이 패킷 전체(헤더+데이터)를 실제로 다 써넣었는지
     * CBA(Current Buffer Address, 하드웨어가 마지막으로 DMA를 완료한
     * 지점)와 대조한다. ROK가 서 있어도 길이 필드 자체가 "그 순간엔
     * 그럴듯해 보이지만 사실은 아직 다 안 쓰인 상태"인 경우가 실측에서
     * 관찰되었다 — 이 경우 짧고 내용이 비어있는 가짜 패킷을 읽어
     * g_rx_offset을 조금만 전진시키고, 그 뒤로는 진짜 패킷의 중간을
     * 헤더로 오인하며 영구히 어긋나는 문제로 이어졌다. CBA는(랩어라운드
     * 전이라면) "이 오프셋까지는 확실히 다 쓰여졌다"를 뜻하므로,
     * 우리가 읽으려는 끝지점이 CBA를 넘어서면 아직 다 안 온 것으로
     * 보고 대기한다.
     * (단순화: 8192바이트 경계를 넘는 랩어라운드 구간은 이 검증을
     * 건너뛰고 기존 status/length 검사에만 의존한다.) */
    uint16_t cba = hal_inw((uint16_t)(g_io_base + REG_CBA));
    uint32_t claimed_end = g_rx_offset + 4 + rx_len;
    if (claimed_end <= RX_BUF_LOGICAL_SIZE && (uint32_t)cba < claimed_end && (uint32_t)cba >= g_rx_offset) {
        return 0; /* 아직 다 안 왔음 — 다음 호출에서 재확인 */
    }

    (void)rx_status; /* ROK 외 세부 플래그는 검사하지 않음 (단순화) */

    uint32_t payload_len = (rx_len >= 4) ? (uint32_t)(rx_len - 4) : 0; /* FCS 4바이트 제외 */
    uint32_t copy_len = payload_len < buf_size ? payload_len : buf_size;

    if (payload_len > 0 && payload_len <= RTL8139_MAX_FRAME) {
        uint8_t *src = g_rx_buf + g_rx_offset + 4;
        uint8_t *dst = (uint8_t *)buf;
        for (uint32_t i = 0; i < copy_len; i++) dst[i] = src[i];
    } else {
        payload_len = 0; /* 손상된 것으로 보이는 길이는 버림 */
    }

    /* 다음 패킷 위치로 오프셋 이동: 헤더 4바이트 + 프레임(FCS 포함), 4바이트 정렬,
     * 8192 경계에서 wrap.
     *
     * 중요: 이더넷 프레임은 최소 60바이트(+FCS 4바이트=64)여야 한다.
     * 실측 결과, 상대(리눅스 실제 TCP 스택)가 보내는 순수 ACK처럼
     * 짧은 프레임(14+20+20=54바이트, 최소 크기 미달)은 NIC이 물리적
     * 으로는 60바이트까지 0으로 패딩해서 링에 써넣지만, rx_len 필드는
     * 패딩 이전의 "진짜" 길이만 보고하는 것으로 관찰되었다. rx_len만
     * 믿고 오프셋을 전진시키면 패딩분(예: 6바이트)이 링에 그대로
     * 남아있다가 다음 호출에서 "상태=0, 길이=6, 내용=0"짜리 가짜
     * 패킷으로 잘못 해석되어(심지어 우연히 seq가 그 시점의 rcv_nxt와
     * 맞아떨어지는 것처럼 보여) 무한히 같은 자리를 맴도는 문제가
     * 실제로 발생했다. 그래서 오프셋 전진 계산에는 rx_len과 최소
     * 프레임 크기(64) 중 큰 값을 쓴다 — payload_len(위에서 이미 계산)
     * 은 원래 rx_len 그대로 쓰므로 실제 데이터 길이 해석에는 영향 없다. */
    uint32_t frame_total = rx_len < 64 ? 64 : rx_len;
    uint32_t advance = 4 + frame_total;
    advance = (advance + 3) & ~3u;
    g_rx_offset = (g_rx_offset + advance) % RX_BUF_LOGICAL_SIZE;

    /* CAPR은 하드웨어 관례상 "다음 읽기 위치 - 16"으로 설정한다. */
    uint16_t capr = (uint16_t)((g_rx_offset - 16) & 0xFFFF);
    hal_outw((uint16_t)(g_io_base + REG_CAPR), capr);

    return payload_len;
}
