#ifndef JETOS_VFS_H
#define JETOS_VFS_H

/*
 * JetOS 논리 공간 네임스페이스:
 *   :>  로컬 디스크 공간   :]  드라이브 공간   :)  미디어 공간
 *   :<  다운로드 공간      :/  네트워크 공간
 *
 * Milestone 4 시점에는 실제 물리 드라이브가 JETFS 데이터 디스크
 * 하나뿐이므로, 다섯 네임스페이스 모두 같은 JETFS 루트로 연결된다.
 * 각 네임스페이스가 실제로 분리된 백엔드(이동식 미디어, 네트워크 등)를
 * 갖게 되는 것은 해당 드라이버가 추가되는 이후 마일스톤 과제다 —
 * 지금 중요한 것은 "문자열이 아니라 진짜 네임스페이스 파싱 계층"이
 * 존재한다는 것이다. */
const char *vfs_translate(const char *ns_path, char *out_buf, int out_buf_size);

#endif
