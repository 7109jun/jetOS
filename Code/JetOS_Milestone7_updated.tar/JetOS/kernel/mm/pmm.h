#ifndef JETOS_PMM_H
#define JETOS_PMM_H

#include <stdint.h>
#include "../../include/efi/efi.h"

#define PMM_PAGE_SIZE 4096ULL

typedef struct {
    uint64_t total_pages;
    uint64_t free_pages;
    uint64_t used_pages;
} pmm_stats_t;

/* UEFI 메모리 맵을 바탕으로 물리 페이지 비트맵을 초기화한다.
 * EfiConventionalMemory 영역만 "가용"으로 표시하고, 그 외(로더 자신이
 * 점유한 영역 포함)는 전부 "사용중"으로 표시한다. */
void pmm_init(EFI_MEMORY_DESCRIPTOR *map, UINTN map_size, UINTN desc_size);

/* 4KB 물리 페이지 1개를 할당한다. 실패 시 0 반환 (물리주소 0은 항상
 * 예약되어 있으므로 0을 "실패" sentinel로 안전하게 사용할 수 있다). */
uint64_t pmm_alloc_page(void);

/* 연속된 물리 페이지 n개를 할당한다 (커널 힙 확장 등에 사용). 실패 시 0. */
uint64_t pmm_alloc_pages(uint64_t count);

void pmm_free_page(uint64_t phys_addr);

void pmm_get_stats(pmm_stats_t *out);

#endif
