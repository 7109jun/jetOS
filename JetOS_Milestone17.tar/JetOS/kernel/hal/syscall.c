/*
 * JetOS - kernel/hal/syscall.c
 * syscall.h 참고. syscall_entry.c(어셈블리 트램폴린)가 레지스터를 저장한
 * 뒤 이 함수를 부른다 — 여기서부터는 100% 순수 C.
 */
#include "syscall.h"
#include "../drivers/serial.h"
#include "../int/pit.h"
#include "../proc/thread.h"

void syscall_dispatch(syscall_regs_t *regs) {
    switch (regs->rax) {
        case SYS_WRITE: {
            const char *s = (const char *)regs->rdi;
            /* 알려진 단순화(syscall.h 참고): 포인터 검증 없음 */
            serial_write(s);
            regs->rax = 0;
            break;
        }
        case SYS_GETTICK: {
            regs->rax = g_timer_ticks;
            break;
        }
        case SYS_EXIT: {
            thread_exit(); /* 돌아오지 않음 */
            break;
        }
        default: {
            serial_write("[syscall] unknown syscall number\n");
            regs->rax = (uint64_t)-1;
            break;
        }
    }
}
