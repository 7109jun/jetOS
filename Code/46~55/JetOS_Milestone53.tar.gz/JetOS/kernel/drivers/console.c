/*
 * JetOS - kernel/drivers/console.c
 * UEFI GOP(Graphics Output Protocol)가 넘겨준 선형 프레임버퍼에 직접
 * 픽셀을 써서 화면 출력을 구현한다. 포트 I/O가 아닌 메모리 매핑된
 * 프레임버퍼이므로 순수 C 메모리 접근(포인터 대입)만으로 동작하며
 * 어셈블리가 전혀 필요 없다.
 */

#include "console.h"
#include "font5x7.h"
#include "utf8.h"
#include "hangul_font.h"

#define GLYPH_SCALE 2
#define GLYPH_ADVANCE ((FONT_W + 1) * GLYPH_SCALE)
#define LINE_ADVANCE  ((FONT_H + 2) * GLYPH_SCALE)
#define HANGUL_SCALE 1
#define HANGUL_ADVANCE (HANGUL_CELL_W * HANGUL_SCALE + 3)
#define HANGUL_LINE_ADVANCE (HANGUL_CELL_H * HANGUL_SCALE + 2)

void console_init(console_t *con, uint32_t *fb, uint32_t width, uint32_t height, uint32_t pps) {
    con->fb = fb;
    con->width = width;
    con->height = height;
    con->pixels_per_scanline = pps;
    con->cursor_x = 0;
    con->cursor_y = 0;
    con->fg_color = 0x00E0E0E0; /* 밝은 회색 텍스트 */
    con->bg_color = 0x00101018; /* JetOS 기본 배경 (Windows와 다른 고유 톤) */
    con->clip_x0 = 0; con->clip_y0 = 0;
    con->clip_x1 = (int)width; con->clip_y1 = (int)height;
}

void console_set_clip(console_t *con, int x0, int y0, int x1, int y1) {
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > (int)con->width) x1 = (int)con->width;
    if (y1 > (int)con->height) y1 = (int)con->height;
    con->clip_x0 = x0; con->clip_y0 = y0;
    con->clip_x1 = x1; con->clip_y1 = y1;
}

void console_reset_clip(console_t *con) {
    con->clip_x0 = 0; con->clip_y0 = 0;
    con->clip_x1 = (int)con->width; con->clip_y1 = (int)con->height;
}

void console_put_pixel(console_t *con, uint32_t x, uint32_t y, uint32_t color) {
    if (x >= con->width || y >= con->height) return;
    if ((int)x < con->clip_x0 || (int)x >= con->clip_x1 ||
        (int)y < con->clip_y0 || (int)y >= con->clip_y1) return;
    con->fb[y * con->pixels_per_scanline + x] = color;
}

void console_fill_rect(console_t *con, uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint32_t color) {
    for (uint32_t j = 0; j < h; j++) {
        for (uint32_t i = 0; i < w; i++) {
            console_put_pixel(con, x + i, y + j, color);
        }
    }
}

void console_clear(console_t *con, uint32_t color) {
    console_fill_rect(con, 0, 0, con->width, con->height, color);
    con->cursor_x = 0;
    con->cursor_y = 0;
}



/* Milestone 23: "픽셀 느낌을 거의 없앤다" — 예전엔 5x7 비트를 그냥
 * GLYPH_SCALE배 만큼 딱딱한 정사각형으로 확대해서(최근접 이웃 확대)
 * 글자가 계단처럼 각져 보였다. 진짜 벡터/트루타입 폰트 렌더러를
 * 새로 만드는 대신(그건 이 작은 5x7 비트맵 폰트 자체를 통째로
 * 갈아엎어야 하는 별도 과제), 같은 비트맵을 유지하면서 **정수 전용
 * 바이리니어 보간 안티에일리어싱**을 입혀서 대각선/곡선 부분을
 * 매끄럽게 만들었다 — 커널이 `-mgeneral-regs-only`로 빌드되어
 * 부동소수점(SSE)을 아예 못 쓰므로, 전부 8비트 고정소수점(0~256)
 * 정수 연산으로 구현했다. 배경색도 그 자리의 실제 프레임버퍼 값을
 * 읽어와 블렌딩하므로 그라디언트 배경 위에서도 자연스럽다. */

/* Milestone 40: 이전엔 미지원 ASCII 문자를 조용히 공백으로 대체했다 —
 * '(' 같은 흔한 프로그래밍 기호가 화면에 아무것도 안 찍히는데 이게
 * "글자가 없는 것"인지 "렌더러가 이 글자를 모르는 것"인지 구분이 안
 * 됐다(자기 자신을 코드로 채워야 하는 self-hosting 목표에서는 특히
 * 위험한 조용한 실패). 이제 못 찾으면 NULL을 반환해서 console_putc가
 * (콘솔이 이미 코드포인트>=128용으로 갖고 있던 것과 똑같은) 자리표시
 * 상자를 그리게 한다 — 눈에 보이는 "모르는 글자" 표시로 통일. */
static const font_glyph_t *find_glyph(char c) {
    for (uint32_t i = 0; i < FONT_GLYPH_COUNT; i++) {
        if (g_font5x7[i].ch == c) return &g_font5x7[i];
    }
    return (const font_glyph_t *)0;
}

static int glyph_bit(const font_glyph_t *g, int row, int col) {
    if (row < 0 || row >= FONT_H || col < 0 || col >= FONT_W) return 0;
    return (g->rows[row] & (1 << (FONT_W - 1 - col))) ? 1 : 0;
}

/* 출력 글리프 셀(가로세로 각각 scale배 확대된) 안의 좌표 (px,py)에서의
 * 커버리지(0~256, 256=완전히 켜짐)를 원본 비트맵을 바이리니어 보간해
 * 계산한다. 좌표 매핑은 표준 텍스처 업샘플링 관례(px+0.5)/scale-0.5를
 * 256배 고정소수점으로 그대로 옮긴 것 — sx256 = ((2*px+1)*128)/scale - 128. */
static int glyph_coverage(const font_glyph_t *g, int px, int py, int scale) {
    int sx256 = ((2 * px + 1) * 128) / scale - 128;
    int sy256 = ((2 * py + 1) * 128) / scale - 128;
    int sx0 = sx256 >> 8; /* 산술 시프트 = floor division(음수도 올바르게) */
    int sy0 = sy256 >> 8;
    int fx = sx256 - (sx0 << 8); /* 0..255 */
    int fy = sy256 - (sy0 << 8);

    int b00 = glyph_bit(g, sy0,     sx0);
    int b10 = glyph_bit(g, sy0,     sx0 + 1);
    int b01 = glyph_bit(g, sy0 + 1, sx0);
    int b11 = glyph_bit(g, sy0 + 1, sx0 + 1);

    int top    = b00 * (256 - fx) + b10 * fx;      /* 0..256*256 */
    int bottom = b01 * (256 - fx) + b11 * fx;
    int total  = top * (256 - fy) + bottom * fy;    /* 0..256*256*256 */
    return total >> 8; /* 0..256 (수정: 예전엔 실수로 >>16을 써서 커버리지가 항상 0이 되는
                         * 버그가 있었다 — total의 실제 최대값은 256*256=65536이므로 8비트만
                         * 시프트해야 한다. 호스트에서 'A' 글자 커버리지 맵을 직접 찍어보고
                         * 전부 0이 나오는 걸로 발견/수정했다.) */
}

/* fg/bg를 coverage(0~256)로 블렌딩한 색을 con의 (x,y)에 쓴다. bg는
 * 그 자리에 원래 있던 실제 프레임버퍼 값을 읽어와 쓴다(그라디언트
 * 배경 위에서도 자연스럽게 섞이도록). coverage가 0/256 근방이면
 * 굳이 블렌딩 계산 없이 원색을 바로 써서(가장 흔한 경우) 조금이라도
 * 빠르게 처리한다. */
void console_blend_pixel(console_t *con, int x, int y, int coverage, uint32_t fg) {
    if (x < 0 || y < 0 || (uint32_t)x >= con->width || (uint32_t)y >= con->height) return;
    if (coverage <= 0) return;
    if (coverage >= 256) { console_put_pixel(con, (uint32_t)x, (uint32_t)y, fg); return; }

    uint32_t bg = con->fb[(uint32_t)y * con->pixels_per_scanline + (uint32_t)x];
    int fr = (int)((fg >> 16) & 0xFF), fgc = (int)((fg >> 8) & 0xFF), fb_ = (int)(fg & 0xFF);
    int br = (int)((bg >> 16) & 0xFF), bgc = (int)((bg >> 8) & 0xFF), bb_ = (int)(bg & 0xFF);
    int r = br + ((fr - br) * coverage) / 256;
    int gch = bgc + ((fgc - bgc) * coverage) / 256;
    int b = bb_ + ((fb_ - bb_) * coverage) / 256;
    uint32_t out = ((uint32_t)r << 16) | ((uint32_t)gch << 8) | (uint32_t)b;
    console_put_pixel(con, (uint32_t)x, (uint32_t)y, out);
}

void console_putc(console_t *con, char c) {
    if (c == '\n') {
        con->cursor_x = 0;
        con->cursor_y += LINE_ADVANCE;
        return;
    }
    if (con->cursor_x + GLYPH_ADVANCE > con->width) {
        con->cursor_x = 0;
        con->cursor_y += LINE_ADVANCE;
    }
    if (con->cursor_y + LINE_ADVANCE > con->height) {
        /* Milestone 1: 스크롤 없음. 화면 하단 도달 시 처음으로 되돌린다. */
        con->cursor_y = 0;
    }

    const font_glyph_t *g = find_glyph(c);
    int cell_w = FONT_W * GLYPH_SCALE, cell_h = FONT_H * GLYPH_SCALE;
    if (!g) {
        /* 미지원 ASCII 문자: console_print()의 미지원 유니코드 코드포인트와
         * 같은 스타일의 자리표시 상자(□)를 그린다 — "안 보임"이 아니라
         * "모르는 글자"라는 걸 눈에 보이게 알린다. */
        console_fill_rect(con, con->cursor_x + 1, con->cursor_y, 2, (uint32_t)(FONT_H * GLYPH_SCALE - 2), con->fg_color);
        console_fill_rect(con, con->cursor_x + (uint32_t)GLYPH_ADVANCE - 4, con->cursor_y, 2, (uint32_t)(FONT_H * GLYPH_SCALE - 2), con->fg_color);
        con->cursor_x += GLYPH_ADVANCE;
        return;
    }
    for (int py = 0; py < cell_h; py++) {
        for (int px = 0; px < cell_w; px++) {
            int cov = glyph_coverage(g, px, py, GLYPH_SCALE);
            if (cov > 0) {
                console_blend_pixel(con, (int)con->cursor_x + px, (int)con->cursor_y + py, cov, con->fg_color);
            }
        }
    }
    con->cursor_x += GLYPH_ADVANCE;
}

void console_print(console_t *con, const char *s) {
    while (*s) {
        uint32_t cp;
        int n = utf8_decode(s, &cp);
        if (n == 0) break;

        if (cp < 128) {
            console_putc(con, (char)cp);
        } else if (hangul_is_syllable(cp)) {
            if (con->cursor_x + (uint32_t)HANGUL_ADVANCE > con->width) {
                con->cursor_x = 0;
                con->cursor_y += (uint32_t)HANGUL_LINE_ADVANCE;
            }
            if (con->cursor_y + (uint32_t)HANGUL_LINE_ADVANCE > con->height) {
                con->cursor_y = 0;
            }
            hangul_draw_syllable(con, (int)con->cursor_x, (int)con->cursor_y, cp, con->fg_color, HANGUL_SCALE);
            con->cursor_x += (uint32_t)HANGUL_ADVANCE;
        } else {
            /* 지원하지 않는 코드포인트: 자리표시 상자(□) 하나를 그리고
             * ASCII 한 칸만큼 전진한다 — 렌더링이 깨지거나 멈추지
             * 않고 계속 진행되는 게 중요하다(Milestone 13). */
            if (con->cursor_x + GLYPH_ADVANCE > con->width) {
                con->cursor_x = 0;
                con->cursor_y += LINE_ADVANCE;
            }
            console_fill_rect(con, con->cursor_x + 1, con->cursor_y, 2, FONT_H * GLYPH_SCALE - 2, con->fg_color);
            console_fill_rect(con, con->cursor_x + GLYPH_ADVANCE - 4, con->cursor_y, 2, FONT_H * GLYPH_SCALE - 2, con->fg_color);
            con->cursor_x += GLYPH_ADVANCE;
        }
        s += n;
    }
}
