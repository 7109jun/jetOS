/*
 * JetOS - kernel/mm/pmm.c
 *
 * 비트맵 기반 Physical Memory Manager.
 * 부트스트랩 문제(할당자가 자기 자신을 위한 메모리를 할당해야 하는
 * 딜레마)를 피하기 위해, 비트맵 자체는 커널 이미지의 정적(.bss) 배열로
 * 확보한다. 1비트가 4KB 페이지 1개에 대응하며, 최대 16GiB까지의 물리
 * 주소 공간을 다룰 수 있다 (그 이상은 향후 마일스톤에서 동적 크기 조절로
 * 확장 예정 — README/ARCHITECTURE에 명시).
 */

#include "pmm.h"

#define PMM_MAX_PHYS_GB   16ULL
#define BITMAP_BITS       ((PMM_MAX_PHYS_GB * 1024ULL * 1024ULL * 1024ULL) / PMM_PAGE_SIZE)
#define BITMAP_BYTES       (BITMAP_BITS / 8)

static uint8_t g_bitmap[BITMAP_BYTES];
static uint64_t g_next_free_hint = 0;
static pmm_stats_t g_stats;

static inline void bitmap_set(uint64_t bit) {
    g_bitmap[bit / 8] |= (uint8_t)(1u << (bit % 8));
}
static inline void bitmap_clear(uint64_t bit) {
    g_bitmap[bit / 8] &= (uint8_t)~(1u << (bit % 8));
}
static inline int bitmap_test(uint64_t bit) {
    return (g_bitmap[bit / 8] >> (bit % 8)) & 1;
}

void pmm_init(EFI_MEMORY_DESCRIPTOR *map, UINTN map_size, UINTN desc_size) {
    /* 1) 기본값: 전 영역 "사용중"으로 표시 */
    for (uint64_t i = 0; i < BITMAP_BYTES; i++) g_bitmap[i] = 0xFF;

    g_stats.total_pages = BITMAP_BITS;
    g_stats.free_pages = 0;
    g_stats.used_pages = BITMAP_BITS;

    /* 2) EfiConventionalMemory 영역만 "가용"으로 표시 */
    uint8_t *cursor = (uint8_t *)map;
    uint8_t *end = (uint8_t *)map + map_size;

    while (cursor < end) {
        EFI_MEMORY_DESCRIPTOR *desc = (EFI_MEMORY_DESCRIPTOR *)cursor;

        if (desc->Type == EfiConventionalMemory) {
            uint64_t start_page = desc->PhysicalStart / PMM_PAGE_SIZE;
            uint64_t page_count = desc->NumberOfPages;

            for (uint64_t p = 0; p < page_count; p++) {
                uint64_t bit = start_page + p;
                if (bit >= BITMAP_BITS) break; /* 지원 범위(16GiB) 밖은 무시 */
                bitmap_clear(bit);
                g_stats.free_pages++;
                g_stats.used_pages--;
            }
        }

        cursor += desc_size;
    }

    /* 3) NULL 페이지(물리주소 0)는 항상 사용중으로 강제 예약 (안전장치) */
    if (!bitmap_test(0)) {
        bitmap_set(0);
        g_stats.free_pages--;
        g_stats.used_pages++;
    }

    g_next_free_hint = 0;
}

uint64_t pmm_alloc_page(void) {
    for (uint64_t bit = g_next_free_hint; bit < BITMAP_BITS; bit++) {
        if (!bitmap_test(bit)) {
            bitmap_set(bit);
            g_stats.free_pages--;
            g_stats.used_pages++;
            g_next_free_hint = bit + 1;
            return bit * PMM_PAGE_SIZE;
        }
    }
    /* 힌트 이후에서 못 찾았으면 처음부터 다시 탐색 */
    for (uint64_t bit = 0; bit < g_next_free_hint; bit++) {
        if (!bitmap_test(bit)) {
            bitmap_set(bit);
            g_stats.free_pages--;
            g_stats.used_pages++;
            g_next_free_hint = bit + 1;
            return bit * PMM_PAGE_SIZE;
        }
    }
    return 0; /* 실패 */
}

uint64_t pmm_alloc_pages(uint64_t count) {
    if (count == 0) return 0;

    for (uint64_t start = 0; start + count <= BITMAP_BITS; start++) {
        int ok = 1;
        for (uint64_t i = 0; i < count; i++) {
            if (bitmap_test(start + i)) { ok = 0; break; }
        }
        if (ok) {
            for (uint64_t i = 0; i < count; i++) {
                bitmap_set(start + i);
            }
            g_stats.free_pages -= count;
            g_stats.used_pages += count;
            return start * PMM_PAGE_SIZE;
        }
    }
    return 0; /* 실패: 연속된 빈 블록 없음 */
}

void pmm_free_page(uint64_t phys_addr) {
    uint64_t bit = phys_addr / PMM_PAGE_SIZE;
    if (bit >= BITMAP_BITS) return;
    if (bitmap_test(bit)) {
        bitmap_clear(bit);
        g_stats.free_pages++;
        g_stats.used_pages--;
        if (bit < g_next_free_hint) g_next_free_hint = bit;
    }
}

void pmm_get_stats(pmm_stats_t *out) {
    *out = g_stats;
}
