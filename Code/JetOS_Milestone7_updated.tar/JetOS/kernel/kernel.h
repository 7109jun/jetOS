#ifndef JETOS_KERNEL_H
#define JETOS_KERNEL_H

#include "drivers/console.h"

/* Milestone 1 전역 콘솔 핸들 (kernel_entry.c 에서 초기화됨) */
extern console_t g_console;

#endif
