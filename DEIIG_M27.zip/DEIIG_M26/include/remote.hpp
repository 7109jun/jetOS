#pragma once
#include <filesystem>
#include <string>
#include <vector>

namespace deiig::remote {

struct Profile {
    std::string name;
    std::string host;
    std::string user;
    int port = 22;
    std::string remote_root;
    std::string key_file;
};

std::filesystem::path profile_file(const std::filesystem::path& project_dir);
bool save_profile(const std::filesystem::path& project_dir, const Profile& profile);
std::vector<Profile> load_profiles(const std::filesystem::path& project_dir);
const Profile* find_profile(const std::vector<Profile>& profiles, const std::string& name);
std::string target(const Profile& profile);
std::string shell_quote(const std::string& value);
std::string ssh_command(const Profile& profile, const std::string& command);
int exec(const std::filesystem::path& project_dir, const Profile& profile, const std::string& command);
int pull(const std::filesystem::path& project_dir, const Profile& profile, const std::string& remote_path, const std::filesystem::path& local_path);
int push(const std::filesystem::path& project_dir, const Profile& profile, const std::filesystem::path& local_path, const std::string& remote_path);

} // namespace deiig::remote
