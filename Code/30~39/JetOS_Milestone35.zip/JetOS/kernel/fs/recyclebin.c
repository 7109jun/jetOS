/* JetOS - kernel/fs/recyclebin.c - recyclebin.h 참고. */
#include "recyclebin.h"
#include "jetfs.h"
#include <stddef.h>

#define RECYCLEBIN_DIR "/.recyclebin"
#define RECYCLEBIN_INDEX "/.recyclebin/index.txt"
#define INDEX_BUF_CAP 16384 /* 인덱스 텍스트 최대 크기 — 항목 하나당 대략 40~60바이트라 수백 개는 넉넉히 담김 */
#define SHORTNAME_CAP 16
#define PATH_CAP 192

static size_t xstrlen(const char *s) { size_t n = 0; while (s[n]) n++; return n; }
static void xstrcpy(char *dst, const char *src, size_t cap) {
    size_t i = 0;
    while (src[i] && i + 1 < cap) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

static void ensure_dir(void) {
    jetfs_inode_type_t t;
    if (!jetfs_stat(RECYCLEBIN_DIR, &t, NULL)) jetfs_create(RECYCLEBIN_DIR, JETFS_TYPE_DIR);
}

static uint64_t read_index(char *buf, uint64_t cap) {
    uint64_t n = 0;
    if (!jetfs_read(RECYCLEBIN_INDEX, buf, cap - 1, &n)) n = 0;
    buf[n] = '\0';
    return n;
}

/* 인덱스 텍스트에서 몇 줄(=몇 항목)인지 센다 — 다음 short_name 번호를
 * 정하는 데 쓴다(recyclebin.h 상단 "알려진 단순화" 참고). */
static int count_lines(const char *buf) {
    int n = 0;
    for (size_t i = 0; buf[i]; i++) if (buf[i] == '\n') n++;
    return n;
}

/* 한 줄(끝에 \n 포함, 없으면 문자열 끝까지)을 out에 복사하고, 그 다음
 * 줄이 시작하는 위치(포인터)를 반환한다(없으면 NULL). */
static const char *next_line(const char *p, char *out, size_t out_cap) {
    if (!p || !*p) return NULL;
    size_t i = 0;
    while (*p && *p != '\n' && i + 1 < out_cap) { out[i++] = *p; p++; }
    out[i] = '\0';
    while (*p && *p != '\n') p++; /* out_cap 넘는 나머지는 버림(비정상적으로 긴 줄 방어) */
    if (*p == '\n') p++;
    return *p ? p : NULL;
}

/* "short_name\toriginal_path" 형태의 줄 하나를 파싱한다. 형식이 아니면 0. */
static int parse_line(const char *line, char *shortname_out, char *path_out) {
    size_t i = 0, j = 0;
    while (line[i] && line[i] != '\t' && j + 1 < SHORTNAME_CAP) shortname_out[j++] = line[i++];
    shortname_out[j] = '\0';
    if (line[i] != '\t') return 0;
    i++;
    j = 0;
    while (line[i] && j + 1 < PATH_CAP) path_out[j++] = line[i++];
    path_out[j] = '\0';
    return shortname_out[0] != '\0' && path_out[0] != '\0';
}

int recyclebin_delete(const char *path) {
    if (!path || !path[0]) return 0;
    jetfs_inode_type_t t; uint64_t sz;
    if (!jetfs_stat(path, &t, &sz) || t != JETFS_TYPE_FILE) return 0; /* 파일만 지원 — recyclebin.h 참고 */
    ensure_dir();

    static char idx[INDEX_BUF_CAP];
    read_index(idx, sizeof(idx));
    int n = count_lines(idx);

    char shortname[SHORTNAME_CAP];
    /* "item" + 4자리 숫자 — 충돌 방지를 위해 이미 존재하지 않는 번호가
     * 나올 때까지 증가시킨다(드물지만 인덱스와 실제 파일이 어긋난
     * 경우 대비). */
    char trash_path[PATH_CAP];
    for (int tries = 0; tries < 10000; tries++) {
        int num = n + tries;
        char digits[6];
        int d = num % 10000;
        digits[0] = (char)('0' + (d / 1000) % 10);
        digits[1] = (char)('0' + (d / 100) % 10);
        digits[2] = (char)('0' + (d / 10) % 10);
        digits[3] = (char)('0' + d % 10);
        digits[4] = '\0';
        xstrcpy(shortname, "item", sizeof(shortname));
        size_t sl = xstrlen(shortname);
        for (int k = 0; k < 4 && sl + 1 < sizeof(shortname); k++) shortname[sl++] = digits[k];
        shortname[sl] = '\0';

        xstrcpy(trash_path, RECYCLEBIN_DIR "/", sizeof(trash_path));
        size_t tl = xstrlen(trash_path);
        for (size_t k = 0; shortname[k] && tl + 1 < sizeof(trash_path); k++) trash_path[tl++] = shortname[k];
        trash_path[tl] = '\0';

        jetfs_inode_type_t exists_t;
        if (!jetfs_stat(trash_path, &exists_t, NULL)) break; /* 안 쓰는 이름을 찾음 */
    }

    if (!jetfs_rename(path, trash_path)) return 0;

    /* 인덱스에 한 줄 추가: "item0007\t/원래/경로\n" */
    char line[SHORTNAME_CAP + PATH_CAP + 2];
    size_t li = 0;
    for (size_t k = 0; shortname[k] && li < sizeof(line) - 1; k++) line[li++] = shortname[k];
    if (li < sizeof(line) - 1) line[li++] = '\t';
    for (size_t k = 0; path[k] && li < sizeof(line) - 1; k++) line[li++] = path[k];
    if (li < sizeof(line) - 1) line[li++] = '\n';
    line[li] = '\0';

    jetfs_inode_type_t idx_t;
    if (!jetfs_stat(RECYCLEBIN_INDEX, &idx_t, NULL)) jetfs_create(RECYCLEBIN_INDEX, JETFS_TYPE_FILE);
    jetfs_append(RECYCLEBIN_INDEX, line, li);
    return 1;
}

int recyclebin_restore(const char *short_name) {
    static char idx[INDEX_BUF_CAP];
    uint64_t n = read_index(idx, sizeof(idx));
    if (n == 0) return 0;

    static char rebuilt[INDEX_BUF_CAP];
    size_t rebuilt_len = 0;
    int found = 0;
    char orig_path[PATH_CAP];

    const char *p = idx;
    char line[SHORTNAME_CAP + PATH_CAP + 2];
    while (p) {
        const char *next = next_line(p, line, sizeof(line));
        if (line[0]) {
            char sn[SHORTNAME_CAP]; char pth[PATH_CAP];
            if (parse_line(line, sn, pth)) {
                int match = 1;
                for (size_t k = 0; ; k++) {
                    if (sn[k] != short_name[k]) { match = 0; break; }
                    if (!sn[k]) break;
                }
                if (match && !found) {
                    found = 1;
                    xstrcpy(orig_path, pth, sizeof(orig_path));
                } else {
                    for (size_t k = 0; line[k] && rebuilt_len + 1 < sizeof(rebuilt); k++) rebuilt[rebuilt_len++] = line[k];
                    if (rebuilt_len + 1 < sizeof(rebuilt)) rebuilt[rebuilt_len++] = '\n';
                }
            }
        }
        p = next;
    }
    rebuilt[rebuilt_len] = '\0';

    if (!found) return 0;

    jetfs_inode_type_t exists_t;
    if (jetfs_stat(orig_path, &exists_t, NULL)) return 0; /* 원래 자리에 이미 뭔가 있음 — 덮어쓰지 않고 실패(안전 우선) */

    char trash_path[PATH_CAP];
    xstrcpy(trash_path, RECYCLEBIN_DIR "/", sizeof(trash_path));
    size_t tl = xstrlen(trash_path);
    for (size_t k = 0; short_name[k] && tl + 1 < sizeof(trash_path); k++) trash_path[tl++] = short_name[k];
    trash_path[tl] = '\0';

    if (!jetfs_rename(trash_path, orig_path)) return 0;
    jetfs_write(RECYCLEBIN_INDEX, rebuilt, rebuilt_len);
    return 1;
}

int recyclebin_purge_one(const char *short_name) {
    static char idx[INDEX_BUF_CAP];
    uint64_t n = read_index(idx, sizeof(idx));
    if (n == 0) return 0;

    static char rebuilt[INDEX_BUF_CAP];
    size_t rebuilt_len = 0;
    int found = 0;

    const char *p = idx;
    char line[SHORTNAME_CAP + PATH_CAP + 2];
    while (p) {
        const char *next = next_line(p, line, sizeof(line));
        if (line[0]) {
            char sn[SHORTNAME_CAP]; char pth[PATH_CAP];
            if (parse_line(line, sn, pth)) {
                int match = 1;
                for (size_t k = 0; ; k++) {
                    if (sn[k] != short_name[k]) { match = 0; break; }
                    if (!sn[k]) break;
                }
                if (match && !found) {
                    found = 1;
                } else {
                    for (size_t k = 0; line[k] && rebuilt_len + 1 < sizeof(rebuilt); k++) rebuilt[rebuilt_len++] = line[k];
                    if (rebuilt_len + 1 < sizeof(rebuilt)) rebuilt[rebuilt_len++] = '\n';
                }
            }
        }
        p = next;
    }
    rebuilt[rebuilt_len] = '\0';
    if (!found) return 0;

    char trash_path[PATH_CAP];
    xstrcpy(trash_path, RECYCLEBIN_DIR "/", sizeof(trash_path));
    size_t tl = xstrlen(trash_path);
    for (size_t k = 0; short_name[k] && tl + 1 < sizeof(trash_path); k++) trash_path[tl++] = short_name[k];
    trash_path[tl] = '\0';

    jetfs_delete(trash_path);
    jetfs_write(RECYCLEBIN_INDEX, rebuilt, rebuilt_len);
    return 1;
}

int recyclebin_empty(void) {
    static char idx[INDEX_BUF_CAP];
    uint64_t n = read_index(idx, sizeof(idx));
    if (n == 0) return 0;

    int count = 0;
    const char *p = idx;
    char line[SHORTNAME_CAP + PATH_CAP + 2];
    while (p) {
        const char *next = next_line(p, line, sizeof(line));
        if (line[0]) {
            char sn[SHORTNAME_CAP]; char pth[PATH_CAP];
            if (parse_line(line, sn, pth)) {
                char trash_path[PATH_CAP];
                xstrcpy(trash_path, RECYCLEBIN_DIR "/", sizeof(trash_path));
                size_t tl = xstrlen(trash_path);
                for (size_t k = 0; sn[k] && tl + 1 < sizeof(trash_path); k++) trash_path[tl++] = sn[k];
                trash_path[tl] = '\0';
                if (jetfs_delete(trash_path)) count++;
            }
        }
        p = next;
    }
    jetfs_write(RECYCLEBIN_INDEX, "", 0);
    return count;
}

int recyclebin_list(recyclebin_list_cb cb, void *ctx) {
    static char idx[INDEX_BUF_CAP];
    uint64_t n = read_index(idx, sizeof(idx));
    if (n == 0) return 0;

    int count = 0;
    const char *p = idx;
    char line[SHORTNAME_CAP + PATH_CAP + 2];
    while (p) {
        const char *next = next_line(p, line, sizeof(line));
        if (line[0]) {
            char sn[SHORTNAME_CAP]; char pth[PATH_CAP];
            if (parse_line(line, sn, pth)) {
                if (cb) cb(sn, pth, ctx);
                count++;
            }
        }
        p = next;
    }
    return count;
}
