#ifndef JETOS_ELF_LOADER_H
#define JETOS_ELF_LOADER_H

#include <stdint.h>

/*
 * JetOS - kernel/exec/elf_loader.h
 *
 * Milestone 15: 네이티브 ELF64 실행 파일 로더 + 실행기.
 *
 * PE32+ 로더(pe_loader.c)가 "Windows 호환"을 위한 것이라면, 이건
 * "JetOS 자체 프로세스"를 위한 것이다 — 표준 ELF64(x86-64) 실행 파일을
 * 그 프로세스만의 격리된 주소공간(vmm_create_process_address_space())에
 * 적재하고, 진짜 Ring3(Milestone 14)에서 실행한다.
 *
 * 알려진 단순화:
 *   - 정적 링크(static) 바이너리만 지원한다. 동적 링커(ld.so)나 공유
 *     라이브러리는 없다.
 *   - 유저 영역이 프로세스당 16MiB로 고정(vmm_user_region_size(),
 *     Milestone 20에서 2MiB→16MiB로 확장)이므로 그 안에 들어가는
 *     프로그램만 실행 가능하다. 로드된 세그먼트를 넘어서는 힙 성장은
 *     SYS_BRK 시스템콜로 가능(syscall.h 참고).
 *   - PIE(위치독립실행파일)는 지원하지 않는다 — ELF의 p_vaddr을 그대로
 *     신뢰해서 매핑하므로, 링크 시점에 vmm_user_virt_base() 근방
 *     주소로 고정 링크된 바이너리여야 한다.
 */

typedef struct {
    int error_code;        /* 0=성공 */
    const char *error_msg;
    uint64_t pml4_phys;     /* 이 프로세스 전용 주소공간 */
    uint64_t entry_point;   /* 유저 가상주소 기준 진입점 */
    uint64_t user_stack_top;
    uint64_t initial_brk;   /* Milestone 20: 로드된 세그먼트 바로 다음 페이지 경계 —
                              * SYS_BRK의 시작점(thread_set_user_brk에 전달됨) */
} elf_load_result_t;

/* JETFS 경로의 ELF64 파일을 읽어 새 프로세스 주소공간에 적재한다. */
void elf_load(const char *path, elf_load_result_t *result);

/* elf_load()에 성공한 결과를 실제로 Ring3에서 실행한다 — CR3를
 * 전환하고 hal_enter_user_mode()로 진입한다. noreturn(이 스레드는
 * 유저 코드의 SYS_EXIT을 통해 thread_exit()로 끝난다). */
__attribute__((noreturn))
void elf_run(const elf_load_result_t *result);

/* jash 등에서 쓰는 편의 함수: 로드+새 스레드에서 실행까지 한 번에.
 * 로드 실패 시 0, 성공(스레드 시작됨) 시 1. */
int elf_execute(const char *path);

/* Milestone 37: elf_execute와 완전히 동일하지만, 이 프로그램이
 * SYS_WRITE로 찍는 출력을 시리얼 말고 stdout_sink에도 전달하게 한다
 * (예: jash가 자기 창에 표시하려고 씀). sink가 NULL이면 elf_execute와
 * 정확히 같다 — elf_execute 자체가 이 함수의 얇은 래퍼로 재구현됨. */
int elf_execute_ex(const char *path, void (*stdout_sink)(const char *s));

#endif
