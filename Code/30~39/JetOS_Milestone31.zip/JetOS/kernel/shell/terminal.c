/*
 * JetOS - kernel/shell/terminal.c
 * 최소 명령어 파서 + JETFS 연동 디스패처.
 */

#include "terminal.h"
#include "../fs/jetfs.h"
#include "../drivers/serial.h"
#include <stddef.h>

#define MAX_TOKENS 8
#define MAX_LINE 128

static int str_eq(const char *a, const char *b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static void serial_write_uint(uint32_t v) {
    char tmp[12]; int t = 0;
    if (v == 0) { serial_putc('0'); return; }
    while (v > 0) { tmp[t++] = (char)('0' + (v % 10)); v /= 10; }
    while (t > 0) serial_putc(tmp[--t]);
}

static int tokenize(char *line, char *tokens[], int max_tokens) {
    int count = 0;
    char *p = line;
    while (*p && count < max_tokens) {
        while (*p == ' ') p++;
        if (!*p) break;
        tokens[count++] = p;
        while (*p && *p != ' ') p++;
        if (*p) { *p = '\0'; p++; }
    }
    return count;
}

static void list_cb(const char *name, jetfs_inode_type_t type, uint64_t size, void *ctx) {
    (void)ctx;
    serial_write("    ");
    serial_write(type == JETFS_TYPE_DIR ? "[DIR]  " : "[FILE] ");
    serial_write(name);
    if (type == JETFS_TYPE_FILE) {
        serial_write("  (");
        serial_write_uint(size);
        serial_write(" bytes)");
    }
    serial_write("\n");
}

static void exec_line(char *line) {
    char original[MAX_LINE];
    int oi = 0;
    for (; line[oi] && oi < MAX_LINE - 1; oi++) original[oi] = line[oi];
    original[oi] = '\0';

    char *tokens[MAX_TOKENS];
    int n = tokenize(line, tokens, MAX_TOKENS);
    if (n == 0) return;

    serial_write("jetos:> ");
    serial_write(original);
    serial_write("\n");

    if (str_eq(tokens[0], "help")) {
        serial_write("  help ls mkdir write cat rename delete\n");
    } else if (str_eq(tokens[0], "ls")) {
        const char *path = (n >= 2) ? tokens[1] : "/";
        if (!jetfs_list(path, list_cb, NULL)) serial_write("  ls: 실패\n");
    } else if (str_eq(tokens[0], "mkdir")) {
        if (n < 2) { serial_write("  사용법: mkdir <경로>\n"); return; }
        serial_write(jetfs_create(tokens[1], JETFS_TYPE_DIR) ? "  생성됨\n" : "  실패(이미 존재하거나 오류)\n");
    } else if (str_eq(tokens[0], "write")) {
        if (n < 3) { serial_write("  사용법: write <경로> <내용>\n"); return; }
        jetfs_create(tokens[1], JETFS_TYPE_FILE); /* 없으면 새로 생성, 있으면 무시 */
        /* tokenize()가 공백을 NUL로 바꿔 tokens[2..n-1]이 끊어져 있으므로,
         * "내용"으로 취급할 나머지 토큰들을 공백으로 다시 이어붙인다. */
        char *content = tokens[2];
        char *end = tokens[n - 1];
        while (*end) end++;
        for (char *c = content; c < end; c++) {
            if (*c == '\0') *c = ' ';
        }
        uint32_t len = (uint32_t)(end - content);
        serial_write(jetfs_write(tokens[1], content, len) ? "  기록됨\n" : "  실패\n");
    } else if (str_eq(tokens[0], "cat")) {
        if (n < 2) { serial_write("  사용법: cat <경로>\n"); return; }
        char buf[512];
        uint64_t out_size = 0;
        if (jetfs_read(tokens[1], buf, sizeof(buf) - 1, &out_size)) {
            buf[out_size] = '\0';
            serial_write("  ");
            serial_write(buf);
            serial_write("\n");
        } else {
            serial_write("  읽기 실패\n");
        }
    } else if (str_eq(tokens[0], "rename")) {
        if (n < 3) { serial_write("  사용법: rename <기존경로> <새경로>\n"); return; }
        serial_write(jetfs_rename(tokens[1], tokens[2]) ? "  이름변경됨\n" : "  실패\n");
    } else if (str_eq(tokens[0], "delete")) {
        if (n < 2) { serial_write("  사용법: delete <경로>\n"); return; }
        serial_write(jetfs_delete(tokens[1]) ? "  삭제됨\n" : "  실패\n");
    } else {
        serial_write("  알 수 없는 명령\n");
    }
}

void terminal_run_demo_script(void) {
    static char script[][MAX_LINE] = {
        "help",
        "mkdir /docs",
        "write /docs/readme.txt Hello from JetOS JETFS!",
        "ls /",
        "ls /docs",
        "cat /docs/readme.txt",
        "rename /docs/readme.txt /docs/note.txt",
        "cat /docs/note.txt",
        "delete /docs/note.txt",
        "ls /docs",
    };
    int n = (int)(sizeof(script) / sizeof(script[0]));

    serial_write("\n=== JETOS TERMINAL DEMO SCRIPT START ===\n");
    for (int i = 0; i < n; i++) {
        char line[MAX_LINE];
        int j = 0;
        while (script[i][j]) { line[j] = script[i][j]; j++; }
        line[j] = '\0';
        exec_line(line);
    }
    serial_write("=== JETOS TERMINAL DEMO SCRIPT END ===\n\n");
}
