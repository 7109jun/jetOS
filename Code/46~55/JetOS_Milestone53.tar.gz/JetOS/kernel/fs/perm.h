#ifndef JETOS_PERM_H
#define JETOS_PERM_H

/*
 * JetOS - kernel/fs/perm.h
 * Milestone 34: 파일 권한/접근 제어 최소 구현 — 처음엔 별도 목록 파일
 * (/system/readonly.txt)로 관리하는 소프트웨어 레벨 방식이었다("정말로
 * 못 쓰게 막는다"는 커널 레벨 강제가 아니라 각 호출부가 저장/삭제
 * 직전에 이 모듈에 물어보는 수준 — jetfs_write를 직접 부르면 우회
 * 가능하다는 게 알려진 한계였음).
 *
 * Milestone 46: 그 한계를 실제로 없앴다. 읽기전용 플래그를
 * jetfs_inode_t 자체에 넣고(jetfs.h의 JETFS_FLAG_READONLY),
 * jetfs_write/jetfs_append/jetfs_delete 안에서 직접 검사하도록
 * 옮겼다 — 이제 이 perm.c를 거치지 않고 jetfs_write를 직접 불러도
 * 막힌다(진짜 커널 레벨 강제). perm_is_readonly/perm_set_readonly는
 * 호출부(jash 등) 코드를 하나도 안 건드리기 위한 얇은 위임 계층으로
 * 남겨뒀다 — 내부적으로 jetfs_is_readonly/jetfs_set_readonly를
 * 그대로 호출할 뿐이다. 예전 /system/readonly.txt 목록에 있던
 * 항목들은 최초 1회 자동으로 새 inode 플래그로 옮겨진다(마이그레이션,
 * perm_migrate_legacy_list 참고 — 재부팅 한 번이면 끝나고 그 뒤로는
 * 이 목록 파일 자체를 더 이상 안 씀).
 */

/* path가 읽기 전용이면 1, 아니면 0. */
int perm_is_readonly(const char *path);

/* path를 읽기 전용(1)으로 표시하거나 해제(0)한다. 성공 시 1, 실패 시 0. */
int perm_set_readonly(const char *path, int readonly);

/* Milestone 46: 부팅 시 한 번 호출 — 예전 /system/readonly.txt 목록에
 * 있던 경로들을 전부 새 inode 플래그로 옮기고 그 목록 파일은 지운다.
 * 목록 파일이 애초에 없으면(신규 설치, 또는 이미 마이그레이션 끝난
 * 경우) 아무 일도 안 하고 조용히 반환. */
void perm_migrate_legacy_list(void);

#endif
