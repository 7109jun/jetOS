#ifndef JETOS_DNS_H
#define JETOS_DNS_H

#include <stdint.h>

/*
 * JetOS - kernel/net/dns.h
 *
 * Milestone 12: 최소 DNS 클라이언트. UDP로 A 레코드(IPv4 주소)만
 * 질의한다 — AAAA, CNAME 체인 추적, 캐싱 없음. QEMU가 기본 제공하는
 * SLIRP 네트워크의 내장 DNS 포워더(10.0.2.3)에 질의하도록 고정되어
 * 있다(별도 DHCP/설정 없이 항상 이 주소를 쓴다).
 */

/* hostname(예: "example.com")을 A 레코드로 질의해 IPv4 주소를 얻는다.
 * 이미 "a.b.c.d" 형태의 리터럴 IP가 주어지면 네트워크 질의 없이 바로
 * 파싱해서 반환한다(net_str_to_ip와 동일 동작).
 * 성공 시 1과 *out_ip 채움, 실패(타임아웃/에러) 시 0. */
int dns_resolve(const char *hostname, uint32_t *out_ip, uint32_t timeout_ticks);

#endif
