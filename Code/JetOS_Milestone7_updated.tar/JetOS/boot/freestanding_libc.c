/*
 * JetOS - boot/freestanding_libc.c
 *
 * -ffreestanding 환경에서도 GCC는 루프를 memcpy/memset 호출로 최적화할
 * 수 있다. 표준 라이브러리가 없으므로 그 심볼들을 직접 정의해 링크
 * 오류를 막는다 (순수 C, 바이트 단위 루프 구현).
 */
#include <stddef.h>

void *memcpy(void *dest, const void *src, size_t n) {
    unsigned char *d = (unsigned char *)dest;
    const unsigned char *s = (const unsigned char *)src;
    for (size_t i = 0; i < n; i++) d[i] = s[i];
    return dest;
}

void *memset(void *dest, int value, size_t n) {
    unsigned char *d = (unsigned char *)dest;
    for (size_t i = 0; i < n; i++) d[i] = (unsigned char)value;
    return dest;
}

int memcmp(const void *a, const void *b, size_t n) {
    const unsigned char *pa = (const unsigned char *)a;
    const unsigned char *pb = (const unsigned char *)b;
    for (size_t i = 0; i < n; i++) {
        if (pa[i] != pb[i]) return pa[i] - pb[i];
    }
    return 0;
}
