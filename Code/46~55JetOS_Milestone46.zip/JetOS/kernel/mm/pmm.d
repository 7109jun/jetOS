kernel/mm/pmm.o: kernel/mm/pmm.c kernel/mm/pmm.h \
 kernel/mm/../../include/efi/efi.h kernel/mm/../hal/x86_asm_shim.h
kernel/mm/pmm.h:
kernel/mm/../../include/efi/efi.h:
kernel/mm/../hal/x86_asm_shim.h:
