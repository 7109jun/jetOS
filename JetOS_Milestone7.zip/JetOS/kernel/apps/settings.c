/*
 * JetOS - kernel/apps/settings.c
 * 시스템 정보(힙/물리메모리/타이머 틱)를 보여주는 설정 앱.
 */

#include <stddef.h>
#include "settings.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../drivers/console.h"
#include "../proc/scheduler.h"

static void write_uint(console_t *dc, uint64_t v) {
    char tmp[20]; int t = 0;
    if (v == 0) { char z[2] = {'0', 0}; console_print(dc, z); return; }
    while (v > 0) { tmp[t++] = (char)('0' + (v % 10)); v /= 10; }
    char buf[20]; int i = 0;
    while (t > 0) buf[i++] = tmp[--t];
    buf[i] = '\0';
    console_print(dc, buf);
}

static void settings_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)h; (void)ctx;
    JetSystemInfo info;
    GetSystemInfoJ(&info);

    int ty = y + 8;
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    console_print(dc, "HEAP USED/TOTAL BYTES:");
    ty += 14;
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    write_uint(dc, info.heap_used_bytes);
    console_print(dc, " / ");
    write_uint(dc, info.heap_total_bytes);
    ty += 20;

    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    console_print(dc, "PMM FREE/TOTAL PAGES:");
    ty += 14;
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    write_uint(dc, info.pmm_free_pages);
    console_print(dc, " / ");
    write_uint(dc, info.pmm_total_pages);
    ty += 20;

    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    console_print(dc, "TIMER TICKS:");
    ty += 14;
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    write_uint(dc, info.timer_ticks);
}

static void settings_thread_fn(void *arg) {
    (void)arg;
    JetWindowHandle win = CreateWindowJ("SETTINGS", 620, 240, 260, 150, 0x00403050);
    if (win >= 0) {
        wm_set_content_callback(win, settings_content_cb, NULL);
    }
    for (;;) {
        scheduler_yield();
    }
}

void settings_launch(void) {
    static int launched = 0;
    if (launched) return;
    launched = 1;
    CreateThreadJ("settings", settings_thread_fn, NULL);
}
