kernel/net/crypto/rng.o: kernel/net/crypto/rng.c kernel/net/crypto/rng.h \
 kernel/net/crypto/sha256.h kernel/net/crypto/../../hal/x86_asm_shim.h \
 kernel/net/crypto/../../int/pit.h kernel/net/crypto/../../drivers/rtc.h
kernel/net/crypto/rng.h:
kernel/net/crypto/sha256.h:
kernel/net/crypto/../../hal/x86_asm_shim.h:
kernel/net/crypto/../../int/pit.h:
kernel/net/crypto/../../drivers/rtc.h:
