#!/usr/bin/env bash
# JetOS를 QEMU + OVMF(UEFI 펌웨어)로 부팅
set -e
cd "$(dirname "$0")/.."

IMG="build/esp.img"
JETFS_IMG="build/jetfs.img"
if [ ! -f "$IMG" ]; then
    echo "오류: $IMG 이(가) 없습니다. 먼저 './scripts/make_esp.sh' 를 실행하세요."
    exit 1
fi
if [ ! -f "$JETFS_IMG" ]; then
    echo "안내: $JETFS_IMG 이(가) 없어 JETFS 데이터 디스크 없이 부팅합니다."
    echo "      JETFS를 테스트하려면: make mkjetfs && ./build/mkjetfs $JETFS_IMG 16"
fi

# 배포판마다 OVMF 경로가 다르므로 자동 탐색을 시도하고, 실패하면
# OVMF_CODE / OVMF_VARS 환경변수로 직접 지정할 수 있게 한다.
OVMF_CODE="${OVMF_CODE:-$(find /usr/share -iname 'OVMF_CODE*.fd' 2>/dev/null | head -n1)}"
OVMF_VARS_SRC="${OVMF_VARS:-$(find /usr/share -iname 'OVMF_VARS*.fd' 2>/dev/null | head -n1)}"

if [ -z "$OVMF_CODE" ] || [ -z "$OVMF_VARS_SRC" ]; then
    echo "오류: OVMF 펌웨어를 찾을 수 없습니다."
    echo "  sudo apt install ovmf 후 다시 시도하거나,"
    echo "  OVMF_CODE=/path/to/OVMF_CODE.fd OVMF_VARS=/path/to/OVMF_VARS.fd 로 직접 지정하세요."
    exit 1
fi

cp "$OVMF_VARS_SRC" build/OVMF_VARS.fd

EXTRA_DRIVE=()
if [ -f "$JETFS_IMG" ]; then
    EXTRA_DRIVE=(-drive format=raw,file="$JETFS_IMG")
fi

qemu-system-x86_64 \
    -machine q35 \
    -m 256M \
    -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" \
    -drive if=pflash,format=raw,file=build/OVMF_VARS.fd \
    -drive format=raw,file="$IMG" \
    "${EXTRA_DRIVE[@]}" \
    -netdev user,id=net0 -device rtl8139,netdev=net0 \
    -serial stdio
