#ifndef JETOS_HMAC_SHA256_H
#define JETOS_HMAC_SHA256_H

/* JetOS - kernel/net/crypto/hmac_sha256.h - RFC 2104 HMAC, SHA-256 기반.
 * TLS 1.2의 PRF(RFC 5246 5절)와 레코드 MAC에 쓰인다. */

#include <stdint.h>
#include <stddef.h>

void hmac_sha256(const uint8_t *key, size_t key_len,
                  const uint8_t *msg, size_t msg_len,
                  uint8_t out[32]);

#endif
