kernel/fs/fat32.o: kernel/fs/fat32.c kernel/fs/fat32.h \
 kernel/fs/../drivers/ahci.h
kernel/fs/fat32.h:
kernel/fs/../drivers/ahci.h:
