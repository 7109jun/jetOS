#ifndef JETOS_CLIPBOARD_H
#define JETOS_CLIPBOARD_H

/*
 * JetOS - kernel/gui/clipboard.h
 * Milestone 28: 앱 사이에 텍스트를 옮길 수 있는 전역 클립보드 —
 * "Windows 7 수준" 목표의 두 번째 항목(첫 번째는 M27의 Aero Snap).
 *
 * 알려진 단순화(정직하게 문서화):
 *   - 텍스트만 지원한다(이미지/파일 클립보드 없음).
 *   - 이 최소 구현에는 "부분 선택"이라는 개념이 아직 없다(마우스로
 *     드래그해서 일부만 선택하는 UI가 존재하지 않음 — 위젯 툴킷/
 *     jash/notepad 어디에도). 그래서 Ctrl+C/X는 "포커스된 입력 영역의
 *     전체 내용"을 복사/잘라내기 대상으로 삼는다(jash는 현재 입력 줄,
 *     notepad와 텍스트박스는 버퍼 전체) — 일반적인 "드래그로 고른
 *     부분만" 복사와는 다르다는 점을 이 문서에 명시해둔다.
 *   - 전역 단일 슬롯(한 번에 하나의 클립보드 내용만 유지, 기록 없음).
 *   - 앱 간 공유가 이 커널 프로세스 내부에서만 유효 — 실제 Windows처럼
 *     재부팅 후에도 남아있거나 외부 프로그램과 공유되지는 않는다.
 */

#include <stddef.h>

#define CLIPBOARD_CAP 256

/* text(len바이트)를 클립보드에 저장한다(기존 내용 덮어씀). len이
 * CLIPBOARD_CAP-1보다 크면 잘린다. */
void clipboard_set(const char *text, int len);

/* 클립보드 내용을 NUL로 끝나는 문자열로 돌려준다. 아직 아무것도
 * 복사된 적 없으면 빈 문자열("")을 돌려준다(NULL 아님 — 호출측이
 * NULL 체크 없이 바로 써도 안전하게). */
const char *clipboard_get(void);

/* clipboard_get()이 돌려주는 문자열의 길이(strlen과 동일, 매번 다시
 * 세지 않도록 캐싱해서 즉시 반환). */
int clipboard_len(void);

#endif
