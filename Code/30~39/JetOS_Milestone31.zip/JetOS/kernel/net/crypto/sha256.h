#ifndef JETOS_SHA256_H
#define JETOS_SHA256_H

/*
 * JetOS - kernel/net/crypto/sha256.h
 * Milestone 19: TLS 1.2 클라이언트용 SHA-256 (FIPS 180-4).
 * 외부 라이브러리 의존 없이 표준 명세 그대로 구현했다. host_test.c로
 * NIST 공식 테스트 벡터("abc" 등)와 대조 검증했다(호스트 하네스 테스트
 * 방법론 — 문서의 "검증 방법론" 참고).
 */

#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint32_t state[8];
    uint64_t bitlen;
    uint8_t buf[64];
    uint32_t buflen;
} sha256_ctx_t;

void sha256_init(sha256_ctx_t *ctx);
void sha256_update(sha256_ctx_t *ctx, const uint8_t *data, size_t len);
void sha256_final(sha256_ctx_t *ctx, uint8_t out[32]);
void sha256_oneshot(const uint8_t *data, size_t len, uint8_t out[32]);

#endif
