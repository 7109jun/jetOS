/* JetOS - kernel/net/crypto/hmac_sha256.c */
#include "hmac_sha256.h"
#include "sha256.h"

#define BLOCK_SIZE 64

void hmac_sha256(const uint8_t *key, size_t key_len,
                  const uint8_t *msg, size_t msg_len,
                  uint8_t out[32]) {
    uint8_t k0[BLOCK_SIZE];
    uint8_t key_hash[32];

    if (key_len > BLOCK_SIZE) {
        sha256_oneshot(key, key_len, key_hash);
        key = key_hash;
        key_len = 32;
    }
    for (size_t i = 0; i < BLOCK_SIZE; i++) {
        k0[i] = (i < key_len) ? key[i] : 0;
    }

    uint8_t ipad[BLOCK_SIZE], opad[BLOCK_SIZE];
    for (int i = 0; i < BLOCK_SIZE; i++) {
        ipad[i] = k0[i] ^ 0x36;
        opad[i] = k0[i] ^ 0x5c;
    }

    sha256_ctx_t ctx;
    uint8_t inner[32];
    sha256_init(&ctx);
    sha256_update(&ctx, ipad, BLOCK_SIZE);
    sha256_update(&ctx, msg, msg_len);
    sha256_final(&ctx, inner);

    sha256_init(&ctx);
    sha256_update(&ctx, opad, BLOCK_SIZE);
    sha256_update(&ctx, inner, 32);
    sha256_final(&ctx, out);
}
