/*
 * JetOS - kernel/net/tls.c
 * tls.h 참고. TLS_RSA_WITH_AES_128_CBC_SHA256 하나만 지원하는 최소
 * TLS 1.2 클라이언트. 암호 프리미티브(SHA-256/HMAC/AES/bignum/x509/
 * PRF/RNG)는 kernel/net/crypto/ 아래 각 파일 — 전부 host_test.c로
 * 알려진 벡터와 대조 검증했다(문서의 "호스트 하네스 테스트" 방법론).
 */
#include "tls.h"
#include "tcp.h"
#include "dns.h"
#include "crypto/sha256.h"
#include "crypto/hmac_sha256.h"
#include "crypto/aes128.h"
#include "crypto/bignum.h"
#include "crypto/x509_min.h"
#include "crypto/x509_trust.h"
#include "crypto/rsa_pkcs1.h"
#include "crypto/tls_prf.h"
#include "crypto/rng.h"
#include "../drivers/serial.h"
#include "../drivers/rtc.h"
#include <stddef.h>
#include <string.h> /* memcmp — 선언만 필요, 실제 심볼은 freestanding_libc.c가 제공(project convention).
                     * Milestone 41: 원래도 fill_next_record의 MAC 비교에서 memcmp를 썼는데
                     * 이 헤더가 빠져서 암묵적 선언 경고가 났었다 — 이번에 고침. */

#define TLS_MAX_CHAIN_CERTS X509_TRUST_MAX_CHAIN

#define TLS_CONTENT_CHANGE_CIPHER 20
#define TLS_CONTENT_ALERT         21
#define TLS_CONTENT_HANDSHAKE     22
#define TLS_CONTENT_APPDATA       23

#define HS_CLIENT_HELLO        1
#define HS_SERVER_HELLO        2
#define HS_CERTIFICATE        11
#define HS_SERVER_KEY_EXCHANGE 12
#define HS_SERVER_HELLO_DONE  14
#define HS_CLIENT_KEY_EXCHANGE 16
#define HS_FINISHED            20

/* Milestone 41: 순방향 비밀성(forward secrecy)이 있는 두 번째 암호모음
 * 추가. 기존 TLS_RSA_WITH_AES_128_CBC_SHA256(0x003C)는 서버 개인키가
 * 나중에 유출되면 예전에 녹화해둔 트래픽까지 전부 복호화 가능(정적
 * RSA 키교환의 근본적 한계 — tls.h에 알려진 한계로 문서화돼 있었음).
 * TLS_DHE_RSA_WITH_AES_128_CBC_SHA256(0x0067)은 매 연결마다 새로운
 * 임시(ephemeral) Diffie-Hellman 키쌍으로 premaster secret을 만들어서,
 * 서버 RSA 개인키가 나중에 털려도 이미 끝난 세션은 복호화할 수 없다
 * (RSA 서명은 여전히 ServerKeyExchange 인증에만 쓰임 — 키교환 자체가
 * 아니라 "이 DH 파라미터를 진짜 이 서버가 보냈다"만 증명). 두 스위트를
 * 다 보내고(DHE를 먼저 나열해 선호를 표시) 서버가 고르는 대로 따라간다
 * — 서버가 RSA만 하면 예전처럼, DHE를 지원하면 순방향 비밀성 있는
 * 연결이 된다. */
#define TLS_CS_DHE_RSA_AES128_SHA256 0x0067
#define TLS_CS_RSA_AES128_SHA256     0x003C

#define MAX_RECORD 16384
#define MAX_RSA_BYTES 512 /* 4096비트 키까지 */

/* ===== 연결 상태 ===== */
static int g_active = 0;
/* Milestone 41: 마지막으로 성공한 핸드셰이크가 DHE_RSA(순방향 비밀성 있음)
 * 였는지 RSA(없음)였는지 — tls_last_cipher_has_forward_secrecy()로 조회.
 * 로그/진단 메시지가 실제 협상 결과를 정확히 반영하게 하려는 용도
 * (연결마다 서버가 뭘 고를지 다르므로 하드코딩된 메시지는 부정확해짐). */
static int g_last_dhe_mode = 0;
static int g_client_cipher_active = 0;
static int g_server_cipher_active = 0;
static uint64_t g_client_seq = 0;
static uint64_t g_server_seq = 0;

static aes128_ctx_t g_client_enc_ctx, g_server_dec_ctx;
static uint8_t g_client_mac_key[32];
static uint8_t g_server_mac_key[32];

static sha256_ctx_t g_hs_hash; /* 모든 핸드셰이크 메시지 바이트의 누적 해시 */
static uint8_t g_client_random[32];
static uint8_t g_server_random[32];
static uint8_t g_master_secret[48];

/* 현재 소비 중인 수신 레코드(핸드셰이크 스트림 재조립용) */
static uint8_t g_rx_buf[MAX_RECORD];
static size_t g_rx_len = 0, g_rx_pos = 0;

static char g_last_error[96] = "연결 시도 없음";

static void set_last_error(const char *msg) {
    size_t i = 0;
    for (; msg[i] && i + 1 < sizeof(g_last_error); i++) g_last_error[i] = msg[i];
    g_last_error[i] = '\0';
}

const char *tls_last_error(void) { return g_last_error; }
int tls_last_cipher_has_forward_secrecy(void) { return g_last_dhe_mode; }

static void hexdump_status(const char *msg) {
    serial_write("[TLS] "); serial_write(msg); serial_write("\n");
    set_last_error(msg);
}

/* serial.h에는 10진수 정수 출력 함수가 없어서(hex64만 있음) 작은 값
 * (신뢰 저장소에 로드된 루트 개수) 출력용으로 최소한만 직접 구현. */
static void serial_write_small_uint(unsigned v) {
    char buf[12];
    int n = 0;
    if (v == 0) { serial_putc('0'); return; }
    while (v > 0 && n < (int)sizeof(buf)) { buf[n++] = (char)('0' + (v % 10)); v /= 10; }
    while (n > 0) serial_putc(buf[--n]);
}

/* Milestone 24: 신뢰 저장소는 파일 I/O가 필요해 상대적으로 비싸므로
 * 연결마다 다시 읽지 않고 첫 사용 시 한 번만 읽어 캐싱한다(부팅 이후
 * /system/certs/roots.der가 바뀌면 재부팅해야 반영됨 — 알려진 단순화). */
static int g_trust_loaded = 0;
static void ensure_trust_loaded(void) {
    if (g_trust_loaded) return;
    g_trust_loaded = 1;
    int n = x509_trust_load("/system/certs/roots.der");
    if (n <= 0) {
        hexdump_status("신뢰 저장소 비어있음/없음 (/system/certs/roots.der) — 체인 검증은 항상 실패함");
    } else {
        serial_write("[TLS] 신뢰 저장소 로드: 루트 ");
        serial_write_small_uint((unsigned)n);
        serial_write("개\n");
    }
}

/* ---------- 레코드 계층 ---------- */

static int send_record_raw(uint8_t type, const uint8_t *payload, size_t len) {
    uint8_t hdr[5];
    hdr[0] = type;
    hdr[1] = 3; hdr[2] = 3; /* TLS 1.2 */
    hdr[3] = (uint8_t)(len >> 8);
    hdr[4] = (uint8_t)(len);

    uint8_t buf[5 + MAX_RECORD];
    if (len > MAX_RECORD) return 0;
    for (int i = 0; i < 5; i++) buf[i] = hdr[i];
    for (size_t i = 0; i < len; i++) buf[5 + i] = payload[i];
    return tcp_send(buf, (uint32_t)(5 + len), 300);
}

/* MAC용 8바이트 빅엔디안 시퀀스 번호 */
static void put_seq(uint8_t *out, uint64_t seq) {
    for (int i = 0; i < 8; i++) out[7 - i] = (uint8_t)(seq >> (i * 8));
}

static int send_record(uint8_t type, const uint8_t *content, size_t clen) {
    if (!g_client_cipher_active) {
        return send_record_raw(type, content, clen);
    }

    uint8_t mac_input[13 + MAX_RECORD];
    size_t mi = 0;
    put_seq(mac_input, g_client_seq); mi += 8;
    mac_input[mi++] = type;
    mac_input[mi++] = 3; mac_input[mi++] = 3;
    mac_input[mi++] = (uint8_t)(clen >> 8);
    mac_input[mi++] = (uint8_t)(clen);
    for (size_t i = 0; i < clen; i++) mac_input[mi + i] = content[i];
    mi += clen;

    uint8_t mac[32];
    hmac_sha256(g_client_mac_key, 32, mac_input, mi, mac);

    /* content || MAC || padding || padding_length */
    size_t unpadded = clen + 32;
    size_t pad_len = (16 - ((unpadded + 1) % 16)) % 16;
    size_t total = unpadded + pad_len + 1;

    uint8_t plain[MAX_RECORD];
    size_t p = 0;
    for (size_t i = 0; i < clen; i++) plain[p++] = content[i];
    for (int i = 0; i < 32; i++) plain[p++] = mac[i];
    for (size_t i = 0; i < pad_len; i++) plain[p++] = (uint8_t)pad_len;
    plain[p++] = (uint8_t)pad_len;

    uint8_t iv[16];
    rng_bytes(iv, 16);

    uint8_t cipher[MAX_RECORD];
    aes128_cbc_encrypt(&g_client_enc_ctx, iv, plain, cipher, total);

    uint8_t fragment[16 + MAX_RECORD];
    for (int i = 0; i < 16; i++) fragment[i] = iv[i];
    for (size_t i = 0; i < total; i++) fragment[16 + i] = cipher[i];

    g_client_seq++;
    return send_record_raw(type, fragment, 16 + total);
}

/* 핸드셰이크 메시지를 보내면서 동시에 누적 해시에 반영 */
static int send_handshake(uint8_t hs_type, const uint8_t *body, size_t body_len) {
    uint8_t msg[4 + MAX_RECORD];
    msg[0] = hs_type;
    msg[1] = (uint8_t)(body_len >> 16);
    msg[2] = (uint8_t)(body_len >> 8);
    msg[3] = (uint8_t)(body_len);
    for (size_t i = 0; i < body_len; i++) msg[4 + i] = body[i];
    sha256_update(&g_hs_hash, msg, 4 + body_len);
    return send_record(TLS_CONTENT_HANDSHAKE, msg, 4 + body_len);
}

/* 원시 레코드 하나를 받아 g_rx_buf에 채운다(복호화까지 완료된 평문).
 * ChangeCipherSpec은 여기서 플래그만 뒤집고 내부적으로 계속 다음
 * 레코드를 기다린다 — 호출측은 Handshake/Alert/AppData만 본다. */
static int fill_next_record(uint8_t *out_type, uint32_t timeout_ticks) {
    for (;;) {
        uint8_t hdr[5];
        if (tcp_recv_exact(hdr, 5, timeout_ticks) != 5) return 0;
        uint8_t type = hdr[0];
        size_t len = ((size_t)hdr[3] << 8) | hdr[4];
        if (len > MAX_RECORD) return 0;

        uint8_t raw[MAX_RECORD];
        if (tcp_recv_exact(raw, (uint32_t)len, timeout_ticks) != len) return 0;

        if (g_server_cipher_active) {
            if (len < 16 + 32 + 1) return 0; /* IV + 최소 MAC+패딩길이바이트 */
            const uint8_t *iv = raw;
            const uint8_t *ciphertext = raw + 16;
            size_t cipher_len = len - 16;
            if (cipher_len % 16 != 0) return 0;

            uint8_t plain[MAX_RECORD];
            aes128_cbc_decrypt(&g_server_dec_ctx, iv, ciphertext, plain, cipher_len);

            uint8_t pad_len = plain[cipher_len - 1];
            if ((size_t)pad_len + 1 > cipher_len) return 0;
            /* 알려진 한계(tls.h 참고): 패딩 바이트 값 검증이 상수시간이
             * 아니다 — 패딩 오라클류 사이드채널 방어는 없음. */
            size_t content_and_mac_len = cipher_len - pad_len - 1;
            if (content_and_mac_len < 32) return 0;
            size_t content_len = content_and_mac_len - 32;
            const uint8_t *content = plain;
            const uint8_t *mac_recv = plain + content_len;

            uint8_t mac_input[13 + MAX_RECORD];
            size_t mi = 0;
            put_seq(mac_input, g_server_seq); mi += 8;
            mac_input[mi++] = type;
            mac_input[mi++] = 3; mac_input[mi++] = 3;
            mac_input[mi++] = (uint8_t)(content_len >> 8);
            mac_input[mi++] = (uint8_t)(content_len);
            for (size_t i = 0; i < content_len; i++) mac_input[mi + i] = content[i];
            mi += content_len;

            uint8_t mac_calc[32];
            hmac_sha256(g_server_mac_key, 32, mac_input, mi, mac_calc);
            int mac_ok = (memcmp(mac_calc, mac_recv, 32) == 0);
            g_server_seq++;
            if (!mac_ok) { hexdump_status("MAC mismatch on received record — aborting"); return 0; }

            for (size_t i = 0; i < content_len; i++) g_rx_buf[i] = content[i];
            g_rx_len = content_len;
        } else {
            for (size_t i = 0; i < len; i++) g_rx_buf[i] = raw[i];
            g_rx_len = len;
        }
        g_rx_pos = 0;

        if (type == TLS_CONTENT_CHANGE_CIPHER) {
            g_server_cipher_active = 1;
            g_server_seq = 0; /* ChangeCipherSpec 이후 시퀀스 번호 리셋(RFC 5246) */
            continue; /* 이 레코드 자체는 상위로 넘기지 않고 다음 레코드를 계속 기다림 */
        }
        if (type == TLS_CONTENT_HANDSHAKE) {
            sha256_update(&g_hs_hash, g_rx_buf, g_rx_len);
        }
        if (type == TLS_CONTENT_ALERT) {
            hexdump_status("received Alert record — aborting");
            return 0;
        }
        *out_type = type;
        return 1;
    }
}

static int hs_read_bytes(uint8_t *out, size_t n, uint32_t timeout_ticks) {
    while (n > 0) {
        if (g_rx_pos >= g_rx_len) {
            uint8_t type;
            if (!fill_next_record(&type, timeout_ticks)) return 0;
            if (type != TLS_CONTENT_HANDSHAKE) return 0;
        }
        size_t avail = g_rx_len - g_rx_pos;
        size_t take = avail < n ? avail : n;
        for (size_t i = 0; i < take; i++) out[i] = g_rx_buf[g_rx_pos + i];
        g_rx_pos += take;
        out += take;
        n -= take;
    }
    return 1;
}

/* ---------- 핸드셰이크 ---------- */

int tls_connect(const char *sni_host, uint32_t dst_ip, uint16_t dst_port, uint32_t timeout_ticks) {
    return tls_connect_ex(sni_host, dst_ip, dst_port, timeout_ticks, 0);
}

int tls_connect_ex(const char *sni_host, uint32_t dst_ip, uint16_t dst_port, uint32_t timeout_ticks, int allow_untrusted) {
    ensure_trust_loaded();
    g_active = 0;
    g_client_cipher_active = 0;
    g_server_cipher_active = 0;
    g_client_seq = 0;
    g_server_seq = 0;
    g_rx_len = 0; g_rx_pos = 0;
    sha256_init(&g_hs_hash);

    if (!tcp_connect(dst_ip, dst_port, timeout_ticks)) {
        hexdump_status("TCP connect failed");
        return 0;
    }

    /* ---- ClientHello ---- */
    rng_bytes(g_client_random, 32);
    int sni_len = 0;
    if (sni_host) { while (sni_host[sni_len]) sni_len++; }

    uint8_t body[512];
    size_t b = 0;
    body[b++] = 3; body[b++] = 3; /* client_version = TLS 1.2 */
    for (int i = 0; i < 32; i++) body[b++] = g_client_random[i];
    body[b++] = 0; /* session_id length = 0 */
    body[b++] = 0; body[b++] = 4; /* cipher_suites length = 4 (스위트 2개) */
    body[b++] = 0x00; body[b++] = 0x67; /* TLS_DHE_RSA_WITH_AES_128_CBC_SHA256 — 순방향 비밀성, 우선 */
    body[b++] = 0x00; body[b++] = 0x3C; /* TLS_RSA_WITH_AES_128_CBC_SHA256 — 폴백 */
    body[b++] = 1; body[b++] = 0; /* compression_methods: [null] */

    size_t ext_start = b;
    b += 2; /* extensions total length 자리 — 나중에 채움 */

    /* signature_algorithms 확장 (RFC 5246 7.4.1.4.1). 정적 RSA 키교환
     * 스위트는 ServerKeyExchange 서명이 필요 없어 이론상 선택사항이지만,
     * OpenSSL 3.x는 이게 없으면 "NO_SUITABLE_SIGNATURE_ALGORITHM"로
     * 거부한다(실제로 겪은 문제 — 재현/수정 기록: kernel_entry.c
     * TLS 자체테스트로 로컬 서버에 접속 시 이 확장 누락으로 매번
     * 핸드셰이크 실패했었다). rsa_pkcs1_sha256만 광고해도 충분하다. */
    body[b++] = 0x00; body[b++] = 0x0d; /* extension type = signature_algorithms */
    body[b++] = 0x00; body[b++] = 0x04; /* extension_data length = 4 */
    body[b++] = 0x00; body[b++] = 0x02; /* supported_signature_algorithms length = 2 */
    body[b++] = 0x04; body[b++] = 0x01; /* {sha256, rsa} = rsa_pkcs1_sha256 */

    if (sni_len > 0) {
        body[b++] = 0x00; body[b++] = 0x00; /* extension type = server_name */
        size_t ext_len_pos = b; b += 2;
        size_t list_len_pos = b; b += 2;
        body[b++] = 0x00; /* name_type = host_name */
        body[b++] = (uint8_t)(sni_len >> 8); body[b++] = (uint8_t)sni_len;
        for (int i = 0; i < sni_len; i++) body[b++] = (uint8_t)sni_host[i];
        size_t list_len = b - (list_len_pos + 2);
        body[list_len_pos] = (uint8_t)(list_len >> 8); body[list_len_pos + 1] = (uint8_t)list_len;
        size_t ext_len = b - (ext_len_pos + 2);
        body[ext_len_pos] = (uint8_t)(ext_len >> 8); body[ext_len_pos + 1] = (uint8_t)ext_len;
    }
    size_t total_ext_len = b - (ext_start + 2);
    body[ext_start] = (uint8_t)(total_ext_len >> 8);
    body[ext_start + 1] = (uint8_t)(total_ext_len);

    if (!send_handshake(HS_CLIENT_HELLO, body, b)) { hexdump_status("send ClientHello failed"); tcp_close(); return 0; }

    /* ---- ServerHello ---- */
    uint8_t hs_hdr[4];
    if (!hs_read_bytes(hs_hdr, 4, timeout_ticks)) { hexdump_status("recv ServerHello header failed"); tcp_close(); return 0; }
    if (hs_hdr[0] != HS_SERVER_HELLO) { hexdump_status("expected ServerHello"); tcp_close(); return 0; }
    size_t sh_len = ((size_t)hs_hdr[1] << 16) | ((size_t)hs_hdr[2] << 8) | hs_hdr[3];
    uint8_t sh_body[256];
    if (sh_len > sizeof(sh_body) || !hs_read_bytes(sh_body, sh_len, timeout_ticks)) {
        hexdump_status("recv ServerHello body failed"); tcp_close(); return 0;
    }
    /* sh_body: version(2) random(32) session_id_len(1) session_id(*) cipher_suite(2) compression(1) [extensions...] */
    for (int i = 0; i < 32; i++) g_server_random[i] = sh_body[2 + i];
    uint8_t sess_len = sh_body[34];
    size_t off = 35 + sess_len;
    uint16_t chosen_suite = (uint16_t)((sh_body[off] << 8) | sh_body[off + 1]);
    int dhe_mode;
    if (chosen_suite == TLS_CS_DHE_RSA_AES128_SHA256) {
        dhe_mode = 1;
    } else if (chosen_suite == TLS_CS_RSA_AES128_SHA256) {
        dhe_mode = 0;
    } else {
        hexdump_status("server chose unsupported cipher suite (only DHE-RSA/RSA AES128-CBC-SHA256)");
        tcp_close(); return 0;
    }
    g_last_dhe_mode = dhe_mode;

    /* ---- Certificate ---- */
    if (!hs_read_bytes(hs_hdr, 4, timeout_ticks)) { hexdump_status("recv Certificate header failed"); tcp_close(); return 0; }
    if (hs_hdr[0] != HS_CERTIFICATE) { hexdump_status("expected Certificate"); tcp_close(); return 0; }
    size_t cert_msg_len = ((size_t)hs_hdr[1] << 16) | ((size_t)hs_hdr[2] << 8) | hs_hdr[3];
    static uint8_t cert_msg[MAX_RECORD];
    if (cert_msg_len > sizeof(cert_msg) || !hs_read_bytes(cert_msg, cert_msg_len, timeout_ticks)) {
        hexdump_status("recv Certificate body failed"); tcp_close(); return 0;
    }
    /* cert_msg: certificate_list_len(3) then repeated { cert_len(3) cert_der(*) } —
     * Milestone 24부터 첫 번째(리프)만이 아니라 서버가 보낸 체인 전체를
     * 파싱해서(최대 TLS_MAX_CHAIN_CERTS개) 체인/신뢰 검증에 쓴다. */
    if (cert_msg_len < 3) { hexdump_status("Certificate message too short"); tcp_close(); return 0; }
    size_t list_len = ((size_t)cert_msg[0] << 16) | ((size_t)cert_msg[1] << 8) | cert_msg[2];
    if (3 + list_len > cert_msg_len) { hexdump_status("Certificate list length mismatch"); tcp_close(); return 0; }

    static x509_cert_t chain[TLS_MAX_CHAIN_CERTS];
    int chain_len = 0;
    {
        size_t off = 3;
        size_t end = 3 + list_len;
        while (off + 3 <= end) {
            size_t clen = ((size_t)cert_msg[off] << 16) | ((size_t)cert_msg[off + 1] << 8) | cert_msg[off + 2];
            off += 3;
            if (off + clen > end) { hexdump_status("Certificate entry length mismatch"); tcp_close(); return 0; }
            if (chain_len < TLS_MAX_CHAIN_CERTS) {
                if (!x509_parse(cert_msg + off, clen, &chain[chain_len])) {
                    hexdump_status("failed to parse certificate in chain (non-RSA or malformed?)");
                    tcp_close(); return 0;
                }
                chain_len++;
            } /* TLS_MAX_CHAIN_CERTS를 넘는 뒤쪽 인증서는 무시(알려진 한계 — 아주 긴 체인) */
            off += clen;
        }
    }
    if (chain_len == 0) { hexdump_status("Certificate list was empty"); tcp_close(); return 0; }

    if (!allow_untrusted) {
        rtc_time_t rt; rtc_read(&rt);
        uint64_t now = x509_pack_time(rt.year, rt.month, rt.day, rt.hour, rt.minute, rt.second);
        const char *reason = "알 수 없는 오류";
        if (!x509_verify_chain(chain, chain_len, now, &reason)) {
            hexdump_status(reason);
            tcp_close(); return 0;
        }
    }
    if (sni_host && !x509_check_hostname(&chain[0], sni_host)) {
        hexdump_status("인증서 호스트명이 접속 대상과 일치하지 않음(SAN/CN 불일치)");
        tcp_close(); return 0;
    }

    bignum_t server_n = chain[0].pubkey_n, server_e = chain[0].pubkey_e;

    /* ---- ServerKeyExchange (DHE_RSA일 때만 옴) ----
     * body: dh_p_len(2) dh_p(*) dh_g_len(2) dh_g(*) dh_Ys_len(2) dh_Ys(*)
     *       signature_hash_alg(2, RFC 5246 7.4.1.4.1 — {hash,sig} 한
     *       쌍) signature_len(2) signature(*)
     * 서명은 client_random(32)+server_random(32)+ServerDHParams의
     * 원본 바이트(길이 필드 포함, 위 세 값 그대로) 전체에 대한 것이다
     * (RFC 5246 7.4.3) — 서버 인증서(chain[0])의 RSA 공개키로 검증해서
     * "이 DH 파라미터가 진짜 이 서버가 보낸 것"임을 확인한다. 이게
     * 없으면 중간자가 자기 DH 키를 끼워넣어도 클라이언트가 못 알아챈다
     * (DHE에서 서명 검증이 곧 인증의 전부 — RSA 키교환과 달리 premaster
     * 자체는 서버 개인키로 보호되지 않으므로 더더욱 중요). */
    bignum_t dh_p, dh_g, dh_ys;
    int have_dh_p = 0;
    if (dhe_mode) {
        if (!hs_read_bytes(hs_hdr, 4, timeout_ticks)) { hexdump_status("recv ServerKeyExchange header failed"); tcp_close(); return 0; }
        if (hs_hdr[0] != HS_SERVER_KEY_EXCHANGE) { hexdump_status("expected ServerKeyExchange"); tcp_close(); return 0; }
        size_t ske_len = ((size_t)hs_hdr[1] << 16) | ((size_t)hs_hdr[2] << 8) | hs_hdr[3];
        static uint8_t ske_body[MAX_RSA_BYTES * 3 + 64];
        if (ske_len > sizeof(ske_body) || !hs_read_bytes(ske_body, ske_len, timeout_ticks)) {
            hexdump_status("recv ServerKeyExchange body failed"); tcp_close(); return 0;
        }
        size_t p = 0;
        if (p + 2 > ske_len) { hexdump_status("ServerKeyExchange truncated (dh_p)"); tcp_close(); return 0; }
        size_t plen = ((size_t)ske_body[p] << 8) | ske_body[p + 1]; p += 2;
        size_t p_val_off = p; p += plen;
        if (p + 2 > ske_len) { hexdump_status("ServerKeyExchange truncated (dh_g)"); tcp_close(); return 0; }
        size_t glen = ((size_t)ske_body[p] << 8) | ske_body[p + 1]; p += 2;
        size_t g_val_off = p; p += glen;
        if (p + 2 > ske_len) { hexdump_status("ServerKeyExchange truncated (dh_Ys)"); tcp_close(); return 0; }
        size_t yslen = ((size_t)ske_body[p] << 8) | ske_body[p + 1]; p += 2;
        size_t ys_val_off = p; p += yslen;
        if (p > ske_len || plen == 0 || glen == 0 || yslen == 0 ||
            plen > MAX_RSA_BYTES || glen > MAX_RSA_BYTES || yslen > MAX_RSA_BYTES) {
            hexdump_status("ServerKeyExchange DH params malformed"); tcp_close(); return 0;
        }
        size_t params_len = p; /* dh_p_len..dh_Ys 전체(길이 필드 포함) — 서명 대상의 일부 */

        if (p + 2 > ske_len) { hexdump_status("ServerKeyExchange truncated (sig alg)"); tcp_close(); return 0; }
        uint8_t sig_hash_alg = ske_body[p], sig_sig_alg = ske_body[p + 1]; p += 2;
        if (sig_hash_alg != 0x04 || sig_sig_alg != 0x01) { /* {sha256, rsa} 외에는 지원 안 함 */
            hexdump_status("ServerKeyExchange signature algorithm not sha256/rsa"); tcp_close(); return 0;
        }
        if (p + 2 > ske_len) { hexdump_status("ServerKeyExchange truncated (sig len)"); tcp_close(); return 0; }
        size_t siglen = ((size_t)ske_body[p] << 8) | ske_body[p + 1]; p += 2;
        if (p + siglen != ske_len) { hexdump_status("ServerKeyExchange signature length mismatch"); tcp_close(); return 0; }
        const uint8_t *sig = ske_body + p;

        /* 서명 대상 = client_random(32) + server_random(32) + ServerDHParams(params_len) */
        static uint8_t sig_input[64 + MAX_RSA_BYTES * 3 + 8];
        size_t si = 0;
        for (int i = 0; i < 32; i++) sig_input[si++] = g_client_random[i];
        for (int i = 0; i < 32; i++) sig_input[si++] = g_server_random[i];
        for (size_t i = 0; i < params_len; i++) sig_input[si++] = ske_body[i];
        uint8_t ske_hash[32];
        sha256_oneshot(sig_input, si, ske_hash);

        if (!rsa_pkcs1_verify_sha256(ske_hash, sig, siglen, &server_n, &server_e)) {
            hexdump_status("ServerKeyExchange signature verification failed — possible MITM, aborting");
            tcp_close(); return 0;
        }

        bn_from_bytes_be(&dh_p, ske_body + p_val_off, plen);
        bn_from_bytes_be(&dh_g, ske_body + g_val_off, glen);
        bn_from_bytes_be(&dh_ys, ske_body + ys_val_off, yslen);
        have_dh_p = 1;
        if (bn_is_zero(&dh_p) || bn_cmp(&dh_ys, &dh_p) >= 0) {
            hexdump_status("ServerKeyExchange DH parameters out of range"); tcp_close(); return 0;
        }
    }
    (void)have_dh_p;

    /* ---- ServerHelloDone ---- */
    if (!hs_read_bytes(hs_hdr, 4, timeout_ticks)) { hexdump_status("recv ServerHelloDone header failed"); tcp_close(); return 0; }
    if (hs_hdr[0] != HS_SERVER_HELLO_DONE) { hexdump_status("expected ServerHelloDone"); tcp_close(); return 0; }
    /* body_len은 항상 0이라 굳이 안 읽어도 되지만, 명세상 있을 수도 있으니 스킵 */
    size_t shd_len = ((size_t)hs_hdr[1] << 16) | ((size_t)hs_hdr[2] << 8) | hs_hdr[3];
    if (shd_len > 0) {
        uint8_t tmp[64];
        if (shd_len > sizeof(tmp) || !hs_read_bytes(tmp, shd_len, timeout_ticks)) { tcp_close(); return 0; }
    }

    /* ---- ClientKeyExchange ----
     * RSA 스위트: 48바이트 premaster를 서버 공개키로 암호화해서 보냄.
     * DHE 스위트: 우리 임시 개인키 x로 Yc=g^x mod p를 계산해 평문으로
     * 보내고(DH 공개값은 원래 비밀이 아님 — 도청자가 봐도 무방, 안전성은
     * 이산로그 문제의 어려움에서 나옴), premaster는 나중에 서버 공개값
     * Ys로부터 별도로 계산한다(둘 다 계산하면 같은 값이 나옴이 DH의
     * 핵심). premaster 길이가 RSA는 항상 48바이트로 고정이지만 DHE는
     * 공유 비밀의 실제 바이트 길이만큼(선행 0 제거, RFC 5246 8.1.2)이라
     * 가변 — 그래서 이후 코드는 premaster_len을 따로 들고 다닌다. */
    uint8_t premaster[MAX_RSA_BYTES];
    size_t premaster_len;

    if (!dhe_mode) {
        /* Milestone 24: 정확한 modulus 바이트 길이를 구하는 "guess loop"이
         * x509_verify_signature에도 똑같이 필요해져서 bn_byte_len()이라는
         * 공용 함수로 뽑아냈다(bignum.h 참고) — 여기서도 그걸 그대로 쓴다. */
        size_t modulus_bytes = bn_byte_len(&server_n);
        if (modulus_bytes == 0 || modulus_bytes > MAX_RSA_BYTES) { hexdump_status("bad RSA modulus size"); tcp_close(); return 0; }

        premaster_len = 48;
        premaster[0] = 3; premaster[1] = 3; /* client_version */
        rng_bytes(premaster + 2, 46);

        uint8_t encrypted_pm[MAX_RSA_BYTES];
        if (!rsa_pkcs1_encrypt(&server_n, &server_e, premaster, 48, encrypted_pm, modulus_bytes)) {
            hexdump_status("RSA encrypt of premaster failed"); tcp_close(); return 0;
        }

        uint8_t cke_body[2 + MAX_RSA_BYTES];
        cke_body[0] = (uint8_t)(modulus_bytes >> 8);
        cke_body[1] = (uint8_t)(modulus_bytes);
        for (size_t i = 0; i < modulus_bytes; i++) cke_body[2 + i] = encrypted_pm[i];
        if (!send_handshake(HS_CLIENT_KEY_EXCHANGE, cke_body, 2 + modulus_bytes)) {
            hexdump_status("send ClientKeyExchange failed"); tcp_close(); return 0;
        }
    } else {
        /* 임시 개인키 x: p와 같은 바이트 길이로 난수를 채우고 최상위
         * 비트를 지워서 x < p를 보장한다(p의 최상위 비트가 서 있다고
         * 가정 — 실제로 쓰이는 DH 소수는 항상 그렇다: RFC 3526/7919
         * 표준 그룹이나 서버가 임의 생성한 소수나 마찬가지). 엄밀한
         * "1 < x < p-1 균등분포"까지는 아니지만, x의 상위 비트 하나를
         * 희생하는 대신 나눗셈/모듈로 연산 없이 안전하게 범위를 보장할
         * 수 있는 실용적 절충 — bignum.h가 modexp 하나만 지원하는
         * "최소 구현"이라는 이 프로젝트의 기존 방침과 일관됨. */
        size_t p_bytes = bn_byte_len(&dh_p);
        if (p_bytes == 0 || p_bytes > MAX_RSA_BYTES) { hexdump_status("bad DH prime size"); tcp_close(); return 0; }

        uint8_t x_bytes[MAX_RSA_BYTES];
        rng_bytes(x_bytes, p_bytes);
        x_bytes[0] &= 0x7F; /* 최상위 비트 클리어 → x < p 보장 */
        if (x_bytes[0] == 0) x_bytes[0] = 0x01; /* x=0 방지(사실상 일어날 확률 무시 가능하지만 방어적으로) */
        bignum_t dh_x;
        bn_from_bytes_be(&dh_x, x_bytes, p_bytes);

        bignum_t dh_yc;
        bn_modexp(&dh_yc, &dh_g, &dh_x, &dh_p); /* Yc = g^x mod p */

        size_t yc_bytes = bn_byte_len(&dh_yc);
        if (yc_bytes == 0 || yc_bytes > MAX_RSA_BYTES) { hexdump_status("DH Yc computation failed"); tcp_close(); return 0; }
        uint8_t yc_buf[MAX_RSA_BYTES];
        if (!bn_to_bytes_be(&dh_yc, yc_buf, yc_bytes)) { hexdump_status("DH Yc encode failed"); tcp_close(); return 0; }

        uint8_t cke_body[2 + MAX_RSA_BYTES];
        cke_body[0] = (uint8_t)(yc_bytes >> 8);
        cke_body[1] = (uint8_t)(yc_bytes);
        for (size_t i = 0; i < yc_bytes; i++) cke_body[2 + i] = yc_buf[i];
        if (!send_handshake(HS_CLIENT_KEY_EXCHANGE, cke_body, 2 + yc_bytes)) {
            hexdump_status("send ClientKeyExchange (DHE) failed"); tcp_close(); return 0;
        }

        /* premaster secret = Ys^x mod p — 서버는 자기 개인키 x_s로
         * Yc^x_s mod p를 계산해서 같은 값을 얻는다(둘 다 g^(x*x_s) mod p
         * 이므로). 이 값은 절대 네트워크로 보내지 않는다 — DH의 핵심. */
        bignum_t dh_pm;
        bn_modexp(&dh_pm, &dh_ys, &dh_x, &dh_p);
        premaster_len = bn_byte_len(&dh_pm);
        if (premaster_len == 0 || premaster_len > MAX_RSA_BYTES) { hexdump_status("DH premaster computation failed"); tcp_close(); return 0; }
        if (!bn_to_bytes_be(&dh_pm, premaster, premaster_len)) { hexdump_status("DH premaster encode failed"); tcp_close(); return 0; }
    }

    /* ---- 키 유도 (RFC 5246 6.3/8.1) — RSA/DHE 공통, premaster_len만 다름 ---- */
    uint8_t seed_cr_sr[64];
    for (int i = 0; i < 32; i++) seed_cr_sr[i] = g_client_random[i];
    for (int i = 0; i < 32; i++) seed_cr_sr[32 + i] = g_server_random[i];
    tls_prf(premaster, premaster_len, "master secret", seed_cr_sr, 64, g_master_secret, 48);

    uint8_t seed_sr_cr[64];
    for (int i = 0; i < 32; i++) seed_sr_cr[i] = g_server_random[i];
    for (int i = 0; i < 32; i++) seed_sr_cr[32 + i] = g_client_random[i];
    uint8_t key_block[2 * 32 + 2 * 16]; /* MAC키(32+32) + AES키(16+16). explicit IV라 IV블록 없음 */
    tls_prf(g_master_secret, 48, "key expansion", seed_sr_cr, 64, key_block, sizeof(key_block));

    for (int i = 0; i < 32; i++) g_client_mac_key[i] = key_block[i];
    for (int i = 0; i < 32; i++) g_server_mac_key[i] = key_block[32 + i];
    aes128_init(&g_client_enc_ctx, key_block + 64);
    aes128_init(&g_server_dec_ctx, key_block + 80);

    /* ---- ChangeCipherSpec + Finished ---- */
    uint8_t ccs = 0x01;
    if (!send_record_raw(TLS_CONTENT_CHANGE_CIPHER, &ccs, 1)) { hexdump_status("send ChangeCipherSpec failed"); tcp_close(); return 0; }
    g_client_cipher_active = 1;

    uint8_t hs_hash_snapshot[32];
    {
        sha256_ctx_t copy = g_hs_hash; /* Finished는 "이 메시지 이전까지"의 해시를 씀 */
        sha256_final(&copy, hs_hash_snapshot);
    }
    uint8_t client_verify[12];
    tls_prf(g_master_secret, 48, "client finished", hs_hash_snapshot, 32, client_verify, 12);
    if (!send_handshake(HS_FINISHED, client_verify, 12)) { hexdump_status("send Finished failed"); tcp_close(); return 0; }

    /* 서버 Finished 검증에 쓸 해시 = ClientHello..클라이언트 Finished까지
     * (서버 Finished 자신은 제외해야 함). send_handshake() 직후,
     * 즉 서버 응답을 아직 읽기 전인 지금 시점에 반드시 스냅샷을
     * 떠둬야 한다 — 이후 fill_next_record()가 서버 Finished를 받으면서
     * g_hs_hash를 계속 갱신해버리기 때문. */
    uint8_t hs_hash_before_server_fin[32];
    {
        sha256_ctx_t copy = g_hs_hash;
        sha256_final(&copy, hs_hash_before_server_fin);
    }

    /* ---- 서버의 ChangeCipherSpec + Finished 수신 ---- */
    if (!hs_read_bytes(hs_hdr, 4, timeout_ticks)) { hexdump_status("recv server Finished header failed"); tcp_close(); return 0; }
    if (hs_hdr[0] != HS_FINISHED) { hexdump_status("expected server Finished"); tcp_close(); return 0; }
    size_t fin_len = ((size_t)hs_hdr[1] << 16) | ((size_t)hs_hdr[2] << 8) | hs_hdr[3];
    uint8_t server_verify_recv[32];
    if (fin_len > sizeof(server_verify_recv) || !hs_read_bytes(server_verify_recv, fin_len, timeout_ticks)) {
        hexdump_status("recv server Finished body failed"); tcp_close(); return 0;
    }

    uint8_t server_verify_expect[12];
    tls_prf(g_master_secret, 48, "server finished", hs_hash_before_server_fin, 32, server_verify_expect, 12);
    if (memcmp(server_verify_expect, server_verify_recv, 12) != 0) {
        hexdump_status("server Finished verify_data mismatch — handshake failed");
        tcp_close(); return 0;
    }

    g_active = 1;
    hexdump_status("handshake complete");
    return 1;
}

int tls_send(const void *data, uint32_t len, uint32_t timeout_ticks) {
    (void)timeout_ticks;
    if (!g_active) return 0;
    const uint8_t *p = (const uint8_t *)data;
    uint32_t sent = 0;
    while (sent < len) {
        uint32_t chunk = len - sent;
        if (chunk > MAX_RECORD - 64) chunk = MAX_RECORD - 64; /* MAC+패딩 여유 */
        if (!send_record(TLS_CONTENT_APPDATA, p + sent, chunk)) return 0;
        sent += chunk;
    }
    return 1;
}

uint32_t tls_recv_until_close(void *buf, uint32_t buf_size, uint32_t timeout_ticks) {
    if (!g_active) return 0;
    uint8_t *out = (uint8_t *)buf;
    uint32_t total = 0;
    while (total < buf_size) {
        uint8_t type;
        if (!fill_next_record(&type, timeout_ticks)) break; /* FIN/RST/타임아웃/close_notify 등 */
        if (type != TLS_CONTENT_APPDATA) continue; /* 다른 타입은 무시하고 계속 */
        size_t take = g_rx_len - g_rx_pos;
        if (total + take > buf_size) take = buf_size - total;
        for (size_t i = 0; i < take; i++) out[total + i] = g_rx_buf[g_rx_pos + i];
        g_rx_pos += take;
        total += (uint32_t)take;
    }
    return total;
}

void tls_close(void) {
    g_active = 0;
    tcp_close();
}
