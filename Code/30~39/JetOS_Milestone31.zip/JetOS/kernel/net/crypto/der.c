/* JetOS - kernel/net/crypto/der.c */
#include "der.h"

void der_init(der_reader_t *r, const uint8_t *buf, size_t len) {
    r->p = buf;
    r->end = buf + len;
}

int der_read_tlv(der_reader_t *r, uint8_t *tag, const uint8_t **val, size_t *vlen) {
    if (r->p >= r->end) return 0;
    uint8_t t = *r->p++;
    if (r->p >= r->end) return 0;
    uint8_t len0 = *r->p++;
    size_t len;
    if (len0 & 0x80) {
        int nbytes = len0 & 0x7F;
        if (nbytes == 0 || nbytes > 4) return 0; /* 4GB 넘는 인증서 필드는 없음 */
        if (r->p + nbytes > r->end) return 0;
        len = 0;
        for (int i = 0; i < nbytes; i++) len = (len << 8) | *r->p++;
    } else {
        len = len0;
    }
    if (r->p + len > r->end) return 0;
    *tag = t;
    *val = r->p;
    *vlen = len;
    r->p += len;
    return 1;
}

void der_enter(der_reader_t *r, const uint8_t *val, size_t vlen) {
    r->p = val;
    r->end = val + vlen;
}
