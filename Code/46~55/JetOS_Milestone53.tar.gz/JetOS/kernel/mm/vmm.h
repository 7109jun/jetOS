#ifndef JETOS_VMM_H
#define JETOS_VMM_H

#include <stdint.h>

/* JetOS 자체 페이지 테이블을 구성하고 CR3에 적재한다.
 * Milestone 2에서는 하위 4GiB를 2MiB 대형 페이지로 항등 매핑(identity
 * mapping)한다 (UEFI가 만들어준 임시 테이블에 더 이상 의존하지 않기
 * 위함). 상위 4GiB를 초과하는 MMIO/메모리는 향후 마일스톤에서 동적
 * 매핑으로 확장한다. */
void vmm_init(void);

/* 현재(공유) 커널 PML4의 물리주소. */
uint64_t vmm_kernel_pml4_phys(void);

/* Milestone 15: 프로세스별 주소공간.
 *
 * vmm_create_process_address_space() — 새 프로세스용 PML4를 만든다.
 * 커널 identity 영역(0~4GiB)은 기존 공유 페이지 테이블을 그대로
 * 재사용(U비트 없음, Ring0 전용 유지)하고, 가상주소
 * vmm_user_virt_base()부터 vmm_user_region_size()만큼의 "유저 영역"만
 * 이 프로세스 전용 페이지 테이블로 새로 마련한다. 실패 시 0.
 *
 * vmm_map_user_page() — 유저 영역 안의 특정 4KB 페이지 하나를 실제
 * 물리 페이지에 연결하고 U비트를 켠다(Ring3 접근 허용). vaddr은 반드시
 * 유저 영역 범위 안이어야 한다. 성공 시 1, 실패(범위 밖 등) 시 0. */
uint64_t vmm_create_process_address_space(void);
int vmm_map_user_page(uint64_t pml4_phys, uint64_t vaddr, uint64_t paddr, int writable);
uint64_t vmm_user_virt_base(void);
uint64_t vmm_user_region_size(void);

/* Milestone 38: 4GiB 위에 있는 MMIO(PCI 64비트 BAR 등)를 커널 가상
 * 주소공간에 매핑한다("하위 4GiB만 항등매핑"이라는 M2 이래의 한계를
 * 실제로 없앤 것 — vmm.c의 기존 주석에 "향후 마일스톤에서 동적 매핑으로
 * 확장한다"고 미리 적어뒀던 바로 그 작업). 2MiB 페이지 단위로 매핑하며,
 * 한 번 매핑한 영역은 해제할 방법이 없다(드라이버 초기화 때 한 번만
 * 쓰고 평생 유지되는 용도로 충분 — 알려진 단순화). phys_addr/size가
 * 가리키는 범위 전체가 실제로 접근 가능한 커널 가상주소를 반환하고,
 * 공간이 부족하면(예약된 창을 다 썼으면) 0을 반환한다.
 *
 * 반드시 이 커널의 공유 주소공간이 아직 살아있는 부팅 초반(첫 유저
 * Ring3 프로세스가 만들어지기 전)에만 호출할 것 — 그래야
 * vmm_create_process_address_space()가 그 이후 만드는 모든 프로세스의
 * PDPT에도 이 매핑이 자동으로 포함된다(커널 identity 영역을 공유하는
 * 것과 완전히 같은 방식). 부팅 후반에 호출하면, 그 시점 이전에 이미
 * 만들어진 프로세스에서는 이 가상주소가 안 보인다(그런 프로세스가
 * 아직 없는 부팅 초반 드라이버 초기화 단계에서만 쓰는 함수라
 * 실무상 문제되지 않음). */
uint64_t vmm_map_mmio(uint64_t phys_addr, uint64_t size);

#endif
