kernel/net/udp.o: kernel/net/udp.c kernel/net/udp.h kernel/net/net.h \
 kernel/net/../int/pit.h kernel/net/../proc/scheduler.h \
 kernel/net/../proc/thread.h kernel/net/../mm/heap.h
kernel/net/udp.h:
kernel/net/net.h:
kernel/net/../int/pit.h:
kernel/net/../proc/scheduler.h:
kernel/net/../proc/thread.h:
kernel/net/../mm/heap.h:
