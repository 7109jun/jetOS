/*
 * JetOS - kernel/apps/calculator.c
 * Milestone 35: 계산기. 설계 이유는 calculator.h 참고.
 *
 * 정직한 한계: 이 커널은 -mgeneral-regs-only로 빌드된다(FPU/SSE 레지스터
 * 사용 금지 — 커널 코드에서 흔한 설정, 부동소수점 상태 저장/복원 없이
 * 인터럽트가 하드웨어 FPU 레지스터를 건드리는 걸 원천 차단하기 위함).
 * 그래서 이 계산기는 float/double을 전혀 쓰지 않고 정수 연산만 지원한다
 * — 소수점 입력 버튼 자체가 없다. "누른 순서대로 왼쪽에서 오른쪽으로"
 * 계산하는 즉시계산기(대부분의 실물 휴대용 계산기와 동일 — 연산자
 * 우선순위 없음: 2 + 3 * 4 는 (2+3)*4=20).
 */

#include <stddef.h>
#include "calculator.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../drivers/console.h"
#include "../proc/scheduler.h"

#define CALC_MAX_DIGITS 9 /* int32 안전 범위 안에서 여유있게 */

typedef enum { OP_NONE, OP_ADD, OP_SUB, OP_MUL, OP_DIV } calc_op_t;

static long g_accumulator = 0;
static long g_entry = 0;
static int g_entry_digits = 0;
static int g_entering = 0; /* 지금 숫자를 입력 중인지(=아니면 결과/누적값을 보여주는 중) */
static calc_op_t g_pending_op = OP_NONE;
static char g_display[24] = "0";
static char g_error = 0;

static void refresh_display(void) {
    long v = g_entering ? g_entry : g_accumulator;
    if (g_error) { g_display[0]='E'; g_display[1]='R'; g_display[2]='R'; g_display[3]='\0'; return; }
    int neg = v < 0;
    unsigned long uv = neg ? (unsigned long)(-v) : (unsigned long)v;
    char tmp[24]; int t = 0;
    if (uv == 0) tmp[t++] = '0';
    while (uv > 0) { tmp[t++] = (char)('0' + uv % 10); uv /= 10; }
    int n = 0;
    if (neg) g_display[n++] = '-';
    while (t > 0) g_display[n++] = tmp[--t];
    g_display[n] = '\0';
}

static void calc_apply_pending(void) {
    if (g_pending_op == OP_NONE) { g_accumulator = g_entry; return; }
    switch (g_pending_op) {
        case OP_ADD: g_accumulator += g_entry; break;
        case OP_SUB: g_accumulator -= g_entry; break;
        case OP_MUL: g_accumulator *= g_entry; break;
        case OP_DIV:
            if (g_entry == 0) { g_error = 1; break; }
            g_accumulator /= g_entry;
            break;
        default: break;
    }
}

static void calc_clear(void) {
    g_accumulator = 0; g_entry = 0; g_entry_digits = 0;
    g_entering = 0; g_pending_op = OP_NONE; g_error = 0;
    refresh_display();
}

static void calc_digit(int d) {
    if (g_error) { calc_clear(); }
    if (g_entry_digits >= CALC_MAX_DIGITS) return;
    g_entry = g_entry * 10 + d;
    g_entry_digits++;
    g_entering = 1;
    refresh_display();
}

static void calc_op(calc_op_t op) {
    if (g_error) return;
    if (g_entering) {
        calc_apply_pending();
        g_entry = 0; g_entry_digits = 0; g_entering = 0;
    }
    g_pending_op = op;
    refresh_display();
}

static void calc_equals(void) {
    if (g_error) return;
    if (g_entering) calc_apply_pending();
    g_entry = 0; g_entry_digits = 0; g_entering = 0;
    g_pending_op = OP_NONE;
    refresh_display();
}

/* 4x4 버튼 그리드: 7 8 9 /, 4 5 6 *, 1 2 3 -, C 0 = + */
typedef struct { const char *label; int is_digit; int digit; calc_op_t op; int is_eq; int is_clear; } calc_btn_t;
static const calc_btn_t BTNS[16] = {
    { "7", 1, 7, OP_NONE, 0, 0 }, { "8", 1, 8, OP_NONE, 0, 0 }, { "9", 1, 9, OP_NONE, 0, 0 }, { "/", 0, 0, OP_DIV, 0, 0 },
    { "4", 1, 4, OP_NONE, 0, 0 }, { "5", 1, 5, OP_NONE, 0, 0 }, { "6", 1, 6, OP_NONE, 0, 0 }, { "*", 0, 0, OP_MUL, 0, 0 },
    { "1", 1, 1, OP_NONE, 0, 0 }, { "2", 1, 2, OP_NONE, 0, 0 }, { "3", 1, 3, OP_NONE, 0, 0 }, { "-", 0, 0, OP_SUB, 0, 0 },
    { "C", 0, 0, OP_NONE, 0, 1 }, { "0", 1, 0, OP_NONE, 0, 0 }, { "=", 0, 0, OP_NONE, 1, 0 }, { "+", 0, 0, OP_ADD, 0, 0 },
};

#define BTN_W 34
#define BTN_H 24
#define BTN_GAP 4
#define GRID_TOP 30
#define GRID_LEFT 8

static void calc_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)h; (void)ctx;
    console_fill_rect(dc, (uint32_t)(x + 8), (uint32_t)(y + 4), 152, 18, 0x00101820u);
    /* 오른쪽 정렬 표시 — 자릿수에 따라 시작 x를 당긴다 */
    int len = 0; while (g_display[len]) len++;
    int tx = x + 8 + 152 - 8 - len * 12;
    if (tx < x + 12) tx = x + 12;
    dc->cursor_x = (uint32_t)tx; dc->cursor_y = (uint32_t)(y + 8);
    console_print(dc, g_display);

    for (int i = 0; i < 16; i++) {
        int row = i / 4, col = i % 4;
        int bx = x + GRID_LEFT + col * (BTN_W + BTN_GAP);
        int by = y + GRID_TOP + row * (BTN_H + BTN_GAP);
        uint32_t color = BTNS[i].is_digit ? 0x00304050u : (BTNS[i].is_eq ? 0x00306030u : 0x00503040u);
        console_fill_rect(dc, (uint32_t)bx, (uint32_t)by, BTN_W, BTN_H, color);
        dc->cursor_x = (uint32_t)(bx + BTN_W / 2 - 4); dc->cursor_y = (uint32_t)(by + BTN_H / 2 - 4);
        console_print(dc, BTNS[i].label);
    }
}

static void calc_click_cb(int lx, int ly, void *ctx) {
    (void)ctx;
    if (ly < GRID_TOP) return;
    int col = (lx - GRID_LEFT) / (BTN_W + BTN_GAP);
    int row = (ly - GRID_TOP) / (BTN_H + BTN_GAP);
    if (col < 0 || col > 3 || row < 0 || row > 3) return;
    int rel_x = (lx - GRID_LEFT) % (BTN_W + BTN_GAP);
    if (rel_x >= BTN_W) return;
    int idx = row * 4 + col;
    const calc_btn_t *b = &BTNS[idx];
    if (b->is_clear) calc_clear();
    else if (b->is_eq) calc_equals();
    else if (b->is_digit) calc_digit(b->digit);
    else calc_op(b->op);
}

static volatile int g_calc_running = 0;

static void calc_on_close(void *ctx) {
    (void)ctx;
    g_calc_running = 0;
}

static void calc_thread_fn(void *arg) {
    (void)arg;
    g_calc_running = 1;
    calc_clear();
    JetWindowHandle win = CreateWindowJ("CALCULATOR", 460, 220, 180, 150, 0x00302838);
    if (win >= 0) {
        wm_set_content_callback(win, calc_content_cb, NULL);
        wm_set_close_callback(win, calc_on_close, NULL);
        wm_set_click_callback(win, calc_click_cb, NULL);
    }
    while (g_calc_running) {
        scheduler_yield();
    }
}

void calculator_launch(void) {
    static int launched = 0;
    if (launched && g_calc_running) return;
    launched = 1;
    CreateThreadJ("calculator", calc_thread_fn, NULL);
}
