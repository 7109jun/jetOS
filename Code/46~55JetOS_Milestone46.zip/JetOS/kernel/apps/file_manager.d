kernel/apps/file_manager.o: kernel/apps/file_manager.c \
 kernel/apps/file_manager.h kernel/apps/../../include/jetapi/jetapi.h \
 kernel/apps/../gui/wm.h kernel/apps/../gui/../drivers/console.h \
 kernel/apps/../gui/widget.h kernel/apps/../drivers/console.h \
 kernel/apps/../proc/scheduler.h kernel/apps/../proc/thread.h
kernel/apps/file_manager.h:
kernel/apps/../../include/jetapi/jetapi.h:
kernel/apps/../gui/wm.h:
kernel/apps/../gui/../drivers/console.h:
kernel/apps/../gui/widget.h:
kernel/apps/../drivers/console.h:
kernel/apps/../proc/scheduler.h:
kernel/apps/../proc/thread.h:
