/*
 * JetOS - kernel/fs/fat32.c
 * fat32.h 참고. 읽기 전용, 루트 디렉터리만, 8.3 짧은 이름만.
 */
#include "fat32.h"
#include "../drivers/ahci.h"

#define SECTOR_SIZE 512
#define MAX_CLUSTER_SECTORS 128 /* 클러스터당 최대 64KB(128*512)까지 지원 */

static int g_drive = -1;
static uint32_t g_fat_start_lba;
static uint32_t g_data_start_lba;
static uint32_t g_sectors_per_cluster;
static uint32_t g_root_cluster;
static uint32_t g_bytes_per_cluster;

static uint16_t rd_u16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t rd_u32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

int fat32_mount(int drive_index) {
    uint8_t boot[SECTOR_SIZE];
    if (!ahci_read_sectors(drive_index, 0, 1, boot)) return 0;

    if (boot[510] != 0x55 || boot[511] != 0xAA) return 0; /* 부트섹터 시그니처 */

    uint16_t bytes_per_sector = rd_u16(boot + 11);
    if (bytes_per_sector != SECTOR_SIZE) return 0; /* 알려진 단순화(fat32.h 참고) */

    uint8_t sectors_per_cluster = boot[13];
    uint16_t reserved_sectors = rd_u16(boot + 14);
    uint8_t num_fats = boot[16];
    uint16_t root_entry_count = rd_u16(boot + 17); /* FAT32면 0이어야 정상 */
    uint32_t fat_size_16 = rd_u16(boot + 22);
    uint32_t fat_size_32 = rd_u32(boot + 36);
    uint32_t root_cluster = rd_u32(boot + 44);

    if (root_entry_count != 0) return 0;   /* FAT12/16 특징 — FAT32 아님 */
    if (fat_size_16 != 0) return 0;
    if (fat_size_32 == 0) return 0;
    if (sectors_per_cluster == 0 || (uint32_t)sectors_per_cluster > MAX_CLUSTER_SECTORS) return 0;

    g_drive = drive_index;
    g_fat_start_lba = reserved_sectors;
    g_data_start_lba = reserved_sectors + (uint32_t)num_fats * fat_size_32;
    g_sectors_per_cluster = sectors_per_cluster;
    g_root_cluster = root_cluster;
    g_bytes_per_cluster = (uint32_t)sectors_per_cluster * SECTOR_SIZE;
    return 1;
}

static uint32_t cluster_to_lba(uint32_t cluster) {
    return g_data_start_lba + (cluster - 2) * g_sectors_per_cluster;
}

static uint32_t fat_next_cluster(uint32_t cluster) {
    uint32_t byte_off = cluster * 4;
    uint32_t sector = g_fat_start_lba + byte_off / SECTOR_SIZE;
    uint32_t off_in_sector = byte_off % SECTOR_SIZE;

    uint8_t sec[SECTOR_SIZE];
    if (!ahci_read_sectors(g_drive, sector, 1, sec)) return 0x0FFFFFFF; /* 에러 시 체인 끝 취급 */
    uint32_t v = rd_u32(sec + off_in_sector) & 0x0FFFFFFFu;
    return v;
}

static int is_end_of_chain(uint32_t cluster) {
    return cluster >= 0x0FFFFFF8u || cluster < 2;
}

/* 8.3 원시 이름(11바이트, 공백 패딩)을 "NAME.EXT" 문자열로 정규화 */
static void normalize_name(const uint8_t *raw11, char *out /* 최소 13바이트 */) {
    int oi = 0;
    for (int i = 0; i < 8; i++) {
        if (raw11[i] == ' ') break;
        out[oi++] = (char)raw11[i];
    }
    int has_ext = 0;
    for (int i = 8; i < 11; i++) if (raw11[i] != ' ') { has_ext = 1; break; }
    if (has_ext) {
        out[oi++] = '.';
        for (int i = 8; i < 11; i++) {
            if (raw11[i] == ' ') break;
            out[oi++] = (char)raw11[i];
        }
    }
    out[oi] = '\0';
}

static int ieq(const char *a, const char *b) {
    while (*a && *b) {
        char ca = *a, cb = *b;
        if (ca >= 'a' && ca <= 'z') ca = (char)(ca - 'a' + 'A');
        if (cb >= 'a' && cb <= 'z') cb = (char)(cb - 'a' + 'A');
        if (ca != cb) return 0;
        a++; b++;
    }
    return *a == *b;
}

/* 루트 디렉터리 클러스터 체인을 순회하며 콜백에 유효한 항목을 하나씩
 * 넘긴다. 콜백이 0을 반환하면 순회를 멈춘다(찾았다는 뜻으로 사용). */
typedef int (*dirent_cb_t)(const fat32_dirent_t *e, void *ctx);

static void walk_root(dirent_cb_t cb, void *ctx) {
    if (g_drive < 0) return;
    /* 스택이 아니라 static(BSS)에 둔다 — 64KB(MAX_CLUSTER_SECTORS*512)를
     * 커널 스레드 스택에 그대로 두면 오버플로 위험이 크다(실제로 겪은
     * 문제: PROGRAM.ELF처럼 여러 클러스터를 훑는 호출 도중 조용히
     * 죽어서 이후 STAGE 로그가 전혀 안 찍히는 증상으로 나타났었다). */
    static uint8_t buf[MAX_CLUSTER_SECTORS * SECTOR_SIZE];
    uint32_t cluster = g_root_cluster;

    while (!is_end_of_chain(cluster)) {
        uint32_t lba = cluster_to_lba(cluster);
        if (!ahci_read_sectors(g_drive, lba, g_sectors_per_cluster, buf)) return;

        for (uint32_t off = 0; off < g_bytes_per_cluster; off += 32) {
            const uint8_t *ent = buf + off;
            if (ent[0] == 0x00) return; /* 이후 항목 없음 — 전체 종료 */
            if (ent[0] == 0xE5) continue; /* 삭제됨 */
            uint8_t attr = ent[11];
            if (attr == 0x0F) continue; /* LFN 항목 — 건너뜀(fat32.h 참고) */
            if (attr & 0x08) continue;  /* 볼륨 라벨 */

            fat32_dirent_t e;
            normalize_name(ent, e.short_name);
            e.size = rd_u32(ent + 28);
            uint32_t hi = rd_u16(ent + 20);
            uint32_t lo = rd_u16(ent + 26);
            e.first_cluster = (hi << 16) | lo;
            e.is_dir = (attr & 0x10) ? 1 : 0;

            /* "." ".." 항목은 루트에도 나타날 수 있어 건너뜀(하위 디렉터리
             * 진입은 어차피 지원 안 하므로 의미 없음) */
            if (e.short_name[0] == '.') continue;

            if (!cb(&e, ctx)) return;
        }

        cluster = fat_next_cluster(cluster);
    }
}

typedef struct { int target_index; int cur; fat32_dirent_t *out; int found; } list_ctx_t;

static int list_cb(const fat32_dirent_t *e, void *ctx_) {
    list_ctx_t *ctx = (list_ctx_t *)ctx_;
    if (ctx->cur == ctx->target_index) {
        *ctx->out = *e;
        ctx->found = 1;
        return 0; /* 멈춤 */
    }
    ctx->cur++;
    return 1;
}

int fat32_list_root(int index, fat32_dirent_t *out) {
    list_ctx_t ctx = { index, 0, out, 0 };
    walk_root(list_cb, &ctx);
    return ctx.found;
}

typedef struct { const char *name; fat32_dirent_t found; int has; } find_ctx_t;

static int find_cb(const fat32_dirent_t *e, void *ctx_) {
    find_ctx_t *ctx = (find_ctx_t *)ctx_;
    if (!e->is_dir && ieq(e->short_name, ctx->name)) {
        ctx->found = *e;
        ctx->has = 1;
        return 0;
    }
    return 1;
}

uint32_t fat32_read_file(const char *short_name, uint8_t *buf, uint32_t buf_cap) {
    if (g_drive < 0) return 0;
    find_ctx_t ctx = { short_name, {0}, 0 };
    walk_root(find_cb, &ctx);
    if (!ctx.has) return 0;

    uint32_t remaining = ctx.found.size;
    if (remaining > buf_cap) remaining = buf_cap; /* 잘림 — fat32.h에 문서화된 동작 */
    uint32_t written = 0;
    uint32_t cluster = ctx.found.first_cluster;

    /* 같은 이유(스택 오버플로 방지)로 static — walk_root의 static buf와는
     * 별개 심볼이라 동시에 살아있어도 안전(재진입/스레드 동시 호출은
     * 안 한다는 전제, fat32.h의 "읽기 전용/단일 사용" 성격과 일관됨). */
    static uint8_t cbuf[MAX_CLUSTER_SECTORS * SECTOR_SIZE];
    int guard = 0;
    while (!is_end_of_chain(cluster) && written < remaining) {
        if (++guard > 1000000) break; /* 방어적 가드 — 정상 동작에서는 절대 안 걸림 */
        uint32_t lba = cluster_to_lba(cluster);
        if (!ahci_read_sectors(g_drive, lba, g_sectors_per_cluster, cbuf)) break;

        uint32_t take = g_bytes_per_cluster;
        if (written + take > remaining) take = remaining - written;
        for (uint32_t i = 0; i < take; i++) buf[written + i] = cbuf[i];
        written += take;

        cluster = fat_next_cluster(cluster);
    }
    return written;
}
