#ifndef JETOS_CONTEXT_SWITCH_H
#define JETOS_CONTEXT_SWITCH_H

#include <stdint.h>

/* 실행 컨텍스트 전환(콘텍스트 스위치)은 "현재 스택 포인터를 저장하고,
 * 다른 스택 포인터로 옮겨간 뒤, 그 스택에 미리 쌓여있던 상태에서
 * 실행을 재개"하는 동작이다. 이는 C 언어의 함수 호출/리턴 모델 자체가
 * 표현할 수 없는 동작이므로(호출한 함수로 "정상적으로" 돌아가는 것이
 * 아니라 완전히 다른 실행 흐름으로 옮겨감), CPU 레지스터 저장/스택
 * 교체를 다루는 최소한의 어셈블리가 불가피하다. 구현은
 * kernel/hal/context_switch.c 한 파일에만 격리되어 있다. */
void switch_context(uint64_t *old_rsp_out, uint64_t new_rsp);

#endif
