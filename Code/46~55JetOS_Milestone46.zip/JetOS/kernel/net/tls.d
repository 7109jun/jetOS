kernel/net/tls.o: kernel/net/tls.c kernel/net/tls.h kernel/net/tcp.h \
 kernel/net/dns.h kernel/net/crypto/sha256.h \
 kernel/net/crypto/hmac_sha256.h kernel/net/crypto/aes128.h \
 kernel/net/crypto/bignum.h kernel/net/crypto/x509_min.h \
 kernel/net/crypto/bignum.h kernel/net/crypto/x509_trust.h \
 kernel/net/crypto/x509_min.h kernel/net/crypto/rsa_pkcs1.h \
 kernel/net/crypto/tls_prf.h kernel/net/crypto/rng.h \
 kernel/net/../drivers/serial.h kernel/net/../drivers/rtc.h
kernel/net/tls.h:
kernel/net/tcp.h:
kernel/net/dns.h:
kernel/net/crypto/sha256.h:
kernel/net/crypto/hmac_sha256.h:
kernel/net/crypto/aes128.h:
kernel/net/crypto/bignum.h:
kernel/net/crypto/x509_min.h:
kernel/net/crypto/bignum.h:
kernel/net/crypto/x509_trust.h:
kernel/net/crypto/x509_min.h:
kernel/net/crypto/rsa_pkcs1.h:
kernel/net/crypto/tls_prf.h:
kernel/net/crypto/rng.h:
kernel/net/../drivers/serial.h:
kernel/net/../drivers/rtc.h:
