kernel/net/crypto/x509_trust.o: kernel/net/crypto/x509_trust.c \
 kernel/net/crypto/x509_trust.h kernel/net/crypto/x509_min.h \
 kernel/net/crypto/bignum.h kernel/net/crypto/der.h \
 kernel/net/crypto/../../fs/jetfs.h
kernel/net/crypto/x509_trust.h:
kernel/net/crypto/x509_min.h:
kernel/net/crypto/bignum.h:
kernel/net/crypto/der.h:
kernel/net/crypto/../../fs/jetfs.h:
