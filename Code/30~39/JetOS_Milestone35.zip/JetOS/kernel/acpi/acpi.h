#ifndef JETOS_ACPI_H
#define JETOS_ACPI_H

#include <stdint.h>

/*
 * JetOS - kernel/acpi/acpi.h
 * Milestone 35: ACPI 테이블 탐색 — APIC/SMP 작업의 1단계.
 *
 * 이 모듈은 **읽기 전용 파싱만** 한다: RSDP(부트로더가 EFI
 * ConfigurationTable에서 찾아 boot_info->acpi_rsdp로 넘겨준 물리주소)에서
 * 시작해 RSDT/XSDT를 걷고, MADT(Multiple APIC Description Table)를 찾아
 * Local APIC 주소·IO APIC 목록·CPU(Local APIC) 목록을 뽑아낸다.
 *
 * 왜 여기서 멈추는가(중요 — 다음 마일스톤과의 경계):
 * 이 모듈은 기존 인터럽트 경로(kernel/int/pic.c 기반 PIC, kernel_entry.c의
 * 초기화 순서)를 **전혀 건드리지 않는다.** ACPI 테이블을 잘못 읽어도
 * 최악의 경우 "정보를 못 얻어서 acpi_available()이 0을 반환"할 뿐, 기존
 * 부팅 경로는 그대로 살아있다 — VirtIO-GPU(M31/M32)나 JETFS 마운트
 * 실패(M22~)와 같은 "못 찾으면 안전하게 우회" 원칙을 그대로 따른다.
 *
 * 실제로 PIC를 끄고 Local APIC/IO APIC로 인터럽트를 넘기는 작업, 그리고
 * SMP AP(Application Processor) 기동(INIT-SIPI-SIPI, 저메모리 real-mode
 * 트램폴린 코드, 코어별 스택/GDT)은 **이번 마일스톤에 포함하지 않았다.**
 * 이유: 이 두 작업은 잘못되면 키보드/마우스/타이머/디스크/네트워크 등
 * 지금 동작하는 모든 인터럽트 기반 기능이 한꺼번에 멈출 수 있는, 이
 * 프로젝트에서 가장 위험도가 높은 변경이다. 지금 이 검증 샌드박스에는
 * QEMU가 없어서(M31부터 반복된 제약) 그 결과를 전혀 확인할 방법이 없다
 * — "컴파일은 되지만 실기에서 뭐가 일어나는지 전혀 모르는" 채로 인터럽트
 * 컨트롤러 자체를 바꾸는 건, 이미 "리스크 있는 작업이라 신중히"라고
 * 미뤄뒀던 파일시스템 저널링보다도 위험하다고 판단했다. ACPI 파싱까지
 * 먼저 실제 QEMU에서(사용자 환경) 값이 올바른지 확인한 뒤, 그 다음
 * 마일스톤에서 APIC 전환 → SMP AP 기동 순서로 진행하는 게 맞다.
 */

#define ACPI_MAX_CPUS 16
#define ACPI_MAX_IOAPICS 4

typedef struct {
    uint8_t apic_id;
    uint8_t acpi_processor_id;
    int enabled; /* MADT 플래그의 "Enabled" 비트 */
} acpi_cpu_t;

typedef struct {
    uint8_t id;
    uint32_t address;          /* IO APIC MMIO 물리주소(대개 4GiB 미만) */
    uint32_t gsi_base;         /* 이 IO APIC가 담당하는 첫 Global System Interrupt 번호 */
} acpi_ioapic_t;

/* boot_info->acpi_rsdp(0이면 즉시 실패)로 RSDP부터 시작해 체크섬 검증
 * → RSDT/XSDT 탐색 → MADT 파싱까지 수행한다. 성공(MADT를 찾았고 Local
 * APIC 주소 + IO APIC 1개 이상 + CPU 1개 이상을 얻음)하면 1, 그 외
 * 모든 실패 경로(RSDP 없음/체크섬 불일치/4GiB 이상 주소/MADT 없음 등)는
 * 조용히 0을 반환한다 — 커널은 이 반환값만 보고 ACPI 관련 기능을 켤지
 * 말지 결정하면 된다. */
int acpi_init(uint64_t rsdp_phys_addr);

int acpi_available(void); /* acpi_init()이 성공했으면 1 */

uint64_t acpi_get_local_apic_addr(void); /* acpi_available()==0이면 0 */

int acpi_get_ioapic_count(void);
const acpi_ioapic_t *acpi_get_ioapic(int idx); /* idx 범위 밖이면 NULL */

int acpi_get_cpu_count(void);
const acpi_cpu_t *acpi_get_cpu(int idx); /* idx 범위 밖이면 NULL */

#endif
