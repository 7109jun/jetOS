kernel/drivers/rtc.o: kernel/drivers/rtc.c kernel/drivers/rtc.h \
 kernel/drivers/../hal/x86_asm_shim.h
kernel/drivers/rtc.h:
kernel/drivers/../hal/x86_asm_shim.h:
