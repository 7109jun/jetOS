#include "network.hpp"

#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <sstream>
#include <string_view>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#else
#include <arpa/inet.h>
#include <cerrno>
#include <fcntl.h>
#include <netdb.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#endif

namespace deiig::network {
namespace {

#ifdef _WIN32
using Socket = SOCKET;
constexpr Socket invalid_socket = INVALID_SOCKET;
#else
using Socket = int;
constexpr Socket invalid_socket = -1;
#endif

class NetInit {
public:
    NetInit() {
#ifdef _WIN32
        WSADATA data{};
        ok_ = WSAStartup(MAKEWORD(2, 2), &data) == 0;
#else
        ok_ = true;
#endif
    }
    ~NetInit() {
#ifdef _WIN32
        if (ok_) WSACleanup();
#endif
    }
    bool ok() const { return ok_; }
private:
    bool ok_ = false;
};

void close_socket(Socket s) {
#ifdef _WIN32
    if (s != invalid_socket) closesocket(s);
#else
    if (s != invalid_socket) ::close(s);
#endif
}

std::string last_error() {
#ifdef _WIN32
    return "socket error " + std::to_string(WSAGetLastError());
#else
    return std::strerror(errno);
#endif
}

bool set_nonblocking(Socket s, bool value) {
#ifdef _WIN32
    u_long mode = value ? 1UL : 0UL;
    return ioctlsocket(s, FIONBIO, &mode) == 0;
#else
    int flags = fcntl(s, F_GETFL, 0);
    if (flags < 0) return false;
    if (value) flags |= O_NONBLOCK;
    else flags &= ~O_NONBLOCK;
    return fcntl(s, F_SETFL, flags) == 0;
#endif
}

bool wait_writable(Socket s, int timeout_ms) {
    fd_set set;
    FD_ZERO(&set);
    FD_SET(s, &set);
    timeval tv{};
    tv.tv_sec = timeout_ms / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;
#ifdef _WIN32
    return select(0, nullptr, &set, nullptr, &tv) > 0;
#else
    return select(s + 1, nullptr, &set, nullptr, &tv) > 0;
#endif
}

bool send_all(Socket s, std::string_view data) {
    std::size_t sent = 0;
    while (sent < data.size()) {
#ifdef _WIN32
        const int n = ::send(s, data.data() + sent, static_cast<int>(data.size() - sent), 0);
#else
        const ssize_t n = ::send(s, data.data() + sent, data.size() - sent, 0);
#endif
        if (n <= 0) return false;
        sent += static_cast<std::size_t>(n);
    }
    return true;
}

bool parse_http_url(const std::string& url, std::string& host, int& port, std::string& path) {
    constexpr std::string_view prefix = "http://";
    if (url.size() < prefix.size() || url.compare(0, prefix.size(), prefix) != 0) return false;
    std::string rest = url.substr(prefix.size());
    const auto slash = rest.find('/');
    std::string authority = slash == std::string::npos ? rest : rest.substr(0, slash);
    path = slash == std::string::npos ? "/" : rest.substr(slash);
    if (authority.empty()) return false;

    port = 80;
    const auto colon = authority.rfind(':');
    if (colon != std::string::npos && authority.find(']') == std::string::npos) {
        host = authority.substr(0, colon);
        try { port = std::stoi(authority.substr(colon + 1)); }
        catch (...) { return false; }
    } else {
        host = authority;
    }
    return !host.empty() && port > 0 && port <= 65535;
}

} // namespace

ResolveResult resolve(const std::string& host) {
    NetInit init;
    ResolveResult out;
    out.host = host;
    if (!init.ok()) { out.error = "network initialization failed"; return out; }

    addrinfo hints{};
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    addrinfo* result = nullptr;
    const int rc = getaddrinfo(host.c_str(), nullptr, &hints, &result);
    if (rc != 0) {
#ifdef _WIN32
        out.error = "getaddrinfo failed: " + std::to_string(rc);
#else
        out.error = gai_strerror(rc);
#endif
        return out;
    }

    for (addrinfo* p = result; p; p = p->ai_next) {
        char text[INET6_ADDRSTRLEN]{};
        const void* addr = nullptr;
        if (p->ai_family == AF_INET) addr = &reinterpret_cast<sockaddr_in*>(p->ai_addr)->sin_addr;
        else if (p->ai_family == AF_INET6) addr = &reinterpret_cast<sockaddr_in6*>(p->ai_addr)->sin6_addr;
        if (!addr) continue;
        if (inet_ntop(p->ai_family, addr, text, sizeof(text))) {
            if (std::find(out.addresses.begin(), out.addresses.end(), text) == out.addresses.end())
                out.addresses.emplace_back(text);
        }
    }
    freeaddrinfo(result);
    if (out.addresses.empty()) out.error = "no addresses returned";
    return out;
}

TcpResult tcp_test(const std::string& host, int port, int timeout_ms) {
    NetInit init;
    TcpResult out{host, port, false, -1, {}};
    if (!init.ok()) { out.error = "network initialization failed"; return out; }

    addrinfo hints{};
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    addrinfo* result = nullptr;
    const std::string service = std::to_string(port);
    const int rc = getaddrinfo(host.c_str(), service.c_str(), &hints, &result);
    if (rc != 0) {
#ifdef _WIN32
        out.error = "getaddrinfo failed: " + std::to_string(rc);
#else
        out.error = gai_strerror(rc);
#endif
        return out;
    }

    const auto started = std::chrono::steady_clock::now();
    for (addrinfo* p = result; p; p = p->ai_next) {
        Socket s = static_cast<Socket>(::socket(p->ai_family, p->ai_socktype, p->ai_protocol));
        if (s == invalid_socket) continue;
        if (!set_nonblocking(s, true)) { close_socket(s); continue; }

        const int c = ::connect(s, p->ai_addr, static_cast<int>(p->ai_addrlen));
        bool ok = c == 0;
        if (!ok) ok = wait_writable(s, timeout_ms);
        if (ok) {
            int socket_error = 0;
#ifdef _WIN32
            int len = sizeof(socket_error);
            getsockopt(s, SOL_SOCKET, SO_ERROR, reinterpret_cast<char*>(&socket_error), &len);
#else
            socklen_t len = sizeof(socket_error);
            getsockopt(s, SOL_SOCKET, SO_ERROR, &socket_error, &len);
#endif
            ok = socket_error == 0;
        }
        close_socket(s);
        if (ok) {
            out.connected = true;
            out.elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - started).count();
            freeaddrinfo(result);
            return out;
        }
    }
    freeaddrinfo(result);
    out.error = "connection failed or timed out";
    return out;
}

HttpResult http_get(const std::string& url, std::size_t max_bytes) {
    NetInit init;
    HttpResult out;
    if (!init.ok()) { out.error = "network initialization failed"; return out; }

    std::string host, path;
    int port = 0;
    if (!parse_http_url(url, host, port, path)) {
        out.error = "only http:// URLs are supported by the built-in client";
        return out;
    }

    addrinfo hints{};
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    addrinfo* result = nullptr;
    const std::string service = std::to_string(port);
    if (getaddrinfo(host.c_str(), service.c_str(), &hints, &result) != 0) {
        out.error = "DNS resolution failed";
        return out;
    }

    Socket sock = invalid_socket;
    for (addrinfo* p = result; p; p = p->ai_next) {
        Socket s = static_cast<Socket>(::socket(p->ai_family, p->ai_socktype, p->ai_protocol));
        if (s == invalid_socket) continue;
        if (::connect(s, p->ai_addr, static_cast<int>(p->ai_addrlen)) == 0) { sock = s; break; }
        close_socket(s);
    }
    freeaddrinfo(result);
    if (sock == invalid_socket) { out.error = "HTTP connection failed: " + last_error(); return out; }

    const std::string request = "GET " + path + " HTTP/1.1\r\nHost: " + host + "\r\nConnection: close\r\nUser-Agent: DEIIG/1.0\r\nAccept: */*\r\n\r\n";
    if (!send_all(sock, request)) {
        close_socket(sock);
        out.error = "failed to send HTTP request";
        return out;
    }

    std::string response;
    response.reserve(std::min<std::size_t>(max_bytes + 4096, 2 * 1024 * 1024));
    char buffer[8192];
    while (response.size() < max_bytes + 8192) {
#ifdef _WIN32
        const int n = ::recv(sock, buffer, sizeof(buffer), 0);
#else
        const ssize_t n = ::recv(sock, buffer, sizeof(buffer), 0);
#endif
        if (n <= 0) break;
        response.append(buffer, buffer + n);
    }
    close_socket(sock);

    const auto split = response.find("\r\n\r\n");
    if (split == std::string::npos) { out.error = "invalid HTTP response"; return out; }
    out.headers = response.substr(0, split);
    out.body = response.substr(split + 4);
    if (out.body.size() > max_bytes) out.body.resize(max_bytes);

    std::istringstream status(out.headers);
    std::string version;
    status >> version >> out.status;
    if (out.status == 0) out.error = "invalid HTTP status";
    return out;
}

int ping(const std::string& host, int count) {
#ifdef _WIN32
    const std::string cmd = "ping -n " + std::to_string(std::max(1, count)) + " " + host;
#else
    const std::string cmd = "ping -c " + std::to_string(std::max(1, count)) + " " + host;
#endif
    return std::system(cmd.c_str());
}

} // namespace deiig::network
