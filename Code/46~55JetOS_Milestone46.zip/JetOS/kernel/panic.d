kernel/panic.o: kernel/panic.c kernel/panic.h kernel/kernel.h \
 kernel/drivers/console.h kernel/drivers/serial.h \
 kernel/hal/x86_asm_shim.h
kernel/panic.h:
kernel/kernel.h:
kernel/drivers/console.h:
kernel/drivers/serial.h:
kernel/hal/x86_asm_shim.h:
