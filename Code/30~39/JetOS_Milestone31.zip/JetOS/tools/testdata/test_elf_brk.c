/* JetOS 네이티브 ELF 테스트 프로그램 — Milestone 20 SYS_BRK 검증.
 *
 * 예전(2MiB 고정)엔 애초에 요청할 수 없던 크기(8MiB)까지 SYS_BRK로
 * 늘려서, 그 새로 매핑된 메모리에 실제로 쓰고 읽어 값이 유지되는지
 * 확인한다 — 단순히 "syscall이 성공했다고 우기는" 게 아니라 실제
 * 물리 페이지가 매핑됐는지를 데이터로 증명한다. */

static long jsyscall(long num, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile (
        "int $0x80"
        : "=a"(ret)
        : "a"(num), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory"
    );
    return ret;
}

#define SYS_WRITE 0
#define SYS_EXIT  1
#define SYS_BRK   3

static void print_str(const char *s) { jsyscall(SYS_WRITE, (long)s, 0, 0); }

static void print_hex64(unsigned long v, char *out) {
    const char *hex = "0123456789abcdef";
    out[0] = '0'; out[1] = 'x';
    for (int i = 0; i < 16; i++) {
        out[2 + i] = hex[(v >> ((15 - i) * 4)) & 0xF];
    }
    out[18] = '\0';
}

void _start(void) {
    print_str("[brk-test] querying current brk...\n");
    long brk0 = jsyscall(SYS_BRK, 0, 0, 0);
    static char linebuf[64];
    print_hex64((unsigned long)brk0, linebuf);
    print_str("[brk-test] initial brk = ");
    print_str(linebuf);
    print_str("\n");

    /* 예전 2MiB 상한을 넘는 8MiB 지점까지 요청 — 성공하면 진짜로
     * 유저 영역이 확장됐다는 뜻(16MiB 상한 안에 들어가므로 성공해야
     * 정상). */
    long target = brk0 + (8 * 1024 * 1024);
    long brk1 = jsyscall(SYS_BRK, target, 0, 0);
    print_hex64((unsigned long)brk1, linebuf);
    print_str("[brk-test] after brk(+8MiB) request, new brk = ");
    print_str(linebuf);
    print_str("\n");

    if (brk1 < target) {
        print_str("[brk-test] FAIL: brk did not grow as requested\n");
        jsyscall(SYS_EXIT, 0, 0, 0);
    }

    /* 새로 매핑된 영역 한가운데(예전 2MiB 안에는 존재할 수 없던 주소)에
     * 실제로 쓰고 다시 읽어서 확인 */
    volatile unsigned char *probe = (volatile unsigned char *)(brk0 + 4 * 1024 * 1024);
    *probe = 0xAB;
    unsigned char readback = *probe;

    if (readback == 0xAB) {
        print_str("[brk-test] PASS: wrote and read back 0xAB at newly-mapped address beyond old 2MiB limit\n");
    } else {
        print_str("[brk-test] FAIL: readback mismatch\n");
    }

    jsyscall(SYS_EXIT, 0, 0, 0);
    for (;;) { }
}
