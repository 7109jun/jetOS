kernel/int/pic.o: kernel/int/pic.c kernel/int/pic.h \
 kernel/int/../hal/x86_asm_shim.h
kernel/int/pic.h:
kernel/int/../hal/x86_asm_shim.h:
