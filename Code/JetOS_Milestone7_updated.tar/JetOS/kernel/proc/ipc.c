#include "ipc.h"
#include "scheduler.h"

void ipc_channel_init(ipc_channel_t *ch) {
    ch->head = 0;
    ch->tail = 0;
    ch->count = 0;
}

void ipc_send(ipc_channel_t *ch, uint64_t msg) {
    while (ch->count >= IPC_QUEUE_CAP) {
        scheduler_yield(); /* 큐가 가득 참 — 소비자가 처리할 때까지 양보하며 대기 */
    }
    ch->buf[ch->tail] = msg;
    ch->tail = (ch->tail + 1) % IPC_QUEUE_CAP;
    ch->count++;
}

uint64_t ipc_receive(ipc_channel_t *ch) {
    while (ch->count == 0) {
        scheduler_yield(); /* 큐가 비어있음 — 생산자가 보낼 때까지 양보하며 대기 */
    }
    uint64_t msg = ch->buf[ch->head];
    ch->head = (ch->head + 1) % IPC_QUEUE_CAP;
    ch->count--;
    return msg;
}
