#ifndef JETOS_APP_PROGRAMS_GUI_H
#define JETOS_APP_PROGRAMS_GUI_H

/*
 * JetOS - kernel/apps/programs_gui.h
 * Milestone 37: 설치된 프로그램 GUI. kernel/fs/programs.c(등록부)를
 * 지금까지처럼 jash 명령(install/uninstall/programs)으로만 쓰는 대신,
 * 클릭으로 실행/제거할 수 있는 창을 추가했다 — recyclebin_gui.c(M35)와
 * 거의 같은 구조.
 */
void programs_gui_launch(void);

#endif
