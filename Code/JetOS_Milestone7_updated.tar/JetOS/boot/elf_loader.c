/*
 * JetOS - boot/elf_loader.c
 * ESP의 "\KERNEL.ELF" 를 UEFI Simple File System Protocol로 읽어,
 * PT_LOAD 세그먼트를 각자의 물리주소(p_paddr)에 그대로 적재한다.
 * Milestone 1까지는 부트로더가 커널을 직접 함수 호출로 포함했지만,
 * Milestone 2부터 실제로 분리된 두 개의 바이너리(BOOTX64.EFI / KERNEL.ELF)
 * 로 동작한다.
 */

#include "elf_loader.h"
#include "elf64.h"
#include <stddef.h>

#define U16(s) ((CHAR16 *) L##s)
#define KERNEL_FILE_BUF_SIZE (8 * 1024 * 1024) /* 8MB - 개발 단계 커널 최대 크기 */
#define EFI_PAGE_SIZE 4096ULL

extern void *memcpy(void *dest, const void *src, size_t n);
extern void *memset(void *dest, int value, size_t n);

static void print(EFI_SYSTEM_TABLE *st, const CHAR16 *s) {
    st->ConOut->OutputString(st->ConOut, (CHAR16 *)s);
}

static uint64_t align_down(uint64_t v, uint64_t align) {
    return v & ~(align - 1);
}
static uint64_t align_up(uint64_t v, uint64_t align) {
    return (v + align - 1) & ~(align - 1);
}

uint64_t elf_load_kernel(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable) {
    EFI_BOOT_SERVICES *bs = SystemTable->BootServices;
    EFI_STATUS status;

    /* 1. 이 부트로더 이미지 자신의 DeviceHandle 획득 */
    EFI_GUID loaded_image_guid = EFI_LOADED_IMAGE_PROTOCOL_GUID;
    EFI_LOADED_IMAGE_PROTOCOL *loaded_image = NULL;
    status = bs->HandleProtocol(ImageHandle, &loaded_image_guid, (VOID **)&loaded_image);
    if (EFI_ERROR(status) || !loaded_image) {
        print(SystemTable, U16("FATAL: LoadedImageProtocol 획득 실패\r\n"));
        return 0;
    }

    /* 2. 같은 볼륨(ESP)의 파일시스템 프로토콜 획득 */
    EFI_GUID fs_guid = EFI_SIMPLE_FILE_SYSTEM_PROTOCOL_GUID;
    EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *fs = NULL;
    status = bs->HandleProtocol(loaded_image->DeviceHandle, &fs_guid, (VOID **)&fs);
    if (EFI_ERROR(status) || !fs) {
        print(SystemTable, U16("FATAL: SimpleFileSystemProtocol 획득 실패\r\n"));
        return 0;
    }

    EFI_FILE_PROTOCOL *root = NULL;
    status = fs->OpenVolume(fs, &root);
    if (EFI_ERROR(status) || !root) {
        print(SystemTable, U16("FATAL: ESP 볼륨 열기 실패\r\n"));
        return 0;
    }

    EFI_FILE_PROTOCOL *kfile = NULL;
    status = root->Open(root, &kfile, U16("KERNEL.ELF"), EFI_FILE_MODE_READ, 0);
    if (EFI_ERROR(status) || !kfile) {
        print(SystemTable, U16("FATAL: \\KERNEL.ELF 를 찾을 수 없습니다\r\n"));
        return 0;
    }

    /* 3. 파일 내용을 통째로 메모리에 읽는다 (Read()는 파일이 버퍼보다
     *    작으면 성공하며 BufferSize를 실제 읽은 바이트 수로 갱신한다) */
    VOID *filebuf = NULL;
    status = bs->AllocatePool(EfiLoaderData, KERNEL_FILE_BUF_SIZE, &filebuf);
    if (EFI_ERROR(status) || !filebuf) {
        print(SystemTable, U16("FATAL: 커널 파일 버퍼 할당 실패\r\n"));
        return 0;
    }

    UINTN read_size = KERNEL_FILE_BUF_SIZE;
    status = kfile->Read(kfile, &read_size, filebuf);
    kfile->Close(kfile);
    if (EFI_ERROR(status) || read_size < sizeof(Elf64_Ehdr)) {
        print(SystemTable, U16("FATAL: KERNEL.ELF 읽기 실패\r\n"));
        return 0;
    }

    print(SystemTable, U16("KERNEL.ELF 로드됨. ELF 헤더 검증 중...\r\n"));

    /* 4. ELF64 헤더 검증 */
    Elf64_Ehdr *ehdr = (Elf64_Ehdr *)filebuf;
    if (ehdr->e_ident[0] != ELFMAG0 || ehdr->e_ident[1] != ELFMAG1 ||
        ehdr->e_ident[2] != ELFMAG2 || ehdr->e_ident[3] != ELFMAG3 ||
        ehdr->e_ident[4] != ELFCLASS64 || ehdr->e_ident[5] != ELFDATA2LSB ||
        ehdr->e_type != ET_EXEC || ehdr->e_machine != EM_X86_64) {
        print(SystemTable, U16("FATAL: 올바른 x86_64 ELF64 실행파일이 아닙니다\r\n"));
        return 0;
    }

    print(SystemTable, U16("PT_LOAD 세그먼트 적재 중...\r\n"));

    /* 5. PT_LOAD 세그먼트를 각각 p_paddr 물리주소에 적재 */
    Elf64_Phdr *phdrs = (Elf64_Phdr *)((uint8_t *)filebuf + ehdr->e_phoff);
    for (uint16_t i = 0; i < ehdr->e_phnum; i++) {
        Elf64_Phdr *ph = &phdrs[i];
        if (ph->p_type != PT_LOAD) continue;

        uint64_t seg_start = align_down(ph->p_paddr, EFI_PAGE_SIZE);
        uint64_t seg_end   = align_up(ph->p_paddr + ph->p_memsz, EFI_PAGE_SIZE);
        uint64_t pages     = (seg_end - seg_start) / EFI_PAGE_SIZE;

        EFI_PHYSICAL_ADDRESS phys = seg_start;
        status = bs->AllocatePages(AllocateAddress, EfiLoaderData, pages, &phys);
        if (EFI_ERROR(status)) {
            print(SystemTable, U16("FATAL: 커널 세그먼트 물리 페이지 할당 실패\r\n"));
            return 0;
        }

        memset((void *)ph->p_paddr, 0, ph->p_memsz);
        memcpy((void *)ph->p_paddr, (uint8_t *)filebuf + ph->p_offset, ph->p_filesz);
    }

    print(SystemTable, U16("커널 세그먼트 적재 완료.\r\n"));
    return ehdr->e_entry;
}
