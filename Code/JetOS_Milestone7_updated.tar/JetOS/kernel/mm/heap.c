/*
 * JetOS - kernel/mm/heap.c
 * PMM이 확보해 준 물리(=항등매핑된 가상) 페이지 위에서 동작하는
 * First-Fit 프리리스트 힙. 블록 헤더를 청크 맨 앞에 두는 전형적인
 * 커널 힙 구조다.
 */

#include "heap.h"
#include "pmm.h"

typedef struct block_header {
    uint64_t size;              /* 헤더를 제외한 payload 크기 */
    int      is_free;
    struct block_header *next;
} block_header_t;

#define HEADER_SIZE sizeof(block_header_t)
#define ALIGN8(x) (((x) + 7ULL) & ~7ULL)

static block_header_t *g_heap_head = NULL;
static uint64_t g_heap_total_bytes = 0;

static void add_region(uint64_t phys_addr, uint64_t bytes) {
    block_header_t *blk = (block_header_t *)phys_addr;
    blk->size = bytes - HEADER_SIZE;
    blk->is_free = 1;
    blk->next = NULL;

    if (!g_heap_head) {
        g_heap_head = blk;
    } else {
        block_header_t *cur = g_heap_head;
        while (cur->next) cur = cur->next;
        cur->next = blk;
    }
    g_heap_total_bytes += bytes;
}

void heap_init(uint64_t initial_pages) {
    uint64_t phys = pmm_alloc_pages(initial_pages);
    if (phys == 0) {
        /* 초기 힙 확보 실패 — 이는 Milestone 2 개발 환경에서는 발생하지
         * 않아야 하는 치명적 상황이다. 상위 계층(kernel_entry)에서
         * heap_get_stats()의 total_bytes == 0 으로 감지 가능하다. */
        return;
    }
    add_region(phys, initial_pages * PMM_PAGE_SIZE);
}

static int grow_heap(uint64_t min_bytes) {
    uint64_t pages_needed = (min_bytes + HEADER_SIZE + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE;
    if (pages_needed < 4) pages_needed = 4; /* 최소 16KB씩 확장 */
    uint64_t phys = pmm_alloc_pages(pages_needed);
    if (phys == 0) return 0;
    add_region(phys, pages_needed * PMM_PAGE_SIZE);
    return 1;
}

void *kmalloc(size_t size) {
    if (size == 0) return NULL;
    uint64_t need = ALIGN8((uint64_t)size);

    for (int attempt = 0; attempt < 2; attempt++) {
        block_header_t *cur = g_heap_head;
        while (cur) {
            if (cur->is_free && cur->size >= need) {
                /* 남는 공간이 헤더+최소단위(16바이트) 이상이면 분할한다 */
                if (cur->size >= need + HEADER_SIZE + 16) {
                    block_header_t *split =
                        (block_header_t *)((uint8_t *)cur + HEADER_SIZE + need);
                    split->size = cur->size - need - HEADER_SIZE;
                    split->is_free = 1;
                    split->next = cur->next;

                    cur->size = need;
                    cur->next = split;
                }
                cur->is_free = 0;
                return (void *)((uint8_t *)cur + HEADER_SIZE);
            }
            cur = cur->next;
        }
        /* 맞는 블록이 없으면 힙을 확장하고 한 번 더 탐색 */
        if (!grow_heap(need)) break;
    }
    return NULL;
}

void kfree(void *ptr) {
    if (!ptr) return;
    block_header_t *blk = (block_header_t *)((uint8_t *)ptr - HEADER_SIZE);
    blk->is_free = 1;

    /* 인접한 free 블록 병합 (단순 순방향 병합, Milestone 2 수준으로 충분) */
    block_header_t *cur = g_heap_head;
    while (cur && cur->next) {
        if (cur->is_free && cur->next->is_free &&
            (uint8_t *)cur + HEADER_SIZE + cur->size == (uint8_t *)cur->next) {
            cur->size += HEADER_SIZE + cur->next->size;
            cur->next = cur->next->next;
        } else {
            cur = cur->next;
        }
    }
}

void heap_get_stats(heap_stats_t *out) {
    out->total_bytes = g_heap_total_bytes;
    out->used_bytes = 0;
    out->free_bytes = 0;
    out->block_count = 0;

    block_header_t *cur = g_heap_head;
    while (cur) {
        out->block_count++;
        if (cur->is_free) out->free_bytes += cur->size;
        else out->used_bytes += cur->size;
        cur = cur->next;
    }
}
