/* JetOS - kernel/net/crypto/rng.c - rng.h 참고. */
#include "rng.h"
#include "sha256.h"
#include "../../hal/x86_asm_shim.h"
#include "../../int/pit.h"
#include "../../drivers/rtc.h"

static int g_have_rdrand = -1; /* -1=아직 확인 안 함 */
static uint32_t g_fallback_counter = 0;

static uint32_t fallback_word(void) {
    /* RDRAND가 없을 때만 쓰는 약한 폴백 — rng.h의 "알려진 한계" 참고 */
    uint8_t seed[24];
    uint64_t tsc = hal_rdtsc();
    uint64_t ticks = g_timer_ticks;
    g_fallback_counter++;
    for (int i = 0; i < 8; i++) seed[i] = (uint8_t)(tsc >> (i * 8));
    for (int i = 0; i < 8; i++) seed[8 + i] = (uint8_t)(ticks >> (i * 8));
    for (int i = 0; i < 4; i++) seed[16 + i] = (uint8_t)(g_fallback_counter >> (i * 8));
    rtc_time_t t; rtc_read(&t);
    seed[20] = t.second; seed[21] = t.minute; seed[22] = t.hour; seed[23] = t.day;

    uint8_t hash[32];
    sha256_oneshot(seed, sizeof(seed), hash);
    return ((uint32_t)hash[0] << 24) | ((uint32_t)hash[1] << 16) | ((uint32_t)hash[2] << 8) | hash[3];
}

void rng_bytes(uint8_t *out, size_t len) {
    if (g_have_rdrand == -1) g_have_rdrand = hal_cpu_has_rdrand();

    size_t i = 0;
    while (i < len) {
        uint32_t w;
        if (g_have_rdrand) {
            int tries = 0;
            while (!hal_rdrand32(&w) && tries < 10) tries++; /* RDRAND는 드물게 실패할 수 있음(재시도 권장) */
            if (tries >= 10) w = fallback_word(); /* 극히 드문 연속 실패 시에만 폴백 */
        } else {
            w = fallback_word();
        }
        for (int b = 0; b < 4 && i < len; b++, i++) {
            out[i] = (uint8_t)(w >> (b * 8));
        }
    }
}
