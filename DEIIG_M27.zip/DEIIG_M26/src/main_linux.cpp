#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <sstream>
#include <deque>
#include <optional>
#include <unistd.h>
#include "workflow.hpp"
#include "plugin_manager.hpp"
#include "workspace.hpp"
#include "app_state.hpp"
#include "remote.hpp"
#include "container.hpp"
#include "database.hpp"
#include "universal_fs.hpp"
#include "browser.hpp"
#include "ai.hpp"
#include "devserver.hpp"
#include "debugger.hpp"
#include "langintel.hpp"
#include "security.hpp"
#include "registry.hpp"
#include "projectgen.hpp"
#include "network.hpp"
#include "performance.hpp"

namespace fs = std::filesystem;

static void print_tree(const fs::path& root, int depth = 0) {
    if (depth > 2) return;
    std::vector<fs::directory_entry> items;
    std::error_code ec;
    for (fs::directory_iterator it(root, fs::directory_options::skip_permission_denied, ec), end; it != end && !ec; it.increment(ec)) {
        const auto& e = *it;
        auto name = e.path().filename().string();
        if (name == ".git" || name == "build" || name == ".vs" || name == ".idea") {
            if (e.is_directory(ec)) continue;
        }
        items.push_back(e);
    }
    std::sort(items.begin(), items.end(), [](const auto& a, const auto& b) {
        if (a.is_directory() != b.is_directory()) return a.is_directory() > b.is_directory();
        return a.path().filename().string() < b.path().filename().string();
    });
    for (const auto& e : items) {
        std::cout << std::string(depth * 2, ' ')
                  << (e.is_directory() ? "[DIR] " : "      ")
                  << e.path().filename().string() << '\n';
        if (e.is_directory()) print_tree(e.path(), depth + 1);
    }
}

static std::vector<fs::path> find_files(const fs::path& root, const std::string& needle) {
    std::vector<fs::path> hits;
    std::error_code ec;
    fs::recursive_directory_iterator it(root, fs::directory_options::skip_permission_denied), end;
    for (; it != end && !ec; it.increment(ec)) {
        const auto& e = *it;
        const auto name = e.path().filename().string();
        if (e.is_directory(ec) && (name == ".git" || name == "build" || name == ".vs" || name == ".idea")) {
            it.disable_recursion_pending();
            continue;
        }
        if (e.is_regular_file(ec) && e.path().filename().string().find(needle) != std::string::npos)
            hits.push_back(e.path());
        if (hits.size() >= 100) break;
    }
    return hits;
}

static bool write_text(const fs::path& p, const std::string& text) {
    std::error_code ec;
    if (!p.parent_path().empty()) fs::create_directories(p.parent_path(), ec);
    std::ofstream f(p, std::ios::binary | std::ios::trunc);
    if (!f) return false;
    f << text;
    return f.good();
}

static int run_cmd(const std::string& cmd) {
    std::cout << "\n$ " << cmd << "\n";
    return std::system(cmd.c_str());
}

static void git_menu(const std::string& line) {
    if (line == "git status") { run_cmd("git status --short --branch"); return; }
    if (line == "git diff") { run_cmd("git diff --stat"); run_cmd("git diff"); return; }
    if (line.rfind("git commit ", 0) == 0) {
        std::string msg=line.substr(11);
        std::string cmd="git add -A && git commit -m \""+msg+"\"";
        run_cmd(cmd); return;
    }
    if (line == "git branches") { run_cmd("git branch --all"); return; }
    std::cout << "Git commands: git status | git diff | git commit <message> | git branches\n";
}

static void package_command(const std::string& line) {
    if (line.rfind("pkg ",0) != 0) return;
    std::istringstream iss(line.substr(4));
    std::string mgr; iss >> mgr;
    if (mgr == "vcpkg") run_cmd("vcpkg list");
    else if (mgr == "conan") run_cmd("conan list");
    else if (mgr == "pip") run_cmd("python3 -m pip list");
    else if (mgr == "cargo") run_cmd("cargo install --list");
    else if (mgr == "nuget") run_cmd("dotnet list package");
    else std::cout << "Supported managers: vcpkg, conan, pip, cargo, nuget\n";
}

static int run_workflow(const fs::path& projectDir, const std::string& name) {
    const auto workflows = deiig::load_workflows(projectDir);
    if (workflows.empty()) { std::cerr << "No DEIIG.workflow found\n"; return 2; }
    const auto* wf = deiig::find_workflow(workflows, name);
    if (!wf) { std::cerr << "Workflow not found: " << name << '\n'; return 2; }
    for (const auto& [k, v] : wf->env) setenv(k.c_str(), v.c_str(), 1);
    int last = 0;
    for (const auto& step : wf->steps) {
        if (step.kind == deiig::WorkflowStep::Kind::IfExists && !fs::exists(projectDir / step.value)) {
            std::cout << "[WORKFLOW] skip (missing): " << step.value << '\n';
            continue;
        }
        std::cout << "[WORKFLOW] " << (step.kind == deiig::WorkflowStep::Kind::IfExists ? step.command : step.command) << '\n';
        last = run_cmd(step.kind == deiig::WorkflowStep::Kind::IfExists ? step.command : step.command);
        if (last != 0 && wf->stopOnError) return last;
    }
    return last;
}

static void workflow_command(const std::string& line) {
    if (line == "workflow list") {
        const auto ws = deiig::load_workflows(fs::current_path());
        for (const auto& w : ws) std::cout << w.name << (w.description.empty() ? "" : " — " + w.description) << '\n';
        if (ws.empty()) std::cout << "No DEIIG.workflow found\n";
        return;
    }
    if (line.rfind("workflow run ", 0) == 0) {
        std::string name = line.substr(13);
        int rc = run_workflow(fs::current_path(), name);
        std::cout << "workflow exit code: " << rc << '\n';
        return;
    }
    std::cout << "Workflow commands: workflow list | workflow run <name>\n";
}


static void remote_usage() {
    std::cout << "Remote commands:\n"
                 "  remote list\n"
                 "  remote add <name> <user> <host> [port] [remote_root] [key_file]\n"
                 "  remote exec <name> <command>\n"
                 "  remote pull <name> <remote_path> <local_path>\n"
                 "  remote push <name> <local_path> <remote_path>\n";
}

static void remote_command(const std::string& line, const fs::path& project) {
    auto profiles = deiig::remote::load_profiles(project);
    if (line == "remote list") {
        if (profiles.empty()) { std::cout << "No remote profiles.\n"; return; }
        for (const auto& p : profiles) {
            std::cout << p.name << " => " << p.user << "@" << p.host << ":" << p.port;
            if (!p.remote_root.empty()) std::cout << " [" << p.remote_root << "]";
            if (!p.key_file.empty()) std::cout << " key=" << p.key_file;
            std::cout << '\n';
        }
        return;
    }
    std::istringstream iss(line); std::string root, op; iss >> root >> op;
    if (op == "help" || op.empty()) { remote_usage(); return; }
    if (op == "add") {
        deiig::remote::Profile p; iss >> p.name >> p.user >> p.host;
        if (p.name.empty() || p.user.empty() || p.host.empty()) { remote_usage(); return; }
        std::string port, rr, key; iss >> port >> rr >> key;
        if (!port.empty()) { try { p.port = std::stoi(port); } catch (...) { p.port = 22; } }
        p.remote_root = rr; p.key_file = key;
        std::cout << (deiig::remote::save_profile(project, p) ? "remote profile saved\n" : "failed to save remote profile\n");
        return;
    }
    std::string name; iss >> name; const auto* p = deiig::remote::find_profile(profiles, name);
    if (!p) { std::cerr << "Remote profile not found: " << name << '\n'; return; }
    if (op == "exec") { std::string cmd; std::getline(iss >> std::ws, cmd); if (cmd.empty()) { remote_usage(); return; } int rc = deiig::remote::exec(project, *p, cmd); std::cout << "remote exit code: " << rc << '\n'; return; }
    if (op == "pull") { std::string remote, local; iss >> remote >> local; if (remote.empty() || local.empty()) { remote_usage(); return; } int rc = deiig::remote::pull(project, *p, remote, local); std::cout << "remote pull exit code: " << rc << '\n'; return; }
    if (op == "push") { std::string local, remote; iss >> local >> remote; if (local.empty() || remote.empty()) { remote_usage(); return; } int rc = deiig::remote::push(project, *p, local, remote); std::cout << "remote push exit code: " << rc << '\n'; return; }
    remote_usage();
}


static void container_usage() {
    std::cout << "Container commands:\n"
                 "  container doctor\n"
                 "  container init <image> [workdir]\n"
                 "  container build <tag> [context] [Containerfile]\n"
                 "  container run <image> [command ...]\n"
                 "  container exec <name> <command ...>\n"
                 "  container stop <name>\n"
                 "  container rm <name>\n"
                 "  container logs <name> [--follow]\n"
                 "  container ps [--all]\n"
                 "  container images\n"
                 "  container pull <image>\n";
}

static void container_command(const std::string& line, const fs::path& project) {
    std::istringstream iss(line);
    std::string root, op; iss >> root >> op;
    if (op.empty() || op == "help") { container_usage(); return; }
    if (op == "doctor") {
        const auto s = deiig::container::detect();
        std::cout << "runtime: " << deiig::container::runtime_name(s.runtime) << "\n"
                  << "available: " << (s.available ? "yes" : "no") << "\n"
                  << "version: " << s.version << "\n";
        return;
    }
    if (op == "init") {
        std::string image; iss >> image;
        std::string workdir; iss >> workdir;
        if (image.empty()) { container_usage(); return; }
        const int rc = deiig::container::init_project(project, image, workdir.empty() ? "/workspace" : workdir);
        std::cout << "container init exit code: " << rc << "\n";
        return;
    }
    if (op == "build") {
        std::string tag, context=".", file="Containerfile"; iss >> tag >> context >> file;
        if (tag.empty()) { container_usage(); return; }
        const int rc = deiig::container::build(project, tag, context, file);
        std::cout << "container build exit code: " << rc << "\n";
        return;
    }
    if (op == "run") {
        std::string image; iss >> image;
        if (image.empty()) { container_usage(); return; }
        std::vector<std::string> args; std::string x; while (iss >> x) args.push_back(x);
        const int rc = deiig::container::run(project, image, args);
        std::cout << "container run exit code: " << rc << "\n";
        return;
    }
    if (op == "exec") {
        std::string name; iss >> name; if (name.empty()) { container_usage(); return; }
        std::vector<std::string> args; std::string x; while (iss >> x) args.push_back(x);
        if (args.empty()) { container_usage(); return; }
        const int rc = deiig::container::exec(project, name, args);
        std::cout << "container exec exit code: " << rc << "\n";
        return;
    }
    if (op == "stop" || op == "rm") {
        std::string name; iss >> name; if (name.empty()) { container_usage(); return; }
        const int rc = (op == "stop") ? deiig::container::stop(project, name) : deiig::container::remove(project, name);
        std::cout << "container " << op << " exit code: " << rc << "\n";
        return;
    }
    if (op == "logs") {
        std::string name; iss >> name; std::string follow; iss >> follow;
        if (name.empty()) { container_usage(); return; }
        const int rc = deiig::container::logs(project, name, follow == "--follow");
        std::cout << "container logs exit code: " << rc << "\n";
        return;
    }
    if (op == "ps") { std::string all; iss >> all; const int rc = deiig::container::ps(project, all == "--all"); std::cout << "container ps exit code: " << rc << "\n"; return; }
    if (op == "images") { const int rc = deiig::container::images(project); std::cout << "container images exit code: " << rc << "\n"; return; }
    if (op == "pull") { std::string image; iss >> image; if (image.empty()) { container_usage(); return; } const int rc = deiig::container::pull(project, image); std::cout << "container pull exit code: " << rc << "\n"; return; }
    container_usage();
}


static void database_usage() {
    std::cout << "Database commands:\n"
                 "  db create <file> <table> <column...>\n"
                 "  db list <file>\n"
                 "  db select <file> <table> [where <column> <value>]\n"
                 "  db insert <file> <table> <value...>\n"
                 "  db update <file> <table> <row> <column> <value>\n"
                 "  db delete <file> <table> <row>\n"
                 "  db drop <file> <table>\n";
}

static bool load_database(const fs::path& path, deiig::database::Database& db) {
    std::string error;
    if (!deiig::database::load(path, db, error)) {
        std::cerr << "database error: " << error << '\n';
        return false;
    }
    return true;
}

static void database_command(const std::string& line, const fs::path& project) {
    std::istringstream iss(line);
    std::string root, op; iss >> root >> op;
    if (op.empty() || op == "help") { database_usage(); return; }
    std::string file_name; iss >> file_name;
    if (file_name.empty()) { database_usage(); return; }
    fs::path file = project / file_name;

    deiig::database::Database db;
    if (op == "create") {
        std::string table; iss >> table;
        std::vector<std::string> columns; std::string col;
        while (iss >> col) columns.push_back(col);
        std::string error;
        if (!deiig::database::load(file, db, error)) { std::cerr << "database error: " << error << '\n'; return; }
        if (!deiig::database::create_table(db, table, columns, error)) { std::cerr << "create error: " << error << '\n'; return; }
        if (!deiig::database::save(file, db, error)) { std::cerr << "save error: " << error << '\n'; return; }
        std::cout << "created table: " << table << " in " << file << '\n';
        return;
    }

    if (!load_database(file, db)) return;
    std::string error;
    if (op == "list") {
        for (const auto& t : db.tables) std::cout << t.name << " (" << t.columns.size() << " columns, " << t.rows.size() << " rows)\n";
        return;
    }
    if (op == "select") {
        std::string table; iss >> table;
        const auto* t = deiig::database::find_table(db, table);
        if (!t) { std::cerr << "table not found\n"; return; }
        std::string where, column, value; iss >> where;
        if (!where.empty()) { if (where != "where") { database_usage(); return; } iss >> column >> value; }
        auto rows = deiig::database::select_rows(db, table, column, value);
        deiig::database::Table view = *t;
        view.rows = std::move(rows);
        std::cout << deiig::database::format_table(view);
        return;
    }
    if (op == "insert") {
        std::string table; iss >> table;
        std::vector<std::string> values; std::string value;
        while (iss >> value) values.push_back(value);
        if (!deiig::database::insert_row(db, table, values, error)) { std::cerr << "insert error: " << error << '\n'; return; }
        if (!deiig::database::save(file, db, error)) { std::cerr << "save error: " << error << '\n'; return; }
        std::cout << "row inserted\n";
        return;
    }
    if (op == "update") {
        std::string table, row_text, column, value; iss >> table >> row_text >> column >> value;
        std::size_t row = 0;
        try { row = static_cast<std::size_t>(std::stoull(row_text)); } catch (...) { std::cerr << "invalid row index\n"; return; }
        if (!deiig::database::update_cell(db, table, row, column, value, error)) { std::cerr << "update error: " << error << '\n'; return; }
        if (!deiig::database::save(file, db, error)) { std::cerr << "save error: " << error << '\n'; return; }
        std::cout << "row updated\n";
        return;
    }
    if (op == "delete") {
        std::string table, row_text; iss >> table >> row_text;
        std::size_t row = 0;
        try { row = static_cast<std::size_t>(std::stoull(row_text)); } catch (...) { std::cerr << "invalid row index\n"; return; }
        if (!deiig::database::delete_row(db, table, row, error)) { std::cerr << "delete error: " << error << '\n'; return; }
        if (!deiig::database::save(file, db, error)) { std::cerr << "save error: " << error << '\n'; return; }
        std::cout << "row deleted\n";
        return;
    }
    if (op == "drop") {
        std::string table; iss >> table;
        if (!deiig::database::drop_table(db, table, error)) { std::cerr << "drop error: " << error << '\n'; return; }
        if (!deiig::database::save(file, db, error)) { std::cerr << "save error: " << error << '\n'; return; }
        std::cout << "dropped table: " << table << '\n';
        return;
    }
    database_usage();
}


static void ufs_usage() {
    std::cout << "Universal FS commands:\n"
                 "  fs inspect <path>\n"
                 "  fs preview <path> [bytes]\n"
                 "  fs hex <path> [bytes]\n"
                 "  fs related <path>\n";
}

static void ufs_command(const std::string& line) {
    std::istringstream iss(line);
    std::string root, op, arg; iss >> root >> op >> arg;
    if (op.empty() || op == "help") { ufs_usage(); return; }
    if (arg.empty()) { ufs_usage(); return; }
    fs::path path = arg;
    if (op == "inspect") {
        const auto info = deiig::ufs::inspect(path);
        std::cout << "path: " << info.path << '\n'
                  << "name: " << info.name << '\n'
                  << "extension: " << info.extension << '\n'
                  << "kind: " << deiig::ufs::kind_name(info.kind) << '\n'
                  << "mime: " << info.mime << '\n'
                  << "size: " << info.size << " bytes\n"
                  << "regular: " << (info.regular ? "yes" : "no") << '\n'
                  << "directory: " << (info.directory ? "yes" : "no") << '\n'
                  << "text-preview: " << (info.readable_text ? "yes" : "no") << '\n';
        return;
    }
    std::string bytes_text; iss >> bytes_text;
    std::size_t bytes = 8192;
    if (!bytes_text.empty()) {
        try { bytes = static_cast<std::size_t>(std::stoull(bytes_text)); }
        catch (...) { std::cerr << "invalid byte count\n"; return; }
        bytes = std::min<std::size_t>(bytes, 1024 * 1024);
    }
    if (op == "preview") {
        const auto info = deiig::ufs::inspect(path);
        if (!info.readable_text) { std::cout << "Not a text-like file. Use: fs hex <path>\n"; return; }
        std::cout << deiig::ufs::preview_text(path, bytes);
        return;
    }
    if (op == "hex") { std::cout << deiig::ufs::hex_dump(path, bytes); return; }
    if (op == "related") {
        const auto related = deiig::ufs::related_files(path);
        for (const auto& p : related) std::cout << p.string() << '\n';
        std::cout << related.size() << " related file(s)\n";
        return;
    }
    ufs_usage();
}

static void plugin_log(const std::string& msg) { std::cout << "[PLUGIN] " << msg << '\n'; }

static deiig::PluginManager g_plugins;

static void plugin_command(const std::string& line) {
    if (line == "plugin list") {
        g_plugins.discover();
        for (const auto& p : g_plugins.list()) std::cout << (p.loaded ? "[loaded] " : "[available] ") << p.name << " -> " << p.path << '\n';
        return;
    }
    if (line == "plugin load") {
        const bool ok = g_plugins.load_all();
        std::cout << "plugins load: " << (ok ? "ok" : "some failed") << '\n';
        return;
    }
    if (line == "plugin commands") {
        for (const auto& c : g_plugins.commands()) std::cout << c << '\n';
        return;
    }
    std::cout << "Plugin commands: plugin list | plugin load | plugin commands\n";
}

static void save_current_workspace(const fs::path& project, const std::deque<std::string>& history) {
    if (project.empty()) return;
    deiig::WorkspaceState state;
    state.project_dir = project;
    state.terminal_history.assign(history.begin(), history.end());
    state.layout_mode = 0;
    if (deiig::save_workspace(state)) std::cout << "workspace saved: " << deiig::workspace_file(project) << '\n';
}

static void workspace_command(const std::string& line, const fs::path& project, const std::deque<std::string>& history) {
    if (line == "workspace save") { save_current_workspace(project, history); return; }
    if (line == "workspace load") {
        deiig::WorkspaceState state;
        if (!deiig::load_workspace(project, state)) { std::cout << "No workspace state found.\n"; return; }
        std::cout << "Workspace\n  project: " << state.project_dir << "\n  current: " << state.current_file
                  << "\n  split: " << (state.split_view ? "true" : "false")
                  << "\n  history: " << state.terminal_history.size()
                  << "\n  browser tabs: " << state.browser_urls.size()
                  << "\n  exe tabs: " << state.exe_paths.size() << '\n';
        return;
    }
    if (line == "workspace path") { std::cout << deiig::workspace_file(project) << '\n'; return; }
    std::cout << "Workspace commands: workspace save | workspace load | workspace path\n";
}


static void browser_command(const std::string& line) {
    if (line.rfind("browser open ",0)==0) { std::cout << "browser exit code: " << deiig::browser::open(line.substr(13)) << '\n'; return; }
    if (line.rfind("browser search ",0)==0) { std::istringstream i(line.substr(15)); std::string e; i>>e; std::string q; std::getline(i>>std::ws,q); std::cout << "search exit code: " << deiig::browser::search(e,q) << '\n'; return; }
    std::cout << "Browser: browser open <url> | browser search <google|bing> <query>\n";
}
static void ai_command(const std::string& line) {
    if (line == "ai config") { auto c=deiig::ai::load_config(); std::cout<<"url="<<c.url<<"\nmodel="<<c.model<<"\nkey="<<(c.key.empty()?"not set":"set")<<'\n'; return; }
    if (line.rfind("ai ask ",0)==0) { auto c=deiig::ai::load_config(); std::string r; int rc=deiig::ai::ask(c,line.substr(7),r); std::cout<<r<<'\n'; std::cout<<"ai exit code: "<<rc<<'\n'; return; }
    std::cout << "AI: set DEIIG_AI_URL/DEIIG_AI_KEY/DEIIG_AI_MODEL, then ai ask <prompt>\n";
}
static void devserver_command(const std::string& line) {
    if(line=="devserver status"){std::cout<<(deiig::devserver::status()==0?"running":"stopped")<<'\n';return;}
    if(line=="devserver stop"){std::cout<<"exit code: "<<deiig::devserver::stop()<<'\n';return;}
    if(line.rfind("devserver start ",0)==0){std::istringstream i(line.substr(16));int port=0;i>>port;std::string cmd;std::getline(i>>std::ws,cmd);if(!port||cmd.empty()){std::cout<<"devserver start <port> <command>\n";return;}std::cout<<"exit code: "<<deiig::devserver::start(cmd,port)<<'\n';return;}
    std::cout<<"Dev server: devserver start <port> <command> | status | stop\n";
}
static void debugger_command(const std::string& line){
    if(line.rfind("debug run ",0)==0){std::cout<<"debugger exit code: "<<deiig::debugger::run(line.substr(10))<<'\n';return;}
    if(line.rfind("debug attach ",0)==0){try{int p=std::stoi(line.substr(13));std::cout<<"debugger exit code: "<<deiig::debugger::attach(p)<<'\n';}catch(...){std::cout<<"invalid pid\n";}return;}
    if(line.rfind("debug cmd ",0)==0){std::cout<<"debugger exit code: "<<deiig::debugger::command(line.substr(10))<<'\n';return;}
    std::cout<<"Debugger: debug run <exe> | debug attach <pid> | debug cmd <gdb-command>\n";
}
static void lang_command(const std::string& line){
    if(line=="lang outline"){deiig::langintel::print_outline(fs::current_path().string());return;}
    if(line.rfind("lang refs ",0)==0){deiig::langintel::find_refs(fs::current_path().string(),line.substr(10));return;}
    std::cout<<"Language: lang outline | lang refs <symbol>\n";
}
static void security_command(const std::string& line){
    if(line=="security mode"){std::cout<<deiig::security::mode()<<'\n';return;}
    if(line.rfind("security set ",0)==0){std::cout<<"exit code: "<<deiig::security::set_mode(line.substr(13))<<'\n';return;}
    std::cout<<"Security: security mode | security set <confirm|allow|deny>\n";
}
static void registry_command(const std::string& line){
    if(line=="registry init"){std::cout<<"exit code: "<<deiig::registry::init()<<'\n';return;}
    if(line.rfind("registry search ",0)==0){std::cout<<"exit code: "<<deiig::registry::search(line.substr(16))<<'\n';return;}
    if(line.rfind("registry install ",0)==0){std::cout<<"exit code: "<<deiig::registry::install(line.substr(17))<<'\n';return;}
    std::cout<<"Registry: registry init | registry search <query> | registry install <name>\n";
}

static void network_command(const std::string& line) {
    if (line == "network help" || line == "network") {
        std::cout << "Network commands:\n"
                     "  network resolve <host>\n"
                     "  network tcp <host> <port> [timeout_ms]\n"
                     "  network http <http://url> [max_bytes]\n"
                     "  network ping <host> [count]\n";
        return;
    }
    std::istringstream iss(line);
    std::string root, op, host;
    iss >> root >> op;
    if (op == "resolve") {
        iss >> host;
        if (host.empty()) { std::cout << "network resolve <host>\n"; return; }
        const auto r = deiig::network::resolve(host);
        if (!r.error.empty()) std::cout << "error: " << r.error << '\n';
        for (const auto& a : r.addresses) std::cout << a << '\n';
        return;
    }
    if (op == "tcp") {
        int port = 0, timeout = 3000;
        iss >> host >> port >> timeout;
        if (host.empty() || port <= 0) { std::cout << "network tcp <host> <port> [timeout_ms]\n"; return; }
        const auto r = deiig::network::tcp_test(host, port, timeout);
        std::cout << host << ':' << port << " -> " << (r.connected ? "open" : "closed/unreachable") << '\n';
        if (r.elapsed_ms >= 0) std::cout << "time: " << r.elapsed_ms << " ms\n";
        if (!r.error.empty()) std::cout << "error: " << r.error << '\n';
        return;
    }
    if (op == "http") {
        std::string url; iss >> url;
        std::size_t max_bytes = 1024 * 1024;
        std::string n; iss >> n;
        if (!n.empty()) { try { max_bytes = std::min<std::size_t>(std::stoull(n), 8 * 1024 * 1024); } catch (...) {} }
        if (url.empty()) { std::cout << "network http <http://url> [max_bytes]\n"; return; }
        const auto r = deiig::network::http_get(url, max_bytes);
        if (!r.error.empty()) { std::cout << "error: " << r.error << '\n'; return; }
        std::cout << "HTTP " << r.status << "\n\n" << r.headers << "\n\n" << r.body << '\n';
        return;
    }
    if (op == "ping") {
        int count = 1; iss >> host >> count;
        if (host.empty()) { std::cout << "network ping <host> [count]\n"; return; }
        std::cout << "ping exit code: " << deiig::network::ping(host, count) << '\n';
        return;
    }
    std::cout << "Network commands: network resolve|tcp|http|ping ...\n";
}

static void performance_command(const std::string& line) {
    if (line == "performance" || line == "performance status") { deiig::performance::print(); return; }
    std::cout << "Performance: performance status\n";
}

static void project_command(const std::string& line){
    if(line.rfind("project new ",0)==0){std::istringstream i(line.substr(12));std::string t,d;i>>t>>d;if(t.empty()||d.empty()){std::cout<<"project new <cpp|digg|web|empty> <dir>\n";return;}std::cout<<"exit code: "<<deiig::projectgen::create(t,d)<<'\n';return;}
    std::cout<<"Project: project new <cpp|digg|web|empty> <dir>\n";
}

static void usage() {
    std::cout << "DEIIG M27 — The Development Environment Is Insanely Good\n"
                 "Linux compatibility shell. Windows GUI integrations are enabled only in the Windows build.\n\n"
                 "Commands:\n"
                 "  tree [path]        Show project tree\n"
                 "  build              Configure/build with CMake\n"
                 "  run <command>      Run a local command\n"
                 "  open <file>        Print a text file\n"
                 "  new <file>         Create a new text file\n"
                 "  find <name>        Find files by filename\n"
                 "  git ...             Git operations\n"
                 "  pkg ...             Package-manager queries\n"
                 "  workflow ...        Run DEIIG workflows\n"
                 "  plugin ...          Manage DEIIG plugins\n"
                 "  workspace ...       Manage session state\n"
                 "  remote ...          SSH remote development\n"
                 "  container ...       Docker/Podman container development\n"
                 "  db ...              Embedded DEIIG database tools\n"
                 "  network ...         DNS/TCP/HTTP/ping tools\n"
                 "  fs ...              Universal file inspection/preview/hex tools\n"
                 "  browser ...          Open/search with web browser\n"
                 "  ai ...               AI assistant via configured API\n"
                 "  devserver ...        Development server process manager\n"
                 "  debug ...            Debugger frontend\n"
                 "  lang ...              Language intelligence\n"
                 "  security ...         Security mode\n"
                 "  registry ...         Package registry\n"
                 "  project new ...      Project generator\n"

                 "  doctor              Run DEIIG diagnostics\n"
                 "  log path            Show DEIIG log path\n"
                 "  info                Show DEIIG/project state\n"
                 "  pwd                 Show current directory\n"
                 "  help                Show this help\n"
                 "  exit                Quit\n";
}

int main(int argc, char** argv) {
    const bool safe_mode = (argc > 1 && std::string(argv[1]) == "--safe-mode");
    if (argc > 1 && std::string(argv[1]) == "--version") {
        std::cout << "DEIIG 1.0-M26 (Linux build)\n";
        return 0;
    }

    deiig::mark_startup(safe_mode);
    deiig::app_log(std::string("PROJECT=") + fs::current_path().string());
    g_plugins.set_project_dir(fs::current_path());
    g_plugins.set_log(&plugin_log);
    if (!safe_mode) g_plugins.load_all();

    std::cout << "DEIIG M27 — The Development Environment Is Insanely Good\n";
    std::cout << "Linux compatibility shell. Windows GUI features are enabled only in the Windows build.\n";
    usage();

    std::deque<std::string> history;
    std::string line;
    while (true) {
        std::cout << "\ndeiig> " << std::flush;
        if (!std::getline(std::cin, line)) break;
        if (line.empty()) continue;
        if (history.empty() || history.back() != line) history.push_back(line);
        if (history.size() > 50) history.pop_front();
        if (line == "exit" || line == "quit") { save_current_workspace(fs::current_path(), history); deiig::mark_clean_exit(); break; }
        if (line == "help") { usage(); continue; }
        if (line == "pwd") { std::cout << fs::current_path().string() << '\n'; continue; }
        if (line == "doctor") {
            for (const auto& d : deiig::run_diagnostics(fs::current_path()))
                std::cout << (d.ok ? "[ OK ] " : "[FAIL] ") << d.name << ": " << d.detail << '\n';
            continue;
        }
        if (line == "log path") { std::cout << deiig::app_state_paths().log.string() << '\n'; continue; }
        if (line == "info") {
            std::cout << "DEIIG M27 / Integrated Development Environment\nplatform: Linux compatibility\nproject: " << fs::current_path() << '\n'
                      << "history: " << history.size() << " commands\n";
            continue;
        }
        if (line.rfind("remote", 0) == 0) { remote_command(line, fs::current_path()); continue; }
        if (line.rfind("container", 0) == 0) { container_command(line, fs::current_path()); continue; }
        if (line.rfind("db", 0) == 0) { database_command(line, fs::current_path()); continue; }
        if (line.rfind("fs", 0) == 0) { ufs_command(line); continue; }
        if (line.rfind("browser", 0) == 0) { browser_command(line); continue; }
        if (line.rfind("ai", 0) == 0) { ai_command(line); continue; }
        if (line.rfind("devserver", 0) == 0) { devserver_command(line); continue; }
        if (line.rfind("debug", 0) == 0) { debugger_command(line); continue; }
        if (line.rfind("lang", 0) == 0) { lang_command(line); continue; }
        if (line.rfind("security", 0) == 0) { security_command(line); continue; }
        if (line.rfind("registry", 0) == 0) { registry_command(line); continue; }
        if (line.rfind("project new", 0) == 0) { project_command(line); continue; }
        if (line.rfind("network", 0) == 0) { network_command(line); continue; }
        if (line.rfind("performance", 0) == 0) { performance_command(line); continue; }

        if (line == "tree") { print_tree(fs::current_path()); continue; }
        if (line.rfind("tree ", 0) == 0) { print_tree(fs::path(line.substr(5))); continue; }
        if (line == "build") {
            int rc = std::system("cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build --parallel");
            std::cout << "build exit code: " << rc << '\n';
            continue;
        }
        if (line.rfind("open ", 0) == 0) {
            fs::path p = line.substr(5);
            std::ifstream f(p);
            if (!f) { std::cerr << "cannot open: " << p << '\n'; continue; }
            std::cout << f.rdbuf() << '\n';
            continue;
        }
        if (line.rfind("new ", 0) == 0) {
            fs::path p = line.substr(4);
            if (fs::exists(p)) { std::cerr << "already exists: " << p << '\n'; continue; }
            if (!write_text(p, "// Created by DEIIG 0.9\n")) { std::cerr << "cannot create: " << p << '\n'; continue; }
            std::cout << "created: " << p << '\n';
            continue;
        }
        if (line.rfind("find ", 0) == 0) {
            auto hits = find_files(fs::current_path(), line.substr(5));
            for (const auto& p : hits) std::cout << p.string() << '\n';
            std::cout << hits.size() << " result(s)\n";
            continue;
        }
        if (line.rfind("run ", 0) == 0) {
            int rc = std::system(line.substr(4).c_str());
            std::cout << "exit code: " << rc << '\n';
            continue;
        }
        if (line.rfind("plugin", 0) == 0) { plugin_command(line); continue; }
        if (line == "git status" || line == "git diff" || line == "git branches" || line.rfind("git commit ", 0) == 0) { git_menu(line); continue; }
        if (line.rfind("pkg ", 0) == 0) { package_command(line); continue; }
        if (line.rfind("workspace", 0) == 0) { workspace_command(line, fs::current_path(), history); continue; }
        if (line == "workflow list" || line.rfind("workflow run ", 0) == 0) { workflow_command(line); continue; }
        if (g_plugins.has_command(line.substr(0, line.find(' ')))) { int rc = g_plugins.invoke(line); std::cout << "plugin exit code: " << rc << "\n"; continue; }
        if (line.rfind("digg ", 0) == 0) {
            std::string command = "./build/DIGGRuntime \"" + line.substr(5) + "\"";
            int rc = std::system(command.c_str());
            std::cout << "DIGG exit code: " << rc << '\n';
            continue;
        }
        std::cout << "Unknown command. Type 'help'.\n";
    }
    return 0;
}
