#include "app_state.hpp"
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <vector>

#ifdef _WIN32
#include <windows.h>
#endif

namespace fs = std::filesystem;
namespace deiig {

static fs::path choose_root() {
#ifdef _WIN32
    if (const char* app = std::getenv("APPDATA")) return fs::path(app) / "DEIIG";
    return fs::current_path() / ".deiig-user";
#else
    if (const char* xdg = std::getenv("XDG_CONFIG_HOME")) return fs::path(xdg) / "DEIIG";
    if (const char* home = std::getenv("HOME")) return fs::path(home) / ".config" / "DEIIG";
    return fs::current_path() / ".deiig-user";
#endif
}

AppStatePaths app_state_paths() {
    const fs::path root = choose_root();
    return {root, root / "settings.conf", root / "deiig.log", root / "previous_run.marker"};
}

void app_log(const std::string& message) {
    const auto paths = app_state_paths();
    std::error_code ec;
    fs::create_directories(paths.root, ec);
    std::ofstream f(paths.log, std::ios::app);
    if (!f) return;
    f << message << '\n';
}

void mark_startup(bool safe_mode) {
    const auto paths = app_state_paths();
    std::error_code ec;
    fs::create_directories(paths.root, ec);
    {
        std::ofstream f(paths.crash_marker, std::ios::trunc);
        if (f) f << (safe_mode ? "safe=1\n" : "safe=0\n");
    }
    app_log(std::string("STARTUP safe_mode=") + (safe_mode ? "1" : "0"));
}

void mark_clean_exit() {
    const auto paths = app_state_paths();
    std::error_code ec;
    fs::remove(paths.crash_marker, ec);
    app_log("CLEAN_EXIT");
}

bool previous_run_was_unclean() {
    std::error_code ec;
    return fs::is_regular_file(app_state_paths().crash_marker, ec);
}

static DiagnosticResult command_check(const std::string& name, const std::string& command) {
    const int rc = std::system(command.c_str());
    std::ostringstream detail;
    detail << "exit=" << rc;
    return {name, rc == 0, detail.str()};
}

std::vector<DiagnosticResult> run_diagnostics(const fs::path& project_dir) {
    std::vector<DiagnosticResult> out;
    std::error_code ec;
    out.push_back({"Project directory", fs::is_directory(project_dir, ec), project_dir.string()});
    out.push_back({"CMakeLists.txt", fs::is_regular_file(project_dir / "CMakeLists.txt", ec), (project_dir / "CMakeLists.txt").string()});
    out.push_back({"Workspace directory", fs::is_directory(project_dir / ".deiig", ec) || fs::create_directories(project_dir / ".deiig", ec), (project_dir / ".deiig").string()});
    out.push_back(command_check("cmake", "cmake --version > /dev/null 2>&1"));
#ifdef _WIN32
    out.push_back({"Windows platform", true, "Win32"});
#else
    out.push_back({"POSIX platform", true, "Linux/Unix compatibility shell"});
#endif
    return out;
}

} // namespace deiig
