/* JetOS - kernel/gfx/direxj.c - direxj.h 참고. */
#include "direxj.h"
#include "../drivers/virtio_gpu.h" /* Milestone 31 */

uint32_t dj_isqrt(uint64_t n) {
    if (n == 0) return 0;
    uint64_t x = n, y = (x + 1) / 2;
    while (y < x) { x = y; y = (x + n / x) / 2; }
    return (uint32_t)x;
}

void dj_fill_circle_aa(console_t *con, int cx, int cy, int r, uint32_t color) {
    if (!con) return;
    for (int dy = -r - 1; dy <= r + 1; dy++) {
        int yy = cy + dy;
        if (yy < 0 || yy >= (int)con->height) continue;
        for (int dx = -r - 1; dx <= r + 1; dx++) {
            uint64_t dist2 = (uint64_t)(dx * dx + dy * dy);
            uint32_t dist256 = dj_isqrt(dist2 << 16); /* dist*256, 8.8 고정소수점 */
            int32_t edge = (int32_t)(r * 256 - (int32_t)dist256) + 128;
            if (edge <= 0) continue;
            if (edge > 256) edge = 256;
            console_blend_pixel(con, cx + dx, yy, edge, color);
        }
    }
}

static int dj_sign_tri(int px, int py, int ax, int ay, int bx, int by) {
    return (px - bx) * (ay - by) - (ax - bx) * (py - by);
}

int dj_point_in_triangle(int px, int py, int ax, int ay, int bx, int by, int cx, int cy) {
    int d1 = dj_sign_tri(px, py, ax, ay, bx, by);
    int d2 = dj_sign_tri(px, py, bx, by, cx, cy);
    int d3 = dj_sign_tri(px, py, cx, cy, ax, ay);
    int has_neg = (d1 < 0) || (d2 < 0) || (d3 < 0);
    int has_pos = (d1 > 0) || (d2 > 0) || (d3 > 0);
    return !(has_neg && has_pos);
}

void dj_fill_triangle_union_aa(console_t *con, const int tris[][6], int tri_count,
                                int bbox_min_x, int bbox_min_y, int bbox_max_x, int bbox_max_y,
                                uint32_t color) {
    if (!con) return;
    for (int py = bbox_min_y; py <= bbox_max_y; py++) {
        for (int px = bbox_min_x; px <= bbox_max_x; px++) {
            int covered = 0;
            for (int sy = 0; sy < DJ_POLY_SS; sy++) {
                int spy = py * DJ_POLY_F + (2 * sy + 1);
                for (int sx = 0; sx < DJ_POLY_SS; sx++) {
                    int spx = px * DJ_POLY_F + (2 * sx + 1);
                    for (int t = 0; t < tri_count; t++) {
                        if (dj_point_in_triangle(spx, spy,
                                                  tris[t][0], tris[t][1],
                                                  tris[t][2], tris[t][3],
                                                  tris[t][4], tris[t][5])) {
                            covered++;
                            break; /* 합집합이라 한 번 안에 걸리면 됨 */
                        }
                    }
                }
            }
            if (covered == 0) continue;
            int coverage256 = covered * 256 / (DJ_POLY_SS * DJ_POLY_SS);
            if (coverage256 > 256) coverage256 = 256;
            console_blend_pixel(con, px, py, coverage256, color);
        }
    }
}

void dj_present_diff(console_t *front, console_t *back) {
    if (!front || !back || !front->fb || !back->fb) return;
    if (front->width != back->width || front->height != back->height) return;

    /* Milestone 31: virtio_gpu_present에 넘길 "바뀐 영역" 바운딩 박스를
     * 픽셀 diff와 같은 루프에서 같이 계산한다(따로 한 번 더 훑지 않음). */
    int min_x = -1, min_y = -1, max_x = -1, max_y = -1;
    int use_gpu = virtio_gpu_available();

    for (uint32_t y = 0; y < front->height; y++) {
        uint32_t row_base = y * front->width;
        for (uint32_t x = 0; x < front->width; x++) {
            uint32_t i = row_base + x;
            if (front->fb[i] != back->fb[i]) {
                front->fb[i] = back->fb[i];
                if (use_gpu) {
                    int xi = (int)x, yi = (int)y;
                    if (min_x < 0 || xi < min_x) min_x = xi;
                    if (min_y < 0 || yi < min_y) min_y = yi;
                    if (xi > max_x) max_x = xi;
                    if (yi > max_y) max_y = yi;
                }
            }
        }
    }
    if (use_gpu && min_x >= 0) {
        virtio_gpu_present(min_x, min_y, max_x - min_x + 1, max_y - min_y + 1);
    }
}
