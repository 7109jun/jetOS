/*
 * JetOS - kernel/apps/task_manager.c
 * 현재 등록된 모든 스레드와 상태를 보여주는 작업 관리자.
 */

#include <stddef.h>
#include "task_manager.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../drivers/console.h"
#include "../proc/scheduler.h"

static const char *state_name(int state) {
    switch (state) {
        case 0: return "READY";
        case 1: return "RUNNING";
        case 2: return "BLOCKED";
        case 3: return "DEAD";
        default: return "?";
    }
}

typedef struct {
    console_t *dc;
    int x, y;
} tm_draw_ctx_t;

static void tm_entry_cb(const char *name, uint32_t id, int state, void *ctx) {
    tm_draw_ctx_t *d = (tm_draw_ctx_t *)ctx;
    d->dc->cursor_x = (uint32_t)d->x;
    d->dc->cursor_y = (uint32_t)d->y;
    console_print(d->dc, name);
    console_print(d->dc, " [");
    console_print(d->dc, state_name(state));
    console_print(d->dc, "]");
    (void)id;
    d->y += 14;
}

static void task_manager_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)h; (void)ctx;
    tm_draw_ctx_t d = { dc, x + 8, y + 8 };
    ListThreadsJ(tm_entry_cb, &d);
}

static void task_manager_thread_fn(void *arg) {
    (void)arg;
    JetWindowHandle win = CreateWindowJ("TASK MANAGER", 900, 60, 260, 220, 0x00503030);
    if (win >= 0) {
        wm_set_content_callback(win, task_manager_content_cb, NULL);
    }
    for (;;) {
        scheduler_yield();
    }
}

void task_manager_launch(void) {
    static int launched = 0;
    if (launched) return;
    launched = 1;
    CreateThreadJ("task_manager", task_manager_thread_fn, NULL);
}
