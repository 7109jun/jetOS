#ifndef JETOS_EXCEPTIONS_H
#define JETOS_EXCEPTIONS_H

#include "idt.h"

__attribute__((interrupt)) void isr_divide_by_zero(struct interrupt_frame *frame);
__attribute__((interrupt)) void isr_breakpoint(struct interrupt_frame *frame);
__attribute__((interrupt)) void isr_invalid_opcode(struct interrupt_frame *frame);
__attribute__((interrupt)) void isr_double_fault(struct interrupt_frame *frame, unsigned long long error_code);
__attribute__((interrupt)) void isr_general_protection(struct interrupt_frame *frame, unsigned long long error_code);
__attribute__((interrupt)) void isr_page_fault(struct interrupt_frame *frame, unsigned long long error_code);
__attribute__((interrupt)) void isr_default_handler(struct interrupt_frame *frame);
__attribute__((interrupt)) void isr_timer(struct interrupt_frame *frame);

#endif
