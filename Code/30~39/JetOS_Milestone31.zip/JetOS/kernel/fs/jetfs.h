#ifndef JETOS_JETFS_H
#define JETOS_JETFS_H

#include <stdint.h>

/*
 * JETFS v1 — JetOS 자체 파일시스템.
 *
 * 레이아웃 (블록 크기 4096바이트 = AHCI 섹터 8개):
 *   블록 0        : 슈퍼블록
 *   블록 1..N     : inode 테이블 (고정 크기 배열)
 *   블록 N+1..M   : 데이터 블록 비트맵
 *   블록 M+1..끝  : 데이터 블록
 *
 * 디렉터리는 "데이터 블록에 dirent 배열을 담은 특수 inode"로 표현된다.
 * (Milestone 4 범위의 단순화가 여전히 남아있음: 디렉터리 자체는 직접
 * 블록 12개까지만 사용 — 항목 약 1700개 정도까지 충분하므로 실질적
 * 제약은 아니다.)
 *
 * Milestone 8: 파일(FILE 타입)은 직접 블록 12개에 더해 단일 간접
 * 블록(indirect block) 1개를 지원한다. 간접 블록은 그 자체가 하나의
 * 데이터 블록이며, uint32_t 블록 번호 1024개(4096/4)를 담을 수 있다.
 * 이 단계에서 파일 최대 크기는 (12 + 1024) * 4096 바이트 ≈ 4.2MB.
 *
 * Milestone 22: 이중 간접 블록(double indirect) 추가. 이중 간접
 * 블록도 그 자체가 데이터 블록이며, "간접 블록 번호" 1024개를
 * 담는다 — 즉 이중 간접 블록 하나가 간접 블록 1024개(각각 데이터
 * 블록 1024개)를 가리켜, 이중 간접 경로로만 1024*1024개 블록에
 * 닿을 수 있다. 이 단계 파일 최대 크기는
 * (12 + 1024 + 1024*1024) * 4096 바이트 ≈ 4.0GB.
 *
 * Milestone 23: 삼중 간접 블록(triple indirect) 추가 — ext2/Linux의
 * 고전적인 "직접+단일+이중+삼중 간접" 아이노드 설계를 개념적으로
 * 참고했다(코드를 그대로 옮긴 게 아니라 "포인터 블록을 한 단계씩
 * 더 두면 주소 공간이 1024배씩 늘어난다"는 아이디어만 가져와 이
 * 프로젝트 스타일대로 새로 작성). 삼중 간접 블록 하나는 "이중
 * 간접 블록 번호" 1024개를 담고, 그 각각이 다시 간접 블록 1024개를,
 * 그 각각이 다시 데이터 블록 1024개를 가리킨다 — 삼중 간접 경로로만
 * 1024*1024*1024개 블록에 닿는다. 최종 파일 최대 크기는
 * (12 + 1024 + 1024*1024 + 1024*1024*1024) * 4096 바이트 ≈ 4.0TB —
 * 요청받은 "파일당 최대 20GB"를 넉넉히 만족한다. 물론 실제로 쓸 수
 * 있는 크기는 디스크 자체 용량(mkjetfs로 만드는 이미지 크기)이 더
 * 작으면 그만큼으로 제한된다 — 20GB 파일을 실제로 담으려면 디스크
 * 이미지 자체를 20GB 이상으로 만들어야 한다(빌드 방법 문서 참고).
 */

#define JETFS_MAGIC 0x4A455446u /* "JETF" */
#define JETFS_BLOCK_SIZE 4096
#define JETFS_SECTORS_PER_BLOCK (JETFS_BLOCK_SIZE / 512)
#define JETFS_MAX_INODES 256
#define JETFS_MAX_NAME 28
#define JETFS_DIRECT_BLOCKS 12
#define JETFS_INDIRECT_PTRS (JETFS_BLOCK_SIZE / sizeof(uint32_t)) /* 1024 */
#define JETFS_DOUBLE_INDIRECT_PTRS (JETFS_BLOCK_SIZE / sizeof(uint32_t)) /* 1024개의 "간접 블록 번호" */
#define JETFS_TRIPLE_INDIRECT_PTRS (JETFS_BLOCK_SIZE / sizeof(uint32_t)) /* 1024개의 "이중간접 블록 번호" */
#define JETFS_MAX_FILE_BLOCKS (JETFS_DIRECT_BLOCKS + JETFS_INDIRECT_PTRS + \
                               (JETFS_DOUBLE_INDIRECT_PTRS * JETFS_INDIRECT_PTRS) + \
                               ((uint64_t)JETFS_TRIPLE_INDIRECT_PTRS * JETFS_DOUBLE_INDIRECT_PTRS * JETFS_INDIRECT_PTRS))
#define JETFS_ROOT_INODE 0

typedef enum {
    JETFS_TYPE_FREE = 0,
    JETFS_TYPE_FILE = 1,
    JETFS_TYPE_DIR  = 2
} jetfs_inode_type_t;

typedef struct {
    uint32_t magic;
    uint32_t total_blocks;
    uint32_t inode_table_start;
    uint32_t inode_table_blocks;
    uint32_t bitmap_start;
    uint32_t bitmap_blocks;
    uint32_t data_start;
    uint32_t root_inode;
    uint8_t  reserved[JETFS_BLOCK_SIZE - 32];
} jetfs_superblock_t;

typedef struct {
    uint32_t type;       /* jetfs_inode_type_t */
    uint64_t size;        /* 바이트 단위(Milestone 23: uint32_t였던 걸 uint64_t로 확장 —
                            * 32비트로는 파일 크기 자체가 ~4.29GB에서 막혀서, 블록
                            * 주소 공간(삼중 간접)을 아무리 늘려도 의미가 없었다) */
    uint32_t block[JETFS_DIRECT_BLOCKS];
    uint32_t block_count;  /* 디렉터리 전용: 사용중인 직접 블록 개수.
                             * 파일은 size로부터 필요 블록 수를 계산하므로
                             * 이 필드를 사용하지 않는다. */
    uint32_t indirect;     /* 파일 전용: 간접 블록 번호 (0=미할당) */
    uint32_t double_indirect; /* 파일 전용(M22): 이중 간접 블록 번호 (0=미할당) */
    uint32_t triple_indirect; /* 파일 전용(M23): 삼중 간접 블록 번호 (0=미할당) */
    uint32_t used;        /* 0=빈 슬롯, 1=사용중 */
} jetfs_inode_t;

typedef struct {
    char name[JETFS_MAX_NAME];
    uint32_t inode;
    uint32_t used;
} jetfs_dirent_t;

/* drive_index의 lba_offset(섹터 단위)부터 시작하는 디스크 영역을 JETFS로
 * 마운트한다. 이미 mkjetfs로 포맷되어 있어야 한다. 성공 시 1. */
int jetfs_mount(int drive_index, uint64_t lba_offset);

/* 루트 기준 절대 경로("/dir/file" 형태)로 파일을 연다. */
int jetfs_create(const char *path, jetfs_inode_type_t type);
int jetfs_read(const char *path, void *buffer, uint64_t max_size, uint64_t *out_size);
int jetfs_write(const char *path, const void *data, uint64_t size);

/* Milestone 23: 파일 끝에 이어쓰기(append). 20GB급 대용량 파일은
 * (이 커널의 RAM 한도상) 한 번의 jetfs_write 호출로 통째로 쓸 수
 * 없으므로 — 예를 들어 청크 단위로 내려받으며 이 함수를 반복
 * 호출해 점점 키우는 식으로 실제로 큰 파일을 만들 수 있다. 파일이
 * 없으면 실패(먼저 jetfs_create 필요). */
int jetfs_append(const char *path, const void *data, uint64_t len);

int jetfs_delete(const char *path);
int jetfs_rename(const char *old_path, const char *new_path);

/* path의 타입/크기를 조회한다. 존재하지 않으면 0. */
int jetfs_stat(const char *path, jetfs_inode_type_t *out_type, uint64_t *out_size);

/* dir_path 아래 항목 이름들을 콜백으로 순서대로 전달한다. */
typedef void (*jetfs_list_cb)(const char *name, jetfs_inode_type_t type, uint64_t size, void *ctx);
int jetfs_list(const char *dir_path, jetfs_list_cb cb, void *ctx);

#endif
