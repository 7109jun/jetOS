/*
 * JetOS - kernel/apps/browser.c
 * browser.h 참고. Milestone 11/12의 TCP/DNS 스택을 그대로 재사용해
 * 실제 HTTP GET을 하고, 아주 단순한 HTML 태그 제거만 거쳐 창에 보여준다.
 */

#include <stddef.h>
#include "browser.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../drivers/console.h"
#include "../proc/scheduler.h"
#include "../mm/heap.h"
#include "../net/net.h"
#include "../net/tcp.h"
#include "../net/dns.h"

#define PAGE_BUF_SIZE 8192

static char g_page_buf[PAGE_BUF_SIZE];
static char g_page_status[80] = "(no page loaded)";
static char g_page_url[80] = "";

/* 아주 단순한 HTML 태그 제거: '<'~'>' 사이는 전부 버리고, 몇 가지
 * 흔한 엔티티만 풀어준다. 실제 레이아웃/CSS/JS는 전혀 처리하지 않는다
 * — "텍스트만이라도 읽을 수 있게" 하는 수준의 단순화다. */
static void html_strip(const char *in, uint32_t in_len, char *out, uint32_t out_cap) {
    uint32_t o = 0;
    int in_tag = 0;
    for (uint32_t i = 0; i < in_len && o + 1 < out_cap; i++) {
        char c = in[i];
        if (c == '<') { in_tag = 1; continue; }
        if (c == '>') { in_tag = 0; continue; }
        if (in_tag) continue;

        if (c == '&' && i + 4 < in_len) {
            if (in[i+1]=='l' && in[i+2]=='t' && in[i+3]==';') { out[o++]='<'; i+=3; continue; }
            if (in[i+1]=='g' && in[i+2]=='t' && in[i+3]==';') { out[o++]='>'; i+=3; continue; }
            if (i+5<in_len && in[i+1]=='a' && in[i+2]=='m' && in[i+3]=='p' && in[i+4]==';') { out[o++]='&'; i+=4; continue; }
        }
        /* 공백/개행 연속을 하나로 압축 */
        if ((c == ' ' || c == '\n' || c == '\r' || c == '\t') && o > 0 && out[o-1] == '\n') continue;
        out[o++] = (c == '\r' || c == '\t') ? ' ' : c;
    }
    out[o] = '\0';
}

static void set_status(const char *s) {
    int i = 0;
    for (; s[i] && i < (int)sizeof(g_page_status) - 1; i++) g_page_status[i] = s[i];
    g_page_status[i] = '\0';
}

static void do_fetch(const char *host, int port, const char *path) {
    set_status("loading...");

    if (!net_available()) { html_strip("NIC not available.", 19, g_page_buf, PAGE_BUF_SIZE); return; }

    uint32_t ip;
    if (!dns_resolve(host, &ip, 300)) {
        html_strip("DNS resolution failed.", 23, g_page_buf, PAGE_BUF_SIZE);
        set_status("DNS failed");
        return;
    }
    if (!tcp_connect(ip, (uint16_t)port, 300)) {
        html_strip("TCP connect failed/timeout.", 28, g_page_buf, PAGE_BUF_SIZE);
        set_status("connect failed");
        return;
    }

    char req[256]; int ri = 0;
    const char *m1 = "GET ";
    for (int k = 0; m1[k]; k++) req[ri++] = m1[k];
    for (int k = 0; path[k] && ri < 200; k++) req[ri++] = path[k];
    const char *m2 = " HTTP/1.0\r\nHost: ";
    for (int k = 0; m2[k]; k++) req[ri++] = m2[k];
    for (int k = 0; host[k] && ri < 230; k++) req[ri++] = host[k];
    const char *m3 = "\r\nUser-Agent: JetOS-Browser/1.0\r\nConnection: close\r\n\r\n";
    for (int k = 0; m3[k]; k++) req[ri++] = m3[k];

    if (!tcp_send(req, (uint32_t)ri, 100)) {
        html_strip("HTTP request send failed.", 26, g_page_buf, PAGE_BUF_SIZE);
        set_status("send failed");
        tcp_close();
        return;
    }

    static char resp[PAGE_BUF_SIZE];
    uint32_t n = tcp_recv_until_close(resp, sizeof(resp) - 1, 300);
    tcp_close();
    resp[n] = '\0';

    /* 헤더(\r\n\r\n까지)는 건너뛰고 본문만 보여준다 */
    uint32_t body_start = 0;
    for (uint32_t k = 0; k + 3 < n; k++) {
        if (resp[k] == '\r' && resp[k+1] == '\n' && resp[k+2] == '\r' && resp[k+3] == '\n') {
            body_start = k + 4;
            break;
        }
    }
    html_strip(resp + body_start, n - body_start, g_page_buf, PAGE_BUF_SIZE);
    set_status("loaded.");
}

static void browser_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)ctx; (void)h;
    dc->cursor_x = (uint32_t)(x + 8);
    dc->cursor_y = (uint32_t)(y + 6);
    console_print(dc, g_page_url[0] ? g_page_url : "(no address)");
    dc->cursor_x = (uint32_t)(x + 8);
    dc->cursor_y = (uint32_t)(y + 20);
    console_print(dc, g_page_status);
    dc->cursor_x = (uint32_t)(x + 8);
    dc->cursor_y = (uint32_t)(y + 40);
    console_print(dc, g_page_buf);
}

static volatile int g_browser_running = 0;
static int g_browser_win = -1;

static void browser_on_close(void *ctx) {
    (void)ctx;
    g_browser_running = 0;
}

typedef struct { char host[80]; int port; char path[96]; } browser_ctx_t;

static void browser_thread_entry(void *arg) {
    browser_ctx_t *bc = (browser_ctx_t *)arg;
    g_browser_running = 1;

    g_browser_win = CreateWindowJ("JETOS BROWSER", 200, 200, 420, 260, 0x00203848);
    if (g_browser_win >= 0) {
        wm_set_content_callback(g_browser_win, browser_content_cb, NULL);
        wm_set_close_callback(g_browser_win, browser_on_close, NULL);
    }

    if (bc) {
        int i = 0;
        const char *pre = "http://";
        for (; pre[i]; i++) g_page_url[i] = pre[i];
        for (int k = 0; bc->host[k] && i < 60; k++) g_page_url[i++] = bc->host[k];
        for (int k = 0; bc->path[k] && i < 78; k++) g_page_url[i++] = bc->path[k];
        g_page_url[i] = '\0';

        do_fetch(bc->host, bc->port, bc->path);
        kfree(bc);
    }

    while (g_browser_running) {
        scheduler_yield();
    }
}

void browser_launch_url(const char *host, int port, const char *path) {
    browser_ctx_t *bc = (browser_ctx_t *)kmalloc(sizeof(browser_ctx_t));
    if (!bc) return;
    int i = 0; for (; host[i] && i < (int)sizeof(bc->host) - 1; i++) bc->host[i] = host[i];
    bc->host[i] = '\0';
    bc->port = port;
    i = 0; for (; path[i] && i < (int)sizeof(bc->path) - 1; i++) bc->path[i] = path[i];
    bc->path[i] = '\0';
    CreateThreadJ("browser", browser_thread_entry, bc);
}

void browser_launch(void) {
    /* 데모용 기본 페이지: 네트워킹 자체 테스트와 같은 호스트의 테스트
     * 서버(10.0.2.2:8000)를 기본값으로 연다. 실제 인터넷 주소를 열려면
     * jash의 'browser <host> <port> </path>' 명령을 쓰면 된다(DNS 지원). */
    browser_launch_url("10.0.2.2", 8000, "/index.html");
}
