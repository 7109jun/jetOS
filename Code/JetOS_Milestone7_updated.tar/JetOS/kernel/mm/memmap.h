#ifndef JETOS_MEMMAP_H
#define JETOS_MEMMAP_H

#include <stdint.h>
#include "../../include/efi/efi.h"

typedef struct {
    uint64_t total_pages;
    uint64_t usable_pages;         /* EfiConventionalMemory */
    uint64_t reserved_pages;
    uint64_t loader_pages;         /* EfiLoaderCode/Data (JetOS 부트로더+커널) */
    uint64_t descriptor_count;
    uint64_t largest_free_block_pages;
    EFI_PHYSICAL_ADDRESS largest_free_block_base;
} jetos_memory_summary_t;

/* UEFI가 넘겨준 원본 EFI_MEMORY_DESCRIPTOR 배열을 순회하여 요약 통계를 만든다. */
void memmap_summarize(EFI_MEMORY_DESCRIPTOR *map, UINTN map_size,
                       UINTN descriptor_size, jetos_memory_summary_t *out);

#endif
