/*
 * JetOS - kernel/mm/memmap.c
 * UEFI Boot Services의 GetMemoryMap()이 반환한 물리 메모리 맵을 순수 C로
 * 순회하여 JetOS Physical Memory Manager(Milestone 2)가 사용할 수 있는
 * 형태로 요약한다. Milestone 1에서는 통계 산출과 콘솔/시리얼 출력까지만
 * 담당하고, 실제 page allocator는 Milestone 2에서 이 결과를 입력으로
 * 받아 구현한다.
 */

#include "memmap.h"

#define EFI_PAGE_SIZE 4096ULL

void memmap_summarize(EFI_MEMORY_DESCRIPTOR *map, UINTN map_size,
                       UINTN descriptor_size, jetos_memory_summary_t *out) {
    out->total_pages = 0;
    out->usable_pages = 0;
    out->reserved_pages = 0;
    out->loader_pages = 0;
    out->descriptor_count = 0;
    out->largest_free_block_pages = 0;
    out->largest_free_block_base = 0;

    uint8_t *cursor = (uint8_t *)map;
    uint8_t *end = (uint8_t *)map + map_size;

    while (cursor < end) {
        EFI_MEMORY_DESCRIPTOR *desc = (EFI_MEMORY_DESCRIPTOR *)cursor;

        out->total_pages += desc->NumberOfPages;
        out->descriptor_count++;

        switch (desc->Type) {
            case EfiConventionalMemory:
                out->usable_pages += desc->NumberOfPages;
                if (desc->NumberOfPages > out->largest_free_block_pages) {
                    out->largest_free_block_pages = desc->NumberOfPages;
                    out->largest_free_block_base = desc->PhysicalStart;
                }
                break;
            case EfiLoaderCode:
            case EfiLoaderData:
                out->loader_pages += desc->NumberOfPages;
                break;
            default:
                out->reserved_pages += desc->NumberOfPages;
                break;
        }

        cursor += descriptor_size;
    }
}
