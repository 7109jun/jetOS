#ifndef JETOS_APP_RECYCLEBIN_GUI_H
#define JETOS_APP_RECYCLEBIN_GUI_H

/*
 * JetOS - kernel/apps/recyclebin_gui.h
 * Milestone 35: 휴지통 GUI. kernel/fs/recyclebin.c(M32)는 지금까지
 * jash 명령(recyclebin/restore/purge)으로만 접근할 수 있었다 — 일상
 * 사용에서 "실수로 지운 파일을 다시 찾는" 흐름이 터미널을 열어야만
 * 가능했던 걸, 클릭 몇 번으로 되돌리는 창으로 만들었다.
 */
void recyclebin_gui_launch(void);

#endif
