/*
 * JetOS - kernel/mm/vmm.c
 * JetOS 자체 PML4/PDPT/PD 를 구성해 하위 4GiB를 2MiB 페이지로 항등
 * 매핑한다. 커널 이미지 자체 정적 배열로 테이블을 확보해 PMM 부트스트랩
 * 순서에 의존하지 않는다.
 *
 * Milestone 15: 프로세스별 주소공간(per-process page table) 지원 추가.
 *
 * 설계: 커널 영역(0~4GiB, 위의 g_pd 2MiB 매핑)은 모든 프로세스가
 * "공유"한다 — U비트 없이(Ring0 전용) 그대로 유지한다. 각 프로세스는
 * 자기 전용 PML4 + PDPT를 새로 받되, PDPT의 0~3번 슬롯(=커널 identity
 * 영역)은 전부 이 파일의 공유 g_pd[]를 그대로 가리키게 해서 커널
 * 코드/데이터에 항상 접근 가능하게 하고, PDPT의 4번 슬롯(가상주소
 * 4GiB~4GiB+2MiB = "유저 영역")만 그 프로세스 전용 PD+PT로 채운다.
 * 그 PT의 각 엔트리에만 U비트를 켜서, "이 프로세스가 로드한 ELF
 * 세그먼트/스택 페이지"만 Ring3에서 접근 가능하고 나머지(커널 전체)는
 * 여전히 Ring0 전용으로 남는다 — Milestone 14의 "전체 항등 매핑에
 * U비트"였던 단순화(보안 구멍)를 여기서 제대로 고친 것이다.
 *
 * 알려진 단순화: 유저 영역은 프로세스당 2MiB(PDPT 슬롯 1개)로 고정.
 * CR3 전환은 스레드 전환기(scheduler.c)와 아직 연동되어 있지 않다 —
 * "한 번에 하나의 유저 프로세스만 실행"하는 현재 범위에서는 커널
 * 스레드들이 전부 공유 매핑만 쓰므로 문제되지 않지만, 여러 프로세스가
 * 동시에 각자의 유저 메모리를 갖는 시나리오는 다음 마일스톤 과제.
 */

#include "vmm.h"
#include "../hal/x86_asm_shim.h"
#include "pmm.h"

#define PAGE_PRESENT  0x1ULL
#define PAGE_WRITABLE 0x2ULL
#define PAGE_USER     0x4ULL
#define PAGE_SIZE_2MB 0x80ULL

#define VMM_IDENTITY_GB 4

/* 유저 영역: PDPT 슬롯 4 = 가상주소 4GiB부터 시작하는 2MiB 구간 */
#define VMM_USER_PDPT_SLOT 4
#define VMM_USER_VIRT_BASE (4ULL * 1024 * 1024 * 1024)
#define VMM_USER_REGION_SIZE (2ULL * 1024 * 1024) /* PD 엔트리 1개 = PT 1개 = 512*4KB */

static uint64_t g_pml4[512] __attribute__((aligned(4096)));
static uint64_t g_pdpt[512] __attribute__((aligned(4096)));
static uint64_t g_pd[VMM_IDENTITY_GB][512] __attribute__((aligned(4096)));

void vmm_init(void) {
    for (int i = 0; i < 512; i++) { g_pml4[i] = 0; g_pdpt[i] = 0; }

    g_pml4[0] = ((uint64_t)&g_pdpt[0]) | PAGE_PRESENT | PAGE_WRITABLE;

    for (int gb = 0; gb < VMM_IDENTITY_GB; gb++) {
        g_pdpt[gb] = ((uint64_t)&g_pd[gb][0]) | PAGE_PRESENT | PAGE_WRITABLE;
        for (int e = 0; e < 512; e++) {
            uint64_t phys = ((uint64_t)gb * 1024ULL * 1024ULL * 1024ULL) +
                             ((uint64_t)e * 2ULL * 1024ULL * 1024ULL);
            g_pd[gb][e] = phys | PAGE_PRESENT | PAGE_WRITABLE | PAGE_SIZE_2MB;
        }
    }

    hal_write_cr3((uint64_t)&g_pml4[0]);
}

uint64_t vmm_kernel_pml4_phys(void) {
    return (uint64_t)&g_pml4[0];
}

uint64_t vmm_user_virt_base(void) {
    return VMM_USER_VIRT_BASE;
}

uint64_t vmm_user_region_size(void) {
    return VMM_USER_REGION_SIZE;
}

uint64_t vmm_create_process_address_space(void) {
    uint64_t pml4_phys = pmm_alloc_page();
    uint64_t pdpt_phys = pmm_alloc_page();
    uint64_t pd_phys    = pmm_alloc_page();
    uint64_t pt_phys    = pmm_alloc_page();
    if (!pml4_phys || !pdpt_phys || !pd_phys || !pt_phys) return 0;

    uint64_t *pml4 = (uint64_t *)pml4_phys;
    uint64_t *pdpt = (uint64_t *)pdpt_phys;
    uint64_t *pd   = (uint64_t *)pd_phys;
    uint64_t *pt   = (uint64_t *)pt_phys;

    for (int i = 0; i < 512; i++) { pml4[i] = 0; pdpt[i] = 0; pd[i] = 0; pt[i] = 0; }

    /* PML4[0]는 U비트를 켜야 한다 — 그래야 아래쪽 유저 영역(PDPT 슬롯 4)
     * 경로에서 U비트가 실제로 효력을 갖는다(경로상의 모든 레벨이
     * U=1이어야 Ring3 접근이 허용됨). 커널 identity 영역(PDPT 슬롯
     * 0~3)은 그 아래 g_pd[] 엔트리 자체가 여전히 U=0이므로, PML4[0]의
     * U비트가 켜져 있어도 커널 메모리가 새어나가지 않는다. */
    pml4[0] = pdpt_phys | PAGE_PRESENT | PAGE_WRITABLE | PAGE_USER;

    /* 커널 identity 영역은 공유 g_pd[]를 그대로 재사용(복사 아님) —
     * 새 페이지를 안 만드니 메모리도 절약되고, 커널 코드/데이터는
     * 항상 최신 상태로 보인다. U비트 없이 그대로. */
    for (int gb = 0; gb < VMM_IDENTITY_GB; gb++) {
        pdpt[gb] = ((uint64_t)&g_pd[gb][0]) | PAGE_PRESENT | PAGE_WRITABLE;
    }

    /* 유저 영역(슬롯 4)만 이 프로세스 전용 PD/PT */
    pdpt[VMM_USER_PDPT_SLOT] = pd_phys | PAGE_PRESENT | PAGE_WRITABLE | PAGE_USER;
    pd[0] = pt_phys | PAGE_PRESENT | PAGE_WRITABLE | PAGE_USER;
    /* pt[] 각 엔트리는 vmm_map_user_page()가 필요할 때마다 채운다 */

    return pml4_phys;
}

int vmm_map_user_page(uint64_t pml4_phys, uint64_t vaddr, uint64_t paddr, int writable) {
    if (vaddr < VMM_USER_VIRT_BASE || vaddr >= VMM_USER_VIRT_BASE + VMM_USER_REGION_SIZE) return 0;
    if (vaddr % PMM_PAGE_SIZE != 0) return 0;

    uint64_t *pml4 = (uint64_t *)pml4_phys;
    uint64_t pdpt_phys = pml4[0] & ~0xFFFULL;
    uint64_t *pdpt = (uint64_t *)pdpt_phys;
    uint64_t pd_phys = pdpt[VMM_USER_PDPT_SLOT] & ~0xFFFULL;
    uint64_t *pd = (uint64_t *)pd_phys;
    uint64_t pt_phys = pd[0] & ~0xFFFULL;
    uint64_t *pt = (uint64_t *)pt_phys;

    uint64_t offset = vaddr - VMM_USER_VIRT_BASE;
    uint64_t pt_index = offset / PMM_PAGE_SIZE;
    if (pt_index >= 512) return 0;

    uint64_t flags = PAGE_PRESENT | PAGE_USER;
    if (writable) flags |= PAGE_WRITABLE;
    pt[pt_index] = (paddr & ~0xFFFULL) | flags;

    /* TLB에 이 가상주소의 옛 매핑이 캐시돼 있을 수 있으니 무효화 */
    __asm__ volatile ("invlpg (%0)" : : "r"(vaddr) : "memory");
    return 1;
}
