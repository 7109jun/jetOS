#!/usr/bin/env bash
# BOOTX64.EFI를 담은 FAT32 ESP(EFI System Partition) 이미지 생성
set -e
cd "$(dirname "$0")/.."

EFI_FILE="build/BOOTX64.EFI"
KERNEL_FILE="build/KERNEL.ELF"
IMG="build/esp.img"

if [ ! -f "$EFI_FILE" ] || [ ! -f "$KERNEL_FILE" ]; then
    echo "오류: $EFI_FILE / $KERNEL_FILE 이(가) 없습니다. 먼저 'make' 를 실행하세요."
    exit 1
fi

command -v mformat >/dev/null 2>&1 || { echo "오류: mtools 가 필요합니다 (scripts/setup_toolchain.sh 실행)"; exit 1; }

rm -f "$IMG"
dd if=/dev/zero of="$IMG" bs=1M count=64 status=none
mformat -i "$IMG" -F ::
mmd -i "$IMG" ::/EFI
mmd -i "$IMG" ::/EFI/BOOT
mcopy -i "$IMG" "$EFI_FILE" ::/EFI/BOOT/BOOTX64.EFI
mcopy -i "$IMG" "$KERNEL_FILE" ::/KERNEL.ELF

echo "ESP 이미지 생성 완료: $IMG"
