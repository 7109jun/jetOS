/*
 * JetOS - kernel/drivers/rtl8139.c
 *
 * Realtek RTL8139 이더넷 컨트롤러 드라이버. QEMU가 `-device rtl8139`로
 * 기본 제공하는 가상 NIC이 정확히 이 칩을 흉내내므로, 별도 드라이버
 * 없이 QEMU 환경에서 실제 패킷 송수신을 실증할 수 있다.
 *
 * AHCI 드라이버와 동일한 설계 철학: 인터럽트 없이 순수 폴링 방식.
 * 레지스터는 전부 포트 I/O(BAR0)로 접근한다 — MMIO(BAR1)도 지원하는
 * 칩이지만, 포트 I/O 쪽이 더 단순하고 이미 hal_inX/outX가 있다.
 */

#include "rtl8139.h"
#include "pci.h"
#include "../hal/x86_asm_shim.h"
#include "../mm/pmm.h"

/* ---- 레지스터 오프셋 (BAR0 기준) ---- */
#define REG_MAC0        0x00 /* 6바이트 MAC 주소 */
#define REG_RBSTART     0x30 /* 수신 버퍼 물리주소 (4바이트) */
#define REG_CMD         0x37 /* 커맨드 레지스터 (1바이트) */
#define REG_CAPR        0x38 /* 현재 읽기 포인터 (2바이트) */
#define REG_IMR         0x3C /* 인터럽트 마스크 (2바이트, 사용 안 함 — 폴링) */
#define REG_ISR         0x3E /* 인터럽트 상태 (2바이트) */
#define REG_TCR         0x40 /* 송신 설정 (4바이트) */
#define REG_RCR         0x44 /* 수신 설정 (4바이트) */
#define REG_CONFIG1     0x52 /* 전원 관리 (1바이트) */
#define REG_TSAD0       0x20 /* 송신 디스크립터 0~3 물리주소, 각 4바이트 간격 */
#define REG_TSD0        0x10 /* 송신 디스크립터 0~3 상태/길이, 각 4바이트 간격 */

#define CMD_RESET   0x10
#define CMD_RX_EN   0x08
#define CMD_TX_EN   0x04
#define CMD_BUF_EMPTY 0x01

#define RCR_AAP  (1 << 0) /* accept all packets (promiscuous) */
#define RCR_APM  (1 << 1) /* accept physical match */
#define RCR_AM   (1 << 2) /* accept multicast */
#define RCR_AB   (1 << 3) /* accept broadcast */
#define RCR_WRAP (1 << 7) /* 수신 버퍼 경계에서 패킷이 잘리지 않게 함 */
#define RCR_MXDMA_UNLIMITED (0x7 << 8)
#define RCR_RBLEN_8K (0x0 << 11) /* 8K+16바이트 버퍼 */

#define TSD_OWN  (1u << 13) /* 1=NIC이 전송을 마치고 소유권을 반환함 */
#define TSD_TOK  (1u << 15) /* 전송 성공 */

#define RX_BUF_PADDING 1536 /* WRAP 옵션 사용 시 버퍼 끝 너머로 밀려 쓸 수 있어 여유분 필요 */
#define RX_BUF_LOGICAL_SIZE 8192
#define RX_BUF_TOTAL_SIZE (RX_BUF_LOGICAL_SIZE + 16 + RX_BUF_PADDING)

#define TX_BUF_SIZE 1536
#define TX_DESC_COUNT 4

static int g_available = 0;
static uint16_t g_io_base = 0;
static uint8_t g_mac[6];

static uint8_t *g_rx_buf = NULL;   /* 가상=물리 (0~4GiB 항등 매핑) */
static uint32_t g_rx_offset = 0;   /* 다음에 읽을 위치 (버퍼 내 오프셋) */

static uint8_t *g_tx_buf[TX_DESC_COUNT];
static int g_tx_next = 0;

int rtl8139_available(void) { return g_available; }

void rtl8139_get_mac(uint8_t mac[6]) {
    for (int i = 0; i < 6; i++) mac[i] = g_mac[i];
}

static void enable_pci_bus_master_io(pci_device_t *dev) {
    /* 오프셋 0x04 = Command(16bit, 하위)/Status(16bit, 상위) 조합 레지스터.
     * bit0=I/O Space Enable, bit2=Bus Master Enable(DMA 허용) */
    uint32_t cmd_status = pci_config_read32(dev->bus, dev->slot, dev->func, 0x04);
    cmd_status |= 0x0005; /* I/O space + bus master */
    pci_config_write32(dev->bus, dev->slot, dev->func, 0x04, cmd_status);
}

int rtl8139_init(void) {
    pci_device_t dev;
    /* Realtek 벤더 0x10EC, RTL8139 계열 디바이스 ID 0x8139 */
    if (!pci_find_device(0x10EC, 0x8139, &dev)) {
        g_available = 0;
        return 0;
    }

    enable_pci_bus_master_io(&dev);

    /* BAR0 하위 2비트는 "이 BAR가 I/O 공간이다"라는 플래그(0x1)이므로
     * 마스킹해서 실제 베이스 포트만 취한다. */
    g_io_base = (uint16_t)(dev.bar[0] & ~0x3u);
    if (g_io_base == 0) { g_available = 0; return 0; }

    /* 전원 관리 해제(wake up) */
    hal_outb((uint16_t)(g_io_base + REG_CONFIG1), 0x00);

    /* 소프트 리셋 — RST 비트는 리셋 완료 시 하드웨어가 스스로 0으로 내림 */
    hal_outb((uint16_t)(g_io_base + REG_CMD), CMD_RESET);
    for (int i = 0; i < 1000000; i++) {
        if ((hal_inb((uint16_t)(g_io_base + REG_CMD)) & CMD_RESET) == 0) break;
    }

    /* MAC 주소 읽기 (레지스터 0x00~0x05) */
    for (int i = 0; i < 6; i++) {
        g_mac[i] = hal_inb((uint16_t)(g_io_base + REG_MAC0 + i));
    }

    /* 수신 버퍼 확보 (물리적으로 연속된 페이지들, 항등 매핑이므로
     * 물리주소를 그대로 포인터로 사용 가능) */
    uint64_t rx_pages = (RX_BUF_TOTAL_SIZE + 4095) / 4096;
    uint64_t rx_phys = pmm_alloc_pages(rx_pages);
    if (rx_phys == 0) { g_available = 0; return 0; }
    g_rx_buf = (uint8_t *)(uintptr_t)rx_phys;
    g_rx_offset = 0;

    hal_outl((uint16_t)(g_io_base + REG_RBSTART), (uint32_t)rx_phys);

    /* 송신 버퍼 4개(디스크립터당 1개) */
    for (int i = 0; i < TX_DESC_COUNT; i++) {
        uint64_t tx_phys = pmm_alloc_pages(1); /* 4096 >= TX_BUF_SIZE */
        if (tx_phys == 0) { g_available = 0; return 0; }
        g_tx_buf[i] = (uint8_t *)(uintptr_t)tx_phys;
        hal_outl((uint16_t)(g_io_base + REG_TSAD0 + i * 4), (uint32_t)tx_phys);
    }
    g_tx_next = 0;

    /* 인터럽트는 쓰지 않지만, 상태 레지스터에 낀 잔여 비트를 깨끗이 지운다 */
    hal_outw((uint16_t)(g_io_base + REG_ISR), 0xFFFF);
    hal_outw((uint16_t)(g_io_base + REG_IMR), 0x0000);

    /* 수신 설정: 모든 유니캐스트(내 MAC)/브로드캐스트/멀티캐스트 허용,
     * WRAP으로 버퍼 경계 문제 방지, DMA 버스트 무제한 */
    hal_outl((uint16_t)(g_io_base + REG_RCR),
             RCR_AAP | RCR_APM | RCR_AM | RCR_AB | RCR_WRAP | RCR_MXDMA_UNLIMITED | RCR_RBLEN_8K);

    /* 송신 설정: DMA 버스트 무제한 (그 외 기본값) */
    hal_outl((uint16_t)(g_io_base + REG_TCR), RCR_MXDMA_UNLIMITED);

    /* 송수신 활성화 */
    hal_outb((uint16_t)(g_io_base + REG_CMD), CMD_RX_EN | CMD_TX_EN);

    g_available = 1;
    return 1;
}

int rtl8139_send(const void *frame, uint32_t len) {
    if (!g_available) return 0;
    if (len > TX_BUF_SIZE) return 0;
    if (len < 60) len = 60; /* 이더넷 최소 프레임 길이(FCS 제외 60바이트) */

    int slot = g_tx_next;
    g_tx_next = (g_tx_next + 1) % TX_DESC_COUNT;

    /* 이전에 이 슬롯을 썼다면 완료(OWN=1)될 때까지 대기 */
    uint32_t timeout = 2000000;
    while (timeout--) {
        uint32_t status = hal_inl((uint16_t)(g_io_base + REG_TSD0 + slot * 4));
        if (status & TSD_OWN) break;
    }

    uint8_t *dst = g_tx_buf[slot];
    const uint8_t *src = (const uint8_t *)frame;
    for (uint32_t i = 0; i < len; i++) dst[i] = src[i];

    /* 길이 필드(하위 13비트)에 쓰면 하드웨어가 즉시 전송을 시작한다.
     * (OWN 비트는 하드웨어가 알아서 0으로 내렸다가 완료 시 다시 1로 올림) */
    hal_outl((uint16_t)(g_io_base + REG_TSD0 + slot * 4), len & 0x1FFF);

    timeout = 2000000;
    while (timeout--) {
        uint32_t status = hal_inl((uint16_t)(g_io_base + REG_TSD0 + slot * 4));
        if (status & TSD_TOK) return 1;
        if (status & TSD_OWN) { /* 소유권은 돌아왔는데 TOK가 없으면 전송 실패(충돌 등) */
            return (status & TSD_TOK) ? 1 : 0;
        }
    }
    return 0; /* 타임아웃 */
}

uint32_t rtl8139_recv(void *buf, uint32_t buf_size) {
    if (!g_available) return 0;

    /* CMD 레지스터의 BUFE(BufferEmpty) 비트가 1이면 대기중인 패킷 없음 */
    if (hal_inb((uint16_t)(g_io_base + REG_CMD)) & CMD_BUF_EMPTY) return 0;

    /* 수신 버퍼 포맷: [status:2][length:2(FCS 포함)][payload...] */
    uint16_t rx_status = *(uint16_t *)(g_rx_buf + g_rx_offset);
    uint16_t rx_len     = *(uint16_t *)(g_rx_buf + g_rx_offset + 2);

    (void)rx_status; /* ROK 등 상세 플래그는 검사하지 않고 길이만으로 판단 (단순화) */

    uint32_t payload_len = (rx_len >= 4) ? (uint32_t)(rx_len - 4) : 0; /* FCS 4바이트 제외 */
    uint32_t copy_len = payload_len < buf_size ? payload_len : buf_size;

    if (payload_len > 0 && payload_len <= RTL8139_MAX_FRAME) {
        uint8_t *src = g_rx_buf + g_rx_offset + 4;
        uint8_t *dst = (uint8_t *)buf;
        for (uint32_t i = 0; i < copy_len; i++) dst[i] = src[i];
    } else {
        payload_len = 0; /* 손상된 것으로 보이는 길이는 버림 */
    }

    /* 다음 패킷 위치로 오프셋 이동: 헤더 4바이트 + 프레임(FCS 포함), 4바이트 정렬,
     * 8192 경계에서 wrap. */
    uint32_t advance = 4 + rx_len;
    advance = (advance + 3) & ~3u;
    g_rx_offset = (g_rx_offset + advance) % RX_BUF_LOGICAL_SIZE;

    /* CAPR은 하드웨어 관례상 "다음 읽기 위치 - 16"으로 설정한다. */
    uint16_t capr = (uint16_t)((g_rx_offset - 16) & 0xFFFF);
    hal_outw((uint16_t)(g_io_base + REG_CAPR), capr);

    return payload_len;
}
