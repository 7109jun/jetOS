#ifndef JETOS_APP_CLOCK_H
#define JETOS_APP_CLOCK_H
void clock_launch(void);
#endif
