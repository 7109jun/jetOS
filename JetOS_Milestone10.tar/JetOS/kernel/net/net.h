#ifndef JETOS_NET_H
#define JETOS_NET_H

#include <stdint.h>

/*
 * JetOS - kernel/net/net.h
 *
 * Milestone 10: 최소 네트워킹 스택.
 *   물리 계층 : RTL8139 (kernel/drivers/rtl8139.c)
 *   L2        : Ethernet II 프레임 송수신
 *   ARP       : 요청/응답 + 작은 캐시
 *   L3        : IPv4 (체크섬 포함, 조각화(fragmentation)는 미지원)
 *   ICMP      : Echo Request/Reply (ping)
 *
 * TCP/UDP, DNS, 실제 HTTP는 다음 마일스톤 과제로 남겨둔다 — 이번
 * 마일스톤은 "링크가 진짜로 살아있고 패킷이 진짜로 오간다"를
 * ARP/ping으로 실증하는 데 집중한다.
 *
 * IP 설정은 QEMU 기본 SLIRP 네트워크(-netdev user)의 기본값에 맞춰
 * 고정되어 있다: 우리 IP 10.0.2.15/24, 게이트웨이 10.0.2.2.
 * (DHCP는 없음 — 정적 설정.)
 */

#define NET_MY_IP      0x0A00020Fu /* 10.0.2.15 (빅엔디안이 아닌 "숫자값"으로 보관) */
#define NET_GATEWAY_IP 0x0A000202u /* 10.0.2.2  */
#define NET_NETMASK    0xFFFFFF00u /* 255.255.255.0 */

/* NIC 탐지 + 초기화. 성공하면 1, NIC이 없으면 0. */
int net_init(void);
int net_available(void);

void net_get_mac(uint8_t mac[6]);
uint32_t net_get_ip(void);      /* 우리 IP (호스트 바이트 순서 정수) */
uint32_t net_get_gateway(void);

/* IPv4 주소를 "a.b.c.d" 문자열로 (buf는 최소 16바이트) */
void net_ip_to_str(uint32_t ip, char *buf);
/* "a.b.c.d" 문자열을 파싱해 IPv4 정수로. 실패 시 0 반환. */
uint32_t net_str_to_ip(const char *s);

/* 대기중인 수신 프레임을 전부 처리한다(ARP 응답, ICMP echo 응답 등).
 * jash net 명령어들이 내부적으로 호출하지만, 다른 곳에서 주기적으로
 * 불러도 안전하다(idle 스레드 등). */
void net_poll(void);

/* ip에 대한 MAC 주소를 ARP로 알아낸다. 캐시에 있으면 즉시, 없으면
 * 요청을 보내고 timeout_ticks(100Hz 기준 틱 수)까지 기다린다.
 * 성공 시 1과 out_mac 채움, 실패(타임아웃) 시 0. */
int net_arp_resolve(uint32_t ip, uint8_t out_mac[6], uint32_t timeout_ticks);

/* ip로 ICMP Echo Request를 보내고 응답을 기다린다.
 * 성공 시 1과 *out_rtt_ticks(왕복시간, 틱 단위)를 채움, 실패(도달 불가/
 * ARP 실패/타임아웃) 시 0. */
int net_ping(uint32_t ip, uint32_t timeout_ticks, uint32_t *out_rtt_ticks);

#endif
