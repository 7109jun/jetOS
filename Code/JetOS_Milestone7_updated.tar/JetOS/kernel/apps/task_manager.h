#ifndef JETOS_APP_TASK_MANAGER_H
#define JETOS_APP_TASK_MANAGER_H
void task_manager_launch(void);
#endif
