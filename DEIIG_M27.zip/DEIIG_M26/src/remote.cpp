#include "remote.hpp"
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <algorithm>

namespace fs = std::filesystem;
namespace deiig::remote {

static std::string trim(std::string s) {
    while (!s.empty() && (s.back() == '\r' || s.back() == ' ' || s.back() == '\t')) s.pop_back();
    size_t p = 0;
    while (p < s.size() && (s[p] == ' ' || s[p] == '\t')) ++p;
    return s.substr(p);
}
static std::string esc(const std::string& in) {
    std::string out;
    for (char c : in) { if (c == '\\') out += "\\\\"; else if (c == '\n') out += "\\n"; else out += c; }
    return out;
}
static std::string unesc(const std::string& in) {
    std::string out; bool slash = false;
    for (char c : in) { if (slash) { if (c == 'n') out += '\n'; else out += c; slash = false; } else if (c == '\\') slash = true; else out += c; }
    if (slash) out += '\\';
    return out;
}
fs::path profile_file(const fs::path& project_dir) { return project_dir / ".deiig" / "remote.profiles"; }
std::vector<Profile> load_profiles(const fs::path& project_dir) {
    std::vector<Profile> out; std::ifstream f(profile_file(project_dir)); if (!f) return out;
    std::string line; Profile* cur = nullptr;
    while (std::getline(f, line)) {
        line = trim(line); if (line.empty() || line[0] == '#' || line == "DEIIG-REMOTE 1") continue;
        if (line.rfind("[profile ", 0) == 0 && line.back() == ']') { out.push_back({}); out.back().name = line.substr(9, line.size() - 10); cur = &out.back(); continue; }
        auto eq = line.find('='); if (!cur || eq == std::string::npos) continue;
        auto key = trim(line.substr(0, eq)); auto value = unesc(trim(line.substr(eq + 1)));
        if (key == "host") cur->host = value; else if (key == "user") cur->user = value; else if (key == "port") { try { cur->port = std::stoi(value); } catch (...) { cur->port = 22; } } else if (key == "remote_root") cur->remote_root = value; else if (key == "key_file") cur->key_file = value;
    }
    out.erase(std::remove_if(out.begin(), out.end(), [](const Profile& p){ return p.name.empty() || p.host.empty() || p.user.empty(); }), out.end()); return out;
}
bool save_profile(const fs::path& project_dir, const Profile& profile) {
    if (profile.name.empty() || profile.host.empty() || profile.user.empty()) return false;
    auto all = load_profiles(project_dir); bool replaced = false;
    for (auto& p : all) if (p.name == profile.name) { p = profile; replaced = true; break; }
    if (!replaced) all.push_back(profile);
    std::error_code ec; fs::create_directories(project_dir / ".deiig", ec); std::ofstream f(profile_file(project_dir), std::ios::trunc); if (!f) return false;
    f << "DEIIG-REMOTE 1\n";
    for (const auto& p : all) { f << "[profile " << p.name << "]\n" << "host=" << esc(p.host) << '\n' << "user=" << esc(p.user) << '\n' << "port=" << p.port << '\n' << "remote_root=" << esc(p.remote_root) << '\n' << "key_file=" << esc(p.key_file) << '\n'; }
    return f.good();
}
const Profile* find_profile(const std::vector<Profile>& profiles, const std::string& name) { for (const auto& p : profiles) if (p.name == name) return &p; return nullptr; }
std::string target(const Profile& profile) { return profile.user + "@" + profile.host; }
std::string shell_quote(const std::string& value) {
#ifdef _WIN32
    std::string out = "\""; for (char c : value) { if (c == '"') out += "\\\""; else out += c; } out += "\""; return out;
#else
    std::string out = "'"; for (char c : value) { if (c == '\'') out += "'\\''"; else out += c; } out += "'"; return out;
#endif
}
static std::string options(const Profile& p) {
    std::ostringstream o; o << " -p " << p.port << " -o BatchMode=yes -o ConnectTimeout=8 "; if (!p.key_file.empty()) o << "-i " << shell_quote(p.key_file) << ' '; return o.str();
}
std::string ssh_command(const Profile& p, const std::string& command) { return "ssh" + options(p) + shell_quote(target(p)) + " " + shell_quote(command); }
int exec(const fs::path&, const Profile& p, const std::string& command) { return std::system(ssh_command(p, command).c_str()); }
int pull(const fs::path&, const Profile& p, const std::string& remote_path, const fs::path& local_path) {
    std::error_code ec; if (!local_path.parent_path().empty()) fs::create_directories(local_path.parent_path(), ec);
    std::ostringstream o; o << "scp -P " << p.port << " -o BatchMode=yes -o ConnectTimeout=8 "; if (!p.key_file.empty()) o << "-i " << shell_quote(p.key_file) << ' '; o << shell_quote(target(p) + ":" + remote_path) << ' ' << shell_quote(local_path.string()); return std::system(o.str().c_str());
}
int push(const fs::path&, const Profile& p, const fs::path& local_path, const std::string& remote_path) {
    std::ostringstream o; o << "scp -P " << p.port << " -o BatchMode=yes -o ConnectTimeout=8 "; if (!p.key_file.empty()) o << "-i " << shell_quote(p.key_file) << ' '; o << shell_quote(local_path.string()) << ' ' << shell_quote(target(p) + ":" + remote_path); return std::system(o.str().c_str());
}
} // namespace deiig::remote
