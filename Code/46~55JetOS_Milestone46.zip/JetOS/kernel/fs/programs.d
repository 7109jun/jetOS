kernel/fs/programs.o: kernel/fs/programs.c kernel/fs/programs.h \
 kernel/fs/jetfs.h kernel/fs/recyclebin.h
kernel/fs/programs.h:
kernel/fs/jetfs.h:
kernel/fs/recyclebin.h:
