/*
 * JetOS - kernel/drivers/keyboard.c
 * PS/2 키보드 (스캔코드 세트 1, IRQ1). 포트 I/O만 사용하는 순수 C 드라이버.
 */

#include "keyboard.h"
#include "../hal/x86_asm_shim.h"

#define KBD_DATA_PORT 0x60
#define KBD_BUF_SIZE 64

static char g_ring[KBD_BUF_SIZE];
static int g_head = 0, g_tail = 0;
static int g_shift = 0;
static int g_ctrl = 0;  /* Milestone 28: 왼쪽 Ctrl만 추적(오른쪽은 미지원 — 알려진 단순화) */
static int g_alt = 0;   /* Milestone 31: 왼쪽 Alt만 추적(패턴은 g_ctrl과 동일) */
static int g_extended = 0; /* 이전 바이트가 0xE0(확장 접두)였는가 */

/* 스캔코드 세트1 -> ASCII (미국 자판, Shift 미적용) */
static const char SC_TO_ASCII[128] = {
    0,27,'1','2','3','4','5','6','7','8','9','0','-','=','\b',
    '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',
    0,'a','s','d','f','g','h','j','k','l',';','\'','`',
    0,'\\','z','x','c','v','b','n','m',',','.','/',0,
    '*',0,' ',0,
    /* 나머지(F키 등)는 0 */
};
static const char SC_TO_ASCII_SHIFT[128] = {
    0,27,'!','@','#','$','%','^','&','*','(',')','_','+','\b',
    '\t','Q','W','E','R','T','Y','U','I','O','P','{','}','\n',
    0,'A','S','D','F','G','H','J','K','L',':','"','~',
    0,'|','Z','X','C','V','B','N','M','<','>','?',0,
    '*',0,' ',0,
};

#define SC_LSHIFT 0x2A
#define SC_RSHIFT 0x36
#define SC_LCTRL  0x1D /* Milestone 28 */
#define SC_LALT   0x38 /* Milestone 31 */
#define SC_TAB    0x0F /* Milestone 31: Alt+Tab 판별용(Tab 단독일 땐 기존처럼 '\t') */
#define SC_E0_PREFIX 0xE0

/* 확장(0xE0 xx) 스캔코드 -> 가상 키 코드 */
#define SC_E0_UP    0x48
#define SC_E0_DOWN  0x50
#define SC_E0_LEFT  0x4B
#define SC_E0_RIGHT 0x4D
#define SC_E0_HOME  0x47
#define SC_E0_END   0x4F
#define SC_E0_DEL   0x53
#define SC_E0_PGUP  0x49 /* Milestone 19 */
#define SC_E0_PGDN  0x51 /* Milestone 19 */

/* 일반(비확장) 기능키 스캔코드 */
#define SC_F5 0x3F
#define SC_F6 0x40

/* Milestone 28: 클립보드 단축키 판별용 문자 스캔코드(세트1, 미국 자판) */
#define SC_C 0x2E
#define SC_X 0x2D
#define SC_V 0x2F

static void ring_push(char c) {
    int next = (g_tail + 1) % KBD_BUF_SIZE;
    if (next == g_head) return; /* 버퍼 가득 참: 드롭 */
    g_ring[g_tail] = c;
    g_tail = next;
}

void keyboard_init(void) {
    g_head = g_tail = 0;
    g_shift = 0;
    g_ctrl = 0;
    g_alt = 0;
}

void keyboard_irq_handler(void) {
    uint8_t sc = hal_inb(KBD_DATA_PORT);

    if (sc == SC_E0_PREFIX) { g_extended = 1; return; }

    if (g_extended) {
        g_extended = 0;
        if (sc & 0x80) return; /* 브레이크 코드 무시 */
        char vk = 0;
        switch (sc) {
            case SC_E0_UP:    vk = KEY_UP; break;
            case SC_E0_DOWN:  vk = KEY_DOWN; break;
            case SC_E0_LEFT:  vk = KEY_LEFT; break;
            case SC_E0_RIGHT: vk = KEY_RIGHT; break;
            case SC_E0_HOME:  vk = KEY_HOME; break;
            case SC_E0_END:   vk = KEY_END; break;
            case SC_E0_DEL:   vk = KEY_DEL; break;
            case SC_E0_PGUP:  vk = KEY_PGUP; break;
            case SC_E0_PGDN:  vk = KEY_PGDN; break;
            default: return;
        }
        ring_push(vk);
        return;
    }

    if (sc == SC_LSHIFT || sc == SC_RSHIFT) { g_shift = 1; return; }
    if (sc == (SC_LSHIFT | 0x80) || sc == (SC_RSHIFT | 0x80)) { g_shift = 0; return; }
    if (sc == SC_LCTRL) { g_ctrl = 1; return; }          /* Milestone 28 */
    if (sc == (SC_LCTRL | 0x80)) { g_ctrl = 0; return; } /* Milestone 28 */
    if (sc == SC_LALT) { g_alt = 1; return; }             /* Milestone 31 */
    if (sc == (SC_LALT | 0x80)) { g_alt = 0; return; }    /* Milestone 31 */
    if (sc & 0x80) return; /* 브레이크 코드(키 뗌)는 무시 */
    if (sc == SC_F5) { ring_push((char)KEY_F5); return; }
    if (sc == SC_F6) { ring_push((char)KEY_F6); return; }
    if (g_alt && sc == SC_TAB) { ring_push((char)KEY_ALT_TAB); return; } /* Milestone 31 */
    if (g_ctrl) { /* Milestone 28: Ctrl+C/X/V만 가상 키코드로, 나머지는 평범히 통과 */
        if (sc == SC_C) { ring_push((char)KEY_CTRL_C); return; }
        if (sc == SC_X) { ring_push((char)KEY_CTRL_X); return; }
        if (sc == SC_V) { ring_push((char)KEY_CTRL_V); return; }
    }
    if (sc >= 128) return;

    char c = g_shift ? SC_TO_ASCII_SHIFT[sc] : SC_TO_ASCII[sc];
    if (c) ring_push(c);
}

char keyboard_poll_char(void) {
    if (g_head == g_tail) return 0;
    char c = g_ring[g_head];
    g_head = (g_head + 1) % KBD_BUF_SIZE;
    return c;
}
