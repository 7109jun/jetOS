#ifndef JETOS_APP_CALCULATOR_H
#define JETOS_APP_CALCULATOR_H

/*
 * JetOS - kernel/apps/calculator.h
 * Milestone 35: 계산기. "10가지 목록"엔 없지만, 매일 쓰는 OS에 정말
 * 없으면 아쉬운 것 중 하나로 꼽았다 — 숫자 하나 더하려고 jash에
 * 수식 파서를 새로 넣느니, 클릭 가능한 버튼 그리드가 있는 작은 창을
 * 만드는 게 이 프로젝트의 다른 GUI 앱들(Notepad, Clock)과도 결이
 * 맞는다고 판단했다. +, -, *, /와 소수점만 지원하는 단순 즉시계산기
 * (스택/우선순위 없음 — 누른 순서 그대로 왼쪽에서 오른쪽으로 계산,
 * 대부분의 실물 휴대용 계산기와 같은 동작).
 */
void calculator_launch(void);

#endif
