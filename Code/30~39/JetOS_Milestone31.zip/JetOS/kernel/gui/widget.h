#ifndef JETOS_WIDGET_H
#define JETOS_WIDGET_H

/*
 * JetOS - kernel/gui/widget.h
 * Milestone 19: 재사용 가능한 위젯 툴킷.
 *
 * 지금까지는 Settings의 색상 스와치처럼 앱마다 버튼/입력창을 직접
 * 그리는 방식이었다(공용 컴포넌트 없음, "알려진 한계" 문서 참고).
 * 이 모듈은 그 첫 걸음으로 가장 많이 재사용될 세 가지를 제공한다:
 *   1) widget_button_t   - 클릭 가능한 사각 버튼 (draw + hit test)
 *   2) widget_textbox_t  - 한 줄 편집 가능한 텍스트 입력창
 *   3) widget_draw_scrollable_text() - 스크롤 가능한 여러 줄 텍스트 렌더러
 *      (wm의 content_h/scroll_y와 맞물려 동작, jash/browser에서 사용)
 *
 * 좌표는 전부 "창 콘텐츠 영역 기준 로컬 좌표"가 아니라 앱이 이미
 * 계산해 넘기는 절대(백버퍼) 좌표를 그대로 받는다 — wm의 content_cb가
 * 받는 x,y와 동일한 규약.
 */

#include <stdint.h>
#include "../drivers/console.h"

/* ---------- 버튼 ---------- */
typedef struct {
    int x, y, w, h;
    char label[24];
} widget_button_t;

void widget_button_init(widget_button_t *b, int x, int y, int w, int h, const char *label);
void widget_button_draw(console_t *dc, const widget_button_t *b, uint32_t bg, uint32_t fg, int pressed);
int  widget_button_hit(const widget_button_t *b, int x, int y); /* 절대좌표 */

/* ---------- 한 줄 텍스트박스 ---------- */
#define WIDGET_TEXTBOX_CAP 96

typedef struct {
    int x, y, w, h;
    char buf[WIDGET_TEXTBOX_CAP];
    int len;
    int cursor;
} widget_textbox_t;

void widget_textbox_init(widget_textbox_t *tb, int x, int y, int w, int h, const char *initial);
void widget_textbox_set(widget_textbox_t *tb, const char *text);
/* 키 입력 하나 처리(백스페이스/좌우/Home/End/일반문자/Ctrl+C/X/V —
 * 클립보드는 Milestone 28, widget.h 상단 참고). 엔터는 처리하지
 * 않고 그대로 무시하니, 호출측이 c=='\n'을 먼저 검사해 커밋 동작을 하고
 * 그 경우엔 이 함수를 부르지 않아야 한다. */
void widget_textbox_key(widget_textbox_t *tb, char c);
void widget_textbox_draw(console_t *dc, const widget_textbox_t *tb, int focused);
int  widget_textbox_hit(const widget_textbox_t *tb, int x, int y); /* 절대좌표 */

/* ---------- 스크롤 가능한 여러 줄 텍스트 ---------- */
/* text 안의 '\n'으로 줄을 나눠 y..y+h 범위에만(수직 클리핑) 그린다.
 * scroll_y(px)만큼 위로 스크롤된 상태로 그리며, 실제 계산된 전체
 * 콘텐츠 높이(px)를 반환한다 — 호출측이 wm_set_content_height()에
 * 그대로 넘기면 스크롤바가 자동으로 나타난다. */
int widget_draw_scrollable_text(console_t *dc, int x, int y, int w, int h,
                                 const char *text, int scroll_y, uint32_t color);

#endif
