#pragma once
#include <filesystem>
#include <string>
#include <vector>

namespace deiig {

struct WorkspaceState {
    std::filesystem::path project_dir;
    std::filesystem::path current_file;
    std::vector<std::filesystem::path> open_files;
    std::vector<std::string> terminal_history;
    bool split_view = false;
    int layout_mode = 0;
    std::vector<std::string> browser_urls;
    std::vector<std::string> exe_paths;
};

std::filesystem::path workspace_file(const std::filesystem::path& project_dir);
bool save_workspace(const WorkspaceState& state);
bool load_workspace(const std::filesystem::path& project_dir, WorkspaceState& state);
bool workspace_exists(const std::filesystem::path& project_dir);

} // namespace deiig
