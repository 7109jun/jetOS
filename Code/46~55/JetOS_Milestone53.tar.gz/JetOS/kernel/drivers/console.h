#ifndef JETOS_CONSOLE_H
#define JETOS_CONSOLE_H

#include <stdint.h>

/* Milestone 19: 위젯 툴킷/스크롤 계산용으로 노출한 줄 높이(px).
 * console.c의 내부 LINE_ADVANCE와 반드시 같은 값으로 유지할 것. */
#define CONSOLE_LINE_H 18

typedef struct {
    uint32_t *fb;          /* framebuffer 시작 주소 (32bpp) */
    uint32_t width;
    uint32_t height;
    uint32_t pixels_per_scanline;
    uint32_t cursor_x;
    uint32_t cursor_y;
    uint32_t fg_color;
    uint32_t bg_color;
    /* Milestone 39: 클리핑 사각형 — [clip_x0,clip_x1) x [clip_y0,clip_y1)
     * 바깥의 모든 픽셀 쓰기는 무시된다(console_put_pixel/console_blend_pixel
     * 이 유일한 저수준 픽셀 쓰기 지점이므로 이 구조체 하나만 고치면
     * console_fill_rect/hline/vline/텍스트/위젯 등 모든 상위 그리기 함수가
     * 자동으로 클리핑된다). console_init은 화면 전체로 초기화한다.
     * 창 내용(content_cb)이 자기 창 크기를 넘어 그려서 작업표시줄이나
     * 다른 창 위로 "튀어나오는" 버그의 근본 수정 — wm_draw()가 content_cb를
     * 부르기 직전에 창의 클라이언트 영역으로 clip을 좁혔다가 직후 원복한다. */
    int clip_x0, clip_y0, clip_x1, clip_y1;
} console_t;

void console_init(console_t *con, uint32_t *fb, uint32_t width, uint32_t height, uint32_t pps);
void console_clear(console_t *con, uint32_t color);
void console_put_pixel(console_t *con, uint32_t x, uint32_t y, uint32_t color);

/* Milestone 39: clip rect를 화면 경계로 클램프한 뒤 설정한다. x1/y1은
 * 배타적 경계(즉 실제로 그려지는 마지막 픽셀은 x1-1, y1-1)다. 잘못된
 * 사각형(x0>=x1 등)이 들어오면 아무것도 그려지지 않는 빈 clip이 된다
 * (경고 없이 조용히 — 호출측 실수로 화면이 깨지는 대신 안전 쪽으로). */
void console_set_clip(console_t *con, int x0, int y0, int x1, int y1);
/* clip을 화면 전체로 되돌린다. */
void console_reset_clip(console_t *con);

/* Milestone 23: coverage(0~256, 256=완전 불투명)만큼 color를 그 자리의
 * 실제 프레임버퍼 값과 블렌딩해서 그린다 — 원/별처럼 대각선·곡선
 * 가장자리가 있는 도형을 "픽셀 느낌 없이" 그릴 때 쓴다. coverage<=0이면
 * 아무것도 안 그리고, >=256이면 그냥 단색으로 찍는다(빠른 경로). */
void console_blend_pixel(console_t *con, int x, int y, int coverage, uint32_t color);
void console_fill_rect(console_t *con, uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint32_t color);
void console_putc(console_t *con, char c);
void console_print(console_t *con, const char *s);

#endif
