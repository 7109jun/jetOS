#ifndef JETOS_SYSCALL_H
#define JETOS_SYSCALL_H

#include <stdint.h>

/*
 * JetOS - kernel/hal/syscall.h
 * Milestone 14: INT 0x80 기반 최소 시스템콜 게이트.
 *
 * 호출 규약(단순화된 SysV 유사 방식): RAX=시스템콜 번호, RDI/RSI/RDX=
 * 인자 0~2. 반환값은 RAX. 유저 코드는 `int $0x80` 한 줄로 커널에 진입한다.
 *
 * Milestone 19: 유저 포인터 검증 추가. Milestone 15/16에서 프로세스별
 * 주소공간(PML4)이 생겼음에도, 그때까지는 시스템콜에 유저가 넘긴
 * 포인터가 "정말 그 프로세스의 유저 영역(vmm_user_virt_base()..+
 * vmm_user_region_size()) 안인지" 확인하는 절차가 없었다 — 즉 Ring3
 * 코드가 SYS_WRITE에 커널 힙이나 다른 프로세스 메모리 주소를 넘겨도
 * 커널이 그대로 읽어버리는 신뢰 경계 부재 상태였다. 이제
 * syscall_check_user_range()가 모든 포인터 인자를 시스템콜 진입 시
 * 검증하고, 범위를 벗어나면 그 스레드를 즉시 종료시킨다(커널
 * 전체에는 영향 없음 — Milestone 16의 장애 격리와 동일한 원칙:
 * 유저 실수/공격은 그 프로세스만 죽는다).
 */

typedef struct {
    uint64_t r15, r14, r13, r12, r11, r10, r9, r8;
    uint64_t rbp, rdi, rsi, rdx, rcx, rbx, rax;
} syscall_regs_t;

#define SYS_WRITE   0 /* rdi = const char* (NUL 종료 문자열, 유저 영역 안이어야 함) */
#define SYS_EXIT    1 /* 유저 스레드 종료 (돌아오지 않음) */
#define SYS_GETTICK 2 /* 반환값(rax) = g_timer_ticks */

/* 유저가 넘긴 [ptr, ptr+len) 구간이 현재 실행중인 스레드의 유저
 * 주소공간 안에 완전히 들어있는지 확인한다. 커널 스레드(cr3==0, 즉
 * 공유 커널 주소공간에서 도는 스레드 — 원래 시스템콜을 걸지 않아야
 * 정상이지만 방어적으로 처리)나 범위를 벗어나는 포인터는 0을
 * 반환한다. 오버플로 안전(포인터+길이 wrap-around도 거부). */
int syscall_check_user_range(const void *ptr, uint64_t len);

/* 유저가 넘긴 NUL 종료 문자열 포인터를 검증하며 길이를 센다.
 * max_len 안에서 NUL을 못 찾거나 범위를 벗어나면 -1. */
int64_t syscall_check_user_cstr(const char *ptr, uint64_t max_len);

/* 시스템콜 진입점(naked, 어셈블리) — idt.c가 벡터 0x80에 이 함수를 건다. */
void syscall_entry(void);

/* 실제 처리 로직(순수 C) — syscall_entry가 레지스터를 저장한 뒤 호출한다. */
void syscall_dispatch(syscall_regs_t *regs);

#endif
