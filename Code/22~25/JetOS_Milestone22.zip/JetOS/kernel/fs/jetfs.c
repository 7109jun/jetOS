/*
 * JetOS - kernel/fs/jetfs.c
 * JETFS v1 구현. AHCI를 통해 섹터 단위로 블록을 읽고 쓴다.
 */

#include "jetfs.h"
#include "../drivers/ahci.h"
#include "../mm/heap.h"

static int g_mounted = 0;
static int g_drive = 0;
static uint64_t g_lba_offset = 0;
static jetfs_superblock_t g_sb;
static uint32_t g_bitmap_next_hint = 0; /* Milestone 22: 데이터 블록 비트맵 할당 힌트
                                          * (아래 bitmap_alloc_block 주석 참고) */

#define INODES_PER_BLOCK (JETFS_BLOCK_SIZE / sizeof(jetfs_inode_t))
#define DIRENTS_PER_BLOCK (JETFS_BLOCK_SIZE / sizeof(jetfs_dirent_t))

static int block_read(uint32_t blockno, void *buf) {
    return ahci_read_sectors(g_drive, g_lba_offset + (uint64_t)blockno * JETFS_SECTORS_PER_BLOCK,
                              JETFS_SECTORS_PER_BLOCK, buf);
}
static int block_write(uint32_t blockno, const void *buf) {
    return ahci_write_sectors(g_drive, g_lba_offset + (uint64_t)blockno * JETFS_SECTORS_PER_BLOCK,
                               JETFS_SECTORS_PER_BLOCK, buf);
}

static int str_eq(const char *a, const char *b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}
static void str_copy(char *dst, const char *src, int max) {
    int i = 0;
    for (; i < max - 1 && src[i]; i++) dst[i] = src[i];
    dst[i] = '\0';
}

int jetfs_mount(int drive_index, uint64_t lba_offset) {
    g_drive = drive_index;
    g_lba_offset = lba_offset;

    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(0, buf)) { kfree(buf); return 0; }

    jetfs_superblock_t *sb = (jetfs_superblock_t *)buf;
    if (sb->magic != JETFS_MAGIC) { kfree(buf); return 0; }

    g_sb = *sb;
    g_mounted = 1;
    g_bitmap_next_hint = 0; /* 마운트마다 처음부터(안전한 기본값 — 실제 사용중인
                              * 비트는 스캔 중 자연히 건너뛴다) */
    kfree(buf);
    return 1;
}

/* ---- inode 테이블 I/O ---- */
static int inode_read(uint32_t idx, jetfs_inode_t *out) {
    uint32_t block = g_sb.inode_table_start + idx / INODES_PER_BLOCK;
    uint32_t off = idx % INODES_PER_BLOCK;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(block, buf)) { kfree(buf); return 0; }
    *out = ((jetfs_inode_t *)buf)[off];
    kfree(buf);
    return 1;
}
static int inode_write(uint32_t idx, const jetfs_inode_t *in) {
    uint32_t block = g_sb.inode_table_start + idx / INODES_PER_BLOCK;
    uint32_t off = idx % INODES_PER_BLOCK;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(block, buf)) { kfree(buf); return 0; }
    ((jetfs_inode_t *)buf)[off] = *in;
    int ok = block_write(block, buf);
    kfree(buf);
    return ok;
}

static int inode_alloc(void) {
    jetfs_inode_t tmp;
    for (uint32_t i = 0; i < JETFS_MAX_INODES; i++) {
        if (!inode_read(i, &tmp)) return -1;
        if (!tmp.used) {
            tmp.used = 1;
            tmp.type = JETFS_TYPE_FREE;
            tmp.size = 0;
            tmp.block_count = 0;
            tmp.indirect = 0;
            tmp.double_indirect = 0;
            for (int b = 0; b < JETFS_DIRECT_BLOCKS; b++) tmp.block[b] = 0;
            inode_write(i, &tmp);
            return (int)i;
        }
    }
    return -1;
}

/* ---- 데이터 블록 비트맵 ----
 * Milestone 22에서 발견/수정: 예전 구현은 매 할당마다 비트 0번부터
 * 다시 스캔하면서, 심지어 "비트 하나 확인할 때마다" 그 비트가 속한
 * 디스크 블록을 다시 읽었다(같은 블록 안의 8*4096개 비트를 볼 때도
 * 매번 block_read를 다시 호출) — 사실상 호출 1번이 O(스캔한 비트 수)
 * 만큼의 디스크 읽기였다. 파일이 최대 ~1036블록(4.2MB)이던 시절엔
 * 감내할 만했지만, 이번에 이중 간접 블록으로 파일 크기 상한을 크게
 * 늘리면서 실제로 문제가 됐다 — 4.5MB 파일 하나 쓰는 데 수만 번의
 * 개별 블록 재할당이 쌓이며(각 재할당이 앞서 채워진 블록 수만큼
 * 다시 스캔) 사실상 O(n^2) 디스크 I/O가 되어 부팅 자체 테스트가
 * 끝나지 않는 것으로 나타났다. PMM(kernel/mm/pmm.c)이 이미 쓰고
 * 있던 "다음 빈 자리 힌트" 패턴을 그대로 가져와 ①힌트 이후부터
 * 스캔 시작 ②비트 하나가 아니라 디스크 블록 하나(비트 32768개)를
 * 한 번만 읽어 그 안을 전부 스캔하도록 고쳤다(g_bitmap_next_hint
 * 변수는 파일 위쪽에 다른 전역들과 함께 선언돼 있음). */
static int bitmap_alloc_block(void) {
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return -1;

    uint32_t total_data_blocks = g_sb.total_blocks - g_sb.data_start;
    uint32_t bits_per_block = JETFS_BLOCK_SIZE * 8;

    /* 힌트 이후 먼저 스캔, 못 찾으면 처음부터 힌트 이전까지 스캔
     * (PMM의 pmm_alloc_page()와 동일한 2-패스 구조) */
    for (int pass = 0; pass < 2; pass++) {
        uint32_t start_bit = (pass == 0) ? g_bitmap_next_hint : 0;
        uint32_t end_bit = (pass == 0) ? total_data_blocks : g_bitmap_next_hint;
        if (start_bit >= end_bit) continue;

        uint32_t bit = start_bit;
        while (bit < end_bit) {
            uint32_t byte_block = g_sb.bitmap_start + (bit / 8) / JETFS_BLOCK_SIZE;
            if (!block_read(byte_block, buf)) { kfree(buf); return -1; }

            /* 이 디스크 블록이 커버하는 비트 범위 안에서(그리고 스캔
             * 상한을 넘지 않는 선에서) 한 번 읽은 buf로 전부 스캔 */
            uint32_t block_bit_start = (bit / bits_per_block) * bits_per_block;
            uint32_t block_bit_end = block_bit_start + bits_per_block;
            if (block_bit_end > end_bit) block_bit_end = end_bit;

            for (uint32_t b = bit; b < block_bit_end; b++) {
                uint32_t byte_off = (b / 8) % JETFS_BLOCK_SIZE;
                if (!(buf[byte_off] & (1 << (b % 8)))) {
                    buf[byte_off] |= (uint8_t)(1 << (b % 8));
                    if (!block_write(byte_block, buf)) { kfree(buf); return -1; }
                    kfree(buf);
                    g_bitmap_next_hint = b + 1;
                    return (int)(g_sb.data_start + b);
                }
            }
            bit = block_bit_end;
        }
    }
    kfree(buf);
    return -1;
}

static int bitmap_free_block(uint32_t blockno) {
    if (blockno < g_sb.data_start) return 0;
    uint32_t bit = blockno - g_sb.data_start;
    uint32_t byte_block = g_sb.bitmap_start + (bit / 8) / JETFS_BLOCK_SIZE;
    uint32_t byte_off   = (bit / 8) % JETFS_BLOCK_SIZE;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(byte_block, buf)) { kfree(buf); return 0; }
    buf[byte_off] &= (uint8_t)~(1 << (bit % 8));
    int ok = block_write(byte_block, buf);
    kfree(buf);
    if (ok && bit < g_bitmap_next_hint) g_bitmap_next_hint = bit; /* 다음 할당이 이 빈자리부터 찾도록 */
    return ok;
}

/* ---- 파일 블록 매핑: 직접(0..11) + 간접(12..1035) + 이중간접
 * (1036..1049611) 인덱스를 실제 데이터 블록 번호로 변환한다.
 * allocate=1이면 없는 블록을 새로 할당하고(간접/이중간접 블록 자체도
 * 필요하면 할당), allocate=0이면 조회만 하고 없으면 0을 반환한다
 * (에러가 아니라 "구멍"으로 취급). ---- */
static int file_block_map(jetfs_inode_t *inode, uint32_t index, int allocate, uint32_t *out_blockno) {
    if (index >= JETFS_MAX_FILE_BLOCKS) return 0; /* 범위 초과 */

    if (index < JETFS_DIRECT_BLOCKS) {
        if (inode->block[index] == 0 && allocate) {
            int nb = bitmap_alloc_block();
            if (nb < 0) return 0;
            inode->block[index] = (uint32_t)nb;
        }
        *out_blockno = inode->block[index];
        return 1;
    }

    if (index < JETFS_DIRECT_BLOCKS + JETFS_INDIRECT_PTRS) {
        uint32_t iidx = index - JETFS_DIRECT_BLOCKS;
        if (inode->indirect == 0) {
            if (!allocate) { *out_blockno = 0; return 1; }
            int nb = bitmap_alloc_block();
            if (nb < 0) return 0;
            inode->indirect = (uint32_t)nb;
            uint8_t *zbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
            if (!zbuf) return 0;
            for (int i = 0; i < JETFS_BLOCK_SIZE; i++) zbuf[i] = 0;
            int ok = block_write(inode->indirect, zbuf);
            kfree(zbuf);
            if (!ok) return 0;
        }

        uint8_t *ibuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (!ibuf) return 0;
        if (!block_read(inode->indirect, ibuf)) { kfree(ibuf); return 0; }
        uint32_t *ptrs = (uint32_t *)ibuf;

        if (ptrs[iidx] == 0 && allocate) {
            int nb = bitmap_alloc_block();
            if (nb < 0) { kfree(ibuf); return 0; }
            ptrs[iidx] = (uint32_t)nb;
            if (!block_write(inode->indirect, ibuf)) { kfree(ibuf); return 0; }
        }
        *out_blockno = ptrs[iidx];
        kfree(ibuf);
        return 1;
    }

    /* 이중 간접 영역 (Milestone 22) */
    uint32_t didx = index - JETFS_DIRECT_BLOCKS - JETFS_INDIRECT_PTRS;
    uint32_t group = didx / JETFS_INDIRECT_PTRS;       /* 어느 간접 블록인지 (0..1023) */
    uint32_t sub   = didx % JETFS_INDIRECT_PTRS;        /* 그 간접 블록 안에서 몇 번째인지 */

    if (inode->double_indirect == 0) {
        if (!allocate) { *out_blockno = 0; return 1; }
        int nb = bitmap_alloc_block();
        if (nb < 0) return 0;
        inode->double_indirect = (uint32_t)nb;
        uint8_t *zbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (!zbuf) return 0;
        for (int i = 0; i < JETFS_BLOCK_SIZE; i++) zbuf[i] = 0;
        int ok = block_write(inode->double_indirect, zbuf);
        kfree(zbuf);
        if (!ok) return 0;
    }

    uint8_t *dibuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!dibuf) return 0;
    if (!block_read(inode->double_indirect, dibuf)) { kfree(dibuf); return 0; }
    uint32_t *dptrs = (uint32_t *)dibuf;

    if (dptrs[group] == 0) {
        if (!allocate) { kfree(dibuf); *out_blockno = 0; return 1; }
        int nb = bitmap_alloc_block();
        if (nb < 0) { kfree(dibuf); return 0; }
        dptrs[group] = (uint32_t)nb;
        if (!block_write(inode->double_indirect, dibuf)) { kfree(dibuf); return 0; }
        uint8_t *zbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (!zbuf) { kfree(dibuf); return 0; }
        for (int i = 0; i < JETFS_BLOCK_SIZE; i++) zbuf[i] = 0;
        int ok = block_write(dptrs[group], zbuf);
        kfree(zbuf);
        if (!ok) { kfree(dibuf); return 0; }
    }
    uint32_t indirect_block = dptrs[group];
    kfree(dibuf);

    uint8_t *ibuf2 = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!ibuf2) return 0;
    if (!block_read(indirect_block, ibuf2)) { kfree(ibuf2); return 0; }
    uint32_t *ptrs2 = (uint32_t *)ibuf2;

    if (ptrs2[sub] == 0 && allocate) {
        int nb = bitmap_alloc_block();
        if (nb < 0) { kfree(ibuf2); return 0; }
        ptrs2[sub] = (uint32_t)nb;
        if (!block_write(indirect_block, ibuf2)) { kfree(ibuf2); return 0; }
    }
    *out_blockno = ptrs2[sub];
    kfree(ibuf2);
    return 1;
}

/* index 블록(및 필요하면 그 이상 전부)을 비트맵에서 해제하고 간접/
 * 이중간접 테이블 항목도 0으로 지운다. allocate 없이 조회 전용으로 쓰인다. */
static void file_block_free(jetfs_inode_t *inode, uint32_t index) {
    if (index < JETFS_DIRECT_BLOCKS) {
        if (inode->block[index]) {
            bitmap_free_block(inode->block[index]);
            inode->block[index] = 0;
        }
        return;
    }
    if (index < JETFS_DIRECT_BLOCKS + JETFS_INDIRECT_PTRS) {
        if (inode->indirect == 0) return;
        uint32_t iidx = index - JETFS_DIRECT_BLOCKS;
        uint8_t *ibuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (!ibuf) return;
        if (!block_read(inode->indirect, ibuf)) { kfree(ibuf); return; }
        uint32_t *ptrs = (uint32_t *)ibuf;
        if (ptrs[iidx]) {
            bitmap_free_block(ptrs[iidx]);
            ptrs[iidx] = 0;
            block_write(inode->indirect, ibuf);
        }
        kfree(ibuf);
        return;
    }

    /* 이중 간접 영역 */
    if (inode->double_indirect == 0) return;
    uint32_t didx = index - JETFS_DIRECT_BLOCKS - JETFS_INDIRECT_PTRS;
    uint32_t group = didx / JETFS_INDIRECT_PTRS;
    uint32_t sub   = didx % JETFS_INDIRECT_PTRS;

    uint8_t *dibuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!dibuf) return;
    if (!block_read(inode->double_indirect, dibuf)) { kfree(dibuf); return; }
    uint32_t *dptrs = (uint32_t *)dibuf;
    uint32_t indirect_block = dptrs[group];
    kfree(dibuf);
    if (indirect_block == 0) return;

    uint8_t *ibuf2 = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!ibuf2) return;
    if (!block_read(indirect_block, ibuf2)) { kfree(ibuf2); return; }
    uint32_t *ptrs2 = (uint32_t *)ibuf2;
    if (ptrs2[sub]) {
        bitmap_free_block(ptrs2[sub]);
        ptrs2[sub] = 0;
        block_write(indirect_block, ibuf2);
    }
    kfree(ibuf2);
}

/* 파일의 모든 데이터 블록(직접+간접+이중간접) 및 그 메타 블록들을 회수한다. */
static void file_free_all_blocks(jetfs_inode_t *inode) {
    for (int i = 0; i < JETFS_DIRECT_BLOCKS; i++) {
        if (inode->block[i]) { bitmap_free_block(inode->block[i]); inode->block[i] = 0; }
    }
    if (inode->indirect) {
        bitmap_free_block(inode->indirect);
        inode->indirect = 0;
    }
    if (inode->double_indirect) {
        uint8_t *dibuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        uint8_t *leafbuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
        if (dibuf && leafbuf) {
            if (block_read(inode->double_indirect, dibuf)) {
                uint32_t *dptrs = (uint32_t *)dibuf;
                for (uint32_t g = 0; g < JETFS_DOUBLE_INDIRECT_PTRS; g++) {
                    if (!dptrs[g]) continue;
                    /* 이 간접 블록이 가리키는 실제 데이터(리프) 블록들을
                     * 먼저 전부 회수하고, 그 다음 간접 블록 자체를 회수 */
                    if (block_read(dptrs[g], leafbuf)) {
                        uint32_t *leaf_ptrs = (uint32_t *)leafbuf;
                        for (uint32_t s = 0; s < JETFS_INDIRECT_PTRS; s++) {
                            if (leaf_ptrs[s]) bitmap_free_block(leaf_ptrs[s]);
                        }
                    }
                    bitmap_free_block(dptrs[g]);
                }
            }
        }
        if (dibuf) kfree(dibuf);
        if (leafbuf) kfree(leafbuf);
        bitmap_free_block(inode->double_indirect);
        inode->double_indirect = 0;
    }
}

/* ---- 디렉터리 순회 ---- */
static int dir_find(uint32_t dir_inode_idx, const char *name,
                     uint32_t *out_block, uint32_t *out_slot, uint32_t *out_inode) {
    jetfs_inode_t dir;
    if (!inode_read(dir_inode_idx, &dir)) return 0;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    for (uint32_t b = 0; b < dir.block_count; b++) {
        if (!block_read(dir.block[b], buf)) continue;
        jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
        for (uint32_t s = 0; s < DIRENTS_PER_BLOCK; s++) {
            if (ents[s].used && str_eq(ents[s].name, name)) {
                if (out_block) *out_block = dir.block[b];
                if (out_slot) *out_slot = s;
                if (out_inode) *out_inode = ents[s].inode;
                kfree(buf);
                return 1;
            }
        }
    }
    kfree(buf);
    return 0;
}

static int dir_add(uint32_t dir_inode_idx, const char *name, uint32_t inode_idx) {
    jetfs_inode_t dir;
    if (!inode_read(dir_inode_idx, &dir)) return 0;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    for (uint32_t b = 0; b < dir.block_count; b++) {
        if (!block_read(dir.block[b], buf)) continue;
        jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
        for (uint32_t s = 0; s < DIRENTS_PER_BLOCK; s++) {
            if (!ents[s].used) {
                str_copy(ents[s].name, name, JETFS_MAX_NAME);
                ents[s].inode = inode_idx;
                ents[s].used = 1;
                int ok = block_write(dir.block[b], buf);
                kfree(buf);
                return ok;
            }
        }
    }

    /* 기존 블록에 빈 슬롯이 없음 -> 새 블록 추가 */
    if (dir.block_count >= JETFS_DIRECT_BLOCKS) { kfree(buf); return 0; }
    int newblock = bitmap_alloc_block();
    if (newblock < 0) { kfree(buf); return 0; }

    for (int i = 0; i < JETFS_BLOCK_SIZE; i++) buf[i] = 0;
    jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
    str_copy(ents[0].name, name, JETFS_MAX_NAME);
    ents[0].inode = inode_idx;
    ents[0].used = 1;
    if (!block_write((uint32_t)newblock, buf)) { kfree(buf); return 0; }

    dir.block[dir.block_count] = (uint32_t)newblock;
    dir.block_count++;
    inode_write(dir_inode_idx, &dir);
    kfree(buf);
    return 1;
}

static int dir_remove(uint32_t dir_inode_idx, const char *name) {
    uint32_t block, slot, inode_idx;
    if (!dir_find(dir_inode_idx, name, &block, &slot, &inode_idx)) return 0;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;
    if (!block_read(block, buf)) { kfree(buf); return 0; }
    jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
    ents[slot].used = 0;
    int ok = block_write(block, buf);
    kfree(buf);
    return ok;
}

/* ---- 경로 해석: "/a/b/c" -> 부모 디렉터리 inode + 마지막 구성요소 이름 ---- */
static int resolve_parent(const char *path, uint32_t *out_parent_inode, char *out_name) {
    if (!path || path[0] != '/') return 0;
    uint32_t cur = g_sb.root_inode;
    int i = 1;
    char comp[JETFS_MAX_NAME];

    while (path[i]) {
        int c = 0;
        while (path[i] && path[i] != '/' && c < JETFS_MAX_NAME - 1) comp[c++] = path[i++];
        comp[c] = '\0';
        while (path[i] == '/') i++;

        if (!path[i]) { /* comp가 마지막 구성요소 */
            *out_parent_inode = cur;
            str_copy(out_name, comp, JETFS_MAX_NAME);
            return 1;
        }
        uint32_t next_inode;
        if (!dir_find(cur, comp, NULL, NULL, &next_inode)) return 0;
        cur = next_inode;
    }
    return 0; /* 빈 경로 또는 "/" 자체 */
}

static int resolve(const char *path, uint32_t *out_inode) {
    if (str_eq(path, "/")) { *out_inode = g_sb.root_inode; return 1; }
    uint32_t parent;
    char name[JETFS_MAX_NAME];
    if (!resolve_parent(path, &parent, name)) return 0;
    return dir_find(parent, name, NULL, NULL, out_inode);
}

/* ---- 공개 API ---- */
int jetfs_create(const char *path, jetfs_inode_type_t type) {
    if (!g_mounted) return 0;
    uint32_t parent;
    char name[JETFS_MAX_NAME];
    if (!resolve_parent(path, &parent, name)) return 0;

    uint32_t existing;
    if (dir_find(parent, name, NULL, NULL, &existing)) return 0; /* 이미 존재 */

    int new_inode = inode_alloc();
    if (new_inode < 0) return 0;

    jetfs_inode_t inode;
    inode_read((uint32_t)new_inode, &inode);
    inode.type = (uint32_t)type;
    inode.size = 0;
    inode.block_count = 0;
    inode.indirect = 0;
    inode.double_indirect = 0;
    inode_write((uint32_t)new_inode, &inode);

    return dir_add(parent, name, (uint32_t)new_inode);
}

int jetfs_read(const char *path, void *buffer, uint32_t max_size, uint32_t *out_size) {
    if (!g_mounted) return 0;
    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    if (inode.type != JETFS_TYPE_FILE) return 0;

    uint32_t to_read = inode.size < max_size ? inode.size : max_size;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    uint32_t done = 0;
    uint32_t block_idx = 0;
    while (done < to_read) {
        uint32_t blockno = 0;
        if (!file_block_map(&inode, block_idx, 0, &blockno) || blockno == 0) break; /* 구멍/오류: 여기서 중단 */
        if (!block_read(blockno, buf)) { kfree(buf); return 0; }
        uint32_t chunk = to_read - done;
        if (chunk > JETFS_BLOCK_SIZE) chunk = JETFS_BLOCK_SIZE;
        uint8_t *dst = (uint8_t *)buffer + done;
        for (uint32_t k = 0; k < chunk; k++) dst[k] = buf[k];
        done += chunk;
        block_idx++;
    }
    kfree(buf);
    if (out_size) *out_size = done;
    return 1;
}

int jetfs_write(const char *path, const void *data, uint32_t size) {
    if (!g_mounted) return 0;
    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    if (inode.type != JETFS_TYPE_FILE) return 0;

    uint32_t blocks_needed = (size + JETFS_BLOCK_SIZE - 1) / JETFS_BLOCK_SIZE;
    if (blocks_needed > JETFS_MAX_FILE_BLOCKS) return 0; /* Milestone 22: 직접12 + 간접1024 + 이중간접(1024*1024) ≈ 4.3GB */

    /* 필요한 만큼 블록을 매핑/할당(직접 -> 필요하면 간접까지) */
    for (uint32_t b = 0; b < blocks_needed; b++) {
        uint32_t blockno;
        if (!file_block_map(&inode, b, 1, &blockno) || blockno == 0) return 0;
    }

    /* 재작성으로 크기가 줄었으면 남는 블록을 뒤에서부터 회수 */
    uint32_t old_blocks = (inode.size + JETFS_BLOCK_SIZE - 1) / JETFS_BLOCK_SIZE;
    if (old_blocks > blocks_needed) {
        for (uint32_t b = old_blocks; b > blocks_needed; b--) file_block_free(&inode, b - 1);

        if (blocks_needed <= JETFS_DIRECT_BLOCKS + JETFS_INDIRECT_PTRS && inode.double_indirect) {
            /* 이중 간접 트리 전체가 더는 필요 없으면(위 루프가 그 안의
             * 리프 데이터 블록들은 이미 다 비워둔 상태) 그 "껍데기"
             * (간접 블록들 + 이중간접 블록 자체)까지 마저 회수한다. */
            uint8_t *dibuf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
            if (dibuf && block_read(inode.double_indirect, dibuf)) {
                uint32_t *dptrs = (uint32_t *)dibuf;
                for (uint32_t g = 0; g < JETFS_DOUBLE_INDIRECT_PTRS; g++) {
                    if (dptrs[g]) bitmap_free_block(dptrs[g]);
                }
            }
            if (dibuf) kfree(dibuf);
            bitmap_free_block(inode.double_indirect);
            inode.double_indirect = 0;
        }
        if (blocks_needed <= JETFS_DIRECT_BLOCKS && inode.indirect) {
            /* 간접 블록이 더는 필요 없으면(전부 직접 블록으로 커버) 통째로 회수 */
            bitmap_free_block(inode.indirect);
            inode.indirect = 0;
        }
    }

    const uint8_t *src = (const uint8_t *)data;
    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    uint32_t done = 0;
    for (uint32_t b = 0; b < blocks_needed; b++) {
        uint32_t blockno;
        file_block_map(&inode, b, 0, &blockno); /* 위에서 이미 할당했으므로 조회만 */
        uint32_t chunk = size - done;
        if (chunk > JETFS_BLOCK_SIZE) chunk = JETFS_BLOCK_SIZE;
        for (uint32_t k = 0; k < JETFS_BLOCK_SIZE; k++) buf[k] = (k < chunk) ? src[done + k] : 0;
        if (!block_write(blockno, buf)) { kfree(buf); return 0; }
        done += chunk;
    }
    kfree(buf);

    inode.size = size;
    return inode_write(idx, &inode);
}

int jetfs_delete(const char *path) {
    if (!g_mounted) return 0;
    uint32_t parent;
    char name[JETFS_MAX_NAME];
    if (!resolve_parent(path, &parent, name)) return 0;

    uint32_t idx;
    if (!dir_find(parent, name, NULL, NULL, &idx)) return 0;

    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;

    /* 데이터 블록 비트맵 회수.
     * 디렉터리는 block_count로 사용중인 직접 블록 개수를 추적한다.
     * 파일은 크기(size)로부터 필요 블록 수를 매번 계산하므로
     * block_count를 쓰지 않는다 — 그냥 할당된 직접 블록 12개 전부와
     * 간접 블록(있다면) 안의 모든 항목을 회수한다. */
    if (inode.type == JETFS_TYPE_FILE) {
        file_free_all_blocks(&inode);
    } else {
        for (uint32_t b = 0; b < inode.block_count; b++) {
            bitmap_free_block(inode.block[b]);
            inode.block[b] = 0;
        }
        inode.block_count = 0;
    }
    inode.size = 0;
    inode.used = 0;
    inode.type = JETFS_TYPE_FREE;
    inode_write(idx, &inode);

    return dir_remove(parent, name);
}

int jetfs_rename(const char *old_path, const char *new_path) {
    if (!g_mounted) return 0;
    uint32_t old_parent, new_parent;
    char old_name[JETFS_MAX_NAME], new_name[JETFS_MAX_NAME];
    if (!resolve_parent(old_path, &old_parent, old_name)) return 0;
    if (!resolve_parent(new_path, &new_parent, new_name)) return 0;

    uint32_t idx;
    if (!dir_find(old_parent, old_name, NULL, NULL, &idx)) return 0;
    if (!dir_remove(old_parent, old_name)) return 0;
    return dir_add(new_parent, new_name, idx);
}

int jetfs_stat(const char *path, jetfs_inode_type_t *out_type, uint32_t *out_size) {
    if (!g_mounted) return 0;
    uint32_t idx;
    if (!resolve(path, &idx)) return 0;
    jetfs_inode_t inode;
    if (!inode_read(idx, &inode)) return 0;
    if (out_type) *out_type = (jetfs_inode_type_t)inode.type;
    if (out_size) *out_size = inode.size;
    return 1;
}

int jetfs_list(const char *dir_path, jetfs_list_cb cb, void *ctx) {
    if (!g_mounted) return 0;
    uint32_t dir_idx;
    if (!resolve(dir_path, &dir_idx)) return 0;

    jetfs_inode_t dir;
    if (!inode_read(dir_idx, &dir)) return 0;
    if (dir.type != JETFS_TYPE_DIR) return 0;

    uint8_t *buf = (uint8_t *)kmalloc(JETFS_BLOCK_SIZE);
    if (!buf) return 0;

    for (uint32_t b = 0; b < dir.block_count; b++) {
        if (!block_read(dir.block[b], buf)) continue;
        jetfs_dirent_t *ents = (jetfs_dirent_t *)buf;
        for (uint32_t s = 0; s < DIRENTS_PER_BLOCK; s++) {
            if (!ents[s].used) continue;
            jetfs_inode_t child;
            if (!inode_read(ents[s].inode, &child)) continue;
            cb(ents[s].name, (jetfs_inode_type_t)child.type, child.size, ctx);
        }
    }
    kfree(buf);
    return 1;
}
