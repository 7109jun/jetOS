kernel/net/dns.o: kernel/net/dns.c kernel/net/dns.h kernel/net/net.h \
 kernel/net/udp.h kernel/net/../int/pit.h
kernel/net/dns.h:
kernel/net/net.h:
kernel/net/udp.h:
kernel/net/../int/pit.h:
