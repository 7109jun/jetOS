kernel/drivers/speaker.o: kernel/drivers/speaker.c \
 kernel/drivers/speaker.h kernel/drivers/../hal/x86_asm_shim.h \
 kernel/drivers/../int/pit.h kernel/drivers/../proc/scheduler.h \
 kernel/drivers/../proc/thread.h
kernel/drivers/speaker.h:
kernel/drivers/../hal/x86_asm_shim.h:
kernel/drivers/../int/pit.h:
kernel/drivers/../proc/scheduler.h:
kernel/drivers/../proc/thread.h:
