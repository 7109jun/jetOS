boot/elf_loader.o: boot/elf_loader.c boot/elf_loader.h \
 boot/../include/efi/efi.h boot/elf64.h
boot/elf_loader.h:
boot/../include/efi/efi.h:
boot/elf64.h:
