#include "panic.h"
#include "kernel.h"
#include "drivers/serial.h"
#include "hal/x86_asm_shim.h"

void jetos_panic(const char *reason, uint64_t code, uint64_t addr) {
    hal_cli();

    console_fill_rect(&g_console, 0, 0, g_console.width, g_console.height, 0x00990000);
    g_console.cursor_x = 20;
    g_console.cursor_y = 20;
    g_console.fg_color = 0x00FFFFFF;
    console_print(&g_console, "JETOS KERNEL PANIC");
    g_console.cursor_x = 20;
    g_console.cursor_y += 20;
    console_print(&g_console, reason);

    serial_write("\n[JETOS PANIC] ");
    serial_write(reason);
    serial_write(" code=");
    serial_write_hex64(code);
    serial_write(" addr=");
    serial_write_hex64(addr);
    serial_write("\nSystem halted.\n");

    for (;;) {
        hal_hlt();
    }
}
