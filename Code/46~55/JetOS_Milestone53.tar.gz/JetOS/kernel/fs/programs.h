#ifndef JETOS_PROGRAMS_H
#define JETOS_PROGRAMS_H

/*
 * JetOS - kernel/fs/programs.h
 * Milestone 37: 소프트웨어 설치/제거 체계 ("10가지 목록" 9번, M34/M35/M36
 * 문서에 계속 이월돼 있던 항목).
 *
 * 지금까지 JCC(M30)나 PE로 만든 프로그램을 쓰려면 매번 정확한 경로를
 * 외워서 jash에 `run /어딘가/파일`을 타이핑해야 했다 — "설치"라는 개념
 * 자체가 없었다. 이번에 아주 단순한 등록부(registry)를 추가했다:
 *   - /system/programs.txt에 "이름|경로" 형식으로 한 줄씩 저장.
 *   - install(name, path): 이름 중복 방지하며 등록.
 *   - uninstall(name): 등록부에서 지우고 실행파일 자체도 삭제(휴지통행 —
 *     recyclebin.c 재사용, 실수로 지워도 복구 가능).
 *   - list(cb, ctx): 등록된 전체 프로그램을 순회.
 *
 * 정직한 한계: 이건 "패키지 관리자"가 아니다 — 의존성 해석도, 버전
 * 관리도, 다운로드도 없다. 이미 JETFS 어딘가에 있는 실행파일 하나에
 * 사람이 기억하기 쉬운 이름을 붙이고 시작메뉴류 UI에서 클릭으로 실행/
 * 제거할 수 있게 해주는 "등록부"에 가깝다. */

/* name(예: "MyGame")으로 path(예: "/games/mygame.elf")를 등록한다.
 * 이름이 이미 등록돼 있으면 실패(0 반환) — 덮어쓰려면 먼저
 * programs_uninstall()로 지울 것. 등록 파일이 없으면 새로 만든다. */
int programs_install(const char *name, const char *path);

/* name으로 등록된 프로그램을 찾아 등록부에서 지우고, 그 경로의
 * 실행파일 자체도 휴지통으로 이동시킨다(recyclebin_delete 재사용).
 * 등록만 지우고 파일은 남겨두고 싶다면 이 함수 대신 앱단에서 직접
 * 등록부만 다시 쓰는 걸 고려할 것 — 지금은 "설치 제거하면 파일도
 * 같이 없앤다"는 단순한 동작만 제공한다. 성공 1, 실패(이름 없음 등) 0. */
int programs_uninstall(const char *name);

typedef void (*programs_list_cb)(const char *name, const char *path, void *ctx);
/* 등록된 프로그램을 전부 콜백으로 알려준다. 반환값은 개수. */
int programs_list(programs_list_cb cb, void *ctx);

#endif
