/*
 * JetOS - kernel/fs/fat32.c
 * fat32.h 참고. 루트 디렉터리만, 8.3 짧은 이름만. Milestone 26에서
 * 쓰기(파일 생성/덮어쓰기) 추가.
 */
#include "fat32.h"
#include "../drivers/ahci.h"

#define SECTOR_SIZE 512
#define MAX_CLUSTER_SECTORS 128 /* 클러스터당 최대 64KB(128*512)까지 지원 */
#define FAT32_EOC 0x0FFFFFFFu   /* end-of-chain 마커로 쓸 값(표준상 0x0FFFFFF8~F 아무거나 가능, FF로 통일) */

static int g_drive = -1;
static uint32_t g_fat_start_lba;
static uint32_t g_data_start_lba;
static uint32_t g_sectors_per_cluster;
static uint32_t g_root_cluster;
static uint32_t g_bytes_per_cluster;
static uint32_t g_num_fats;        /* Milestone 26: FAT 사본 개수(보통 2) — 쓸 때 전부 갱신 */
static uint32_t g_fat_size_32;     /* Milestone 26: FAT 하나의 섹터 수(사본 간 LBA 간격 계산용) */
static uint32_t g_total_clusters;  /* Milestone 26: 빈 클러스터 탐색 상한(디스크 끝 판단용) */

static uint16_t rd_u16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t rd_u32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static void wr_u16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void wr_u32(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24);
}

int fat32_mount(int drive_index) {
    uint8_t boot[SECTOR_SIZE];
    if (!ahci_read_sectors(drive_index, 0, 1, boot)) return 0;

    if (boot[510] != 0x55 || boot[511] != 0xAA) return 0; /* 부트섹터 시그니처 */

    uint16_t bytes_per_sector = rd_u16(boot + 11);
    if (bytes_per_sector != SECTOR_SIZE) return 0; /* 알려진 단순화(fat32.h 참고) */

    uint8_t sectors_per_cluster = boot[13];
    uint16_t reserved_sectors = rd_u16(boot + 14);
    uint8_t num_fats = boot[16];
    uint16_t root_entry_count = rd_u16(boot + 17); /* FAT32면 0이어야 정상 */
    uint32_t fat_size_16 = rd_u16(boot + 22);
    uint32_t fat_size_32 = rd_u32(boot + 36);
    uint32_t root_cluster = rd_u32(boot + 44);
    uint16_t total_sectors_16 = rd_u16(boot + 19);
    uint32_t total_sectors_32 = rd_u32(boot + 32);
    uint32_t total_sectors = total_sectors_16 ? total_sectors_16 : total_sectors_32; /* Milestone 26 */

    if (root_entry_count != 0) return 0;   /* FAT12/16 특징 — FAT32 아님 */
    if (fat_size_16 != 0) return 0;
    if (fat_size_32 == 0) return 0;
    if (sectors_per_cluster == 0 || (uint32_t)sectors_per_cluster > MAX_CLUSTER_SECTORS) return 0;

    g_drive = drive_index;
    g_fat_start_lba = reserved_sectors;
    g_data_start_lba = reserved_sectors + (uint32_t)num_fats * fat_size_32;
    g_sectors_per_cluster = sectors_per_cluster;
    g_root_cluster = root_cluster;
    g_bytes_per_cluster = (uint32_t)sectors_per_cluster * SECTOR_SIZE;
    g_num_fats = num_fats;
    g_fat_size_32 = fat_size_32;
    g_total_clusters = (total_sectors > g_data_start_lba)
        ? (total_sectors - g_data_start_lba) / g_sectors_per_cluster
        : 0;
    return 1;
}

static uint32_t cluster_to_lba(uint32_t cluster) {
    return g_data_start_lba + (cluster - 2) * g_sectors_per_cluster;
}

static uint32_t fat_next_cluster(uint32_t cluster) {
    uint32_t byte_off = cluster * 4;
    uint32_t sector = g_fat_start_lba + byte_off / SECTOR_SIZE;
    uint32_t off_in_sector = byte_off % SECTOR_SIZE;

    uint8_t sec[SECTOR_SIZE];
    if (!ahci_read_sectors(g_drive, sector, 1, sec)) return 0x0FFFFFFF; /* 에러 시 체인 끝 취급 */
    uint32_t v = rd_u32(sec + off_in_sector) & 0x0FFFFFFFu;
    return v;
}

static int is_end_of_chain(uint32_t cluster) {
    return cluster >= 0x0FFFFFF8u || cluster < 2;
}

/* ---- Milestone 26: 쓰기 지원 ---- */

/* FAT[cluster] = value를 모든 FAT 사본에 반영한다(상위 4비트는 예약이라
 * 보존). 사본마다 섹터를 매번 다시 읽고 쓰는 방식이라 큰 파일(클러스터
 * 수가 많은 경우)에서는 느릴 수 있다 — 알려진 한계, fat32.h 참고. */
static void fat_set_next_cluster(uint32_t cluster, uint32_t value) {
    if (g_drive < 0) return;
    uint32_t byte_off = cluster * 4;
    uint32_t sector_in_fat = byte_off / SECTOR_SIZE;
    uint32_t off_in_sector = byte_off % SECTOR_SIZE;
    uint8_t sec[SECTOR_SIZE];
    for (uint32_t copy = 0; copy < g_num_fats; copy++) {
        uint32_t lba = g_fat_start_lba + copy * g_fat_size_32 + sector_in_fat;
        if (!ahci_read_sectors(g_drive, lba, 1, sec)) continue;
        uint32_t old = rd_u32(sec + off_in_sector);
        wr_u32(sec + off_in_sector, (old & 0xF0000000u) | (value & 0x0FFFFFFFu));
        ahci_write_sectors(g_drive, lba, 1, sec);
    }
}

/* cluster부터 이어지는 체인 전체를 반납(FAT 엔트리를 전부 0으로)한다.
 * 데이터 자체는 지우지 않는다(대부분의 파일시스템과 동일 — 새 파일이
 * 그 자리를 재사용할 때 덮어써질 뿐). */
static void free_cluster_chain(uint32_t cluster) {
    int guard = 0;
    while (!is_end_of_chain(cluster) && ++guard < 1000000) {
        uint32_t next = fat_next_cluster(cluster);
        fat_set_next_cluster(cluster, 0);
        cluster = next;
    }
}

/* start_hint부터 순서대로(끝까지 가면 2부터 다시) FAT를 훑어 값이 0인
 * (=비어있는) 첫 클러스터 번호를 찾는다. 없으면 0(디스크 꽉 참). */
static uint32_t find_free_cluster(uint32_t start_hint) {
    if (g_total_clusters == 0) return 0;
    uint32_t max_cluster = g_total_clusters + 2; /* 클러스터 번호는 2부터 시작 */
    for (uint32_t c = start_hint; c < max_cluster; c++) {
        if (fat_next_cluster(c) == 0) return c;
    }
    for (uint32_t c = 2; c < start_hint && c < max_cluster; c++) {
        if (fat_next_cluster(c) == 0) return c;
    }
    return 0;
}

/* data(len바이트)를 새 클러스터 체인에 쓰고 첫 클러스터 번호를 반환한다.
 * len==0이면 클러스터가 필요 없으므로 0(FAT32에서 "클러스터 없음"과
 * 동일한 값 — 0바이트 파일의 정상적인 표현). 디스크가 꽉 차서 실패하면
 * 0xFFFFFFFF(센티널, 0바이트 파일과 구분하기 위함)를 반환하고 이미
 * 할당했던 클러스터는 전부 반납한다(부분 실패 상태를 남기지 않음). */
static uint32_t allocate_and_write_chain(const uint8_t *data, uint32_t len) {
    if (len == 0) return 0;
    uint32_t clusters_needed = (len + g_bytes_per_cluster - 1) / g_bytes_per_cluster;
    uint32_t first = 0, prev = 0, written = 0, search_from = 2;
    static uint8_t wbuf[MAX_CLUSTER_SECTORS * SECTOR_SIZE]; /* walk_root/fat32_read_file의
                                                               * static 버퍼들과는 별개 심볼 —
                                                               * 동시 사용은 안 한다는 전제 동일 */
    for (uint32_t i = 0; i < clusters_needed; i++) {
        uint32_t c = find_free_cluster(search_from);
        if (c == 0) {
            if (first) free_cluster_chain(first);
            return 0xFFFFFFFFu;
        }
        fat_set_next_cluster(c, FAT32_EOC); /* 다음 탐색에서 다시 "빈 클러스터"로 안 보이게 즉시 예약 */
        if (prev) fat_set_next_cluster(prev, c); else first = c;

        uint32_t chunk = g_bytes_per_cluster;
        if (written + chunk > len) chunk = len - written;
        for (uint32_t k = 0; k < chunk; k++) wbuf[k] = data[written + k];
        for (uint32_t k = chunk; k < g_bytes_per_cluster; k++) wbuf[k] = 0; /* 클러스터 나머지는 0 패딩 */
        ahci_write_sectors(g_drive, cluster_to_lba(c), g_sectors_per_cluster, wbuf);

        written += chunk;
        prev = c;
        search_from = c + 1;
    }
    return first;
}

/* short_name을 8.3 원시 11바이트 형태(대문자, 공백 패딩)로 변환한다.
 * 이름부 8자/확장자 3자를 넘거나 이름부가 비어있으면 실패(0). */
static int name_to_raw11(const char *name, uint8_t out[11]) {
    for (int i = 0; i < 11; i++) out[i] = ' ';
    int ni = 0;
    while (name[ni] && name[ni] != '.') {
        if (ni >= 8) return 0;
        char c = name[ni];
        if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
        out[ni] = (uint8_t)c;
        ni++;
    }
    if (ni == 0) return 0;
    if (name[ni] == '.') {
        int p = ni + 1, ei = 0;
        while (name[p]) {
            if (ei >= 3) return 0;
            char c = name[p];
            if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
            out[8 + ei] = (uint8_t)c;
            ei++; p++;
        }
    }
    return 1;
}

typedef struct {
    int exists;
    uint32_t dir_cluster, offset;         /* 기존 항목의 위치(exists일 때만 유효) */
    uint32_t old_first_cluster, old_size;
    int free_found;
    uint32_t free_cluster, free_offset;   /* 재사용 가능한 빈 슬롯(0x00/0xE5) 위치 */
    uint32_t last_cluster;                /* 루트 디렉터리 체인의 마지막 클러스터(확장용) */
} fat32_slot_t;

/* 루트 디렉터리를 훑으며 raw11과 일치하는 기존 항목과, 재사용 가능한
 * 빈 슬롯을 동시에 찾는다(있으면 둘 다 기록 — 호출측이 exists를
 * 우선한다). 디스크 I/O 실패 시 0. */
static int locate_slot(const uint8_t raw11[11], fat32_slot_t *out) {
    if (g_drive < 0) return 0;
    out->exists = 0;
    out->free_found = 0;
    static uint8_t dbuf[MAX_CLUSTER_SECTORS * SECTOR_SIZE];
    uint32_t cluster = g_root_cluster;
    out->last_cluster = g_root_cluster;

    while (!is_end_of_chain(cluster)) {
        if (!ahci_read_sectors(g_drive, cluster_to_lba(cluster), g_sectors_per_cluster, dbuf)) return 0;
        int hit_terminator = 0;
        for (uint32_t off = 0; off < g_bytes_per_cluster; off += 32) {
            uint8_t *ent = dbuf + off;
            if (ent[0] == 0x00) {
                if (!out->free_found) { out->free_found = 1; out->free_cluster = cluster; out->free_offset = off; }
                hit_terminator = 1;
                break; /* 0x00 이후로는 유효한 항목이 없다고 보장됨(FAT 규약) */
            }
            if (ent[0] == 0xE5) {
                if (!out->free_found) { out->free_found = 1; out->free_cluster = cluster; out->free_offset = off; }
                continue;
            }
            uint8_t attr = ent[11];
            if (attr == 0x0F || (attr & 0x08) || (attr & 0x10)) continue; /* LFN/볼륨라벨/디렉터리 제외 */
            int match = 1;
            for (int i = 0; i < 11; i++) if (ent[i] != raw11[i]) { match = 0; break; }
            if (match) {
                out->exists = 1;
                out->dir_cluster = cluster;
                out->offset = off;
                out->old_first_cluster = ((uint32_t)rd_u16(ent + 20) << 16) | rd_u16(ent + 26);
                out->old_size = rd_u32(ent + 28);
            }
        }
        out->last_cluster = cluster;
        if (hit_terminator) break;
        cluster = fat_next_cluster(cluster);
    }
    return 1;
}

int fat32_write_file(const char *short_name, const uint8_t *data, uint32_t len) {
    if (g_drive < 0) return 0;
    uint8_t raw11[11];
    if (!name_to_raw11(short_name, raw11)) return 0;

    fat32_slot_t slot = {0};
    if (!locate_slot(raw11, &slot)) return 0;

    uint32_t new_first = allocate_and_write_chain(data, len);
    if (new_first == 0xFFFFFFFFu) return 0; /* 디스크 꽉 참 — 기존 파일은 그대로 보존됨 */

    if (slot.exists && slot.old_first_cluster != 0) free_cluster_chain(slot.old_first_cluster);

    uint32_t target_cluster, target_offset;
    static uint8_t ebuf[MAX_CLUSTER_SECTORS * SECTOR_SIZE];
    if (slot.exists) {
        target_cluster = slot.dir_cluster; target_offset = slot.offset;
    } else if (slot.free_found) {
        target_cluster = slot.free_cluster; target_offset = slot.free_offset;
    } else {
        /* 빈 슬롯이 없음 — 루트 디렉터리 체인을 클러스터 하나만큼 늘린다 */
        uint32_t newc = find_free_cluster(2);
        if (newc == 0) { if (new_first) free_cluster_chain(new_first); return 0; }
        fat_set_next_cluster(newc, FAT32_EOC);
        fat_set_next_cluster(slot.last_cluster, newc);
        for (uint32_t k = 0; k < g_bytes_per_cluster; k++) ebuf[k] = 0;
        ahci_write_sectors(g_drive, cluster_to_lba(newc), g_sectors_per_cluster, ebuf);
        target_cluster = newc; target_offset = 0;
    }

    if (!ahci_read_sectors(g_drive, cluster_to_lba(target_cluster), g_sectors_per_cluster, ebuf)) {
        if (new_first) free_cluster_chain(new_first);
        return 0;
    }
    uint8_t *ent = ebuf + target_offset;
    for (int i = 0; i < 11; i++) ent[i] = raw11[i];
    ent[11] = 0x20; /* ATTR_ARCHIVE — 일반 파일 */
    ent[12] = 0;    /* NTRes */
    ent[13] = 0;    /* CrtTimeTenth */
    wr_u16(ent + 14, 0); /* CrtTime */
    wr_u16(ent + 16, 0); /* CrtDate — fat32.h에 문서화된 단순화: 항상 0 */
    wr_u16(ent + 18, 0); /* LstAccDate */
    wr_u16(ent + 20, (uint16_t)(new_first >> 16));
    wr_u16(ent + 22, 0); /* WrtTime */
    wr_u16(ent + 24, 0); /* WrtDate */
    wr_u16(ent + 26, (uint16_t)(new_first & 0xFFFF));
    wr_u32(ent + 28, len);
    ahci_write_sectors(g_drive, cluster_to_lba(target_cluster), g_sectors_per_cluster, ebuf);
    return 1;
}

/* 8.3 원시 이름(11바이트, 공백 패딩)을 "NAME.EXT" 문자열로 정규화 */
static void normalize_name(const uint8_t *raw11, char *out /* 최소 13바이트 */) {
    int oi = 0;
    for (int i = 0; i < 8; i++) {
        if (raw11[i] == ' ') break;
        out[oi++] = (char)raw11[i];
    }
    int has_ext = 0;
    for (int i = 8; i < 11; i++) if (raw11[i] != ' ') { has_ext = 1; break; }
    if (has_ext) {
        out[oi++] = '.';
        for (int i = 8; i < 11; i++) {
            if (raw11[i] == ' ') break;
            out[oi++] = (char)raw11[i];
        }
    }
    out[oi] = '\0';
}

static int ieq(const char *a, const char *b) {
    while (*a && *b) {
        char ca = *a, cb = *b;
        if (ca >= 'a' && ca <= 'z') ca = (char)(ca - 'a' + 'A');
        if (cb >= 'a' && cb <= 'z') cb = (char)(cb - 'a' + 'A');
        if (ca != cb) return 0;
        a++; b++;
    }
    return *a == *b;
}

/* 루트 디렉터리 클러스터 체인을 순회하며 콜백에 유효한 항목을 하나씩
 * 넘긴다. 콜백이 0을 반환하면 순회를 멈춘다(찾았다는 뜻으로 사용). */
typedef int (*dirent_cb_t)(const fat32_dirent_t *e, void *ctx);

static void walk_root(dirent_cb_t cb, void *ctx) {
    if (g_drive < 0) return;
    /* 스택이 아니라 static(BSS)에 둔다 — 64KB(MAX_CLUSTER_SECTORS*512)를
     * 커널 스레드 스택에 그대로 두면 오버플로 위험이 크다(실제로 겪은
     * 문제: PROGRAM.ELF처럼 여러 클러스터를 훑는 호출 도중 조용히
     * 죽어서 이후 STAGE 로그가 전혀 안 찍히는 증상으로 나타났었다). */
    static uint8_t buf[MAX_CLUSTER_SECTORS * SECTOR_SIZE];
    uint32_t cluster = g_root_cluster;

    while (!is_end_of_chain(cluster)) {
        uint32_t lba = cluster_to_lba(cluster);
        if (!ahci_read_sectors(g_drive, lba, g_sectors_per_cluster, buf)) return;

        for (uint32_t off = 0; off < g_bytes_per_cluster; off += 32) {
            const uint8_t *ent = buf + off;
            if (ent[0] == 0x00) return; /* 이후 항목 없음 — 전체 종료 */
            if (ent[0] == 0xE5) continue; /* 삭제됨 */
            uint8_t attr = ent[11];
            if (attr == 0x0F) continue; /* LFN 항목 — 건너뜀(fat32.h 참고) */
            if (attr & 0x08) continue;  /* 볼륨 라벨 */

            fat32_dirent_t e;
            normalize_name(ent, e.short_name);
            e.size = rd_u32(ent + 28);
            uint32_t hi = rd_u16(ent + 20);
            uint32_t lo = rd_u16(ent + 26);
            e.first_cluster = (hi << 16) | lo;
            e.is_dir = (attr & 0x10) ? 1 : 0;

            /* "." ".." 항목은 루트에도 나타날 수 있어 건너뜀(하위 디렉터리
             * 진입은 어차피 지원 안 하므로 의미 없음) */
            if (e.short_name[0] == '.') continue;

            if (!cb(&e, ctx)) return;
        }

        cluster = fat_next_cluster(cluster);
    }
}

typedef struct { int target_index; int cur; fat32_dirent_t *out; int found; } list_ctx_t;

static int list_cb(const fat32_dirent_t *e, void *ctx_) {
    list_ctx_t *ctx = (list_ctx_t *)ctx_;
    if (ctx->cur == ctx->target_index) {
        *ctx->out = *e;
        ctx->found = 1;
        return 0; /* 멈춤 */
    }
    ctx->cur++;
    return 1;
}

int fat32_list_root(int index, fat32_dirent_t *out) {
    list_ctx_t ctx = { index, 0, out, 0 };
    walk_root(list_cb, &ctx);
    return ctx.found;
}

typedef struct { const char *name; fat32_dirent_t found; int has; } find_ctx_t;

static int find_cb(const fat32_dirent_t *e, void *ctx_) {
    find_ctx_t *ctx = (find_ctx_t *)ctx_;
    if (!e->is_dir && ieq(e->short_name, ctx->name)) {
        ctx->found = *e;
        ctx->has = 1;
        return 0;
    }
    return 1;
}

uint32_t fat32_read_file(const char *short_name, uint8_t *buf, uint32_t buf_cap) {
    if (g_drive < 0) return 0;
    find_ctx_t ctx = { short_name, {0}, 0 };
    walk_root(find_cb, &ctx);
    if (!ctx.has) return 0;

    uint32_t remaining = ctx.found.size;
    if (remaining > buf_cap) remaining = buf_cap; /* 잘림 — fat32.h에 문서화된 동작 */
    uint32_t written = 0;
    uint32_t cluster = ctx.found.first_cluster;

    /* 같은 이유(스택 오버플로 방지)로 static — walk_root의 static buf와는
     * 별개 심볼이라 동시에 살아있어도 안전(재진입/스레드 동시 호출은
     * 안 한다는 전제, fat32.h의 "읽기 전용/단일 사용" 성격과 일관됨). */
    static uint8_t cbuf[MAX_CLUSTER_SECTORS * SECTOR_SIZE];
    int guard = 0;
    while (!is_end_of_chain(cluster) && written < remaining) {
        if (++guard > 1000000) break; /* 방어적 가드 — 정상 동작에서는 절대 안 걸림 */
        uint32_t lba = cluster_to_lba(cluster);
        if (!ahci_read_sectors(g_drive, lba, g_sectors_per_cluster, cbuf)) break;

        uint32_t take = g_bytes_per_cluster;
        if (written + take > remaining) take = remaining - written;
        for (uint32_t i = 0; i < take; i++) buf[written + i] = cbuf[i];
        written += take;

        cluster = fat_next_cluster(cluster);
    }
    return written;
}
