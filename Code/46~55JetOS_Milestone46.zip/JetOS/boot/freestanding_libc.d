boot/freestanding_libc.o: boot/freestanding_libc.c
