/*
 * JetOS - kernel/drivers/virtio_input.c
 * virtio_input.h 참고 — 설계 의도/정직한 단순화는 거기 문서화.
 */
#include "virtio_input.h"
#include "pci.h"
#include "serial.h"
#include "../hal/x86_asm_shim.h"
#include "../mm/pmm.h"
#include "../mm/vmm.h"
#include "../int/pit.h"

#define VIRTIO_VENDOR_ID     0x1AF4
#define VIRTIO_INPUT_DEVICE_ID 0x1052 /* virtio device id 18(input) + 0x1040, modern만 */

#define PCI_CAP_ID_VNDR 0x09
#define VIRTIO_PCI_CAP_COMMON_CFG 1
#define VIRTIO_PCI_CAP_NOTIFY_CFG 2

#define VIRTIO_STATUS_ACKNOWLEDGE 1
#define VIRTIO_STATUS_DRIVER      2
#define VIRTIO_STATUS_DRIVER_OK   4
#define VIRTIO_STATUS_FEATURES_OK 8
#define VIRTIO_STATUS_FAILED      128

#define VMM_IDENTITY_MAP_LIMIT 0x100000000ULL /* 4GiB — virtio_gpu.c와 동일한 상수(M38: vmm_map_mmio로 위든 아래든 다 됨) */

/* ---- Linux input-event-codes.h 참고(사용자 허가하에 리눅스 값 그대로 사용) ---- */
#define EV_SYN 0x00
#define EV_KEY 0x01
#define EV_ABS 0x03
#define ABS_X  0x00
#define ABS_Y  0x01
#define BTN_LEFT   0x110
#define BTN_RIGHT  0x111
#define BTN_MIDDLE 0x112

/* QEMU virtio-input-hid 태블릿의 실제 고정 절대좌표 범위(virtio_input.h
 * 주석의 "정직한 단순화" 참고) */
#define VIRTIO_TABLET_ABS_MAX 0x7FFF

typedef volatile struct {
    uint32_t device_feature_select;
    uint32_t device_feature;
    uint32_t driver_feature_select;
    uint32_t driver_feature;
    uint16_t msix_config;
    uint16_t num_queues;
    uint8_t  device_status;
    uint8_t  config_generation;
    uint16_t queue_select;
    uint16_t queue_size;
    uint16_t queue_msix_vector;
    uint16_t queue_enable;
    uint16_t queue_notify_off;
    uint64_t queue_desc;
    uint64_t queue_avail;
    uint64_t queue_used;
} virtio_pci_common_cfg_t;

#define VQ_SIZE 16 /* 2의 거듭제곱 — 미리 던져두는 이벤트 버퍼 개수 */

typedef struct { uint64_t addr; uint32_t len; uint16_t flags; uint16_t next; } virtq_desc_t;
#define VIRTQ_DESC_F_WRITE 2

typedef volatile struct { uint16_t flags; uint16_t idx; uint16_t ring[VQ_SIZE]; } virtq_avail_t;
typedef struct { uint32_t id; uint32_t len; } virtq_used_elem_t;
typedef volatile struct { uint16_t flags; uint16_t idx; virtq_used_elem_t ring[VQ_SIZE]; } virtq_used_t;

typedef struct { uint16_t type; uint16_t code; uint32_t value; } virtio_input_event_t; /* spec 5.8.6, 8바이트 */

static int g_available = 0;
static virtio_pci_common_cfg_t *g_common;
static volatile uint8_t *g_notify_base;
static uint32_t g_notify_off_multiplier;
static uint16_t g_notify_off_eventq;
static virtq_desc_t *g_desc;
static virtq_avail_t *g_avail;
static virtq_used_t *g_used;
static uint16_t g_used_seen;
static virtio_input_event_t *g_event_bufs; /* VQ_SIZE개, 각 8바이트 */

/* 마지막으로 관측된 원시(raw, 0~0x7FFF) 절대좌표 + 버튼 상태 —
 * poll()이 호출될 때마다 이 값들을 화면 좌표로 스케일링해서 돌려준다. */
static int g_raw_x = 0, g_raw_y = 0;
static int g_btn_left = 0, g_btn_right = 0, g_btn_middle = 0;
static int g_dirty = 0; /* 마지막 poll 이후 뭔가 바뀐 게 있으면 1 */

#define INPUT_TIMEOUT_TICKS 200

static uint8_t pci_read8(pci_device_t *d, uint8_t off) {
    uint32_t v = pci_config_read32(d->bus, d->slot, d->func, (uint8_t)(off & 0xFC));
    return (uint8_t)(v >> ((off & 3) * 8));
}
static uint32_t pci_read32_raw(pci_device_t *d, uint8_t off) {
    return pci_config_read32(d->bus, d->slot, d->func, off);
}

static int find_virtio_cap(pci_device_t *d, uint8_t cfg_type, uint8_t *bar_out, uint32_t *off_out, uint32_t *len_out, uint32_t *extra_out) {
    uint32_t status = pci_read32_raw(d, 0x04);
    if (!(status & (1u << 20))) return 0;
    uint8_t ptr = pci_read8(d, 0x34);
    int guard = 0;
    while (ptr != 0 && guard++ < 64) {
        uint8_t cap_id = pci_read8(d, ptr);
        uint8_t cap_next = pci_read8(d, (uint8_t)(ptr + 1));
        if (cap_id == PCI_CAP_ID_VNDR) {
            uint8_t cfg_type_here = pci_read8(d, (uint8_t)(ptr + 3));
            if (cfg_type_here == cfg_type) {
                *bar_out = pci_read8(d, (uint8_t)(ptr + 4));
                *off_out = pci_read32_raw(d, (uint8_t)(ptr + 8));
                *len_out = pci_read32_raw(d, (uint8_t)(ptr + 12));
                if (cfg_type == VIRTIO_PCI_CAP_NOTIFY_CFG && extra_out) {
                    *extra_out = pci_read32_raw(d, (uint8_t)(ptr + 16));
                }
                return 1;
            }
        }
        ptr = cap_next;
    }
    return 0;
}

static uint64_t bar_phys_addr(pci_device_t *d, int bar_idx) {
    uint32_t lo = d->bar[bar_idx];
    if (lo & 1) return 0;
    int is64 = ((lo >> 1) & 3) == 2;
    uint64_t addr = (uint64_t)(lo & 0xFFFFFFF0u);
    if (is64 && bar_idx < 5) addr |= ((uint64_t)d->bar[bar_idx + 1]) << 32;
    return addr;
}

int virtio_input_available(void) { return g_available; }

/* TEMP: expose raw used->idx for debugging */
uint16_t virtio_input_debug_used_idx(void) { return g_used ? g_used->idx : 0xFFFF; }

/* 이미 다 쓴 디스크립터(desc_id)를 다시 빈 버퍼로 avail 링에 돌려놓는다
 * — eventq는 "빈 버퍼를 계속 공급해야 장치가 계속 이벤트를 채워준다"는
 * 구조라(spec 5.8), 이 재활용 없이는 16개 버퍼를 다 쓰고 나면 그 뒤로
 * 이벤트가 전부 유실된다. */
static void repost_buffer(uint16_t desc_id) {
    uint16_t slot = (uint16_t)(g_avail->idx % VQ_SIZE);
    g_avail->ring[slot] = desc_id;
    g_avail->idx = (uint16_t)(g_avail->idx + 1);
    volatile uint16_t *notify_reg = (volatile uint16_t *)(g_notify_base + (uint64_t)g_notify_off_eventq * g_notify_off_multiplier);
    *notify_reg = 0;
}

static void process_event(const virtio_input_event_t *ev) {
    if (ev->type == EV_ABS) {
        if (ev->code == ABS_X) { g_raw_x = (int)ev->value; g_dirty = 1; }
        else if (ev->code == ABS_Y) { g_raw_y = (int)ev->value; g_dirty = 1; }
    } else if (ev->type == EV_KEY) {
        int pressed = (ev->value != 0);
        if (ev->code == BTN_LEFT) { g_btn_left = pressed; g_dirty = 1; }
        else if (ev->code == BTN_RIGHT) { g_btn_right = pressed; g_dirty = 1; }
        else if (ev->code == BTN_MIDDLE) { g_btn_middle = pressed; g_dirty = 1; }
    }
    /* EV_SYN(프레임 구분자)이나 그 외 코드는 무시 — 이 폴링 모델에서는
     * 매 poll() 호출 자체가 "지금까지 쌓인 걸 한 프레임으로" 취급하므로
     * SYN을 특별 취급할 필요가 없다(정직한 단순화, virtio_input.h 참고). */
}

int virtio_input_poll(int screen_w, int screen_h, int *out_x, int *out_y,
                       int *out_left, int *out_right, int *out_middle) {
    if (!g_available) return 0;

    while (g_used->idx != g_used_seen) {
        uint16_t ring_slot = (uint16_t)(g_used_seen % VQ_SIZE);
        uint32_t desc_id = g_used->ring[ring_slot].id;
        if (desc_id < VQ_SIZE) process_event(&g_event_bufs[desc_id]);
        g_used_seen = (uint16_t)(g_used_seen + 1);
        repost_buffer((uint16_t)desc_id);
    }

    if (!g_dirty) return 0;
    g_dirty = 0;

    int sx = (g_raw_x * screen_w) / VIRTIO_TABLET_ABS_MAX;
    int sy = (g_raw_y * screen_h) / VIRTIO_TABLET_ABS_MAX;
    if (sx < 0) sx = 0;
    if (sx >= screen_w) sx = screen_w - 1;
    if (sy < 0) sy = 0;
    if (sy >= screen_h) sy = screen_h - 1;

    *out_x = sx; *out_y = sy;
    *out_left = g_btn_left; *out_right = g_btn_right; *out_middle = g_btn_middle;
    return 1;
}

int virtio_input_init(void) {
    g_available = 0;

    pci_device_t dev;
    if (!pci_find_device(VIRTIO_VENDOR_ID, VIRTIO_INPUT_DEVICE_ID, &dev)) {
        serial_write("[virtio-input] PCI 장치를 못 찾음(vendor=0x1AF4 device=0x1052) — PS/2 마우스만 사용\n");
        return 0;
    }
    serial_write("[virtio-input] 장치 발견: bus="); serial_write_hex64(dev.bus);
    serial_write(" slot="); serial_write_hex64(dev.slot);
    serial_write(" func="); serial_write_hex64(dev.func); serial_write("\n");

    uint32_t cmd = pci_read32_raw(&dev, 0x04);
    pci_config_write32(dev.bus, dev.slot, dev.func, 0x04, cmd | 0x0006u);

    uint8_t bar; uint32_t off, len, extra;
    if (!find_virtio_cap(&dev, VIRTIO_PCI_CAP_COMMON_CFG, &bar, &off, &len, &extra)) {
        serial_write("[virtio-input] COMMON_CFG capability를 못 찾음\n");
        return 0;
    }
    if (bar > 5) return 0;
    uint64_t common_phys = bar_phys_addr(&dev, bar);
    if (!common_phys) return 0;
    uint64_t common_vaddr;
    if (common_phys + off + sizeof(virtio_pci_common_cfg_t) <= VMM_IDENTITY_MAP_LIMIT) {
        common_vaddr = common_phys + off;
    } else {
        /* M38: virtio-gpu와 동일하게 vmm_map_mmio로 4GiB 위도 그냥 매핑 */
        uint64_t mapped = vmm_map_mmio(common_phys, off + sizeof(virtio_pci_common_cfg_t));
        if (!mapped) { serial_write("[virtio-input] vmm_map_mmio 실패 — 포기\n"); return 0; }
        common_vaddr = mapped + off;
    }
    g_common = (virtio_pci_common_cfg_t *)(uintptr_t)common_vaddr;

    if (!find_virtio_cap(&dev, VIRTIO_PCI_CAP_NOTIFY_CFG, &bar, &off, &len, &extra)) return 0;
    if (bar > 5) return 0;
    uint64_t notify_phys = bar_phys_addr(&dev, bar);
    if (!notify_phys) return 0;
    uint64_t notify_vaddr;
    if (notify_phys + off < VMM_IDENTITY_MAP_LIMIT) {
        notify_vaddr = notify_phys + off;
    } else {
        uint64_t mapped = vmm_map_mmio(notify_phys, off + 4);
        if (!mapped) { serial_write("[virtio-input] vmm_map_mmio 실패(notify) — 포기\n"); return 0; }
        notify_vaddr = mapped + off;
    }
    g_notify_base = (volatile uint8_t *)(uintptr_t)notify_vaddr;
    g_notify_off_multiplier = extra;

    /* ---- 초기화 시퀀스(virtio spec 3.1.1), virtio_gpu.c와 동일 ---- */
    g_common->device_status = 0;
    { uint64_t deadline = g_timer_ticks + INPUT_TIMEOUT_TICKS; while (g_common->device_status != 0) { if (g_timer_ticks > deadline) return 0; } }
    g_common->device_status = VIRTIO_STATUS_ACKNOWLEDGE;
    g_common->device_status |= VIRTIO_STATUS_DRIVER;

    g_common->device_feature_select = 1;
    uint32_t feat_hi = g_common->device_feature;
    if (!(feat_hi & 1u)) { serial_write("[virtio-input] VIRTIO_F_VERSION_1 미지원 — 포기\n"); return 0; }
    g_common->driver_feature_select = 0;
    g_common->driver_feature = 0;
    g_common->driver_feature_select = 1;
    g_common->driver_feature = 1;

    g_common->device_status |= VIRTIO_STATUS_FEATURES_OK;
    if (!(g_common->device_status & VIRTIO_STATUS_FEATURES_OK)) return 0;

    /* eventq(큐 0) 설정 — statusq(큐 1)는 이 드라이버가 아무것도 안
     * 보낼 거라 아예 손 안 댐(virtio_input.h의 단순화 참고). */
    g_common->queue_select = 0;
    uint16_t dev_qsize = g_common->queue_size;
    if (dev_qsize == 0) return 0;
    uint16_t use_qsize = (dev_qsize < VQ_SIZE) ? dev_qsize : VQ_SIZE;

    uint64_t desc_page = pmm_alloc_page();
    uint64_t avail_page = pmm_alloc_page();
    uint64_t used_page = pmm_alloc_page();
    uint64_t event_page = pmm_alloc_page();
    if (!desc_page || !avail_page || !used_page || !event_page) return 0;

    g_desc = (virtq_desc_t *)(uintptr_t)desc_page;
    g_avail = (virtq_avail_t *)(uintptr_t)avail_page;
    g_used = (virtq_used_t *)(uintptr_t)used_page;
    g_event_bufs = (virtio_input_event_t *)(uintptr_t)event_page;

    g_avail->flags = 0; g_avail->idx = 0;
    g_used->flags = 0; g_used->idx = 0;
    g_used_seen = 0;

    /* VQ_SIZE개의 이벤트 버퍼 전부를 "장치가 써도 되는" 디스크립터로
     * 만들어 미리 avail 링에 던져둔다 — 장치가 이벤트가 생길 때마다
     * 이 버퍼들을 순서 없이 채워 used 링으로 돌려준다. */
    for (int i = 0; i < VQ_SIZE; i++) {
        g_desc[i].addr = event_page + (uint64_t)i * sizeof(virtio_input_event_t);
        g_desc[i].len = sizeof(virtio_input_event_t);
        g_desc[i].flags = VIRTQ_DESC_F_WRITE;
        g_desc[i].next = 0;
        g_avail->ring[i] = (uint16_t)i;
    }
    g_avail->idx = VQ_SIZE;

    g_common->queue_size = use_qsize;
    g_common->queue_desc = desc_page;
    g_common->queue_avail = avail_page;
    g_common->queue_used = used_page;
    g_notify_off_eventq = g_common->queue_notify_off;
    g_common->queue_enable = 1;

    g_common->device_status |= VIRTIO_STATUS_DRIVER_OK;

    /* 방금 던져둔 버퍼들을 실제로 채우기 시작하라고 알림 */
    volatile uint16_t *notify_reg = (volatile uint16_t *)(g_notify_base + (uint64_t)g_notify_off_eventq * g_notify_off_multiplier);
    *notify_reg = 0;

    g_raw_x = 0; g_raw_y = 0;
    g_btn_left = g_btn_right = g_btn_middle = 0;
    g_dirty = 0;

    g_available = 1;
    serial_write("[virtio-input] 초기화 성공 — 절대좌표 태블릿 입력 사용 가능\n");
    return 1;
}
