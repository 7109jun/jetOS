#include "security.hpp"
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <algorithm>
namespace fs=std::filesystem; namespace deiig::security {
static fs::path cfg(){return fs::current_path()/".deiig"/"security.mode";}
std::string mode(){std::ifstream f(cfg());std::string s;f>>s;return s.empty()?"confirm":s;}
int set_mode(const std::string&m){if(m!="confirm"&&m!="allow"&&m!="deny")return 1;fs::create_directories(cfg().parent_path());std::ofstream(cfg())<<m<<"\n";return 0;}
bool command_allowed(const std::string&cmd){std::string low=cmd;std::transform(low.begin(),low.end(),low.begin(),[](unsigned char c){return (char)std::tolower(c);});if(low.find("rm -rf /")!=std::string::npos||low.find("format c:")!=std::string::npos||low.find("del /s /q c:\\")!=std::string::npos)return false;return mode()!="deny";}
}
