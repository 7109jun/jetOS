#ifndef JETOS_GDT_H
#define JETOS_GDT_H

#include <stdint.h>

/*
 * JetOS - kernel/hal/gdt.h
 * Milestone 14: 자체 GDT + TSS 구성. 지금까지는 UEFI가 부팅 시 만들어준
 * GDT(플랫 코드/데이터 세그먼트, 전부 Ring0)를 그대로 썼다 — Ring0
 * 전용으로 돌아가는 동안은 그걸로 충분했다. Ring3(유저 모드)로 내려가려면
 * DPL=3인 코드/데이터 세그먼트와, 인터럽트/시스템콜로 Ring3→Ring0
 * 복귀할 때 쓸 커널 스택 포인터(RSP0)를 알려주는 TSS가 반드시 필요하다.
 */

/* 셀렉터 값 (GDT 인덱스*8 | RPL) */
#define GDT_SEL_KERNEL_CODE 0x08
#define GDT_SEL_KERNEL_DATA 0x10
#define GDT_SEL_USER_CODE   (0x18 | 3)
#define GDT_SEL_USER_DATA   (0x20 | 3)
#define GDT_SEL_TSS         0x28

void gdt_init(void);

/* 인터럽트/시스템콜로 유저 모드에서 커널로 돌아올 때 CPU가 자동으로
 * 전환할 스택 포인터(RSP0)를 갱신한다. 스레드마다 커널 스택이 다르므로
 * 스레드를 전환할 때마다 호출해줘야 한다(스케줄러 연동은 이후 마일스톤
 * 과제 — 지금은 테스트 스레드 하나만 고려한 최소 구현). */
void gdt_set_kernel_stack(uint64_t rsp0);

#endif
