/*
 * JetOS - kernel/hal/auth.c
 * Milestone 34: 사용자 계정 / 로그인. 설계 이유는 auth.h 참고.
 */

#include "auth.h"
#include "../kernel.h"
#include "../fs/jetfs.h"
#include "../net/crypto/sha256.h"
#include "../drivers/keyboard.h"
#include "../drivers/console.h"
#include "../drivers/serial.h"
#include "../proc/scheduler.h"
#include <stddef.h>

#define AUTH_FILE "/system/user.txt"
#define AUTH_LINE_CAP 32

static int s_len(const char *s) {
    int i = 0;
    while (s[i]) i++;
    return i;
}

static int s_eq(const char *a, const char *b) {
    int i = 0;
    while (a[i] && b[i]) { if (a[i] != b[i]) return 0; i++; }
    return a[i] == b[i];
}

static void hex_encode(const uint8_t *in, int n, char *out) {
    static const char H[] = "0123456789abcdef";
    for (int i = 0; i < n; i++) {
        out[i * 2] = H[in[i] >> 4];
        out[i * 2 + 1] = H[in[i] & 0xF];
    }
    out[n * 2] = '\0';
}

/* 비밀번호 원문을 SHA-256으로 해시해 64자 소문자 hex로 만든다(솔트
 * 없음 — auth.h의 정직한 한계 표기 참고). */
static void hash_password(const char *pw, char out_hex65[65]) {
    uint8_t digest[32];
    sha256_oneshot((const uint8_t *)pw, (size_t)s_len(pw), digest);
    hex_encode(digest, 32, out_hex65);
}

static int load_account(char *user_out, int user_cap, char *hash_out65) {
    jetfs_inode_type_t t;
    uint64_t sz = 0;
    if (!jetfs_stat(AUTH_FILE, &t, &sz) || t != JETFS_TYPE_FILE) return 0;

    char buf[160];
    uint64_t got = 0;
    if (!jetfs_read(AUTH_FILE, buf, sizeof(buf) - 1, &got)) return 0;
    buf[got] = '\0';

    int i = 0, u = 0;
    while (buf[i] && buf[i] != '\n' && u < user_cap - 1) user_out[u++] = buf[i++];
    user_out[u] = '\0';
    if (buf[i] == '\n') i++;

    int h = 0;
    while (buf[i] && buf[i] != '\n' && h < 64) hash_out65[h++] = buf[i++];
    hash_out65[h] = '\0';

    return h == 64; /* sha256 hex는 정확히 64자 — 짧으면 손상된 파일로 취급 */
}

static int save_account(const char *user, const char *hash_hex) {
    char out[160];
    int n = 0;
    for (int k = 0; user[k] && n < (int)sizeof(out) - 2; k++) out[n++] = user[k];
    out[n++] = '\n';
    for (int k = 0; hash_hex[k] && n < (int)sizeof(out) - 2; k++) out[n++] = hash_hex[k];
    out[n++] = '\n';

    if (!jetfs_stat(AUTH_FILE, NULL, NULL)) {
        if (!jetfs_create(AUTH_FILE, JETFS_TYPE_FILE)) return 0;
    }
    return jetfs_write(AUTH_FILE, out, (uint64_t)n);
}

/* x,y(절대 프레임버퍼 좌표)에서 한 줄을 편집 가능하게 입력받는다.
 * mask=1이면 입력된 글자 수만큼 '*'만 그린다(비밀번호 필드). Enter로
 * 확정, Backspace로 지움. 다른 위젯 인프라(widget_textbox_t)는 wm 창
 * 안에서만 동작하므로, wm이 아직 초기화되기 전인 이 게이트 화면에서는
 * 쓸 수 없어 g_console에 직접 그리는 최소 버전을 따로 둔다. */
static int auth_read_line(console_t *dc, int x, int y, char *out, int cap, int mask) {
    int len = 0;
    out[0] = '\0';
    char stars[AUTH_LINE_CAP + 1];
    for (;;) {
        char c = keyboard_poll_char();
        if (!c) { scheduler_yield(); continue; }
        if (c == '\n' || c == '\r') break;
        if (c == '\b') {
            if (len > 0) { len--; out[len] = '\0'; }
        } else if (c >= 32 && c < 127 && len < cap - 1 && len < AUTH_LINE_CAP) {
            out[len++] = c;
            out[len] = '\0';
        }
        console_fill_rect(dc, (uint32_t)x, (uint32_t)(y - 12), 300, 16, 0x00101820);
        dc->cursor_x = (uint32_t)x; dc->cursor_y = (uint32_t)y;
        dc->fg_color = 0x00E0ECFA;
        if (mask) {
            int i = 0;
            for (; i < len; i++) stars[i] = '*';
            stars[i] = '\0';
            console_print(dc, stars);
        } else {
            console_print(dc, out);
        }
    }
    return len;
}

static void wait_any_key(void) {
    while (keyboard_poll_char()) {} /* 버퍼 비우기 */
    while (!keyboard_poll_char()) scheduler_yield();
}

void auth_run_gate(void) {
    keyboard_init();

    if (!jetfs_stat("/", NULL, NULL)) {
        serial_write("STAGE: AUTH SKIPPED (JETFS not mounted)\n");
        return;
    }

    console_t *dc = &g_console;
    char username[32];
    char stored_hash[65];
    int has_account = load_account(username, sizeof(username), stored_hash);

    if (!has_account) {
        for (;;) {
            console_clear(dc, 0x00101820);
            dc->fg_color = 0x00E0ECFA;
            dc->cursor_x = 40; dc->cursor_y = 40;
            console_print(dc, "JETOS FIRST BOOT - CREATE ACCOUNT");

            dc->cursor_x = 40; dc->cursor_y = 74;
            console_print(dc, "USERNAME:");
            char user[32];
            int ulen = auth_read_line(dc, 170, 74, user, sizeof(user), 0);
            if (ulen == 0) continue;

            dc->cursor_x = 40; dc->cursor_y = 104;
            console_print(dc, "PASSWORD:");
            char pw1[AUTH_LINE_CAP];
            auth_read_line(dc, 170, 104, pw1, sizeof(pw1), 1);

            dc->cursor_x = 40; dc->cursor_y = 134;
            console_print(dc, "CONFIRM PASSWORD:");
            char pw2[AUTH_LINE_CAP];
            auth_read_line(dc, 220, 134, pw2, sizeof(pw2), 1);

            if (pw1[0] == '\0' || !s_eq(pw1, pw2)) {
                dc->fg_color = 0x00FF8080;
                dc->cursor_x = 40; dc->cursor_y = 170;
                console_print(dc, "PASSWORDS EMPTY OR DID NOT MATCH - PRESS ANY KEY TO RETRY");
                wait_any_key();
                continue;
            }

            char hash_hex[65];
            hash_password(pw1, hash_hex);
            if (save_account(user, hash_hex)) {
                serial_write("STAGE: AUTH ACCOUNT CREATED (user=");
                serial_write(user);
                serial_write(")\n");
                break;
            } else {
                dc->fg_color = 0x00FF8080;
                dc->cursor_x = 40; dc->cursor_y = 170;
                console_print(dc, "SAVE FAILED - PRESS ANY KEY TO RETRY");
                wait_any_key();
            }
        }
        console_clear(dc, 0x00101820);
        return; /* 계정을 막 만들었으니 그대로 로그인 상태로 취급 */
    }

    for (;;) {
        console_clear(dc, 0x00101820);
        dc->fg_color = 0x00E0ECFA;
        dc->cursor_x = 40; dc->cursor_y = 40;
        console_print(dc, "JETOS LOGIN");
        dc->cursor_x = 40; dc->cursor_y = 74;
        console_print(dc, "USER: ");
        console_print(dc, username);

        dc->cursor_x = 40; dc->cursor_y = 104;
        console_print(dc, "PASSWORD:");
        char pw[AUTH_LINE_CAP];
        auth_read_line(dc, 170, 104, pw, sizeof(pw), 1);

        char hash_hex[65];
        hash_password(pw, hash_hex);
        if (s_eq(hash_hex, stored_hash)) {
            serial_write("STAGE: AUTH LOGIN OK\n");
            console_clear(dc, 0x00101820);
            return;
        }

        dc->fg_color = 0x00FF8080;
        dc->cursor_x = 40; dc->cursor_y = 134;
        console_print(dc, "WRONG PASSWORD - PRESS ANY KEY TO RETRY");
        serial_write("STAGE: AUTH LOGIN FAILED (wrong password)\n");
        wait_any_key();
    }
}
