/*
 * JetOS - tools/jcc.c
 * Milestone 30: JCC(JetOS C Compiler) — 호스트에서 도는(mkjetfs.c와 같은
 * 위치, 같은 방식으로 빌드되는) C 서브셋 컴파일러. .c 소스를 곧바로
 * JetOS 네이티브 정적 ELF64 실행파일(kernel/exec/elf_loader.c가 그대로
 * 읽을 수 있는 형식)로 컴파일한다 — 외부 어셈블러(as)/링커(ld)를 전혀
 * 쓰지 않고 x86-64 기계어 바이트를 직접 만들어낸다(이 프로젝트가
 * bignum/RSA/SHA-256/AES를 전부 처음부터 구현한 것과 같은 원칙:
 * 외부 도구에 기대지 않는다).
 *
 * ===== 지원하는 C 서브셋(정직하게 문서화) =====
 * 타입: int, char, void, 단일 레벨 포인터(T*), 1차원 배열(T name[N]).
 *   전역 배열의 여러 차원, 구조체/공용체, enum, typedef, float/double은
 *   지원하지 않는다.
 * 선언: 전역 변수(정수 상수 초기화만 가능, 문자열/포인터 초기화는
 *   지원 안 함), 함수(매개변수 최대 6개, System V 정수 레지스터
 *   전달 규약과 동일한 순서: rdi,rsi,rdx,rcx,r8,r9), 지역 변수(초기화
 *   식 지원, 배열 초기화 리스트 int a[3]={1,2,3} 지원 — Milestone 36.
 *   명시된 항목보다 배열이 크면 나머지는 0으로 채움, C 표준과 동일).
 * 문장: if/else, while, for, return, 블록, 식문장. switch/goto/do-while
 *   없음.
 * 식: 산술(+ - * / %), 비교(== != < > <= >=), 논리(&& ||, 단락평가),
 *   단항(- ! * &), 배열 인덱싱, 함수 호출, 대입(=). 복합 대입(+= 등),
 *   증감(++/--), 삼항연산자, 콤마연산자는 없음.
 * 전처리기: 없음(#include/#define 등은 그냥 무시하고 건너뛴다 — 이
 *   컴파일러가 이해하는 게 아니라 단순히 렉서가 '#'로 시작하는 줄을
 *   스킵할 뿐이라는 뜻).
 * 스코프: 함수 전체가 하나의 평평한(flat) 스코프다 — 블록{} 안에서
 *   선언해도 그 함수 끝까지 보인다(진짜 C의 블록 스코프가 아님, 알려진
 *   단순화).
 * 값 표현: char든 int든 포인터든 레지스터/스택에서는 전부 8바이트로
 *   다룬다(단순화) — 예외는 배열/문자열 리터럴이 가리키는 "메모리
 *   내용 자체"뿐, 그건 표준 C처럼 char=1바이트/int=8바이트(포인터
 *   산술 스케일도 이를 따름) 단위로 저장된다.
 *
 * ===== 런타임(runtime) =====
 * JetOS는 시스템콜이 SYS_WRITE(문자열 1개)/SYS_EXIT/SYS_GETTICK/SYS_BRK
 * 4개뿐이다(kernel/hal/syscall.h). 이 컴파일러는 매 산출물 앞부분에
 * 작은 고정 "런타임 트램폴린"(_write/_exit/_gettick, 각각 int $0x80 한
 * 줄짜리)을 자동으로 붙이고, 사용자 코드가 이 이름들을 평범한 함수처럼
 * 호출하면 된다. 그 위에 표준 라이브러리 비슷한 걸 조금 더(정수를
 * 10진수 문자열로 바꿔 출력하는 print_int 등) "프렐류드"로 자동
 * 앞붙임 — 진짜 malloc/printf 등은 없다(SYS_BRK로 힙을 늘릴 수는
 * 있지만 이 컴파일러가 malloc을 자동 제공하진 않음, 알려진 한계).
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

/* ===================== 유틸 ===================== */
static void die(const char *msg) {
    fprintf(stderr, "jcc: error: %s\n", msg);
    exit(1);
}
static void dief(const char *fmt, const char *arg) {
    fprintf(stderr, "jcc: error: ");
    fprintf(stderr, fmt, arg);
    fprintf(stderr, "\n");
    exit(1);
}

/* growable byte buffer — 코드/데이터 섹션 둘 다 이걸로 만든다 */
typedef struct {
    uint8_t *data;
    size_t len, cap;
} Buf;
static void buf_init(Buf *b) { b->data = NULL; b->len = 0; b->cap = 0; }
static void buf_reserve(Buf *b, size_t extra) {
    if (b->len + extra <= b->cap) return;
    size_t ncap = b->cap ? b->cap * 2 : 256;
    while (ncap < b->len + extra) ncap *= 2;
    b->data = (uint8_t *)realloc(b->data, ncap);
    if (!b->data) die("메모리 부족(buf_reserve)");
    b->cap = ncap;
}
static size_t buf_u8(Buf *b, uint8_t v) { buf_reserve(b, 1); b->data[b->len] = v; return b->len++; }
static void buf_bytes(Buf *b, const void *p, size_t n) {
    buf_reserve(b, n);
    memcpy(b->data + b->len, p, n);
    b->len += n;
}
static void buf_u32_at(Buf *b, size_t off, uint32_t v) { memcpy(b->data + off, &v, 4); }
static void buf_u64_at(Buf *b, size_t off, uint64_t v) { memcpy(b->data + off, &v, 8); }
static void buf_u32(Buf *b, uint32_t v) { buf_bytes(b, &v, 4); }
static void buf_u64(Buf *b, uint64_t v) { buf_bytes(b, &v, 8); }

/* ===================== 렉서 ===================== */
typedef enum { TK_NUM, TK_CHAR, TK_STR, TK_IDENT, TK_PUNCT, TK_EOF } TokKind;
typedef struct {
    TokKind kind;
    long ival;
    char *sval; /* TK_STR: 디코딩된 바이트(길이=slen, NUL 미포함), TK_IDENT/TK_PUNCT: 텍스트(NUL 종료) */
    int slen;
} Token;

static Token *g_toks;
static int g_ntoks, g_tokcap;
static void tok_push(Token t) {
    if (g_ntoks >= g_tokcap) { g_tokcap = g_tokcap ? g_tokcap * 2 : 256; g_toks = (Token *)realloc(g_toks, sizeof(Token) * g_tokcap); }
    g_toks[g_ntoks++] = t;
}

static int is_ident_start(int c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_'; }
static int is_ident_char(int c) { return is_ident_start(c) || (c >= '0' && c <= '9'); }

static int decode_escape(const char *p, int *consumed) {
    /* p[0]=='\\' 가정, p[1]이 이스케이프 문자 */
    *consumed = 2;
    switch (p[1]) {
        case 'n': return '\n';
        case 't': return '\t';
        case 'r': return '\r';
        case '0': return '\0';
        case '\\': return '\\';
        case '\'': return '\'';
        case '"': return '"';
        default: return p[1];
    }
}

static void lex(const char *src) {
    const char *p = src;
    while (*p) {
        if (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') { p++; continue; }
        if (p[0] == '/' && p[1] == '/') { while (*p && *p != '\n') p++; continue; }
        if (p[0] == '/' && p[1] == '*') {
            p += 2;
            while (*p && !(p[0] == '*' && p[1] == '/')) p++;
            if (*p) p += 2;
            continue;
        }
        if (*p == '#') { while (*p && *p != '\n') p++; continue; } /* 전처리기 줄은 통째로 무시 */

        if (*p >= '0' && *p <= '9') {
            long v = strtol(p, (char **)&p, 0);
            Token t; t.kind = TK_NUM; t.ival = v; t.sval = NULL; t.slen = 0;
            tok_push(t);
            continue;
        }
        if (*p == '\'') {
            p++;
            int c;
            if (*p == '\\') { int n; c = decode_escape(p, &n); p += n; } else { c = (unsigned char)*p; p++; }
            if (*p != '\'') die("문자 리터럴이 '로 안 끝남");
            p++;
            Token t; t.kind = TK_CHAR; t.ival = c; t.sval = NULL; t.slen = 0;
            tok_push(t);
            continue;
        }
        if (*p == '"') {
            p++;
            char *buf = (char *)malloc(strlen(p) + 1);
            int n = 0;
            while (*p && *p != '"') {
                if (*p == '\\') { int used; buf[n++] = (char)decode_escape(p, &used); p += used; }
                else buf[n++] = *p++;
            }
            if (*p != '"') die("문자열 리터럴이 \"로 안 끝남");
            p++;
            Token t; t.kind = TK_STR; t.sval = buf; t.slen = n; t.ival = 0;
            tok_push(t);
            continue;
        }
        if (is_ident_start(*p)) {
            const char *start = p;
            while (is_ident_char(*p)) p++;
            int len = (int)(p - start);
            char *buf = (char *)malloc(len + 1);
            memcpy(buf, start, len); buf[len] = '\0';
            Token t; t.kind = TK_IDENT; t.sval = buf; t.slen = len; t.ival = 0;
            tok_push(t);
            continue;
        }
        /* 펀크추에이터 — 2글자 먼저 시도 */
        {
            static const char *two[] = { "==", "!=", "<=", ">=", "&&", "||", NULL };
            int matched = 0;
            for (int i = 0; two[i]; i++) {
                if (p[0] == two[i][0] && p[1] == two[i][1]) {
                    char *buf = (char *)malloc(3); buf[0] = p[0]; buf[1] = p[1]; buf[2] = '\0';
                    Token t; t.kind = TK_PUNCT; t.sval = buf; t.slen = 2; t.ival = 0;
                    tok_push(t);
                    p += 2; matched = 1; break;
                }
            }
            if (matched) continue;
        }
        {
            char *buf = (char *)malloc(2); buf[0] = *p; buf[1] = '\0';
            Token t; t.kind = TK_PUNCT; t.sval = buf; t.slen = 1; t.ival = 0;
            tok_push(t);
            p++;
        }
    }
    Token eof; eof.kind = TK_EOF; eof.sval = NULL; eof.slen = 0; eof.ival = 0;
    tok_push(eof);
}

/* ===================== 타입 ===================== */
typedef struct Type {
    enum { TY_INT, TY_CHAR, TY_VOID, TY_PTR, TY_ARRAY } kind;
    struct Type *base;   /* PTR/ARRAY */
    int array_len;       /* ARRAY */
} Type;
static Type ty_int_v = { TY_INT, NULL, 0 };
static Type ty_char_v = { TY_CHAR, NULL, 0 };
static Type ty_void_v = { TY_VOID, NULL, 0 };
static Type *ty_int = &ty_int_v, *ty_char = &ty_char_v, *ty_void = &ty_void_v;

static Type *ptr_to(Type *base) {
    Type *t = (Type *)malloc(sizeof(Type));
    t->kind = TY_PTR; t->base = base; t->array_len = 0;
    return t;
}
static Type *array_of(Type *base, int n) {
    Type *t = (Type *)malloc(sizeof(Type));
    t->kind = TY_ARRAY; t->base = base; t->array_len = n;
    return t;
}
/* 이 값이 "가리키는" 대상 하나의 바이트 크기 — 포인터연산/역참조/
 * 인덱싱 스케일과 로드폭(1바이트 vs 8바이트)을 결정한다. */
static int elem_size(Type *pointee) { return pointee->kind == TY_CHAR ? 1 : 8; }
/* 배열이 함수 인자/식 안에서 쓰일 때 붕괴(decay)하는 포인터 타입 */
static Type *decay(Type *t) { return t->kind == TY_ARRAY ? ptr_to(t->base) : t; }
/* 지역변수 하나가 스택에서 차지하는 총 바이트(스칼라는 8, 배열은 원소수*elem_size) */
static int var_storage_size(Type *t) {
    if (t->kind == TY_ARRAY) return t->array_len * elem_size(t->base);
    return 8;
}

/* ===================== 심볼(변수) ===================== */
typedef struct Var {
    char *name;
    Type *type;
    int is_local;
    int offset;      /* local: rbp 기준 음수 오프셋 */
    int data_offset;  /* global: 데이터 섹션 내 오프셋 */
    long init_val;    /* global: 정수 상수 초기화값(없으면 0) */
    struct Var *next;
} Var;

static Var *g_globals = NULL;
static Var *find_global(const char *name) {
    for (Var *v = g_globals; v; v = v->next) if (strcmp(v->name, name) == 0) return v;
    return NULL;
}

/* ===================== AST ===================== */
typedef enum {
    ND_NUM, ND_STR, ND_VAR, ND_ASSIGN,
    ND_ADD, ND_SUB, ND_MUL, ND_DIV, ND_MOD,
    ND_EQ, ND_NE, ND_LT, ND_LE, ND_GT, ND_GE, ND_LAND, ND_LOR,
    ND_NEG, ND_NOT, ND_ADDR, ND_DEREF, ND_INDEX, ND_CALL,
    ND_BLOCK, ND_IF, ND_WHILE, ND_FOR, ND_RETURN, ND_EXPR_STMT, ND_LOCAL_DECL, ND_NOP
} NodeKind;

typedef struct Node Node;
struct Node {
    NodeKind kind;
    Node *lhs, *rhs;
    Node *cond, *then_, *els_, *init, *post, *body;
    Node *next;   /* 블록 내 statement 연결, call args 연결 */
    long ival;
    char *sval; int slen;
    char *name;
    Var *var;
    Node *args;
    Type *type;   /* 식의 결과 타입(코드생성 중 채워짐) */
};
static Node *new_node(NodeKind k) { Node *n = (Node *)calloc(1, sizeof(Node)); n->kind = k; return n; }

/* ===================== 함수 ===================== */
typedef struct Function {
    char *name;
    Type *ret_type;
    Var *params[6];
    int param_count;
    Var *locals; /* 함수 전체 평평한 스코프(alloc 순서) */
    Node *body;
    int stack_size;
    int is_builtin; /* 런타임 트램폴린(true) vs 사용자 함수(false) */
    int code_offset; /* 최종 코드버퍼 내 시작 오프셋(레이아웃 완료 후 채워짐) */
    struct Function *next;
} Function;
static Function *g_funcs = NULL, *g_funcs_tail = NULL;
static void add_func(Function *f) {
    if (g_funcs_tail) g_funcs_tail->next = f; else g_funcs = f;
    g_funcs_tail = f;
}
static Function *find_func(const char *name) {
    for (Function *f = g_funcs; f; f = f->next) if (strcmp(f->name, name) == 0) return f;
    return NULL;
}

/* ===================== 파서 ===================== */
static int g_pos;
static Token *cur(void) { return &g_toks[g_pos]; }
static int at_punct(const char *s) { return cur()->kind == TK_PUNCT && strcmp(cur()->sval, s) == 0; }
static int at_kw(const char *s) { return cur()->kind == TK_IDENT && strcmp(cur()->sval, s) == 0; }
static void expect_punct(const char *s) {
    if (!at_punct(s)) dief("'%s'가 필요함", s);
    g_pos++;
}
static char *expect_ident(void) {
    if (cur()->kind != TK_IDENT) die("식별자가 필요함");
    char *s = cur()->sval; g_pos++; return s;
}

static Function *g_cur_func = NULL;
static Var *find_local(const char *name) {
    if (!g_cur_func) return NULL;
    for (Var *v = g_cur_func->locals; v; v = v->next) if (strcmp(v->name, name) == 0) return v;
    return NULL;
}
static Var *add_local(char *name, Type *type) {
    Var *v = (Var *)calloc(1, sizeof(Var));
    v->name = name; v->type = type; v->is_local = 1;
    v->next = g_cur_func->locals; /* 최신 선언이 먼저 오도록(같은 이름 재선언 시 최근 것 우선 — 알려진 단순화) */
    g_cur_func->locals = v;
    return v;
}

/* 타입 키워드로 시작하는지(선언문인지) 판별 */
static int at_type_kw(void) {
    return cur()->kind == TK_IDENT &&
           (strcmp(cur()->sval, "int") == 0 || strcmp(cur()->sval, "char") == 0 || strcmp(cur()->sval, "void") == 0);
}
/* base 타입 + '*' 여러 개 파싱 */
static Type *parse_type(void) {
    Type *t;
    if (at_kw("int")) { t = ty_int; g_pos++; }
    else if (at_kw("char")) { t = ty_char; g_pos++; }
    else if (at_kw("void")) { t = ty_void; g_pos++; }
    else { die("타입(int/char/void)이 필요함"); t = ty_int; }
    while (at_punct("*")) { t = ptr_to(t); g_pos++; }
    return t;
}

static Node *parse_expr(void);
static Node *parse_assign(void);

static Node *parse_primary(void) {
    if (at_punct("(")) {
        g_pos++;
        Node *n = parse_expr();
        expect_punct(")");
        return n;
    }
    if (cur()->kind == TK_NUM) {
        Node *n = new_node(ND_NUM); n->ival = cur()->ival; g_pos++; return n;
    }
    if (cur()->kind == TK_CHAR) {
        Node *n = new_node(ND_NUM); n->ival = cur()->ival; g_pos++; return n;
    }
    if (cur()->kind == TK_STR) {
        Node *n = new_node(ND_STR); n->sval = cur()->sval; n->slen = cur()->slen; g_pos++; return n;
    }
    if (cur()->kind == TK_IDENT) {
        char *name = cur()->sval; g_pos++;
        if (at_punct("(")) { /* 함수 호출 */
            g_pos++;
            Node *n = new_node(ND_CALL);
            n->name = name;
            Node head; head.next = NULL; Node *tail = &head;
            if (!at_punct(")")) {
                for (;;) {
                    Node *a = parse_assign();
                    tail->next = a; tail = a;
                    if (at_punct(",")) { g_pos++; continue; }
                    break;
                }
            }
            expect_punct(")");
            n->args = head.next;
            return n;
        }
        Node *n = new_node(ND_VAR);
        n->name = name;
        return n;
    }
    die("식이 필요함");
    return NULL;
}

static Node *parse_postfix(void) {
    Node *n = parse_primary();
    for (;;) {
        if (at_punct("[")) {
            g_pos++;
            Node *idx = parse_expr();
            expect_punct("]");
            Node *ix = new_node(ND_INDEX);
            ix->lhs = n; ix->rhs = idx;
            n = ix;
        } else break;
    }
    return n;
}

static Node *parse_unary(void) {
    if (at_punct("-")) { g_pos++; Node *n = new_node(ND_NEG); n->lhs = parse_unary(); return n; }
    if (at_punct("!")) { g_pos++; Node *n = new_node(ND_NOT); n->lhs = parse_unary(); return n; }
    if (at_punct("*")) { g_pos++; Node *n = new_node(ND_DEREF); n->lhs = parse_unary(); return n; }
    if (at_punct("&")) { g_pos++; Node *n = new_node(ND_ADDR); n->lhs = parse_unary(); return n; }
    return parse_postfix();
}

static Node *parse_term(void) {
    Node *n = parse_unary();
    for (;;) {
        NodeKind k;
        if (at_punct("*")) k = ND_MUL; else if (at_punct("/")) k = ND_DIV; else if (at_punct("%")) k = ND_MOD; else break;
        g_pos++;
        Node *r = parse_unary();
        Node *b = new_node(k); b->lhs = n; b->rhs = r; n = b;
    }
    return n;
}
static Node *parse_additive(void) {
    Node *n = parse_term();
    for (;;) {
        NodeKind k;
        if (at_punct("+")) k = ND_ADD; else if (at_punct("-")) k = ND_SUB; else break;
        g_pos++;
        Node *r = parse_term();
        Node *b = new_node(k); b->lhs = n; b->rhs = r; n = b;
    }
    return n;
}
static Node *parse_relational(void) {
    Node *n = parse_additive();
    for (;;) {
        NodeKind k;
        if (at_punct("<")) k = ND_LT; else if (at_punct(">")) k = ND_GT;
        else if (at_punct("<=")) k = ND_LE; else if (at_punct(">=")) k = ND_GE;
        else break;
        g_pos++;
        Node *r = parse_additive();
        Node *b = new_node(k); b->lhs = n; b->rhs = r; n = b;
    }
    return n;
}
static Node *parse_equality(void) {
    Node *n = parse_relational();
    for (;;) {
        NodeKind k;
        if (at_punct("==")) k = ND_EQ; else if (at_punct("!=")) k = ND_NE; else break;
        g_pos++;
        Node *r = parse_relational();
        Node *b = new_node(k); b->lhs = n; b->rhs = r; n = b;
    }
    return n;
}
static Node *parse_logand(void) {
    Node *n = parse_equality();
    while (at_punct("&&")) { g_pos++; Node *r = parse_equality(); Node *b = new_node(ND_LAND); b->lhs = n; b->rhs = r; n = b; }
    return n;
}
static Node *parse_logor(void) {
    Node *n = parse_logand();
    while (at_punct("||")) { g_pos++; Node *r = parse_logand(); Node *b = new_node(ND_LOR); b->lhs = n; b->rhs = r; n = b; }
    return n;
}
static Node *parse_assign(void) {
    Node *n = parse_logor();
    if (at_punct("=")) {
        g_pos++;
        Node *rhs = parse_assign();
        Node *a = new_node(ND_ASSIGN); a->lhs = n; a->rhs = rhs;
        return a;
    }
    return n;
}
static Node *parse_expr(void) { return parse_assign(); }

static Node *parse_stmt(void);

static Node *parse_block(void) {
    expect_punct("{");
    Node *blk = new_node(ND_BLOCK);
    Node head; head.next = NULL; Node *tail = &head;
    while (!at_punct("}")) {
        Node *s = parse_stmt();
        tail->next = s; tail = s;
    }
    expect_punct("}");
    blk->body = head.next;
    return blk;
}

static Node *parse_local_decl(void) {
    Type *base = parse_type();
    char *name = expect_ident();
    Type *t = base;
    int arr_len = -1;
    if (at_punct("[")) {
        g_pos++;
        if (cur()->kind != TK_NUM) die("배열 크기(정수 상수)가 필요함");
        arr_len = (int)cur()->ival; g_pos++;
        expect_punct("]");
        t = array_of(base, arr_len);
    }
    Var *v = add_local(name, t);
    Node *decl = new_node(ND_LOCAL_DECL);
    decl->var = v;
    if (at_punct("=")) {
        g_pos++;
        if (arr_len >= 0) {
            /* Milestone 36: 배열 초기화 리스트 { e0, e1, ... } — 콜 인자
             * 리스트와 같은 방식(Node.args + next 체인)으로 저장해두고,
             * gen_stmt의 ND_LOCAL_DECL 처리에서 원소별 대입으로 풀어낸다.
             * C 표준과 동일하게: 명시된 항목보다 배열이 크면 나머지는
             * 0으로 채운다. 항목이 배열 크기보다 많으면 에러. */
            expect_punct("{");
            Node head; head.next = NULL; Node *tail = &head;
            int count = 0;
            if (!at_punct("}")) {
                for (;;) {
                    Node *e = parse_assign();
                    e->next = NULL;
                    tail->next = e; tail = e;
                    count++;
                    if (at_punct(",")) {
                        g_pos++;
                        if (at_punct("}")) break; /* trailing comma 허용 */
                        continue;
                    }
                    break;
                }
            }
            expect_punct("}");
            if (count > arr_len) die("배열 초기화 항목이 배열 크기보다 많음");
            decl->args = head.next;
            decl->ival = count;
        } else {
            decl->rhs = parse_assign();
        }
    }
    expect_punct(";");
    return decl;
}

static Node *parse_stmt(void) {
    if (at_punct("{")) return parse_block();
    if (at_kw("if")) {
        g_pos++;
        expect_punct("(");
        Node *n = new_node(ND_IF);
        n->cond = parse_expr();
        expect_punct(")");
        n->then_ = parse_stmt();
        if (at_kw("else")) { g_pos++; n->els_ = parse_stmt(); }
        return n;
    }
    if (at_kw("while")) {
        g_pos++;
        expect_punct("(");
        Node *n = new_node(ND_WHILE);
        n->cond = parse_expr();
        expect_punct(")");
        n->body = parse_stmt();
        return n;
    }
    if (at_kw("for")) {
        g_pos++;
        expect_punct("(");
        Node *n = new_node(ND_FOR);
        if (!at_punct(";")) n->init = parse_expr();
        expect_punct(";");
        if (!at_punct(";")) n->cond = parse_expr();
        expect_punct(";");
        if (!at_punct(")")) n->post = parse_expr();
        expect_punct(")");
        n->body = parse_stmt();
        return n;
    }
    if (at_kw("return")) {
        g_pos++;
        Node *n = new_node(ND_RETURN);
        if (!at_punct(";")) n->lhs = parse_expr();
        expect_punct(";");
        return n;
    }
    if (at_punct(";")) { g_pos++; return new_node(ND_NOP); }
    if (at_type_kw()) return parse_local_decl();
    {
        Node *n = new_node(ND_EXPR_STMT);
        n->lhs = parse_expr();
        expect_punct(";");
        return n;
    }
}

static void parse_program(void) {
    while (cur()->kind != TK_EOF) {
        Type *base = parse_type();
        char *name = expect_ident();
        if (at_punct("(")) { /* 함수 정의(선언만 하고 정의 없는 프로토타입은 지원 안 함) */
            g_pos++;
            Function *f = (Function *)calloc(1, sizeof(Function));
            f->name = name; f->ret_type = base;
            g_cur_func = f;
            if (!at_punct(")")) {
                for (;;) {
                    if (f->param_count >= 6) die("매개변수는 최대 6개까지만 지원함");
                    Type *pt = parse_type();
                    char *pname = expect_ident();
                    Var *pv = add_local(pname, pt);
                    f->params[f->param_count++] = pv;
                    if (at_punct(",")) { g_pos++; continue; }
                    break;
                }
            }
            expect_punct(")");
            f->body = parse_block();
            add_func(f);
            g_cur_func = NULL;
            continue;
        }
        /* 전역 변수 */
        Type *t = base;
        int arr_len = -1;
        if (at_punct("[")) {
            g_pos++;
            if (cur()->kind != TK_NUM) die("배열 크기(정수 상수)가 필요함");
            arr_len = (int)cur()->ival; g_pos++;
            expect_punct("]");
            t = array_of(base, arr_len);
        }
        Var *v = (Var *)calloc(1, sizeof(Var));
        v->name = name; v->type = t; v->is_local = 0;
        if (at_punct("=")) {
            g_pos++;
            if (cur()->kind != TK_NUM && cur()->kind != TK_CHAR) die("전역 변수는 정수 상수 초기화만 지원함(알려진 한계)");
            v->init_val = cur()->ival; g_pos++;
        }
        v->next = g_globals; g_globals = v;
        expect_punct(";");
    }
}

/* ===================== x86-64 기계어 인코더 ===================== */
enum { RAX=0,RCX=1,RDX=2,RBX=3,RSP=4,RBP=5,RSI=6,RDI=7,R8=8,R9=9,R10=10 };
static const int ARG_REGS[6] = { RDI, RSI, RDX, RCX, R8, R9 };

static void rex(Buf *b, int w, int r, int x, int bb) {
    buf_u8(b, (uint8_t)(0x40 | (w?8:0) | (r?4:0) | (x?2:0) | (bb?1:0)));
}
static void modrm(Buf *b, int mod, int reg, int rm) {
    buf_u8(b, (uint8_t)((mod << 6) | ((reg & 7) << 3) | (rm & 7)));
}
static void e_push(Buf *b, int reg) { if (reg >= 8) rex(b,0,0,0,1); buf_u8(b, (uint8_t)(0x50 + (reg & 7))); }
static void e_pop(Buf *b, int reg)  { if (reg >= 8) rex(b,0,0,0,1); buf_u8(b, (uint8_t)(0x58 + (reg & 7))); }
static size_t e_mov_imm64(Buf *b, int reg, uint64_t imm) {
    rex(b,1,0,0,reg>=8); buf_u8(b,(uint8_t)(0xB8+(reg&7)));
    size_t at = b->len; buf_u64(b, imm); return at;
}
static void e_mov_imm32_eax(Buf *b, uint32_t imm) { buf_u8(b,0xB8); buf_u32(b, imm); } /* eax만, REX 불필요 */
static void e_mov_reg_reg(Buf *b, int dst, int src) { /* mov dst, src (64bit) */
    rex(b,1,src>=8,0,dst>=8); buf_u8(b,0x89); modrm(b,3,src,dst);
}
/* mov dst, [base+disp32] (64비트 로드) */
static void e_load64(Buf *b, int dst, int base, int32_t disp) {
    rex(b,1,dst>=8,0,base>=8); buf_u8(b,0x8B); modrm(b,2,dst,base); buf_u32(b,(uint32_t)disp);
}
/* mov [base+disp32], src (64비트 스토어) */
static void e_store64(Buf *b, int base, int32_t disp, int src) {
    rex(b,1,src>=8,0,base>=8); buf_u8(b,0x89); modrm(b,2,src,base); buf_u32(b,(uint32_t)disp);
}
/* movzx dst64, byte[base+disp32] */
static void e_loadzx8(Buf *b, int dst, int base, int32_t disp) {
    rex(b,1,dst>=8,0,base>=8); buf_u8(b,0x0F); buf_u8(b,0xB6); modrm(b,2,dst,base); buf_u32(b,(uint32_t)disp);
}
/* mov byte[base+disp32], src(하위 1바이트) */
static void e_store8(Buf *b, int base, int32_t disp, int src) {
    rex(b,0,src>=8,0,base>=8); buf_u8(b,0x88); modrm(b,2,src,base); buf_u32(b,(uint32_t)disp);
}
/* lea dst, [base+disp32] */
static void e_lea(Buf *b, int dst, int base, int32_t disp) {
    rex(b,1,dst>=8,0,base>=8); buf_u8(b,0x8D); modrm(b,2,dst,base); buf_u32(b,(uint32_t)disp);
}
static void e_add(Buf *b, int dst, int src) { rex(b,1,src>=8,0,dst>=8); buf_u8(b,0x01); modrm(b,3,src,dst); }
static void e_sub(Buf *b, int dst, int src) { rex(b,1,src>=8,0,dst>=8); buf_u8(b,0x29); modrm(b,3,src,dst); }
static void e_imul(Buf *b, int dst, int src) { rex(b,1,dst>=8,0,src>=8); buf_u8(b,0x0F); buf_u8(b,0xAF); modrm(b,3,dst,src); }
static void e_cmp(Buf *b, int a, int bb_) { rex(b,1,bb_>=8,0,a>=8); buf_u8(b,0x39); modrm(b,3,bb_,a); }
static void e_cqo(Buf *b) { rex(b,1,0,0,0); buf_u8(b,0x99); }
static void e_idiv(Buf *b, int reg) { rex(b,1,0,0,reg>=8); buf_u8(b,0xF7); modrm(b,3,7,reg); }
static void e_neg(Buf *b, int reg)  { rex(b,1,0,0,reg>=8); buf_u8(b,0xF7); modrm(b,3,3,reg); }
static void e_setcc(Buf *b, uint8_t cc, int reg) { /* reg는 al 등 하위바이트, reg<4만 지원(우리는 항상 rax만 씀) */
    buf_u8(b,0x0F); buf_u8(b,cc); modrm(b,3,0,reg);
}
static void e_movzx_al(Buf *b) { buf_u8(b,0x0F); buf_u8(b,0xB6); modrm(b,3,RAX,RAX); } /* movzx eax,al */
static void e_test_self(Buf *b, int reg) { rex(b,1,reg>=8,0,reg>=8); buf_u8(b,0x85); modrm(b,3,reg,reg); }
static size_t e_jmp(Buf *b)  { buf_u8(b,0xE9); size_t at=b->len; buf_u32(b,0); return at; }
static size_t e_jz(Buf *b)   { buf_u8(b,0x0F); buf_u8(b,0x84); size_t at=b->len; buf_u32(b,0); return at; }
static size_t e_call_placeholder(Buf *b) { buf_u8(b,0xE8); size_t at=b->len; buf_u32(b,0); return at; }
static void e_ret(Buf *b) { buf_u8(b,0xC3); }
static void e_leave(Buf *b) { buf_u8(b,0xC9); }
static void e_int80(Buf *b) { buf_u8(b,0xCD); buf_u8(b,0x80); }
static void patch_rel32(Buf *b, size_t at, size_t target_off) {
    int32_t rel = (int32_t)((int64_t)target_off - (int64_t)(at + 4));
    buf_u32_at(b, at, (uint32_t)rel);
}

/* ===================== 지연 고정(fixup) ===================== */
typedef enum { FX_CALL, FX_GLOBAL_ADDR, FX_STR_ADDR } FixupKind;
typedef struct { size_t patch_off; FixupKind kind; Function *func; Var *var; int str_id; } Fixup;
static Fixup *g_fixups; static int g_nfixups, g_fixup_cap;
static void add_fixup(size_t off, FixupKind kind, Function *f, Var *v, int str_id) {
    if (g_nfixups >= g_fixup_cap) { g_fixup_cap = g_fixup_cap?g_fixup_cap*2:256; g_fixups=(Fixup*)realloc(g_fixups,sizeof(Fixup)*g_fixup_cap); }
    Fixup fx = { off, kind, f, v, str_id };
    g_fixups[g_nfixups++] = fx;
}
typedef struct { char *bytes; int len; int offset; } StrEntry;
static StrEntry *g_strs; static int g_nstrs, g_str_cap;
static int add_string(const char *bytes, int len) {
    if (g_nstrs >= g_str_cap) { g_str_cap = g_str_cap?g_str_cap*2:256; g_strs=(StrEntry*)realloc(g_strs,sizeof(StrEntry)*g_str_cap); }
    g_strs[g_nstrs].bytes = (char*)bytes; g_strs[g_nstrs].len = len; g_strs[g_nstrs].offset = 0;
    return g_nstrs++;
}

/* 인코더 추가분 (앞에서 빠뜨린 것들) */
static void e_sub_imm32(Buf *b, int reg, uint32_t imm) { rex(b,1,0,0,reg>=8); buf_u8(b,0x81); modrm(b,3,5,reg); buf_u32(b,imm); }
static size_t e_jnz(Buf *b) { buf_u8(b,0x0F); buf_u8(b,0x85); size_t at=b->len; buf_u32(b,0); return at; }

/* ===================== 코드생성 ===================== */
static Buf *code; /* 모든 함수(런타임 트램폴린 포함)가 순서대로 쌓이는 공용 버퍼 */

static Type *expr_type(Node *n) {
    switch (n->kind) {
        case ND_NUM: return ty_int;
        case ND_STR: return ptr_to(ty_char);
        case ND_VAR: {
            Var *v = find_local(n->name);
            if (!v) v = find_global(n->name);
            if (!v) dief("선언되지 않은 변수: %s", n->name);
            n->var = v;
            return decay(v->type);
        }
        case ND_ADDR: return ptr_to(expr_type(n->lhs));
        case ND_DEREF: { Type *t = expr_type(n->lhs); if (t->kind != TY_PTR) die("포인터가 아닌 값을 역참조함(*)"); return t->base; }
        case ND_INDEX: { Type *t = expr_type(n->lhs); if (t->kind != TY_PTR) die("배열/포인터가 아닌 값을 인덱싱함([])"); return t->base; }
        case ND_CALL: { Function *f = find_func(n->name); if (!f) dief("선언되지 않은 함수 호출: %s", n->name); return f->ret_type; }
        case ND_ASSIGN: return expr_type(n->lhs);
        case ND_ADD: case ND_SUB: { Type *lt = expr_type(n->lhs); return (lt->kind == TY_PTR) ? lt : ty_int; }
        default: return ty_int;
    }
}

static void gen_expr(Node *n);

static void gen_addr(Node *n) {
    switch (n->kind) {
        case ND_VAR: {
            Var *v = n->var ? n->var : (find_local(n->name) ? find_local(n->name) : find_global(n->name));
            if (!v) dief("선언되지 않은 변수: %s", n->name);
            n->var = v;
            if (v->is_local) { e_lea(code, RAX, RBP, v->offset); }
            else { size_t at = e_mov_imm64(code, RAX, 0); add_fixup(at, FX_GLOBAL_ADDR, NULL, v, 0); }
            return;
        }
        case ND_DEREF: gen_expr(n->lhs); return;
        case ND_INDEX: {
            Type *base_t = expr_type(n->lhs);
            int esz = elem_size(base_t->base);
            gen_expr(n->lhs); e_push(code, RAX);
            gen_expr(n->rhs);
            if (esz != 1) { e_mov_imm64(code, R10, (uint64_t)esz); e_imul(code, RAX, R10); }
            e_pop(code, RCX);
            e_add(code, RAX, RCX);
            return;
        }
        default: die("대입 불가능한 식(lvalue 아님)");
    }
}

static void gen_expr(Node *n) {
    switch (n->kind) {
        case ND_NUM: e_mov_imm64(code, RAX, (uint64_t)(int64_t)n->ival); return;
        case ND_STR: {
            int id = add_string(n->sval, n->slen);
            size_t at = e_mov_imm64(code, RAX, 0);
            add_fixup(at, FX_STR_ADDR, NULL, NULL, id);
            return;
        }
        case ND_VAR: {
            expr_type(n); /* n->var 채우기 위해 호출(부수효과) */
            Var *v = n->var;
            if (v->type->kind == TY_ARRAY) { gen_addr(n); return; }
            if (v->is_local) { e_load64(code, RAX, RBP, v->offset); }
            else {
                size_t at = e_mov_imm64(code, RAX, 0);
                add_fixup(at, FX_GLOBAL_ADDR, NULL, v, 0);
                e_load64(code, RAX, RAX, 0);
            }
            return;
        }
        case ND_ASSIGN: {
            int width8 = 1;
            if (n->lhs->kind == ND_DEREF || n->lhs->kind == ND_INDEX) {
                Type *pointee = expr_type(n->lhs);
                width8 = (elem_size(pointee) == 8);
            }
            gen_addr(n->lhs); e_push(code, RAX);
            gen_expr(n->rhs);
            e_mov_reg_reg(code, RCX, RAX);
            e_pop(code, RAX);
            if (width8) e_store64(code, RAX, 0, RCX); else e_store8(code, RAX, 0, RCX);
            e_mov_reg_reg(code, RAX, RCX);
            return;
        }
        case ND_ADD: case ND_SUB: {
            Type *lt = expr_type(n->lhs);
            int scale = (lt->kind == TY_PTR) ? elem_size(lt->base) : 1;
            gen_expr(n->lhs); e_push(code, RAX);
            gen_expr(n->rhs);
            if (scale != 1) { e_mov_imm64(code, R10, (uint64_t)scale); e_imul(code, RAX, R10); }
            e_mov_reg_reg(code, RCX, RAX);
            e_pop(code, RAX);
            if (n->kind == ND_ADD) e_add(code, RAX, RCX); else e_sub(code, RAX, RCX);
            return;
        }
        case ND_MUL: case ND_DIV: case ND_MOD: {
            gen_expr(n->lhs); e_push(code, RAX);
            gen_expr(n->rhs); e_mov_reg_reg(code, RCX, RAX); e_pop(code, RAX);
            if (n->kind == ND_MUL) e_imul(code, RAX, RCX);
            else { e_cqo(code); e_idiv(code, RCX); if (n->kind == ND_MOD) e_mov_reg_reg(code, RAX, RDX); }
            return;
        }
        case ND_EQ: case ND_NE: case ND_LT: case ND_LE: case ND_GT: case ND_GE: {
            gen_expr(n->lhs); e_push(code, RAX);
            gen_expr(n->rhs); e_mov_reg_reg(code, RCX, RAX); e_pop(code, RAX);
            e_cmp(code, RAX, RCX);
            uint8_t cc = 0x94;
            switch (n->kind) {
                case ND_EQ: cc = 0x94; break; case ND_NE: cc = 0x95; break;
                case ND_LT: cc = 0x9C; break; case ND_LE: cc = 0x9E; break;
                case ND_GT: cc = 0x9F; break; case ND_GE: cc = 0x9D; break;
                default: break;
            }
            e_setcc(code, cc, RAX); e_movzx_al(code);
            return;
        }
        case ND_NEG: gen_expr(n->lhs); e_neg(code, RAX); return;
        case ND_NOT: {
            gen_expr(n->lhs);
            e_mov_imm64(code, RCX, 0);
            e_cmp(code, RAX, RCX);
            e_setcc(code, 0x94, RAX); e_movzx_al(code);
            return;
        }
        case ND_ADDR: gen_addr(n->lhs); return;
        case ND_DEREF: {
            Type *t = expr_type(n);
            gen_expr(n->lhs);
            if (elem_size(t) == 8) e_load64(code, RAX, RAX, 0); else e_loadzx8(code, RAX, RAX, 0);
            return;
        }
        case ND_INDEX: {
            Type *t = expr_type(n);
            gen_addr(n);
            if (elem_size(t) == 8) e_load64(code, RAX, RAX, 0); else e_loadzx8(code, RAX, RAX, 0);
            return;
        }
        case ND_LAND: {
            gen_expr(n->lhs); e_test_self(code, RAX); size_t j1 = e_jz(code);
            gen_expr(n->rhs); e_test_self(code, RAX); size_t j2 = e_jz(code);
            e_mov_imm64(code, RAX, 1); size_t jend = e_jmp(code);
            size_t flbl = code->len; e_mov_imm64(code, RAX, 0);
            size_t elbl = code->len;
            patch_rel32(code, j1, flbl); patch_rel32(code, j2, flbl); patch_rel32(code, jend, elbl);
            return;
        }
        case ND_LOR: {
            gen_expr(n->lhs); e_test_self(code, RAX); size_t j1 = e_jnz(code);
            gen_expr(n->rhs); e_test_self(code, RAX); size_t j2 = e_jnz(code);
            e_mov_imm64(code, RAX, 0); size_t jend = e_jmp(code);
            size_t tlbl = code->len; e_mov_imm64(code, RAX, 1);
            size_t elbl = code->len;
            patch_rel32(code, j1, tlbl); patch_rel32(code, j2, tlbl); patch_rel32(code, jend, elbl);
            return;
        }
        case ND_CALL: {
            Node *args[6]; int argc = 0;
            for (Node *a = n->args; a; a = a->next) { if (argc >= 6) die("함수 호출 인자는 최대 6개까지만 지원함"); args[argc++] = a; }
            for (int i = 0; i < argc; i++) { gen_expr(args[i]); e_push(code, RAX); }
            for (int i = argc - 1; i >= 0; i--) e_pop(code, ARG_REGS[i]);
            Function *f = find_func(n->name);
            if (!f) dief("선언되지 않은 함수: %s", n->name);
            size_t at = e_call_placeholder(code);
            add_fixup(at, FX_CALL, f, NULL, 0);
            return;
        }
        default: die("지원하지 않는 식 종류(내부 오류)");
    }
}

static void gen_stmt(Node *n) {
    switch (n->kind) {
        case ND_BLOCK: for (Node *s = n->body; s; s = s->next) gen_stmt(s); return;
        case ND_EXPR_STMT: gen_expr(n->lhs); return;
        case ND_LOCAL_DECL: {
            if (n->args || n->ival > 0) {
                /* Milestone 36: 배열 초기화 리스트 — 원소별로 arr[i] = expr_i
                 * (또는 리스트가 짧으면 0) 형태의 대입을 그대로 재사용해
                 * 코드를 생성한다. 다른 스칼라 대입 경로와 동일하게
                 * "스택에 임시 Node를 만들어 gen_expr(ND_ASSIGN)에 넘기는"
                 * 기존 기법(바로 아래 스칼라 분기 참고)을 그대로 따랐다. */
                Node *cur_init = n->args;
                int elen = n->var->type->array_len;
                for (int i = 0; i < elen; i++) {
                    Node idxnode; memset(&idxnode, 0, sizeof(idxnode));
                    idxnode.kind = ND_NUM; idxnode.ival = i;

                    Node arrnode; memset(&arrnode, 0, sizeof(arrnode));
                    arrnode.kind = ND_VAR; arrnode.name = n->var->name; arrnode.var = n->var;

                    Node idxexpr; memset(&idxexpr, 0, sizeof(idxexpr));
                    idxexpr.kind = ND_INDEX; idxexpr.lhs = &arrnode; idxexpr.rhs = &idxnode;

                    Node zero; memset(&zero, 0, sizeof(zero));
                    zero.kind = ND_NUM; zero.ival = 0;

                    Node asg; memset(&asg, 0, sizeof(asg));
                    asg.kind = ND_ASSIGN; asg.lhs = &idxexpr;
                    asg.rhs = cur_init ? cur_init : &zero;

                    gen_expr(&asg);
                    if (cur_init) cur_init = cur_init->next;
                }
                return;
            }
            if (n->rhs) {
                Node varnode; memset(&varnode, 0, sizeof(varnode));
                varnode.kind = ND_VAR; varnode.name = n->var->name; varnode.var = n->var;
                Node asg; memset(&asg, 0, sizeof(asg));
                asg.kind = ND_ASSIGN; asg.lhs = &varnode; asg.rhs = n->rhs;
                gen_expr(&asg);
            }
            return;
        }
        case ND_IF: {
            gen_expr(n->cond); e_test_self(code, RAX);
            size_t j1 = e_jz(code);
            gen_stmt(n->then_);
            if (n->els_) {
                size_t j2 = e_jmp(code);
                patch_rel32(code, j1, code->len);
                gen_stmt(n->els_);
                patch_rel32(code, j2, code->len);
            } else {
                patch_rel32(code, j1, code->len);
            }
            return;
        }
        case ND_WHILE: {
            size_t loop_start = code->len;
            gen_expr(n->cond); e_test_self(code, RAX);
            size_t j1 = e_jz(code);
            gen_stmt(n->body);
            size_t jback = e_jmp(code); patch_rel32(code, jback, loop_start);
            patch_rel32(code, j1, code->len);
            return;
        }
        case ND_FOR: {
            if (n->init) gen_expr(n->init);
            size_t loop_start = code->len;
            size_t j1 = 0; int has_cond = (n->cond != NULL);
            if (has_cond) { gen_expr(n->cond); e_test_self(code, RAX); j1 = e_jz(code); }
            gen_stmt(n->body);
            if (n->post) gen_expr(n->post);
            size_t jback = e_jmp(code); patch_rel32(code, jback, loop_start);
            if (has_cond) patch_rel32(code, j1, code->len);
            return;
        }
        case ND_RETURN: {
            if (n->lhs) gen_expr(n->lhs); else e_mov_imm64(code, RAX, 0);
            e_leave(code); e_ret(code);
            return;
        }
        case ND_NOP: return;
        default: gen_expr(n); return;
    }
}

static void assign_offsets(Function *f) {
    int offset = 0;
    for (Var *v = f->locals; v; v = v->next) {
        int sz = var_storage_size(v->type);
        sz = (sz + 7) & ~7;
        offset += sz;
        v->offset = -offset;
    }
    f->stack_size = (offset + 15) & ~15;
}

static void gen_function(Function *f) {
    g_cur_func = f;
    assign_offsets(f);
    f->code_offset = (int)code->len;
    e_push(code, RBP);
    e_mov_reg_reg(code, RBP, RSP);
    e_sub_imm32(code, RSP, (uint32_t)f->stack_size);
    for (int i = 0; i < f->param_count; i++) e_store64(code, RBP, f->params[i]->offset, ARG_REGS[i]);
    gen_stmt(f->body);
    e_leave(code); e_ret(code); /* 암묵적 fallthrough(명시적 return 없이 함수 끝에 도달) 대비 */
    g_cur_func = NULL;
}

static void pad_to(Buf *b, size_t start_offset, size_t min_len) {
    while (b->len - start_offset < min_len) buf_u8(b, 0xCC); /* int3 필러 */
}

static Function *make_builtin(const char *name, Type *ret) {
    Function *f = (Function *)calloc(1, sizeof(Function));
    f->name = strdup(name); f->ret_type = ret; f->is_builtin = 1;
    add_func(f);
    return f;
}

/* _write/_exit/_gettick 트램폴린 몸체를 코드버퍼 맨 앞에 심는다. 각각
 * 16바이트로 패딩해두는 이유: 이 자리 자체는 JetOS에서 실제로 쓰는
 * int $0x80 트램폴린이지만, 호스트 테스트 하네스가 검증 목적으로 이
 * 자리를 real syscall/함수포인터 호출로 바꿔치기할 수 있게 여유
 * 공간을 남겨둔 것(개발용 편의, OS 런타임 계약과는 무관 — jcc.c
 * 헤더 주석 참고). */
static void gen_builtins(void) {
    Function *fw = find_func("_write");
    fw->code_offset = (int)code->len;
    e_mov_imm32_eax(code, 0); e_int80(code); e_ret(code);
    pad_to(code, (size_t)fw->code_offset, 16);

    Function *fe = find_func("_exit");
    fe->code_offset = (int)code->len;
    e_mov_imm32_eax(code, 1); e_int80(code); e_ret(code);
    pad_to(code, (size_t)fe->code_offset, 16);

    Function *fg = find_func("_gettick");
    fg->code_offset = (int)code->len;
    e_mov_imm32_eax(code, 2); e_int80(code); e_ret(code);
    pad_to(code, (size_t)fg->code_offset, 16);
}

/* ===================== ELF64 산출물 ===================== */
#define LINK_BASE 0x100000000ULL /* kernel/mm/vmm.c의 VMM_USER_VIRT_BASE(4GiB)와 반드시 일치해야 함 */
#define HEADER_SIZE 120           /* Elf64 헤더(64) + 프로그램 헤더 1개(56) */

static void emit_elf_header(Buf *out, uint64_t entry, uint64_t filesize) {
    uint8_t ident[16] = { 0x7F,'E','L','F', 2,1,1,0, 0,0,0,0,0,0,0,0 };
    buf_bytes(out, ident, 16);
    uint16_t e_type = 2, e_machine = 62; /* ET_EXEC, EM_X86_64 */
    buf_bytes(out, &e_type, 2);
    buf_bytes(out, &e_machine, 2);
    uint32_t e_version = 1; buf_bytes(out, &e_version, 4);
    buf_u64(out, entry);
    buf_u64(out, 64);   /* e_phoff */
    buf_u64(out, 0);    /* e_shoff */
    uint32_t e_flags = 0; buf_bytes(out, &e_flags, 4);
    uint16_t e_ehsize = 64, e_phentsize = 56, e_phnum = 1, e_shentsize = 0, e_shnum = 0, e_shstrndx = 0;
    buf_bytes(out, &e_ehsize, 2);
    buf_bytes(out, &e_phentsize, 2);
    buf_bytes(out, &e_phnum, 2);
    buf_bytes(out, &e_shentsize, 2);
    buf_bytes(out, &e_shnum, 2);
    buf_bytes(out, &e_shstrndx, 2);

    uint32_t p_type = 1, p_flags = 7; /* PT_LOAD, RWX */
    buf_bytes(out, &p_type, 4);
    buf_bytes(out, &p_flags, 4);
    buf_u64(out, 0);           /* p_offset */
    buf_u64(out, LINK_BASE);   /* p_vaddr */
    buf_u64(out, LINK_BASE);   /* p_paddr */
    buf_u64(out, filesize);    /* p_filesz */
    buf_u64(out, filesize);    /* p_memsz  */
    buf_u64(out, 0x1000);      /* p_align */
}

int main(int argc, char **argv) {
    if (argc != 3) { fprintf(stderr, "사용법: jcc <입력.c> <출력.elf>\n"); return 1; }

    FILE *fin = fopen(argv[1], "rb");
    if (!fin) { fprintf(stderr, "jcc: '%s'를 열 수 없음\n", argv[1]); return 1; }
    fseek(fin, 0, SEEK_END); long fsize = ftell(fin); fseek(fin, 0, SEEK_SET);
    char *src = (char *)malloc((size_t)fsize + 1);
    if (fread(src, 1, (size_t)fsize, fin) != (size_t)fsize) { fprintf(stderr, "jcc: 소스 읽기 실패\n"); return 1; }
    src[fsize] = '\0';
    fclose(fin);

    lex(src);
    make_builtin("_write", ty_int);
    make_builtin("_exit", ty_void);
    make_builtin("_gettick", ty_int);
    parse_program();

    Function *main_fn = find_func("main");
    if (!main_fn || main_fn->is_builtin) die("main 함수가 없음");

    Buf codebuf; buf_init(&codebuf);
    code = &codebuf;

    gen_builtins();

    /* _start: main() 호출 -> 반환값을 _exit()로 넘김(어차피 커널이 무시하지만
     * C 관례상 형태는 갖춘다 — tools/jcc.c 상단 주석 참고) */
    size_t start_off = code->len;
    { size_t at = e_call_placeholder(code); add_fixup(at, FX_CALL, main_fn, NULL, 0); }
    e_mov_reg_reg(code, RDI, RAX);
    { Function *fe = find_func("_exit"); size_t at = e_call_placeholder(code); add_fixup(at, FX_CALL, fe, NULL, 0); }
    e_ret(code); /* 안 돌아오지만 안전망 */

    for (Function *f = g_funcs; f; f = f->next) {
        if (f->is_builtin) continue;
        gen_function(f);
    }

    /* ---- 데이터 섹션 레이아웃(전역 변수 -> 문자열 리터럴 풀 순서) ---- */
    Buf databuf; buf_init(&databuf);
    for (Var *v = g_globals; v; v = v->next) {
        v->data_offset = (int)databuf.len;
        int sz = var_storage_size(v->type);
        for (int i = 0; i < sz; i++) buf_u8(&databuf, 0);
        if (v->type->kind != TY_ARRAY) buf_u64_at(&databuf, (size_t)v->data_offset, (uint64_t)(int64_t)v->init_val);
    }
    for (int i = 0; i < g_nstrs; i++) {
        g_strs[i].offset = (int)databuf.len;
        buf_bytes(&databuf, g_strs[i].bytes, (size_t)g_strs[i].len);
        buf_u8(&databuf, 0); /* NUL 종료 */
    }

    uint64_t code_base = LINK_BASE + HEADER_SIZE;
    uint64_t data_base = code_base + code->len;

    /* ---- 지연 고정(fixup) 전부 해소 ---- */
    for (int i = 0; i < g_nfixups; i++) {
        Fixup *fx = &g_fixups[i];
        if (fx->kind == FX_CALL) {
            /* patch_rel32은 code버퍼 내부 상대offset 좌표계를 쓴다 —
             * code_base(=LINK_BASE+HEADER_SIZE)는 호출측/대상측 양쪽에
             * 똑같이 더해지는 값이라 상대오프셋 계산에서 상쇄되므로,
             * func->code_offset을 그대로 넘기면 된다. */
            patch_rel32(code, fx->patch_off, (size_t)fx->func->code_offset);
        } else if (fx->kind == FX_GLOBAL_ADDR) {
            uint64_t addr = data_base + (uint64_t)fx->var->data_offset;
            buf_u64_at(code, fx->patch_off, addr);
        } else if (fx->kind == FX_STR_ADDR) {
            uint64_t addr = data_base + (uint64_t)g_strs[fx->str_id].offset;
            buf_u64_at(code, fx->patch_off, addr);
        }
    }

    uint64_t entry = code_base + start_off;
    uint64_t filesize = HEADER_SIZE + code->len + databuf.len;

    Buf out; buf_init(&out);
    emit_elf_header(&out, entry, filesize);
    buf_bytes(&out, code->data, code->len);
    buf_bytes(&out, databuf.data, databuf.len);

    FILE *fout = fopen(argv[2], "wb");
    if (!fout) { fprintf(stderr, "jcc: '%s'를 쓸 수 없음\n", argv[2]); return 1; }
    fwrite(out.data, 1, out.len, fout);
    fclose(fout);

    fprintf(stderr, "jcc: %s -> %s (%zu바이트, entry=0x%llx)\n", argv[1], argv[2], out.len, (unsigned long long)entry);
    return 0;
}
