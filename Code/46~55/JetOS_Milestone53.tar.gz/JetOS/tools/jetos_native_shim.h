/* JetOS - tools/jetos_native_shim.h
 * Milestone 43: "JetOS가 JetOS를 개발할 수 있는 환경"의 핵심 조각.
 *
 * jcc.c(M30)/jas.c(M42)는 지금까지 호스트(개발 샌드박스)의 gcc로 빌드되는
 * "호스트 도구"였다 — JetOS 소스를 컴파일/어셈블하긴 하지만, 그 컴파일
 * 작업 자체는 호스트 CPU에서 돌았다. 이 헤더는 그 두 도구(그리고 앞으로
 * 나올 비슷한 도구)를 __JETOS_NATIVE__ 매크로 하나로 "JetOS 위에서 직접
 * 실행되는 Ring3 프로그램"으로도 빌드할 수 있게 해주는 최소 런타임이다.
 *
 * 전략: libc를 통째로 새로 구현하는 대신, jcc.c/jas.c가 실제로 쓰는
 * 극히 좁은 부분집합(malloc/calloc/realloc, memcpy/memset/strcmp/strlen/
 * strdup/strtol, isspace/isxdigit/isdigit/tolower)만 JetOS 시스템콜
 * (kernel/hal/syscall.h) 위에 다시 구현한다. 이 함수들의 이름과
 * 시그니처를 표준 libc 함수와 똑같이 맞춰뒀기 때문에(jetos_malloc이
 * 아니라 매크로로 malloc 자체를 가리키게 함), jcc.c/jas.c 본문은 단
 * 한 줄도 안 고쳐도 된다 — #include 부분과 die()류의 에러 출력
 * 몇 줄만 #ifdef로 갈라주면 끝.
 *
 * 빌드법(tools/testdata/elf_link.ld와 build_test_native_elf.sh가 이미
 * 확립해둔 패턴 그대로 재사용):
 *   gcc -nostdlib -static -O2 -fno-pic -no-pie -fno-stack-protector \
 *       -mcmodel=large -D__JETOS_NATIVE__ -Wl,--build-id=none \
 *       -T tools/testdata/elf_link.ld -o build/jcc.elf tools/jcc.c
 * 산출물은 LINK_BASE(0x100000000)에 링크된 진짜 JetOS ELF64 실행파일 —
 * jash에서 `run /jcc.elf hello.c hello_out.elf` 처럼 그대로 실행된다.
 *
 * 알려진 한계(정직하게 문서화):
 *   - malloc은 SYS_BRK 위의 단순 "bump 할당기"다 — free()는 사실상
 *     아무것도 안 한다(jcc/jas 둘 다 컴파일 한 번 하고 죽는 짧은 수명의
 *     프로그램이라 메모리를 안 돌려줘도 실용적으로 문제없다는 판단,
 *     jcc.c가 host 버전에서도 애초에 free()를 한 번도 안 부른다는
 *     점과 일관됨).
 *   - realloc은 "새로 malloc하고 옛날 내용을 복사"만 한다 — 옛 블록
 *     크기를 따로 기억 안 해서 항상 요청한 새 크기만큼 전부 복사한다
 *     (더 큰 값을 복사해도 안전하도록 넉넉히 어림잡음 — 아래 참고).
 *   - 파일은 JETFS 세계관 안에서만 존재(호스트 파일시스템 경로 없음).
 *   - argv/argc는 JetOS의 실행 로더가 아직 인자 전달을 지원하지 않아서
 *     (kernel/exec/elf_loader.c, 알려진 한계) 이 시점에는 넘어오지
 *     않는다 — 그래서 이번 마일스톤에서는 jcc_native/jas_native가
 *     고정 경로(/jcc_in.c, /jcc_out.elf 등)를 쓰는 임시 버전으로
 *     검증한다(아래 tools/jcc.c의 __JETOS_NATIVE__ main() 참고).
 */
#ifndef JETOS_NATIVE_SHIM_H
#define JETOS_NATIVE_SHIM_H
#include <stddef.h> /* size_t, NULL — 컴파일러 내장 헤더라 libc 링크 없이도 안전 */

typedef size_t size_t_j; /* 기존 이름 유지(아래 함수들에서 계속 씀) */

#define J_SYS_WRITE    0
#define J_SYS_EXIT     1
#define J_SYS_GETTICK  2
#define J_SYS_BRK      3
#define J_SYS_OPEN     4
#define J_SYS_READ     5
#define J_SYS_WRITE_FD 6
#define J_SYS_CLOSE    7

static long jsyscall(long num, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile (
        "int $0x80"
        : "=a"(ret)
        : "a"(num), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory"
    );
    return ret;
}

/* ---- 메모리: SYS_BRK 위의 bump 할당기 ---- */
static unsigned char *g_heap_cur = (unsigned char *)0;
static unsigned char *g_heap_end = (unsigned char *)0;

static void *malloc(size_t_j n) {
    n = (n + 15UL) & ~15UL; /* 16바이트 정렬 */
    if (!g_heap_cur) {
        long cur_brk = jsyscall(J_SYS_BRK, 0, 0, 0); /* 조회 */
        g_heap_cur = (unsigned char *)cur_brk;
        g_heap_end = g_heap_cur;
    }
    if ((size_t_j)(g_heap_end - g_heap_cur) < n) {
        size_t_j grow = n > 0x100000UL ? n : 0x100000UL; /* 최소 1MiB씩 확장 */
        long want = (long)(g_heap_end + grow);
        long got = jsyscall(J_SYS_BRK, want, 0, 0);
        g_heap_end = (unsigned char *)got;
        if ((size_t_j)(g_heap_end - g_heap_cur) < n) return (void *)0; /* OOM */
    }
    void *p = g_heap_cur;
    g_heap_cur += n;
    return p;
}
static void *calloc(size_t_j nmemb, size_t_j size) {
    size_t_j total = nmemb * size;
    unsigned char *p = (unsigned char *)malloc(total);
    if (p) for (size_t_j i = 0; i < total; i++) p[i] = 0;
    return p;
}
static void *realloc(void *ptr, size_t_j newsize) {
    /* 표준 realloc 규약: ptr==NULL이면 malloc(newsize)와 같다(옛 내용을
     * 복사할 게 없음) — 이걸 빠뜨리면 jcc.c/jas.c의 "cap==0일 때 처음
     * 할당" 경로가 존재하지도 않는 옛 블록을 읽으려다 NULL 역참조로
     * 죽는다(이번 마일스톤에서 실제로 잡은 크래시 — 아래 host harness
     * 참고). ptr이 NULL이 아닐 때는, 옛 블록 크기를 안 남겨두므로
     * "새 크기만큼 전부" 복사한다 — jcc.c/jas.c의 growable buffer가
     * 항상 확장 방향으로만 realloc을 호출한다는 전제 하에 안전
     * (정확한 해법은 아니지만 이 두 도구의 실제 buf_reserve 패턴에서는
     * 항상 맞음, 아래 host harness로 검증). */
    if (!ptr) return malloc(newsize);
    void *np = malloc(newsize);
    if (!np) return (void *)0;
    unsigned char *d = (unsigned char *)np, *s = (unsigned char *)ptr;
    for (size_t_j i = 0; i < newsize; i++) d[i] = s[i];
    return np;
}

/* ---- 문자열/메모리 ---- */
static size_t_j strlen(const char *s) { size_t_j n = 0; while (s[n]) n++; return n; }
static int strcmp(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}
static void *memcpy(void *dst, const void *src, size_t_j n) {
    unsigned char *d = (unsigned char *)dst; const unsigned char *s = (const unsigned char *)src;
    for (size_t_j i = 0; i < n; i++) d[i] = s[i];
    return dst;
}
static char *strdup(const char *s) {
    size_t_j n = strlen(s);
    char *p = (char *)malloc(n + 1);
    memcpy(p, s, n + 1);
    return p;
}
static void *memset(void *dst, int c, size_t_j n) {
    unsigned char *d = (unsigned char *)dst;
    for (size_t_j i = 0; i < n; i++) d[i] = (unsigned char)c;
    return dst;
}
static char *strchr(const char *s, int c) {
    while (*s) { if (*s == (char)c) return (char *)s; s++; }
    return (c == 0) ? (char *)s : (char *)0;
}
static char *strrchr(const char *s, int c) {
    const char *last = (c == 0) ? s + strlen(s) : (char *)0;
    for (; *s; s++) if (*s == (char)c) last = s;
    return (char *)last;
}
static char *strncpy(char *dst, const char *src, size_t_j n) {
    size_t_j i = 0;
    for (; i < n && src[i]; i++) dst[i] = src[i];
    for (; i < n; i++) dst[i] = 0;
    return dst;
}
static long strtol(const char *nptr, char **endptr, int base) {
    const char *p = nptr;
    int neg = 0;
    if (*p == '-') { neg = 1; p++; } else if (*p == '+') { p++; }
    if (base == 0) {
        if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) { base = 16; p += 2; }
        else if (p[0] == '0' && p[1] >= '0' && p[1] <= '7') { base = 8; p++; }
        else base = 10;
    } else if (base == 16 && p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) {
        p += 2;
    }
    long v = 0;
    for (;;) {
        int d;
        char c = *p;
        if (c >= '0' && c <= '9') d = c - '0';
        else if (c >= 'a' && c <= 'f') d = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') d = c - 'A' + 10;
        else break;
        if (d >= base) break;
        v = v * base + d;
        p++;
    }
    if (endptr) *endptr = (char *)p;
    return neg ? -v : v;
}
static long long strtoll(const char *nptr, char **endptr, int base) {
    /* strtol과 완전히 같은 로직 재사용(jas.c는 32비트 .quad 상수 이상은
     * 안 다뤄서 정밀도 손실 없음 — long과 long long이 이 x86-64 ABI에서
     * 둘 다 64비트라 캐스트로 충분). */
    return (long long)strtol(nptr, endptr, base);
}

/* ---- ctype.h 최소 대체(jas.c가 쓰는 것만) ---- */
static int isspace(int c) { return c==' '||c=='\t'||c=='\n'||c=='\r'||c=='\v'||c=='\f'; }
static int isxdigit(int c) { return (c>='0'&&c<='9')||(c>='a'&&c<='f')||(c>='A'&&c<='F'); }
static int isdigit(int c) { return c>='0'&&c<='9'; }
static int tolower(int c) { return (c>='A'&&c<='Z') ? c+32 : c; }

/* ---- 출력/종료 ---- */
static void jetos_write_str(const char *s) { jsyscall(J_SYS_WRITE, (long)s, 0, 0); }
static void jetos_exit(int code) { (void)code; jsyscall(J_SYS_EXIT, 0, 0, 0); for (;;) {} }

/* ---- 파일 I/O ---- */
static int jetos_open(const char *path, int mode) { return (int)jsyscall(J_SYS_OPEN, (long)path, mode, 0); }
static long jetos_read(int fd, void *buf, long n) { return jsyscall(J_SYS_READ, fd, (long)buf, n); }
static long jetos_write_fd(int fd, const void *buf, long n) { return jsyscall(J_SYS_WRITE_FD, fd, (long)buf, n); }
static void jetos_close(int fd) { jsyscall(J_SYS_CLOSE, fd, 0, 0); }

/* 파일 전체를 읽어 malloc된 버퍼로 반환(+NUL 종단), *out_len에 길이.
 * fseek/ftell이 없는 이 ABI에서 fopen+fread 조합을 대신한다 — SYS_READ가
 * 0을 반환할 때까지(EOF) 4KiB씩 누적해서 읽는다. */
static char *jetos_read_whole_file(const char *path, size_t_j *out_len) {
    int fd = jetos_open(path, 0);
    if (fd < 0) return (char *)0;
    size_t_j cap = 4096, len = 0;
    char *buf = (char *)malloc(cap);
    for (;;) {
        if (len + 4096 > cap) {
            size_t_j ncap = cap * 2;
            char *nb = (char *)malloc(ncap);
            memcpy(nb, buf, len);
            buf = nb; cap = ncap;
        }
        long got = jetos_read(fd, buf + len, 4096);
        if (got <= 0) break;
        len += (size_t_j)got;
    }
    jetos_close(fd);
    buf[len] = '\0';
    if (out_len) *out_len = len;
    return buf;
}

#endif /* JETOS_NATIVE_SHIM_H */
