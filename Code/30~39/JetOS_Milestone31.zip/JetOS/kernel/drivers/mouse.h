#ifndef JETOS_MOUSE_H
#define JETOS_MOUSE_H

#include <stdint.h>

typedef struct {
    int dx, dy;         /* 마지막 폴링 이후 상대 이동량 */
    int left, right, middle; /* 버튼 상태 (1=눌림) */
    int wheel;           /* Milestone 20: 마지막 폴링 이후 휠 이동량(+위로, -아래로).
                           * IntelliMouse 확장을 지원하지 않는 마우스/컨트롤러에서는
                           * 항상 0 — mouse_init()이 초기화 시 자동 감지한다. */
} mouse_event_t;

/* 8042 컨트롤러의 보조(aux) 포트를 활성화하고 PS/2 마우스를 기본
 * 설정(3바이트 패킷, 데이터 리포팅 활성화)으로 초기화한다.
 * Milestone 20: 초기화 중 Microsoft IntelliMouse 매직 시퀀스로 휠
 * 지원 여부를 감지해서, 되면 4바이트 패킷 모드로 전환한다(실패해도
 * 표준 3바이트 모드로 정상 동작 — 그냥 휠만 안 됨). */
void mouse_init(void);

/* IRQ12 핸들러(순수 C)에서 호출된다. 포트 0x60에서 바이트를 읽어
 * 3바이트 패킷을 누적/해석한다. */
void mouse_irq_handler(void);

/* 마지막으로 완성된 패킷 이후의 상대 이동/버튼 상태를 가져오고
 * 내부 dx/dy 누적을 리셋한다. 새 이벤트가 없으면 0을 반환한다. */
int mouse_poll_event(mouse_event_t *out);

#endif
