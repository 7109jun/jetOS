kernel/drivers/keyboard.o: kernel/drivers/keyboard.c \
 kernel/drivers/keyboard.h kernel/drivers/../hal/x86_asm_shim.h
kernel/drivers/keyboard.h:
kernel/drivers/../hal/x86_asm_shim.h:
