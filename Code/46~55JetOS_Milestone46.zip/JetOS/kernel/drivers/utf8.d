kernel/drivers/utf8.o: kernel/drivers/utf8.c kernel/drivers/utf8.h
kernel/drivers/utf8.h:
