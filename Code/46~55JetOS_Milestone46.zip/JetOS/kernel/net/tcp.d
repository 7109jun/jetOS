kernel/net/tcp.o: kernel/net/tcp.c kernel/net/tcp.h kernel/net/net.h \
 kernel/net/../int/pit.h kernel/net/../proc/scheduler.h \
 kernel/net/../proc/thread.h
kernel/net/tcp.h:
kernel/net/net.h:
kernel/net/../int/pit.h:
kernel/net/../proc/scheduler.h:
kernel/net/../proc/thread.h:
