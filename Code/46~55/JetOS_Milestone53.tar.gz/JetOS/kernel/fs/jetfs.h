#ifndef JETOS_JETFS_H
#define JETOS_JETFS_H

#include <stdint.h>

/*
 * JETFS v1 — JetOS 자체 파일시스템.
 *
 * 레이아웃 (블록 크기 4096바이트 = AHCI 섹터 8개):
 *   블록 0        : 슈퍼블록
 *   블록 1..N     : inode 테이블 (고정 크기 배열)
 *   블록 N+1..M   : 데이터 블록 비트맵
 *   블록 M+1..끝  : 데이터 블록
 *
 * 디렉터리는 "데이터 블록에 dirent 배열을 담은 특수 inode"로 표현된다.
 * (Milestone 4 범위의 단순화가 여전히 남아있음: 디렉터리 자체는 직접
 * 블록 12개까지만 사용 — 항목 약 1700개 정도까지 충분하므로 실질적
 * 제약은 아니다.)
 *
 * Milestone 8: 파일(FILE 타입)은 직접 블록 12개에 더해 단일 간접
 * 블록(indirect block) 1개를 지원한다. 간접 블록은 그 자체가 하나의
 * 데이터 블록이며, uint32_t 블록 번호 1024개(4096/4)를 담을 수 있다.
 * 이 단계에서 파일 최대 크기는 (12 + 1024) * 4096 바이트 ≈ 4.2MB.
 *
 * Milestone 22: 이중 간접 블록(double indirect) 추가. 이중 간접
 * 블록도 그 자체가 데이터 블록이며, "간접 블록 번호" 1024개를
 * 담는다 — 즉 이중 간접 블록 하나가 간접 블록 1024개(각각 데이터
 * 블록 1024개)를 가리켜, 이중 간접 경로로만 1024*1024개 블록에
 * 닿을 수 있다. 이 단계 파일 최대 크기는
 * (12 + 1024 + 1024*1024) * 4096 바이트 ≈ 4.0GB.
 *
 * Milestone 23: 삼중 간접 블록(triple indirect) 추가 — ext2/Linux의
 * 고전적인 "직접+단일+이중+삼중 간접" 아이노드 설계를 개념적으로
 * 참고했다(코드를 그대로 옮긴 게 아니라 "포인터 블록을 한 단계씩
 * 더 두면 주소 공간이 1024배씩 늘어난다"는 아이디어만 가져와 이
 * 프로젝트 스타일대로 새로 작성). 삼중 간접 블록 하나는 "이중
 * 간접 블록 번호" 1024개를 담고, 그 각각이 다시 간접 블록 1024개를,
 * 그 각각이 다시 데이터 블록 1024개를 가리킨다 — 삼중 간접 경로로만
 * 1024*1024*1024개 블록에 닿는다. 최종 파일 최대 크기는
 * (12 + 1024 + 1024*1024 + 1024*1024*1024) * 4096 바이트 ≈ 4.0TB —
 * 요청받은 "파일당 최대 20GB"를 넉넉히 만족한다. 물론 실제로 쓸 수
 * 있는 크기는 디스크 자체 용량(mkjetfs로 만드는 이미지 크기)이 더
 * 작으면 그만큼으로 제한된다 — 20GB 파일을 실제로 담으려면 디스크
 * 이미지 자체를 20GB 이상으로 만들어야 한다(빌드 방법 문서 참고).
 */

#define JETFS_MAGIC 0x4A455446u /* "JETF" */
#define JETFS_BLOCK_SIZE 4096
#define JETFS_SECTORS_PER_BLOCK (JETFS_BLOCK_SIZE / 512)
#define JETFS_MAX_INODES 256
#define JETFS_MAX_NAME 28
#define JETFS_DIRECT_BLOCKS 12
#define JETFS_INDIRECT_PTRS (JETFS_BLOCK_SIZE / sizeof(uint32_t)) /* 1024 */
#define JETFS_DOUBLE_INDIRECT_PTRS (JETFS_BLOCK_SIZE / sizeof(uint32_t)) /* 1024개의 "간접 블록 번호" */
#define JETFS_TRIPLE_INDIRECT_PTRS (JETFS_BLOCK_SIZE / sizeof(uint32_t)) /* 1024개의 "이중간접 블록 번호" */
#define JETFS_MAX_FILE_BLOCKS (JETFS_DIRECT_BLOCKS + JETFS_INDIRECT_PTRS + \
                               (JETFS_DOUBLE_INDIRECT_PTRS * JETFS_INDIRECT_PTRS) + \
                               ((uint64_t)JETFS_TRIPLE_INDIRECT_PTRS * JETFS_DOUBLE_INDIRECT_PTRS * JETFS_INDIRECT_PTRS))
#define JETFS_ROOT_INODE 0

typedef enum {
    JETFS_TYPE_FREE = 0,
    JETFS_TYPE_FILE = 1,
    JETFS_TYPE_DIR  = 2
} jetfs_inode_type_t;

typedef struct {
    uint32_t magic;
    uint32_t total_blocks;
    uint32_t inode_table_start;
    uint32_t inode_table_blocks;
    uint32_t bitmap_start;
    uint32_t bitmap_blocks;
    uint32_t data_start;
    uint32_t root_inode;
    /* Milestone 47: 저널 영역(아래 JETFS_JOURNAL_BLOCKS 참고) 위치.
     * 슈퍼블록 바로 뒤(블록 1)에 고정 배치 — inode 테이블/비트맵/데이터
     * 영역이 전부 이만큼씩 뒤로 밀렸다. 기존 이미지(이 필드가 없던
     * 시절 mkjetfs로 만든 것)는 이 필드가 0으로 읽히는데, 그러면
     * jetfs_mount가 즉시 실패하도록 명시적으로 검사한다(자세한 이유는
     * jetfs_mount 주석 참고) — 새 mkjetfs로 다시 포맷해야 한다는 걸
     * 조용히 무시하는 대신 눈에 보이게 알리기 위함. */
    uint32_t journal_start;
    /* Milestone 48: jetfs_inode_t에 owner_uid가 추가되면서 구조체
     * 크기가 바뀌어 inode 테이블의 온디스크 레이아웃(inode당 바이트
     * 오프셋)이 달라진다 — M47이 journal_start=0을 "예전 포맷"
     * 신호로 썼던 것과 같은 이유로, mkjetfs가 자신이 실제로 빌드된
     * jetfs_inode_t 크기를 여기 적어두고 jetfs_mount가 현재
     * sizeof(jetfs_inode_t)와 다르면 명시적으로 거부한다(조용히
     * inode를 잘못된 오프셋에서 읽어 소유자/블록 정보가 깨지는 것보다
     * 눈에 보이게 재포맷을 요구하는 쪽을 택함). */
    uint32_t inode_struct_size;
    uint8_t  reserved[JETFS_BLOCK_SIZE - 40];
} jetfs_superblock_t;

/* Milestone 47: 메타데이터 쓰기 저널링(write-ahead log) — 정전/크래시
 * 도중에 여러 블록에 걸친 메타데이터 갱신(예: 파일 생성 = inode 블록 +
 * 디렉터리 블록 + 비트맵 블록 3개를 따로따로 씀)이 "일부만 반영된 채"
 * 멈추면 파일시스템이 일관성을 잃는다(예: 디렉터리엔 항목이 생겼는데
 * inode는 아직 안 써져서 가리키는 곳이 쓰레기인 경우). 저널 영역에
 * 먼저 "이 블록들에 이 내용을 쓸 것이다"를 통째로 기록하고 커밋
 * 마커를 마지막에 써서, 그 사이 어디서 멈춰도 다음 마운트 시
 * jetfs_mount가 저널을 읽어 안전하게 재생(replay)하거나 무시할 수
 * 있게 한다. 실제 파일 데이터(큰 파일의 내용 블록)는 저널링 대상이
 * 아니다 — ext3/4의 기본 저널링 모드도 메타데이터만 저널링하는 것과
 * 같은 이유(데이터까지 전부 저널링하면 쓰기가 사실상 두 배가 됨).
 * 레이아웃: journal_start 블록 = 헤더(jetfs_journal_header_t),
 * journal_start+1 .. journal_start+JETFS_JOURNAL_MAX_ENTRIES = 엔트리별
 * "섀도우" 데이터 블록(엔트리 i의 내용은 journal_start+1+i에). */
#define JETFS_JOURNAL_MAX_ENTRIES 16
#define JETFS_JOURNAL_BLOCKS (1 + JETFS_JOURNAL_MAX_ENTRIES)
#define JETFS_JOURNAL_MAGIC_EMPTY     0x4A524E30u /* "JRN0" */
#define JETFS_JOURNAL_MAGIC_COMMITTED 0x4A524E31u /* "JRN1" */

typedef struct {
    uint32_t magic;
    uint32_t entry_count;
    uint32_t target_block[JETFS_JOURNAL_MAX_ENTRIES];
    uint32_t checksum; /* target_block[0..entry_count) XOR — 헤더 자체 손상 감지용(정교한 CRC는 아님) */
} jetfs_journal_header_t;

typedef struct {
    uint32_t type;       /* jetfs_inode_type_t */
    uint64_t size;        /* 바이트 단위(Milestone 23: uint32_t였던 걸 uint64_t로 확장 —
                            * 32비트로는 파일 크기 자체가 ~4.29GB에서 막혀서, 블록
                            * 주소 공간(삼중 간접)을 아무리 늘려도 의미가 없었다) */
    uint32_t block[JETFS_DIRECT_BLOCKS];
    uint32_t block_count;  /* 디렉터리 전용: 사용중인 직접 블록 개수.
                             * 파일은 size로부터 필요 블록 수를 계산하므로
                             * 이 필드를 사용하지 않는다. */
    uint32_t indirect;     /* 파일 전용: 간접 블록 번호 (0=미할당) */
    uint32_t double_indirect; /* 파일 전용(M22): 이중 간접 블록 번호 (0=미할당) */
    uint32_t triple_indirect; /* 파일 전용(M23): 삼중 간접 블록 번호 (0=미할당) */
    uint32_t used;        /* 0=빈 슬롯, 1=사용중 */
    /* Milestone 46: 파일 속성 비트. 기존 이미지(mkjetfs가 inode 테이블
     * 블록 전체를 0으로 밀어서 만듦)에서도 이 필드는 자동으로 0(=속성
     * 없음)이 되므로 하위호환 문제 없음 — 기존 jetfs.img를 새 커널로
     * 열어도 모든 파일이 "속성 없음"으로 잘 읽힌다. */
    uint32_t flags;
    /* Milestone 48: 진짜 소유자 uid. jetfs_create가 만든 시점의
     * scheduler_current()->uid를 그대로 찍는다(커널 스레드/아직
     * 로그인 전이면 0=root). 0은 "루트가 만든 파일"이면서 동시에
     * "권한 검사를 우회할 수 있는 특권 uid"이기도 하다(Unix 관례와
     * 동일) — mkjetfs가 만드는 루트 디렉터리(inode 0)도 필드가
     * 0으로 초기화되어 자연히 root 소유가 된다. */
    uint32_t owner_uid;
} jetfs_inode_t;
#define JETFS_FLAG_READONLY 0x1u /* 켜져 있으면 write/append/delete 전부 거부(rename은 허용 — Windows 관례) */
#define JETFS_ROOT_UID 0u

typedef struct {
    char name[JETFS_MAX_NAME];
    uint32_t inode;
    uint32_t used;
} jetfs_dirent_t;

/* drive_index의 lba_offset(섹터 단위)부터 시작하는 디스크 영역을 JETFS로
 * 마운트한다. 이미 mkjetfs로 포맷되어 있어야 한다. 성공 시 1. */
int jetfs_mount(int drive_index, uint64_t lba_offset);

/* 루트 기준 절대 경로("/dir/file" 형태)로 파일을 연다. */
int jetfs_create(const char *path, jetfs_inode_type_t type);
int jetfs_read(const char *path, void *buffer, uint64_t max_size, uint64_t *out_size);
int jetfs_write(const char *path, const void *data, uint64_t size);

/* Milestone 23: 파일 끝에 이어쓰기(append). 20GB급 대용량 파일은
 * (이 커널의 RAM 한도상) 한 번의 jetfs_write 호출로 통째로 쓸 수
 * 없으므로 — 예를 들어 청크 단위로 내려받으며 이 함수를 반복
 * 호출해 점점 키우는 식으로 실제로 큰 파일을 만들 수 있다. 파일이
 * 없으면 실패(먼저 jetfs_create 필요). */
int jetfs_append(const char *path, const void *data, uint64_t len);

int jetfs_delete(const char *path);
int jetfs_rename(const char *old_path, const char *new_path);

/* Milestone 46: 읽기전용 속성. jetfs_set_readonly(path, 1)을 걸어두면
 * 이후 jetfs_write/jetfs_append/jetfs_delete가 전부 실패(0 반환)한다 —
 * 실수로 시스템 파일을 덮어쓰거나 지우는 걸 막는 최소한의 안전장치
 * (진짜 다중 사용자 권한 모델은 아직 아님 — 사용자별 소유권/other
 * 권한 비트 같은 건 없고, "이 파일을 건드리지 마라"라는 단일 플래그
 * 뿐이다). jetfs_rename은 일부러 막지 않는다(Windows의 읽기전용
 * 속성과 같은 관례 — 이름 변경은 내용을 안 건드림). */
int jetfs_set_readonly(const char *path, int readonly);
int jetfs_is_readonly(const char *path); /* 존재 안 하면 0 */

/* Milestone 48: 진짜 다중 사용자 소유권. jetfs_write/append/delete/
 * rename은 이제 (readonly 플래그 검사에 더해) 호출 스레드의
 * scheduler_current()->uid가 파일 소유자와 같거나 root(uid 0)일
 * 때만 허용한다 — 다르면 실패(0 반환)한다. 읽기(read/stat/list)는
 * 의도적으로 검사하지 않는다(권한 비트 없이 "전체 읽기 허용, 쓰기는
 * 소유자+root만"이라는 가장 단순한 모델 — 진짜 유닉스식 rwx는 다음
 * 과제로 남김, 알려진 한계). */
int jetfs_get_owner(const char *path); /* 존재 안 하면 -1 */
int jetfs_chown(const char *path, uint32_t new_uid); /* root만 가능, 성공 시 1 */

/* Milestone 47 — 테스트 전용 API(제품 코드에서는 호출 금지):
 * path에 old_content를 정상적으로(트랜잭션 밖에서) 써서 파일을 만든
 * 뒤, 그 파일의 첫 데이터 블록에 new_content를 "저널에 커밋까지만
 * 하고 실제 위치엔 반영 안 한" 상태로 남겨둔다 — 정전/크래시가 딱 그
 * 타이밍에 난 상황을 재현. 이 함수가 반환된 직후 프로세스를 강제
 * 종료하고(실제로는 QEMU를 kill) 같은 디스크 이미지로 재부팅하면,
 * jetfs_mount()의 복구 로직이 new_content를 실제로 반영해야 정상 —
 * 재부팅 후 path를 읽었을 때 new_content가 보이면 저널 복구가 실제로
 * 동작한다는 뜻이고, old_content가 보이면(복구 실패) 또는 파일 자체가
 * 깨져 있으면(부분 적용) 저널링에 버그가 있다는 뜻이다. */
int jetfs_debug_crash_test_prepare(const char *path, const char *old_content, const char *new_content);

/* path의 타입/크기를 조회한다. 존재하지 않으면 0. */
int jetfs_stat(const char *path, jetfs_inode_type_t *out_type, uint64_t *out_size);

/* dir_path 아래 항목 이름들을 콜백으로 순서대로 전달한다. */
typedef void (*jetfs_list_cb)(const char *name, jetfs_inode_type_t type, uint64_t size, void *ctx);
int jetfs_list(const char *dir_path, jetfs_list_cb cb, void *ctx);

#endif
