/* JetOS - kernel/net/crypto/x509_min.c - x509_min.h 참고. */
#include "x509_min.h"
#include "der.h"

static int read_seq(der_reader_t *r, const uint8_t **val, size_t *vlen) {
    uint8_t tag;
    if (!der_read_tlv(r, &tag, val, vlen)) return 0;
    return tag == DER_TAG_SEQUENCE;
}

static int read_any(der_reader_t *r, uint8_t *tag, const uint8_t **val, size_t *vlen) {
    return der_read_tlv(r, tag, val, vlen);
}

int x509_extract_rsa_pubkey(const uint8_t *der, size_t der_len, bignum_t *out_n, bignum_t *out_e) {
    der_reader_t cert;
    der_init(&cert, der, der_len);

    /* Certificate ::= SEQUENCE { tbsCertificate, sigAlg, sigValue } */
    const uint8_t *certval; size_t certlen;
    if (!read_seq(&cert, &certval, &certlen)) return 0;
    der_reader_t certbody;
    der_enter(&certbody, certval, certlen);

    /* tbsCertificate ::= SEQUENCE { ... } */
    const uint8_t *tbsval; size_t tbslen;
    if (!read_seq(&certbody, &tbsval, &tbslen)) return 0;
    der_reader_t tbs;
    der_enter(&tbs, tbsval, tbslen);

    uint8_t tag; const uint8_t *val; size_t vlen;
    if (!read_any(&tbs, &tag, &val, &vlen)) return 0;
    if (tag == 0xA0) {
        /* version [0] EXPLICIT — 있으면 스킵하고 다음(serialNumber) 읽기 */
        if (!read_any(&tbs, &tag, &val, &vlen)) return 0;
    }
    /* 지금 tag는 serialNumber(INTEGER)여야 함 — 그냥 지나간다 */
    if (!read_any(&tbs, &tag, &val, &vlen)) return 0; /* signature AlgorithmIdentifier */
    if (!read_any(&tbs, &tag, &val, &vlen)) return 0; /* issuer Name */
    if (!read_any(&tbs, &tag, &val, &vlen)) return 0; /* validity */
    if (!read_any(&tbs, &tag, &val, &vlen)) return 0; /* subject Name */

    /* subjectPublicKeyInfo ::= SEQUENCE { algorithm, subjectPublicKey BIT STRING } */
    if (!read_any(&tbs, &tag, &val, &vlen)) return 0;
    if (tag != DER_TAG_SEQUENCE) return 0;
    der_reader_t spki;
    der_enter(&spki, val, vlen);

    if (!read_any(&spki, &tag, &val, &vlen)) return 0; /* AlgorithmIdentifier — RSA인지 OID 확인은
                                                          * 생략(알려진 단순화, x509_min.h 참고) */
    if (!read_any(&spki, &tag, &val, &vlen)) return 0; /* subjectPublicKey BIT STRING */
    if (tag != DER_TAG_BITSTRING || vlen < 1) return 0;

    /* BIT STRING의 첫 바이트는 "미사용 비트 수"(RSA 키에서는 항상 0) */
    const uint8_t *rsakey_der = val + 1;
    size_t rsakey_len = vlen - 1;

    der_reader_t rsakey;
    der_init(&rsakey, rsakey_der, rsakey_len);
    const uint8_t *rsaval; size_t rsalen;
    if (!read_seq(&rsakey, &rsaval, &rsalen)) return 0; /* RSAPublicKey ::= SEQUENCE */
    der_reader_t rsabody;
    der_enter(&rsabody, rsaval, rsalen);

    const uint8_t *nval, *eval; size_t nlen, elen;
    if (!read_any(&rsabody, &tag, &nval, &nlen) || tag != DER_TAG_INTEGER) return 0;
    if (!read_any(&rsabody, &tag, &eval, &elen) || tag != DER_TAG_INTEGER) return 0;

    /* INTEGER 선행 0x00(양수 부호 바이트) 제거 */
    if (nlen > 1 && nval[0] == 0x00) { nval++; nlen--; }
    if (elen > 1 && eval[0] == 0x00) { eval++; elen--; }

    bn_from_bytes_be(out_n, nval, nlen);
    bn_from_bytes_be(out_e, eval, elen);
    return 1;
}
