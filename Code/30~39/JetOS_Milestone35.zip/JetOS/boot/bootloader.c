/*
 * JetOS - boot/bootloader.c  (Milestone 2)
 *
 * 흐름:
 *   1. UEFI ConOut으로 진행 상황 출력
 *   2. GOP 프레임버퍼 확보
 *   3. ESP의 "\KERNEL.ELF" 를 elf_load_kernel()로 적재 (Milestone 2부터
 *      부트로더와 커널이 완전히 분리된 두 개의 바이너리다)
 *   4. GetMemoryMap() 으로 물리 메모리 지도 확보
 *   5. ExitBootServices()
 *   6. KERNEL.ELF의 진입점(kernel_entry)으로 점프
 *
 * 부트로더는 mingw-w64(MS x64 ABI/PE32+)로, 커널은 네이티브 gcc
 * (SysV ABI/ELF64)로 각각 별도 컴파일된다. 두 ABI를 넘나드는 이
 * 단일 호출 지점에서만 __attribute__((sysv_abi)) 함수 포인터로 명시적
 * 호출 규약을 지정한다.
 */

#include "../include/efi/efi.h"
#include "../include/jetos/boot_info.h"
#include "elf_loader.h"

#define U16(s) ((CHAR16 *) L##s)

static void print(EFI_SYSTEM_TABLE *st, const CHAR16 *s) {
    st->ConOut->OutputString(st->ConOut, (CHAR16 *)s);
}

/* Milestone 35: EFI_GUID 16바이트 원시 비교(EFI_GUID는 UINT32+UINT16+
 * UINT16+UINT8[8] = 정확히 16바이트, 패딩 없음 — 그래서 바이트 단위
 * 비교가 안전하다). */
static int guid_eq(const EFI_GUID *a, const EFI_GUID *b) {
    const uint8_t *pa = (const uint8_t *)a;
    const uint8_t *pb = (const uint8_t *)b;
    for (int i = 0; i < 16; i++) {
        if (pa[i] != pb[i]) return 0;
    }
    return 1;
}

/* KERNEL.ELF는 SysV ABI(네이티브 gcc 기본값)로 컴파일되므로, MS ABI인
 * 이 부트로더에서 점프할 때는 반드시 sysv_abi를 명시해야 한다. */
typedef void (__attribute__((sysv_abi)) *kernel_entry_fn)(jetos_boot_info_t *);

EFI_STATUS EFIAPI efi_main(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable) {
    SystemTable->ConOut->ClearScreen(SystemTable->ConOut);
    print(SystemTable, U16("JetOS Bootloader (Milestone 2)\r\n"));
    print(SystemTable, U16("Locating Graphics Output Protocol...\r\n"));

    /* ---- GOP 프레임버퍼 확보 ---- */
    EFI_GUID gop_guid = EFI_GRAPHICS_OUTPUT_PROTOCOL_GUID;
    EFI_GRAPHICS_OUTPUT_PROTOCOL *gop = NULL;
    EFI_STATUS status = SystemTable->BootServices->LocateProtocol(&gop_guid, NULL, (VOID **)&gop);
    if (EFI_ERROR(status) || gop == NULL) {
        print(SystemTable, U16("FATAL: GOP not found.\r\n"));
        for (;;) { }
    }

    jetos_boot_info_t boot_info;
    boot_info.framebuffer_base = gop->Mode->FrameBufferBase;
    boot_info.framebuffer_size = gop->Mode->FrameBufferSize;
    boot_info.width  = gop->Mode->Info->HorizontalResolution;
    boot_info.height = gop->Mode->Info->VerticalResolution;
    boot_info.pixels_per_scanline = gop->Mode->Info->PixelsPerScanLine;

    /* ---- Milestone 35: ACPI RSDP 찾기 (EFI ConfigurationTable 순회) ----
     * ACPI 2.0+ GUID를 우선 찾고, 없으면 ACPI 1.0 GUID로 폴백한다. 둘 다
     * 없으면 0으로 둬서 커널이 ACPI 관련 기능(APIC/SMP 포함)을 전부
     * 건너뛰고 기존 PIC 단일 코어 경로로 안전하게 폴백하게 한다 —
     * "못 찾으면 죽지 않고 우회"는 이 프로젝트 전체(VirtIO-GPU BAR 검사,
     * JETFS 마운트 실패 시 SKIP 등)에서 반복돼온 원칙이다. */
    EFI_GUID acpi2_guid = { 0x8868e871, 0xe4f1, 0x11d3, { 0xbc, 0x22, 0x00, 0x80, 0xc7, 0x3c, 0x88, 0x81 } };
    EFI_GUID acpi1_guid = { 0xeb9d2d30, 0x2d88, 0x11d3, { 0x9a, 0x16, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d } };
    boot_info.acpi_rsdp = 0;
    for (UINTN ti = 0; ti < SystemTable->NumberOfTableEntries; ti++) {
        EFI_CONFIGURATION_TABLE *ct = &SystemTable->ConfigurationTable[ti];
        if (guid_eq(&ct->VendorGuid, &acpi2_guid)) {
            boot_info.acpi_rsdp = (uint64_t)(UINTN)ct->VendorTable;
            break; /* ACPI 2.0을 찾으면 최우선 — 더 볼 것 없음 */
        }
        if (boot_info.acpi_rsdp == 0 && guid_eq(&ct->VendorGuid, &acpi1_guid)) {
            boot_info.acpi_rsdp = (uint64_t)(UINTN)ct->VendorTable; /* 계속 돌다 2.0을 찾으면 위에서 덮어씀 */
        }
    }
    print(SystemTable, boot_info.acpi_rsdp ? U16("ACPI RSDP found.\r\n") : U16("ACPI RSDP NOT found (continuing without ACPI).\r\n"));

    /* ---- KERNEL.ELF 로드 (Boot Services가 살아있는 동안 해야 함) ---- */
    print(SystemTable, U16("Loading KERNEL.ELF...\r\n"));
    uint64_t entry_point = elf_load_kernel(ImageHandle, SystemTable);
    if (entry_point == 0) {
        print(SystemTable, U16("FATAL: KERNEL.ELF load failed.\r\n"));
        for (;;) { }
    }

    print(SystemTable, U16("Reading UEFI memory map...\r\n"));

    /* ---- 메모리 맵 확보 (ExitBootServices 직전에 반드시 필요) ---- */
    UINTN map_size = 0;
    UINTN map_key = 0;
    UINTN desc_size = 0;
    UINT32 desc_version = 0;
    EFI_MEMORY_DESCRIPTOR *map = NULL;

    SystemTable->BootServices->GetMemoryMap(&map_size, map, &map_key, &desc_size, &desc_version);
    map_size += desc_size * 8; /* AllocatePool 자체가 맵을 바꿀 수 있으므로 여유분 확보 */

    status = SystemTable->BootServices->AllocatePool(EfiLoaderData, map_size, (VOID **)&map);
    if (EFI_ERROR(status)) {
        print(SystemTable, U16("FATAL: AllocatePool failed.\r\n"));
        for (;;) { }
    }

    status = SystemTable->BootServices->GetMemoryMap(&map_size, map, &map_key, &desc_size, &desc_version);
    if (EFI_ERROR(status)) {
        print(SystemTable, U16("FATAL: GetMemoryMap failed.\r\n"));
        for (;;) { }
    }

    boot_info.memory_map = map;
    boot_info.memory_map_size = map_size;
    boot_info.memory_map_descriptor_size = desc_size;

    print(SystemTable, U16("Exiting UEFI Boot Services...\r\n"));

    status = SystemTable->BootServices->ExitBootServices(ImageHandle, map_key);
    if (EFI_ERROR(status)) {
        SystemTable->BootServices->GetMemoryMap(&map_size, map, &map_key, &desc_size, &desc_version);
        status = SystemTable->BootServices->ExitBootServices(ImageHandle, map_key);
        if (EFI_ERROR(status)) {
            print(SystemTable, U16("FATAL: ExitBootServices failed.\r\n"));
            for (;;) { }
        }
    }

    /* 이 지점부터 UEFI Boot Services는 사용할 수 없다. KERNEL.ELF의
     * 진입점으로 점프한다 — 부트로더의 역할은 여기서 끝난다. */
    kernel_entry_fn kentry = (kernel_entry_fn)(uintptr_t)entry_point;
    kentry(&boot_info);

    /* kernel_entry는 반환하지 않는다. 안전망으로 무한 정지. */
    for (;;) { }
    return EFI_SUCCESS;
}
