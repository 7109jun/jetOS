/*
 * JetOS - kernel/hal/auth.c
 * Milestone 34: 사용자 계정 / 로그인(단일 계정).
 * Milestone 48: 진짜 다중 사용자로 확장 — 계정 여러 개를
 * /system/users.txt에 "uid:username:sha256hex\n" 형식으로 저장하고,
 * 로그인에 성공하면 그 uid를 scheduler_current()->uid에 실제로
 * 반영한다(kernel/fs/jetfs.c의 소유권 검사가 그 값을 그대로 읽음).
 * 설계 이유는 auth.h 참고.
 */

#include "auth.h"
#include "../kernel.h"
#include "../fs/jetfs.h"
#include "../net/crypto/sha256.h"
#include "../drivers/keyboard.h"
#include "../drivers/console.h"
#include "../drivers/serial.h"
#include "../proc/scheduler.h"
#include <stddef.h>

#define AUTH_FILE "/system/users.txt"
#define AUTH_LINE_CAP 32
#define AUTH_MAX_USERS 16
#define AUTH_BUF_MAX 1600 /* 16명 * (uid + ':' + 이름31 + ':' + hash64 + '\n') 여유 */

typedef struct {
    uint32_t uid;
    char name[32];
    char hash[65];
} auth_user_t;

static auth_user_t g_users[AUTH_MAX_USERS];
static int g_user_count = 0;
static int g_users_loaded = 0;

static int s_len(const char *s) {
    int i = 0;
    while (s[i]) i++;
    return i;
}

static int s_eq(const char *a, const char *b) {
    int i = 0;
    while (a[i] && b[i]) { if (a[i] != b[i]) return 0; i++; }
    return a[i] == b[i];
}

static void s_copy(char *dst, const char *src, int cap) {
    int i = 0;
    for (; src[i] && i < cap - 1; i++) dst[i] = src[i];
    dst[i] = '\0';
}

static void hex_encode(const uint8_t *in, int n, char *out) {
    static const char H[] = "0123456789abcdef";
    for (int i = 0; i < n; i++) {
        out[i * 2] = H[in[i] >> 4];
        out[i * 2 + 1] = H[in[i] & 0xF];
    }
    out[n * 2] = '\0';
}

/* 비밀번호 원문을 SHA-256으로 해시해 64자 소문자 hex로 만든다(솔트
 * 없음 — auth.h의 정직한 한계 표기 참고). */
static void hash_password(const char *pw, char out_hex65[65]) {
    uint8_t digest[32];
    sha256_oneshot((const uint8_t *)pw, (size_t)s_len(pw), digest);
    hex_encode(digest, 32, out_hex65);
}

static void uid_to_str(uint32_t v, char *buf) {
    char tmp[12]; int n = 0;
    if (v == 0) { buf[0] = '0'; buf[1] = '\0'; return; }
    while (v > 0 && n < 11) { tmp[n++] = (char)('0' + (v % 10)); v /= 10; }
    int i = 0;
    for (int k = n - 1; k >= 0; k--) buf[i++] = tmp[k];
    buf[i] = '\0';
}

static uint32_t str_to_uid(const char *s, int len) {
    uint32_t v = 0;
    for (int i = 0; i < len; i++) {
        if (s[i] < '0' || s[i] > '9') break;
        v = v * 10 + (uint32_t)(s[i] - '0');
    }
    return v;
}

/* "uid:username:hash\n" 줄들을 파싱해 g_users에 채운다. 손상되거나
 * 필드 하나라도 빠진 줄은 조용히 건너뛴다(최선 노력 파싱 — 이
 * 파일은 오직 auth.c만 쓰므로 정상 상태라면 항상 이 형식이다). */
static void users_load(void) {
    if (g_users_loaded) return;
    g_users_loaded = 1;
    g_user_count = 0;

    jetfs_inode_type_t t;
    if (!jetfs_stat(AUTH_FILE, &t, NULL) || t != JETFS_TYPE_FILE) return;

    char buf[AUTH_BUF_MAX];
    uint64_t got = 0;
    if (!jetfs_read(AUTH_FILE, buf, sizeof(buf) - 1, &got)) return;
    buf[got] = '\0';

    uint64_t i = 0;
    while (i < got && g_user_count < AUTH_MAX_USERS) {
        char uidbuf[12]; int ui = 0;
        while (i < got && buf[i] != ':' && buf[i] != '\n' && ui < 11) uidbuf[ui++] = buf[i++];
        uidbuf[ui] = '\0';
        if (i >= got || buf[i] != ':') { while (i < got && buf[i] != '\n') i++; if (i < got) i++; continue; }
        i++; /* skip ':' */

        char name[32]; int ni = 0;
        while (i < got && buf[i] != ':' && buf[i] != '\n' && ni < 31) name[ni++] = buf[i++];
        name[ni] = '\0';
        if (i >= got || buf[i] != ':') { while (i < got && buf[i] != '\n') i++; if (i < got) i++; continue; }
        i++; /* skip ':' */

        char hash[65]; int hi = 0;
        while (i < got && buf[i] != '\n' && hi < 64) hash[hi++] = buf[i++];
        hash[hi] = '\0';
        if (i < got && buf[i] == '\n') i++;

        if (ui > 0 && ni > 0 && hi == 64) {
            g_users[g_user_count].uid = str_to_uid(uidbuf, ui);
            s_copy(g_users[g_user_count].name, name, sizeof(g_users[g_user_count].name));
            s_copy(g_users[g_user_count].hash, hash, sizeof(g_users[g_user_count].hash));
            g_user_count++;
        }
    }
}

static int users_save(void) {
    char out[AUTH_BUF_MAX];
    int n = 0;
    for (int u = 0; u < g_user_count && n < (int)sizeof(out) - 100; u++) {
        char uidbuf[12];
        uid_to_str(g_users[u].uid, uidbuf);
        for (int k = 0; uidbuf[k] && n < (int)sizeof(out) - 2; k++) out[n++] = uidbuf[k];
        out[n++] = ':';
        for (int k = 0; g_users[u].name[k] && n < (int)sizeof(out) - 2; k++) out[n++] = g_users[u].name[k];
        out[n++] = ':';
        for (int k = 0; g_users[u].hash[k] && n < (int)sizeof(out) - 2; k++) out[n++] = g_users[u].hash[k];
        out[n++] = '\n';
    }

    if (!jetfs_stat(AUTH_FILE, NULL, NULL)) {
        if (!jetfs_create(AUTH_FILE, JETFS_TYPE_FILE)) return 0;
    }
    return jetfs_write(AUTH_FILE, out, (uint64_t)n);
}

static int find_by_name(const char *name) {
    for (int i = 0; i < g_user_count; i++) if (s_eq(g_users[i].name, name)) return i;
    return -1;
}

static int find_by_uid(uint32_t uid) {
    for (int i = 0; i < g_user_count; i++) if (g_users[i].uid == uid) return i;
    return -1;
}

/* x,y(절대 프레임버퍼 좌표)에서 한 줄을 편집 가능하게 입력받는다.
 * mask=1이면 입력된 글자 수만큼 '*'만 그린다(비밀번호 필드). Enter로
 * 확정, Backspace로 지움. 다른 위젯 인프라(widget_textbox_t)는 wm 창
 * 안에서만 동작하므로, wm이 아직 초기화되기 전인 이 게이트 화면에서는
 * 쓸 수 없어 g_console에 직접 그리는 최소 버전을 따로 둔다. */
static int auth_read_line(console_t *dc, int x, int y, char *out, int cap, int mask) {
    int len = 0;
    out[0] = '\0';
    char stars[AUTH_LINE_CAP + 1];
    for (;;) {
        char c = keyboard_poll_char();
        if (!c) { scheduler_yield(); continue; }
        if (c == '\n' || c == '\r') break;
        if (c == '\b') {
            if (len > 0) { len--; out[len] = '\0'; }
        } else if (c >= 32 && c < 127 && len < cap - 1 && len < AUTH_LINE_CAP) {
            out[len++] = c;
            out[len] = '\0';
        }
        console_fill_rect(dc, (uint32_t)x, (uint32_t)(y - 12), 300, 16, 0x00101820);
        dc->cursor_x = (uint32_t)x; dc->cursor_y = (uint32_t)y;
        dc->fg_color = 0x00E0ECFA;
        if (mask) {
            int i = 0;
            for (; i < len; i++) stars[i] = '*';
            stars[i] = '\0';
            console_print(dc, stars);
        } else {
            console_print(dc, out);
        }
    }
    return len;
}

static void wait_any_key(void) {
    while (keyboard_poll_char()) {} /* 버퍼 비우기 */
    while (!keyboard_poll_char()) scheduler_yield();
}

/* 로그인/계정생성이 성공한 uid를 지금 이 화면을 그리고 있는(=곧
 * jash/desktop을 계속 실행할) 스레드에 실제로 반영한다. */
static void adopt_uid(uint32_t uid) {
    thread_t *t = scheduler_current();
    if (t) t->uid = uid;
}

void auth_run_gate(void) {
    keyboard_init();

    if (!jetfs_stat("/", NULL, NULL)) {
        serial_write("STAGE: AUTH SKIPPED (JETFS not mounted)\n");
        return;
    }

    console_t *dc = &g_console;
    users_load();

    if (g_user_count == 0) {
        for (;;) {
            console_clear(dc, 0x00101820);
            dc->fg_color = 0x00E0ECFA;
            dc->cursor_x = 40; dc->cursor_y = 40;
            console_print(dc, "JETOS FIRST BOOT - CREATE ACCOUNT");

            dc->cursor_x = 40; dc->cursor_y = 74;
            console_print(dc, "USERNAME:");
            char user[32];
            int ulen = auth_read_line(dc, 170, 74, user, sizeof(user), 0);
            if (ulen == 0) continue;

            dc->cursor_x = 40; dc->cursor_y = 104;
            console_print(dc, "PASSWORD:");
            char pw1[AUTH_LINE_CAP];
            auth_read_line(dc, 170, 104, pw1, sizeof(pw1), 1);

            dc->cursor_x = 40; dc->cursor_y = 134;
            console_print(dc, "CONFIRM PASSWORD:");
            char pw2[AUTH_LINE_CAP];
            auth_read_line(dc, 220, 134, pw2, sizeof(pw2), 1);

            if (pw1[0] == '\0' || !s_eq(pw1, pw2)) {
                dc->fg_color = 0x00FF8080;
                dc->cursor_x = 40; dc->cursor_y = 170;
                console_print(dc, "PASSWORDS EMPTY OR DID NOT MATCH - PRESS ANY KEY TO RETRY");
                wait_any_key();
                continue;
            }

            /* 최초 계정 = uid 0 = root(관리자). Milestone 48: 이후
             * 이 uid가 kernel/fs/jetfs.c의 소유권 검사에서 "누구
             * 파일이든 건드릴 수 있는" 특권 uid로 취급된다 — Windows의
             * 최초 계정이 자동으로 관리자가 되는 것과 같은 관례. */
            g_users[0].uid = 0;
            s_copy(g_users[0].name, user, sizeof(g_users[0].name));
            hash_password(pw1, g_users[0].hash);
            g_user_count = 1;

            if (users_save()) {
                serial_write("STAGE: AUTH ACCOUNT CREATED (user=");
                serial_write(user);
                serial_write(", uid=0/root)\n");
                adopt_uid(0);
                break;
            } else {
                g_user_count = 0;
                dc->fg_color = 0x00FF8080;
                dc->cursor_x = 40; dc->cursor_y = 170;
                console_print(dc, "SAVE FAILED - PRESS ANY KEY TO RETRY");
                wait_any_key();
            }
        }
        console_clear(dc, 0x00101820);
        return;
    }

    for (;;) {
        console_clear(dc, 0x00101820);
        dc->fg_color = 0x00E0ECFA;
        dc->cursor_x = 40; dc->cursor_y = 40;
        console_print(dc, "JETOS LOGIN");

        dc->cursor_x = 40; dc->cursor_y = 74;
        console_print(dc, "USERNAME:");
        char user[32];
        auth_read_line(dc, 170, 74, user, sizeof(user), 0);

        dc->cursor_x = 40; dc->cursor_y = 104;
        console_print(dc, "PASSWORD:");
        char pw[AUTH_LINE_CAP];
        auth_read_line(dc, 170, 104, pw, sizeof(pw), 1);

        int idx = find_by_name(user);
        char hash_hex[65];
        hash_password(pw, hash_hex);
        if (idx >= 0 && s_eq(hash_hex, g_users[idx].hash)) {
            serial_write("STAGE: AUTH LOGIN OK (user=");
            serial_write(g_users[idx].name);
            serial_write(")\n");
            adopt_uid(g_users[idx].uid);
            console_clear(dc, 0x00101820);
            return;
        }

        dc->fg_color = 0x00FF8080;
        dc->cursor_x = 40; dc->cursor_y = 134;
        console_print(dc, "WRONG USERNAME OR PASSWORD - PRESS ANY KEY TO RETRY");
        serial_write("STAGE: AUTH LOGIN FAILED\n");
        wait_any_key();
    }
}

void auth_lock_screen(void) {
    console_t *dc = &g_console;
    users_load();
    if (g_user_count == 0) return; /* 계정 없음 — 잠글 게 없음 */

    thread_t *t = scheduler_current();
    uint32_t cur_uid = t ? t->uid : 0;
    int idx = find_by_uid(cur_uid);
    if (idx < 0) return; /* 지금 이 스레드의 uid로 된 계정이 없음 — 잠글 수 없으니 그냥 통과 */

    serial_write("STAGE: SCREEN LOCKED\n");
    for (;;) {
        console_clear(dc, 0x00101820);
        dc->fg_color = 0x00E0ECFA;
        dc->cursor_x = 40; dc->cursor_y = 40;
        console_print(dc, "JETOS LOCKED");
        dc->cursor_x = 40; dc->cursor_y = 74;
        console_print(dc, "USER: ");
        console_print(dc, g_users[idx].name);

        dc->cursor_x = 40; dc->cursor_y = 104;
        console_print(dc, "PASSWORD:");
        char pw[AUTH_LINE_CAP];
        auth_read_line(dc, 170, 104, pw, sizeof(pw), 1);

        char hash_hex[65];
        hash_password(pw, hash_hex);
        if (s_eq(hash_hex, g_users[idx].hash)) {
            serial_write("STAGE: SCREEN UNLOCKED\n");
            console_clear(dc, 0x00101820);
            return;
        }

        dc->fg_color = 0x00FF8080;
        dc->cursor_x = 40; dc->cursor_y = 134;
        console_print(dc, "WRONG PASSWORD - PRESS ANY KEY TO RETRY");
        wait_any_key();
    }
}

/* Milestone 48: jash용 API — whoami/useradd/su/chown. */
int auth_username_for_uid(uint32_t uid, char *out, int cap) {
    users_load();
    int idx = find_by_uid(uid);
    if (idx < 0) return 0;
    s_copy(out, g_users[idx].name, cap);
    return 1;
}

int auth_add_user(const char *name, const char *pw) {
    users_load();
    /* root(uid 0)만 계정을 새로 만들 수 있다 — 정책을 호출측(jash)이
     * 아니라 여기서 강제해서, 앞으로 다른 호출부가 생겨도 실수로
     * 우회할 수 없게 한다. */
    thread_t *t = scheduler_current();
    uint32_t me = t ? t->uid : 0;
    if (me != 0) return -1;
    if (name[0] == '\0' || pw[0] == '\0') return -1;
    if (g_user_count >= AUTH_MAX_USERS) return -1;
    if (find_by_name(name) >= 0) return -1; /* 중복 이름 */

    uint32_t max_uid = 0;
    for (int i = 0; i < g_user_count; i++) if (g_users[i].uid >= max_uid) max_uid = g_users[i].uid + 1;
    uint32_t new_uid = (g_user_count == 0) ? 0 : max_uid;

    g_users[g_user_count].uid = new_uid;
    s_copy(g_users[g_user_count].name, name, sizeof(g_users[g_user_count].name));
    hash_password(pw, g_users[g_user_count].hash);
    g_user_count++;

    if (!users_save()) { g_user_count--; return -1; }
    return (int)new_uid;
}

int auth_switch_user(const char *name, const char *pw) {
    users_load();
    int idx = find_by_name(name);
    if (idx < 0) return 0;
    char hash_hex[65];
    hash_password(pw, hash_hex);
    if (!s_eq(hash_hex, g_users[idx].hash)) return 0;

    thread_t *t = scheduler_current();
    if (t) t->uid = g_users[idx].uid;
    return 1;
}
