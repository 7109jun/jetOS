#ifndef JETOS_VMM_H
#define JETOS_VMM_H

#include <stdint.h>

/* JetOS 자체 페이지 테이블을 구성하고 CR3에 적재한다.
 * Milestone 2에서는 하위 4GiB를 2MiB 대형 페이지로 항등 매핑(identity
 * mapping)한다 (UEFI가 만들어준 임시 테이블에 더 이상 의존하지 않기
 * 위함). 상위 4GiB를 초과하는 MMIO/메모리는 향후 마일스톤에서 동적
 * 매핑으로 확장한다. */
void vmm_init(void);

/* 현재(공유) 커널 PML4의 물리주소. */
uint64_t vmm_kernel_pml4_phys(void);

/* Milestone 15: 프로세스별 주소공간.
 *
 * vmm_create_process_address_space() — 새 프로세스용 PML4를 만든다.
 * 커널 identity 영역(0~4GiB)은 기존 공유 페이지 테이블을 그대로
 * 재사용(U비트 없음, Ring0 전용 유지)하고, 가상주소
 * vmm_user_virt_base()부터 vmm_user_region_size()만큼의 "유저 영역"만
 * 이 프로세스 전용 페이지 테이블로 새로 마련한다. 실패 시 0.
 *
 * vmm_map_user_page() — 유저 영역 안의 특정 4KB 페이지 하나를 실제
 * 물리 페이지에 연결하고 U비트를 켠다(Ring3 접근 허용). vaddr은 반드시
 * 유저 영역 범위 안이어야 한다. 성공 시 1, 실패(범위 밖 등) 시 0. */
uint64_t vmm_create_process_address_space(void);
int vmm_map_user_page(uint64_t pml4_phys, uint64_t vaddr, uint64_t paddr, int writable);
uint64_t vmm_user_virt_base(void);
uint64_t vmm_user_region_size(void);

#endif
