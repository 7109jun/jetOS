#ifndef JETOS_THREAD_H
#define JETOS_THREAD_H

#include <stdint.h>

#define THREAD_NAME_MAX 16
#define THREAD_DEFAULT_STACK_SIZE (16 * 1024) /* 16KB */
#define THREAD_MAX_FDS 8 /* Milestone 36: 프로세스당 열 수 있는 파일 개수 */
#define THREAD_FD_PATH_MAX 160

typedef enum {
    THREAD_READY,
    THREAD_RUNNING,
    THREAD_BLOCKED,
    THREAD_DEAD
} thread_state_t;

typedef struct thread {
    uint64_t rsp;                  /* 이 스레드가 실행중이 아닐 때의 저장된 스택 포인터 */
    void    *stack_base;           /* kfree용 */
    uint64_t stack_size;
    void   (*entry)(void *arg);
    void    *arg;
    thread_state_t state;
    uint32_t id;
    char     name[THREAD_NAME_MAX];
    uint64_t cr3;                  /* Milestone 16: 이 스레드 전용 주소공간(PML4)의
                                     * 물리주소. 0이면 "공유 커널 주소공간을 그대로
                                     * 쓴다"는 뜻(대부분의 커널 스레드가 이 경우) —
                                     * 스케줄러가 매 컨텍스트 스위치마다 이 값을 보고
                                     * CR3를 갈아끼운다(여러 유저 프로세스가 동시에
                                     * 떠 있어도 서로의 주소공간을 침범하지 않도록). */
    uint64_t user_brk;             /* Milestone 20: SYS_BRK용 — 이 프로세스의 유저
                                     * 영역에서 "현재까지 실제 매핑된" 다음 경계
                                     * 가상주소(페이지 정렬). cr3==0인 커널 스레드는
                                     * 항상 0. */
    struct thread *next;           /* 스케줄러 준비 큐(원형 연결 리스트) 링크 */

    /* Milestone 36: 프로세스별 열린 파일 테이블(SYS_OPEN/READ/WRITE_FD/
     * CLOSE용). fd_mode[i]==0이면 그 슬롯은 비어있음(닫힘), 1=읽기용
     * 열림, 2=쓰기(append-only)용 열림. fd_pos는 다음 읽기가 시작할
     * 파일 내 오프셋(쓰기 모드에서는 안 씀 — 항상 파일 끝에 append).
     * 스레드가 죽어도(thread_exit) 이 테이블을 정리하는 코드는 없다 —
     * 어차피 thread_t 구조체 전체가 곧 kfree되므로 사실상 자동으로
     * "닫히는" 셈이지만, 파일 시스템 쪽에 "이 파일을 쓰기 모드로 물고
     * 있다"는 상태가 남는 게 아니라(JETFS는 그런 잠금 개념이 아예 없음)
     * 정말로 아무 문제가 없다는 걸 명시해둔다. */
    char     fd_path[THREAD_MAX_FDS][THREAD_FD_PATH_MAX];
    uint64_t fd_pos[THREAD_MAX_FDS];
    int      fd_mode[THREAD_MAX_FDS];

    /* Milestone 37: SYS_WRITE 출력을 시리얼 말고 어딘가(예: jash 창)에도
     * 보여주고 싶을 때 쓰는 훅. NULL이면 지금까지처럼 시리얼로만 간다.
     * elf_execute_ex()가 프로그램을 띄운 쪽(예: jash)의 요청에 따라
     * 설정해준다 — thread_t 자신은 "누가 이걸 설정했는지" 전혀 모르고
     * 그냥 함수 포인터 하나를 들고 있을 뿐이다(느슨한 결합). */
    void (*stdout_sink)(const char *s);
} thread_t;

/* 새 스레드를 생성하고 준비(READY) 상태로 스케줄러에 등록한다.
 * entry(arg)가 반환하면 자동으로 thread_exit()이 호출된다. */
thread_t *thread_create(const char *name, void (*entry)(void *arg), void *arg);

/* Milestone 16: 이 스레드를 특정 프로세스 주소공간에 묶는다. 아직
 * 실행을 시작하지 않은(THREAD_READY) 스레드에 대해서만 호출해야
 * 안전하다 — thread_create() 직후, 그 스레드가 실제로 스케줄되기
 * 전에 부르는 용도다(elf_loader.c가 이렇게 쓴다). */
void thread_set_address_space(thread_t *t, uint64_t pml4_phys);

/* Milestone 20: 이 스레드(유저 프로세스)의 현재 brk(다음으로 매핑된
 * 가상주소 경계)를 설정한다. elf_loader.c가 ELF 로드 직후 "세그먼트가
 * 끝나는 지점"으로 초기화하고, 이후 SYS_BRK 시스템콜이 갱신한다. */
void thread_set_user_brk(thread_t *t, uint64_t brk);

/* 현재 스레드를 종료한다 (반환하지 않음) */
__attribute__((noreturn)) void thread_exit(void);

#endif
