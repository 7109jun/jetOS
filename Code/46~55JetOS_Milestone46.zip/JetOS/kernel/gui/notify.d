kernel/gui/notify.o: kernel/gui/notify.c kernel/gui/notify.h \
 kernel/gui/../int/pit.h
kernel/gui/notify.h:
kernel/gui/../int/pit.h:
