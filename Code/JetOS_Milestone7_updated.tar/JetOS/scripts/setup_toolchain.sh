#!/usr/bin/env bash
# JetOS 개발환경 설치 스크립트 (Debian/Ubuntu 기준)
set -e
echo "[JetOS] 필요한 패키지 설치 중..."
sudo apt update
sudo apt install -y mingw-w64 qemu-system-x86 ovmf mtools dosfstools make
echo "[JetOS] 설치 완료."
echo "  - 컴파일러: x86_64-w64-mingw32-gcc"
echo "  - QEMU:     qemu-system-x86_64"
echo "  - OVMF 펌웨어 위치 확인: dpkg -L ovmf | grep OVMF"
