#ifndef JETOS_KERNEL_ENTRY_H
#define JETOS_KERNEL_ENTRY_H

#include "../include/jetos/boot_info.h"

/* KERNEL.ELF의 실제 ELF 진입점 (부트로더가 e_entry로 이 심볼을 직접 호출).
 * SysV ABI(native gcc 기본값)로 컴파일되며, 부트로더 쪽에서는
 * __attribute__((sysv_abi)) 함수 포인터로 캐스팅해 호출한다. */
void kernel_entry(jetos_boot_info_t *boot_info);

#endif
