#include "utf8.h"

int utf8_decode(const char *s, uint32_t *out_codepoint) {
    const uint8_t *p = (const uint8_t *)s;
    uint8_t b0 = p[0];
    if (b0 == 0) return 0;

    if (b0 < 0x80) { /* 1바이트 (ASCII) */
        *out_codepoint = b0;
        return 1;
    }
    if ((b0 & 0xE0) == 0xC0 && (p[1] & 0xC0) == 0x80) { /* 2바이트 */
        *out_codepoint = (uint32_t)((b0 & 0x1F) << 6) | (p[1] & 0x3F);
        return 2;
    }
    if ((b0 & 0xF0) == 0xE0 && (p[1] & 0xC0) == 0x80 && (p[2] & 0xC0) == 0x80) { /* 3바이트 (한글 포함) */
        *out_codepoint = (uint32_t)((b0 & 0x0F) << 12) | (uint32_t)((p[1] & 0x3F) << 6) | (p[2] & 0x3F);
        return 3;
    }
    if ((b0 & 0xF8) == 0xF0 && (p[1] & 0xC0) == 0x80 && (p[2] & 0xC0) == 0x80 && (p[3] & 0xC0) == 0x80) { /* 4바이트 */
        *out_codepoint = (uint32_t)((b0 & 0x07) << 18) | (uint32_t)((p[1] & 0x3F) << 12) |
                         (uint32_t)((p[2] & 0x3F) << 6) | (p[3] & 0x3F);
        return 4;
    }

    /* 잘못된 시퀀스: 이 바이트 하나만 소비하고 라틴1 폴백으로 취급 */
    *out_codepoint = b0;
    return 1;
}
