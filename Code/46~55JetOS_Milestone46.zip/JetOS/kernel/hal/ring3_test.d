kernel/hal/ring3_test.o: kernel/hal/ring3_test.c kernel/hal/ring3_test.h \
 kernel/hal/x86_asm_shim.h kernel/hal/gdt.h kernel/hal/syscall.h \
 kernel/hal/../mm/heap.h kernel/hal/../drivers/serial.h
kernel/hal/ring3_test.h:
kernel/hal/x86_asm_shim.h:
kernel/hal/gdt.h:
kernel/hal/syscall.h:
kernel/hal/../mm/heap.h:
kernel/hal/../drivers/serial.h:
