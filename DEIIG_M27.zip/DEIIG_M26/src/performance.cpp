#include "performance.hpp"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <thread>
#include <algorithm>
#ifdef _WIN32
#include <windows.h>
#include <psapi.h>
#else
#include <unistd.h>
#endif

namespace fs = std::filesystem;
namespace deiig::performance {

std::uint64_t parse_kb_line(const std::string& line) {
    std::istringstream s(line); std::string key, unit; std::uint64_t v=0; s >> key >> v >> unit; return v * 1024ULL;
}

Snapshot sample() {
    Snapshot x;
#ifdef _WIN32
    MEMORYSTATUSEX ms{}; ms.dwLength=sizeof(ms); if (GlobalMemoryStatusEx(&ms)) { x.memory_total=ms.ullTotalPhys; x.memory_used=ms.ullTotalPhys-ms.ullAvailPhys; }
    PROCESS_MEMORY_COUNTERS pm{}; if (GetProcessMemoryInfo(GetCurrentProcess(), &pm, sizeof(pm))) x.process_memory=pm.WorkingSetSize;
    FILETIME a,b,c,d; if (GetProcessTimes(GetCurrentProcess(),&a,&b,&c,&d)) { ULARGE_INTEGER u{},k{}; u.LowPart=d.dwLowDateTime;u.HighPart=d.dwHighDateTime;k.LowPart=c.dwLowDateTime;k.HighPart=c.dwHighDateTime; x.cpu_percent=0.0; }
    ULARGE_INTEGER freeb,totalb,totalfree{}; if (GetDiskFreeSpaceExW(L".",&freeb,&totalb,&totalfree)) { x.disk_total=totalb.QuadPart; x.disk_free=freeb.QuadPart; }
    x.uptime_seconds=GetTickCount64()/1000ULL;
#else
    std::ifstream mem("/proc/meminfo"); std::string line; std::uint64_t total=0,avail=0; while(std::getline(mem,line)){ if(line.rfind("MemTotal:",0)==0) total=parse_kb_line(line); else if(line.rfind("MemAvailable:",0)==0) avail=parse_kb_line(line); } x.memory_total=total; x.memory_used=total>avail?total-avail:0;
    std::ifstream stat("/proc/self/status"); while(std::getline(stat,line)){ if(line.rfind("VmRSS:",0)==0) x.process_memory=parse_kb_line(line); else if(line.rfind("Threads:",0)==0) { std::istringstream s(line); std::string k; s>>k>>x.process_threads; } }
    std::ifstream up("/proc/uptime"); double u=0; up>>u; x.uptime_seconds=(std::uint64_t)u;
    std::ifstream cpu("/proc/stat"); std::string l; std::uint64_t user=0,nice=0,sys=0,idle=0,iowait=0,irq=0,soft=0,steal=0; if(std::getline(cpu,l)){ std::istringstream s(l); std::string k; s>>k>>user>>nice>>sys>>idle>>iowait>>irq>>soft>>steal; }
    const auto t1=user+nice+sys+idle+iowait+irq+soft+steal; const auto idle1=idle+iowait; std::this_thread::sleep_for(std::chrono::milliseconds(80)); cpu.clear();cpu.seekg(0); if(std::getline(cpu,l)){std::istringstream s(l);s>>l>>user>>nice>>sys>>idle>>iowait>>irq>>soft>>steal;} const auto t2=user+nice+sys+idle+iowait+irq+soft+steal; const auto idle2=idle+iowait; if(t2>t1) x.cpu_percent=100.0*(double)(t2-t1-(idle2-idle1))/(double)(t2-t1);
    std::error_code ec; auto sp=fs::space(".",ec); if(!ec){x.disk_total=sp.capacity;x.disk_free=sp.available;}
#endif
    return x;
}

std::string format_bytes(std::uint64_t b) { const char* u[]={"B","KB","MB","GB","TB"}; double v=(double)b; int i=0; while(v>=1024 && i<4){v/=1024;i++;} std::ostringstream s; s.setf(std::ios::fixed);s.precision(i?1:0);s<<v<<' '<<u[i];return s.str(); }
void print() { auto x=sample(); std::cout<<"CPU: "<<x.cpu_percent<<"%\nMemory: "<<format_bytes(x.memory_used)<<" / "<<format_bytes(x.memory_total)<<"\nDEIIG process: "<<format_bytes(x.process_memory)<<"\nThreads: "<<x.process_threads<<"\nDisk free: "<<format_bytes(x.disk_free)<<" / "<<format_bytes(x.disk_total)<<"\nUptime: "<<x.uptime_seconds<<" s\n"; }
}
