#ifndef JETOS_TERMINAL_H
#define JETOS_TERMINAL_H

/* Milestone 4의 터미널은 "커맨드 파서 + 파일시스템 연동"이 실제로
 * 동작함을 증명하기 위한 스크립트 실행기다. 아직 키보드 드라이버가
 * 없으므로(Milestone 5 과제) 사용자가 실시간으로 타이핑하는 대화형
 * 셸은 아니며, 미리 정해진 명령어 시퀀스를 하나씩 해석/실행하고 결과를
 * 화면+시리얼에 출력한다. 명령어 파서/디스패처 자체는 실제 대화형
 * 셸에서도 그대로 재사용 가능한 구조로 작성되어 있다. */
void terminal_run_demo_script(void);

#endif
