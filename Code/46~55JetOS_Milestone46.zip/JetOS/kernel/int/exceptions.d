kernel/int/exceptions.o: kernel/int/exceptions.c kernel/int/exceptions.h \
 kernel/int/idt.h kernel/int/../panic.h kernel/int/../hal/x86_asm_shim.h \
 kernel/int/pic.h kernel/int/pit.h kernel/int/../proc/scheduler.h \
 kernel/int/../proc/thread.h kernel/int/../proc/thread.h \
 kernel/int/../drivers/keyboard.h kernel/int/../drivers/mouse.h \
 kernel/int/../drivers/serial.h
kernel/int/exceptions.h:
kernel/int/idt.h:
kernel/int/../panic.h:
kernel/int/../hal/x86_asm_shim.h:
kernel/int/pic.h:
kernel/int/pit.h:
kernel/int/../proc/scheduler.h:
kernel/int/../proc/thread.h:
kernel/int/../proc/thread.h:
kernel/int/../drivers/keyboard.h:
kernel/int/../drivers/mouse.h:
kernel/int/../drivers/serial.h:
