#ifndef JETOS_BOOT_INFO_H
#define JETOS_BOOT_INFO_H

/*
 * 부트로더(mingw로 컴파일된 PE) <-> 커널(native gcc로 컴파일된 ELF)
 * 사이에서 공유되는 순수 데이터 구조체.
 *
 * 이 구조체는 두 개의 서로 다른 컴파일러/ABI(MS x64 vs SysV)로 컴파일된
 * 코드 사이에서 "포인터로 전달"되므로, 함수 포인터를 포함해서는 안 되고
 * (호출 규약이 갈리기 때문) 오직 스칼라 값과 데이터 포인터만 담는다.
 * uint32_t/uint64_t 등 표준 정수 타입은 두 ABI에서 크기/정렬이 동일하므로
 * 구조체 레이아웃이 안전하게 일치한다.
 */

#include <stdint.h>
#include "../efi/efi.h"  /* EFI_MEMORY_DESCRIPTOR 등 순수 데이터 타입만 재사용 */

typedef struct {
    uint64_t framebuffer_base;
    uint64_t framebuffer_size;
    uint32_t width;
    uint32_t height;
    uint32_t pixels_per_scanline;

    EFI_MEMORY_DESCRIPTOR *memory_map;
    UINTN memory_map_size;
    UINTN memory_map_descriptor_size;
} jetos_boot_info_t;

#endif
