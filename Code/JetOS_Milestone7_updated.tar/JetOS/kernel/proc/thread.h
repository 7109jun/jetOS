#ifndef JETOS_THREAD_H
#define JETOS_THREAD_H

#include <stdint.h>

#define THREAD_NAME_MAX 16
#define THREAD_DEFAULT_STACK_SIZE (16 * 1024) /* 16KB */

typedef enum {
    THREAD_READY,
    THREAD_RUNNING,
    THREAD_BLOCKED,
    THREAD_DEAD
} thread_state_t;

typedef struct thread {
    uint64_t rsp;                  /* 이 스레드가 실행중이 아닐 때의 저장된 스택 포인터 */
    void    *stack_base;           /* kfree용 */
    uint64_t stack_size;
    void   (*entry)(void *arg);
    void    *arg;
    thread_state_t state;
    uint32_t id;
    char     name[THREAD_NAME_MAX];
    struct thread *next;           /* 스케줄러 준비 큐(원형 연결 리스트) 링크 */
} thread_t;

/* 새 스레드를 생성하고 준비(READY) 상태로 스케줄러에 등록한다.
 * entry(arg)가 반환하면 자동으로 thread_exit()이 호출된다. */
thread_t *thread_create(const char *name, void (*entry)(void *arg), void *arg);

/* 현재 스레드를 종료한다 (반환하지 않음) */
__attribute__((noreturn)) void thread_exit(void);

#endif
