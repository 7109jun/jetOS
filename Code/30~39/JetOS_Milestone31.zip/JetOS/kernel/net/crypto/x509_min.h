#ifndef JETOS_X509_MIN_H
#define JETOS_X509_MIN_H

/*
 * JetOS - kernel/net/crypto/x509_min.h
 * Milestone 19: X.509 인증서에서 RSA 공개키만 뽑아내는 최소 파서로 시작.
 *
 * Milestone 24: "최소 추출"에서 "실사용 가능한 검증"으로 범위 확장.
 * Milestone 25: basicConstraints/keyUsage 확장 파싱 추가(체인 검증의
 * 가장 큰 남은 구멍이었음 — M24 문서에서 이미 다음 우선순위로 예고).
 *
 * Milestone 26: 신뢰 앵커 매칭에 더해 extendedKeyUsage(있다면 leaf에
 * serverAuth 또는 anyExtendedKeyUsage가 있는지)까지 확인한다.
 *
 * 이제 뽑아내는 필드:
 *   - RSA 공개키(modulus n, exponent e)                — M19부터
 *   - tbsCertificate 원본 DER 바이트(서명 검증의 해시 대상)      — M24
 *   - issuer / subject Name의 원본 DER 바이트(체인 연결 확인용 —
 *     RFC 5280의 완전한 이름 정규화 규칙 대신 "바이트 완전 일치"로
 *     비교하는 단순화, 알려진 한계로 아래 문서화)                — M24
 *   - signatureAlgorithm이 sha256WithRSAEncryption인지 여부 + 원본
 *     서명값(BIT STRING 내용, 선행 unused-bits 바이트 제거됨)      — M24
 *   - notBefore/notAfter(Validity) — UTCTime/GeneralizedTime을
 *     "YYYYMMDDHHMMSS" 형태의 비교 가능한 정수로 변환               — M24
 *   - subject의 commonName(CN)과 subjectAltName의 dNSName 목록
 *     (호스트명 검증용)                                            — M24
 *   - basicConstraints(cA BOOLEAN, pathLenConstraint INTEGER)      — M25
 *   - keyUsage 중 keyCertSign 비트만                                — M25
 *   - extendedKeyUsage 중 serverAuth(또는 anyExtendedKeyUsage) 존재
 *     여부만                                                        — M26
 *
 * 여전히 파싱하지 않는 것(알려진 단순화):
 *   - extendedKeyUsage의 serverAuth/anyExtendedKeyUsage 외 나머지
 *     KeyPurposeId(codeSigning, emailProtection 등)는 구분하지 않는다
 *     — "서버 인증 용도가 있는가/없는가"만 본다. 확장 자체가 없으면
 *     (RFC 5280대로) 제약 없음으로 취급한다.
 *   - extendedKeyUsage는 리프 인증서에만 적용한다 — 중간 CA가
 *     이 확장으로 자신이 발급할 수 있는 인증서의 용도를 제한하는
 *     경우(예: "이 CA 아래로는 codeSigning만 발급 가능")는 확인하지
 *     않는다(문서화된 스코프).
 *   - CRL/OCSP 폐지(revocation) 확인 없음.
 *   - Name 비교가 RFC 5280의 문자열 정규화(대소문자/공백 접기 등)를
 *     따르지 않고 DER 바이트 완전 일치로만 판단한다 — 실무에서 같은
 *     CA가 발급한 체인이면 보통 문제없지만, 이론적으로 더 엄격한
 *     비교가 필요한 예외 케이스가 있을 수 있다.
 */

#include <stdint.h>
#include <stddef.h>
#include "bignum.h"

#define X509_MAX_CN_LEN 64
#define X509_MAX_SAN 8
#define X509_MAX_SAN_LEN 128

typedef struct {
    bignum_t pubkey_n, pubkey_e;

    /* tbsCertificate 전체(태그+길이 헤더 포함) 원본 DER — 이 인증서의
     * 서명이 실제로 해시하는 대상. der/cert 버퍼가 살아있는 동안만 유효
     * (복사하지 않고 포인터만 들고 있음). */
    const uint8_t *tbs_der;
    size_t tbs_len;

    /* issuer/subject Name SEQUENCE의 내용물(태그+길이 제외) 원본 바이트.
     * 체인 연결 시 "child.issuer_der == parent.subject_der(바이트 일치)"로
     * 비교한다. */
    const uint8_t *issuer_der;  size_t issuer_len;
    const uint8_t *subject_der; size_t subject_len;

    int sig_is_rsa_sha256;             /* signatureAlgorithm이 sha256WithRSAEncryption(OID 1.2.840.113549.1.1.11)인지 */
    const uint8_t *sig_val; size_t sig_len; /* 원본 서명 바이트(BIT STRING의 unused-bits 바이트 제거됨) */

    uint64_t not_before; /* YYYYMMDDHHMMSS, UTC 가정(Z 표기가 아니면 파싱 실패로 취급) */
    uint64_t not_after;

    int has_cn;
    char cn[X509_MAX_CN_LEN];
    int san_count;
    char san[X509_MAX_SAN][X509_MAX_SAN_LEN]; /* subjectAltName의 dNSName들 */

    /* Milestone 25: basicConstraints(OID 2.5.29.19) — 확장 자체가 없으면
     * has_basic_constraints=0(그러면 is_ca/has_path_len은 의미 없음).
     * cA는 DEFAULT FALSE라 확장이 있어도 값이 없으면 is_ca=0. */
    int has_basic_constraints;
    int is_ca;
    int has_path_len;
    int path_len; /* pathLenConstraint — "이 인증서 아래로 몇 개의 중간 CA까지
                    * 허용하는지"(리프 자신은 세지 않음, RFC 5280 4.2.1.9) */

    /* Milestone 25: keyUsage(OID 2.5.29.15) 중 keyCertSign 비트만 뽑아낸다
     * (그 외 비트는 이 최소 구현의 스코프 밖 — x509_min.h 상단 참고). */
    int has_key_usage;
    int key_cert_sign;

    /* Milestone 26: extendedKeyUsage(OID 2.5.29.37) — serverAuth 또는
     * anyExtendedKeyUsage KeyPurposeId가 있는지만 본다(x509_min.h 상단
     * 참고). 확장이 아예 없으면 has_eku=0(제약 없음으로 취급). */
    int has_eku;
    int eku_server_auth;
} x509_cert_t;

/* der(cert_len바이트)에서 위 필드를 전부 파싱해 out에 채운다. out의
 * 포인터 필드(tbs_der 등)는 der 버퍼를 그대로 가리키므로, der가 유효한
 * 동안만 out을 사용할 것. 성공 1, 실패(형식 오류/RSA 아님) 0. */
int x509_parse(const uint8_t *der, size_t der_len, x509_cert_t *out);

/* cert가 issuer_n/issuer_e(발급자의 RSA 공개키)로 서명됐는지 확인한다.
 * RSASSA-PKCS1-v1_5 with SHA-256(RFC 8017 8.2.2)를 그대로 구현: sig^e mod n을
 * 계산해 EM(0x00 0x01 FF..FF 0x00 || DigestInfo(SHA-256) || hash(tbs))과
 * 바이트 단위로 비교. 성공(서명 유효) 1, 실패 0. */
int x509_verify_signature(const x509_cert_t *cert, const bignum_t *issuer_n, const bignum_t *issuer_e);

/* host(접속하려는 호스트명)가 cert의 subjectAltName(dNSName들, 있으면
 * 우선) 또는 CN(SAN이 하나도 없을 때만 폴백)과 일치하는지 확인한다.
 * RFC 6125을 간소화해서 지원: 대소문자 무시 완전 일치, 그리고 최좌측
 * 라벨 하나가 "*"인 단일 와일드카드만 허용(예: "*.example.com"은
 * "www.example.com"과는 일치하지만 "a.b.example.com"이나
 * "example.com" 자체와는 일치하지 않음). 일치 1, 불일치 0. */
int x509_check_hostname(const x509_cert_t *cert, const char *host);

/* cert의 유효기간이 now(YYYYMMDDHHMMSS 형식 정수, x509_pack_time 참고)를
 * 포함하는지 확인한다. 포함 1, 만료/아직 유효하지 않음 0. */
int x509_check_validity(const x509_cert_t *cert, uint64_t now);

/* RTC에서 읽은 년/월/일/시/분/초를 x509_check_validity가 쓰는
 * YYYYMMDDHHMMSS 정수 형식으로 합친다. */
uint64_t x509_pack_time(uint16_t year, uint8_t month, uint8_t day, uint8_t hour, uint8_t minute, uint8_t second);

#endif
