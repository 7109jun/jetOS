kernel/exec/pe_loader.o: kernel/exec/pe_loader.c kernel/exec/pe_loader.h \
 kernel/exec/../fs/jetfs.h kernel/exec/../fs/vfs.h \
 kernel/exec/../mm/heap.h kernel/exec/../mm/pmm.h \
 kernel/exec/../mm/../../include/efi/efi.h kernel/exec/../proc/thread.h \
 kernel/exec/../proc/scheduler.h kernel/exec/../proc/thread.h \
 kernel/exec/../compat/win32.h kernel/exec/../drivers/serial.h
kernel/exec/pe_loader.h:
kernel/exec/../fs/jetfs.h:
kernel/exec/../fs/vfs.h:
kernel/exec/../mm/heap.h:
kernel/exec/../mm/pmm.h:
kernel/exec/../mm/../../include/efi/efi.h:
kernel/exec/../proc/thread.h:
kernel/exec/../proc/scheduler.h:
kernel/exec/../proc/thread.h:
kernel/exec/../compat/win32.h:
kernel/exec/../drivers/serial.h:
