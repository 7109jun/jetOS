/*
 * JetOS - kernel/apps/settings.c
 * 시스템 정보(힙/물리메모리/타이머 틱) + 테마 선택(Milestone 18).
 * 진짜 클릭 가능한 색상 스와치 버튼으로 테마를 바꾼다 — File Manager의
 * 클릭 내비게이션(Milestone 13)과 같은 wm_set_click_callback 인프라를
 * 재사용한다.
 */

#include <stddef.h>
#include "settings.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../gui/theme.h"
#include "../drivers/console.h"
#include "../proc/scheduler.h"
#include "../fs/config.h" /* Milestone 33: 영속 구성 */

static void write_uint(console_t *dc, uint64_t v) {
    char tmp[20]; int t = 0;
    if (v == 0) { char z[2] = {'0', 0}; console_print(dc, z); return; }
    while (v > 0) { tmp[t++] = (char)('0' + (v % 10)); v /= 10; }
    char buf[20]; int i = 0;
    while (t > 0) buf[i++] = tmp[--t];
    buf[i] = '\0';
    console_print(dc, buf);
}

#define SWATCH_W 52
#define SWATCH_H 28
#define SWATCH_GAP 6
#define SWATCH_TOP_OFFSET 96 /* content 영역 y 기준 스와치 줄까지의 거리 */

/* Milestone 33: 시계 12/24시간제 토글. 스와치 줄 바로 아래 배치. */
#define CLOCK_TOGGLE_W 72
#define CLOCK_TOGGLE_H 24
#define CLOCK_TOGGLE_LABEL_OFFSET 20 /* 토글 위 "CLOCK FORMAT:" 라벨까지의 거리 */
#define CLOCK_TOGGLE_TOP_OFFSET (SWATCH_TOP_OFFSET + SWATCH_H + CLOCK_TOGGLE_LABEL_OFFSET)

/* Milestone 34: 배경화면 프리셋 스와치. 시계 토글 바로 아래. */
#define WALL_SWATCH_W 40
#define WALL_SWATCH_H 24
#define WALL_SWATCH_GAP 6
#define WALL_LABEL_OFFSET 20
#define WALL_TOP_OFFSET (CLOCK_TOGGLE_TOP_OFFSET + CLOCK_TOGGLE_H + WALL_LABEL_OFFSET)

static void settings_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)h; (void)ctx;
    JetSystemInfo info;
    GetSystemInfoJ(&info);

    int ty = y + 8;
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    console_print(dc, "HEAP USED/TOTAL BYTES:");
    ty += 14;
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    write_uint(dc, info.heap_used_bytes);
    console_print(dc, " / ");
    write_uint(dc, info.heap_total_bytes);
    ty += 20;

    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    console_print(dc, "PMM FREE/TOTAL PAGES:");
    ty += 14;
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    write_uint(dc, info.pmm_free_pages);
    console_print(dc, " / ");
    write_uint(dc, info.pmm_total_pages);
    ty += 22;

    /* ---- 테마 선택 (Milestone 18) ---- */
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)ty;
    console_print(dc, "THEME: ");
    console_print(dc, theme_preset_name(theme_get_preset()));
    ty += 16;

    int sy = y + SWATCH_TOP_OFFSET;
    int n = theme_preset_count();
    int sx = x + 8;
    int current = theme_get_preset();
    for (int i = 0; i < n; i++) {
        /* theme_accent()는 "현재" 프리셋만 알려주므로, 다른 프리셋의
         * 스와치 색은 인덱스별 고정값을 여기서 직접 흉내낸다(테마
         * 목록 자체를 조회하는 API는 없음 — 그래서 프리셋 이름과
         * 순서만으로 대략적인 색을 매핑). */
        uint32_t swatch_color;
        switch (i % 4) {
            case 0: swatch_color = 0x003070C0; break; /* Ocean Blue */
            case 1: swatch_color = 0x00309050; break; /* Forest Green */
            case 2: swatch_color = 0x00D08030; break; /* Sunset Orange */
            default: swatch_color = 0x008040C0; break; /* Royal Purple */
        }
        console_fill_rect(dc, (uint32_t)sx, (uint32_t)sy, SWATCH_W, SWATCH_H, swatch_color);
        if (i == current) {
            /* 선택된 스와치는 밝은 테두리로 표시 */
            for (int b = 0; b < 2; b++) {
                console_fill_rect(dc, (uint32_t)(sx - b), (uint32_t)(sy - b), SWATCH_W + b * 2, 2, 0x00FFFFFF);
                console_fill_rect(dc, (uint32_t)(sx - b), (uint32_t)(sy + SWATCH_H + b - 2), SWATCH_W + b * 2, 2, 0x00FFFFFF);
            }
        }
        sx += SWATCH_W + SWATCH_GAP;
    }

    /* ---- 시계 형식 토글 (Milestone 33) ---- */
    int tty = y + CLOCK_TOGGLE_TOP_OFFSET;
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)(tty - CLOCK_TOGGLE_LABEL_OFFSET + 4);
    console_print(dc, "CLOCK FORMAT:");

    int is24 = config_get_clock_24h();
    uint32_t btn_color = is24 ? theme_accent() : 0x00304050;
    console_fill_rect(dc, (uint32_t)(x + 8), (uint32_t)tty, CLOCK_TOGGLE_W, CLOCK_TOGGLE_H, btn_color);
    dc->cursor_x = (uint32_t)(x + 8 + 18); dc->cursor_y = (uint32_t)(tty + 6);
    console_print(dc, is24 ? "24H" : "12H");

    /* ---- 배경화면 프리셋 (Milestone 34) ---- */
    int wty = y + WALL_TOP_OFFSET;
    dc->cursor_x = (uint32_t)(x + 8); dc->cursor_y = (uint32_t)(wty - WALL_LABEL_OFFSET + 4);
    console_print(dc, "WALLPAPER:");

    int wn = wm_wallpaper_preset_count();
    int wcur = wm_get_wallpaper_preset();
    int wx = x + 8;
    /* wm.c의 WALLPAPER_PRESETS는 static이라 여기서 못 읽으므로, 프리셋
     * 이름/순서에 맞춰 대표색만 여기서 따로 흉내낸다(테마 스와치가
     * theme.c 색을 직접 못 읽어와 하는 것과 같은 이유·같은 패턴). */
    for (int i = 0; i < wn; i++) {
        uint32_t swatch_color;
        switch (i % 4) {
            case 0: swatch_color = 0x00602868; break; /* Sunset */
            case 1: swatch_color = 0x00102840; break; /* Midnight */
            case 2: swatch_color = 0x00104028; break; /* Forest */
            default: swatch_color = 0x00602040; break; /* Rose */
        }
        console_fill_rect(dc, (uint32_t)wx, (uint32_t)wty, WALL_SWATCH_W, WALL_SWATCH_H, swatch_color);
        if (i == wcur) {
            for (int b = 0; b < 2; b++) {
                console_fill_rect(dc, (uint32_t)(wx - b), (uint32_t)(wty - b), WALL_SWATCH_W + b * 2, 2, 0x00FFFFFF);
                console_fill_rect(dc, (uint32_t)(wx - b), (uint32_t)(wty + WALL_SWATCH_H + b - 2), WALL_SWATCH_W + b * 2, 2, 0x00FFFFFF);
            }
        }
        wx += WALL_SWATCH_W + WALL_SWATCH_GAP;
    }
}

static void settings_click_cb(int local_x, int local_y, void *ctx) {
    (void)ctx;

    /* 테마 스와치 (Milestone 18, M33부터 config로 영속) */
    if (local_y >= SWATCH_TOP_OFFSET && local_y < SWATCH_TOP_OFFSET + SWATCH_H) {
        int rel_x = local_x - 8;
        if (rel_x < 0) return;
        int idx = rel_x / (SWATCH_W + SWATCH_GAP);
        int within = rel_x % (SWATCH_W + SWATCH_GAP);
        if (within >= SWATCH_W) return; /* 스와치 사이 여백 클릭 */
        if (idx >= 0 && idx < theme_preset_count()) {
            config_set_theme_preset(idx); /* theme_set_preset 적용 + 즉시 저장 */
        }
        return;
    }

    /* 시계 12/24시간제 토글 (Milestone 33) */
    if (local_y >= CLOCK_TOGGLE_TOP_OFFSET && local_y < CLOCK_TOGGLE_TOP_OFFSET + CLOCK_TOGGLE_H) {
        int rel_x = local_x - 8;
        if (rel_x >= 0 && rel_x < CLOCK_TOGGLE_W) {
            config_set_clock_24h(!config_get_clock_24h());
        }
        return;
    }

    /* 배경화면 프리셋 스와치 (Milestone 34) */
    if (local_y >= WALL_TOP_OFFSET && local_y < WALL_TOP_OFFSET + WALL_SWATCH_H) {
        int rel_x = local_x - 8;
        if (rel_x < 0) return;
        int idx = rel_x / (WALL_SWATCH_W + WALL_SWATCH_GAP);
        int within = rel_x % (WALL_SWATCH_W + WALL_SWATCH_GAP);
        if (within >= WALL_SWATCH_W) return;
        if (idx >= 0 && idx < wm_wallpaper_preset_count()) {
            config_set_wallpaper_preset(idx);
        }
    }
}

static volatile int g_settings_running = 0;

static void settings_on_close(void *ctx) {
    (void)ctx;
    g_settings_running = 0;
}

static void settings_thread_fn(void *arg) {
    (void)arg;
    g_settings_running = 1;
    JetWindowHandle win = CreateWindowJ("SETTINGS", 620, 240, 280, 230, 0x00403050);
    if (win >= 0) {
        wm_set_content_callback(win, settings_content_cb, NULL);
        wm_set_close_callback(win, settings_on_close, NULL);
        wm_set_click_callback(win, settings_click_cb, NULL);
    }
    while (g_settings_running) {
        scheduler_yield();
    }
}

void settings_launch(void) {
    static int launched = 0;
    if (launched && g_settings_running) return;
    launched = 1;
    CreateThreadJ("settings", settings_thread_fn, NULL);
}
