/* JetOS - kernel/net/crypto/x509_min.c - x509_min.h 참고.
 * Milestone 24: x509_extract_rsa_pubkey 하나짜리 최소 파서에서
 * x509_parse(전체 필드) + x509_verify_signature + x509_check_hostname +
 * x509_check_validity로 확장. */
#include "x509_min.h"
#include "der.h"
#include "sha256.h"
#include "rsa_pkcs1.h" /* Milestone 41: 서명 검증을 rsa_pkcs1_verify_sha256으로 위임 */
#include <string.h> /* memcmp — 선언만 필요, 실제 심볼은 freestanding_libc.c가 제공(project convention) */

static const uint8_t OID_COMMON_NAME[3]      = { 0x55, 0x04, 0x03 };
static const uint8_t OID_SUBJECT_ALT_NAME[3] = { 0x55, 0x1D, 0x11 };
static const uint8_t OID_BASIC_CONSTRAINTS[3] = { 0x55, 0x1D, 0x13 }; /* 2.5.29.19 — Milestone 25 */
static const uint8_t OID_KEY_USAGE[3]         = { 0x55, 0x1D, 0x0F }; /* 2.5.29.15 — Milestone 25 */
static const uint8_t OID_EXT_KEY_USAGE[3]     = { 0x55, 0x1D, 0x25 }; /* 2.5.29.37 — Milestone 26 */
static const uint8_t OID_KP_SERVER_AUTH[8]    = { 0x2B, 0x06, 0x01, 0x05, 0x05, 0x07, 0x03, 0x01 }; /* 1.3.6.1.5.5.7.3.1 */
static const uint8_t OID_ANY_EKU[4]           = { 0x55, 0x1D, 0x25, 0x00 }; /* 2.5.29.37.0 anyExtendedKeyUsage */
static const uint8_t OID_SHA256_WITH_RSA[9]  = { 0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x01, 0x0B };

static int read_seq(der_reader_t *r, const uint8_t **val, size_t *vlen) {
    uint8_t tag;
    if (!der_read_tlv(r, &tag, val, vlen)) return 0;
    return tag == DER_TAG_SEQUENCE;
}

static int read_any(der_reader_t *r, uint8_t *tag, const uint8_t **val, size_t *vlen) {
    return der_read_tlv(r, tag, val, vlen);
}

static int oid_eq(const uint8_t *a, size_t alen, const uint8_t *b, size_t blen) {
    if (alen != blen) return 0;
    for (size_t i = 0; i < alen; i++) if (a[i] != b[i]) return 0;
    return 1;
}

static int is_digit(uint8_t c) { return c >= '0' && c <= '9'; }

uint64_t x509_pack_time(uint16_t year, uint8_t month, uint8_t day, uint8_t hour, uint8_t minute, uint8_t second) {
    return (uint64_t)year * 10000000000ULL + (uint64_t)month * 100000000ULL +
           (uint64_t)day * 1000000ULL + (uint64_t)hour * 10000ULL +
           (uint64_t)minute * 100ULL + (uint64_t)second;
}

/* Time ::= CHOICE { UTCTime("YYMMDDHHMMSSZ"), GeneralizedTime("YYYYMMDDHHMMSSZ") }.
 * Z(UTC) 표기가 아닌 값은 지원하지 않는다(알려진 단순화, x509_min.h 참고). */
static int parse_time(uint8_t tag, const uint8_t *val, size_t vlen, uint64_t *out) {
    int has_century = (tag == 0x18); /* GeneralizedTime */
    if (tag != 0x17 && tag != 0x18) return 0;
    size_t need = has_century ? 15 : 13;
    if (vlen != need) return 0;
    if (val[vlen - 1] != 'Z') return 0;
    for (size_t i = 0; i + 1 < vlen; i++) if (!is_digit(val[i])) return 0;

    size_t p = 0;
    uint32_t year;
    if (has_century) {
        year = (uint32_t)(val[0] - '0') * 1000 + (val[1] - '0') * 100 + (val[2] - '0') * 10 + (val[3] - '0');
        p = 4;
    } else {
        uint32_t yy = (uint32_t)(val[0] - '0') * 10 + (val[1] - '0');
        year = (yy < 50) ? (2000 + yy) : (1900 + yy); /* RFC 5280 4.1.2.5.1 규칙 */
        p = 2;
    }
    uint32_t month  = (uint32_t)(val[p] - '0') * 10 + (val[p + 1] - '0'); p += 2;
    uint32_t day    = (uint32_t)(val[p] - '0') * 10 + (val[p + 1] - '0'); p += 2;
    uint32_t hour   = (uint32_t)(val[p] - '0') * 10 + (val[p + 1] - '0'); p += 2;
    uint32_t minute = (uint32_t)(val[p] - '0') * 10 + (val[p + 1] - '0'); p += 2;
    uint32_t second = (uint32_t)(val[p] - '0') * 10 + (val[p + 1] - '0');

    if (month < 1 || month > 12 || day < 1 || day > 31 || hour > 23 || minute > 59 || second > 60) return 0;
    *out = x509_pack_time((uint16_t)year, (uint8_t)month, (uint8_t)day, (uint8_t)hour, (uint8_t)minute, (uint8_t)second);
    return 1;
}

/* subject/issuer Name(SEQUENCE OF RDN, RDN = SET OF AttributeTypeAndValue)에서
 * commonName(OID 2.5.4.3) 값을 찾아 out->cn에 채운다. 여러 개면 마지막 걸 쓴다
 * (실무에서 CN은 보통 하나뿐 — 단순화). */
static void extract_cn(const uint8_t *name_der, size_t name_len, x509_cert_t *out) {
    der_reader_t rdns;
    der_init(&rdns, name_der, name_len);
    while (rdns.p < rdns.end) {
        uint8_t tag; const uint8_t *val; size_t vlen;
        if (!read_any(&rdns, &tag, &val, &vlen)) break;
        if (tag != 0x31) continue; /* SET */
        der_reader_t rdn;
        der_enter(&rdn, val, vlen);
        while (rdn.p < rdn.end) {
            uint8_t atag; const uint8_t *aval; size_t alen;
            if (!read_any(&rdn, &atag, &aval, &alen) || atag != DER_TAG_SEQUENCE) break;
            der_reader_t atv;
            der_enter(&atv, aval, alen);
            uint8_t otag; const uint8_t *oval; size_t olen;
            if (!read_any(&atv, &otag, &oval, &olen) || otag != 0x06) continue;
            if (!oid_eq(oval, olen, OID_COMMON_NAME, sizeof(OID_COMMON_NAME))) continue;
            uint8_t vtag; const uint8_t *vval; size_t vvlen;
            if (!read_any(&atv, &vtag, &vval, &vvlen)) continue;
            size_t n = vvlen;
            if (n >= X509_MAX_CN_LEN) n = X509_MAX_CN_LEN - 1;
            for (size_t i = 0; i < n; i++) out->cn[i] = (char)vval[i];
            out->cn[n] = '\0';
            out->has_cn = 1;
        }
    }
}

/* extnValue(OCTET STRING 안의 GeneralNames SEQUENCE)에서 dNSName([2] IA5String,
 * 태그 0x82)들만 뽑아 out->san[]에 채운다. */
static void extract_san_dns_names(const uint8_t *octet_val, size_t octet_len, x509_cert_t *out) {
    der_reader_t gn_outer;
    der_init(&gn_outer, octet_val, octet_len);
    const uint8_t *gnsv; size_t gnsl;
    if (!read_seq(&gn_outer, &gnsv, &gnsl)) return; /* GeneralNames ::= SEQUENCE OF GeneralName */
    der_reader_t gns;
    der_enter(&gns, gnsv, gnsl);
    while (gns.p < gns.end && out->san_count < X509_MAX_SAN) {
        uint8_t gtag; const uint8_t *gval; size_t glen;
        if (!read_any(&gns, &gtag, &gval, &glen)) break;
        if (gtag != 0x82) continue; /* dNSName [2] IMPLICIT IA5String만 관심대상 */
        size_t n = glen;
        if (n >= X509_MAX_SAN_LEN) n = X509_MAX_SAN_LEN - 1;
        for (size_t i = 0; i < n; i++) out->san[out->san_count][i] = (char)gval[i];
        out->san[out->san_count][n] = '\0';
        out->san_count++;
    }
}

/* BasicConstraints ::= SEQUENCE { cA BOOLEAN DEFAULT FALSE,
 *                                  pathLenConstraint INTEGER OPTIONAL }
 * cA가 생략되면(SEQUENCE가 비어있거나 첫 필드가 바로 INTEGER면) DEFAULT
 * FALSE 그대로 is_ca=0. */
static void parse_basic_constraints(const uint8_t *octet_val, size_t octet_len, x509_cert_t *out) {
    der_reader_t outer;
    der_init(&outer, octet_val, octet_len);
    const uint8_t *seqv; size_t seql;
    if (!read_seq(&outer, &seqv, &seql)) return; /* 파싱 실패 — has_basic_constraints 그대로 0 */

    out->has_basic_constraints = 1;
    out->is_ca = 0;
    out->has_path_len = 0;
    out->path_len = 0;

    der_reader_t bc;
    der_enter(&bc, seqv, seql);
    if (bc.p >= bc.end) return; /* 빈 SEQUENCE — cA=FALSE, pathLen 없음 */

    uint8_t tag; const uint8_t *val; size_t vlen;
    if (!read_any(&bc, &tag, &val, &vlen)) return;

    if (tag == 0x01) { /* BOOLEAN cA */
        out->is_ca = (vlen >= 1 && val[0] != 0x00);
        if (bc.p < bc.end && read_any(&bc, &tag, &val, &vlen) && tag == DER_TAG_INTEGER) {
            int64_t v = 0;
            for (size_t i = 0; i < vlen && i < 8; i++) v = (v << 8) | val[i];
            out->has_path_len = 1;
            out->path_len = (int)v;
        }
    } else if (tag == DER_TAG_INTEGER) { /* cA 생략, 바로 pathLenConstraint */
        int64_t v = 0;
        for (size_t i = 0; i < vlen && i < 8; i++) v = (v << 8) | val[i];
        out->has_path_len = 1;
        out->path_len = (int)v;
    }
}

/* KeyUsage ::= BIT STRING — 이 구현은 keyCertSign 비트(6번째, 0-based
 * 인덱스 5)만 확인한다(x509_min.h 상단 스코프 참고). BIT STRING의 첫
 * 내용 바이트는 "미사용 비트 수"이고, 그 다음부터가 실제 비트를
 * MSB-first로 담는다 — 즉 bit 0(digitalSignature)은 두 번째 바이트의
 * 최상위 비트, bit 5(keyCertSign)는 같은 바이트의 6번째 비트(0x04). */
static void parse_key_usage(const uint8_t *octet_val, size_t octet_len, x509_cert_t *out) {
    der_reader_t r;
    der_init(&r, octet_val, octet_len);
    uint8_t tag; const uint8_t *val; size_t vlen;
    if (!read_any(&r, &tag, &val, &vlen) || tag != DER_TAG_BITSTRING || vlen < 2) return;
    out->has_key_usage = 1;
    /* val[0] = unused bits, val[1] = 첫 8비트(bit 0~7). bit 5(keyCertSign)는
     * val[1]의 (7-5)=2번째 자리, 즉 0x04 마스크. */
    out->key_cert_sign = (val[1] & 0x04) != 0;
}

/* ExtKeyUsageSyntax ::= SEQUENCE OF KeyPurposeId(OBJECT IDENTIFIER).
 * serverAuth(1.3.6.1.5.5.7.3.1) 또는 anyExtendedKeyUsage(2.5.29.37.0)가
 * 목록에 있는지만 확인한다(x509_min.h 상단 스코프 참고). */
static void parse_ext_key_usage(const uint8_t *octet_val, size_t octet_len, x509_cert_t *out) {
    der_reader_t outer;
    der_init(&outer, octet_val, octet_len);
    const uint8_t *seqv; size_t seql;
    if (!read_seq(&outer, &seqv, &seql)) return;
    out->has_eku = 1;
    out->eku_server_auth = 0;
    der_reader_t items;
    der_enter(&items, seqv, seql);
    while (items.p < items.end) {
        uint8_t tag; const uint8_t *val; size_t vlen;
        if (!read_any(&items, &tag, &val, &vlen) || tag != 0x06) break; /* OID가 아니면 형식 오류 — 중단 */
        if (oid_eq(val, vlen, OID_KP_SERVER_AUTH, sizeof(OID_KP_SERVER_AUTH)) ||
            oid_eq(val, vlen, OID_ANY_EKU, sizeof(OID_ANY_EKU))) {
            out->eku_server_auth = 1;
        }
    }
}

/* tbsCertificate의 extensions([3] EXPLICIT SEQUENCE OF Extension) 안에서
 * subjectAltName/basicConstraints/keyUsage/extendedKeyUsage 확장을 찾아
 * 파싱한다. 그 외 확장은 무시 — 알려진 단순화(x509_min.h 참고). */
static void extract_extensions(const uint8_t *ext_field_val, size_t ext_field_len, x509_cert_t *out) {
    der_reader_t outer;
    der_init(&outer, ext_field_val, ext_field_len);
    const uint8_t *seqv; size_t seql;
    if (!read_seq(&outer, &seqv, &seql)) return;
    der_reader_t exts;
    der_enter(&exts, seqv, seql);
    while (exts.p < exts.end) {
        uint8_t etag; const uint8_t *eval; size_t elen;
        if (!read_any(&exts, &etag, &eval, &elen) || etag != DER_TAG_SEQUENCE) break;

        der_reader_t one;
        der_init(&one, eval, elen);
        uint8_t otag; const uint8_t *oval; size_t olen;
        if (!read_any(&one, &otag, &oval, &olen) || otag != 0x06) continue; /* extnID OID */

        int is_san = oid_eq(oval, olen, OID_SUBJECT_ALT_NAME, sizeof(OID_SUBJECT_ALT_NAME));
        int is_bc  = oid_eq(oval, olen, OID_BASIC_CONSTRAINTS, sizeof(OID_BASIC_CONSTRAINTS));
        int is_ku  = oid_eq(oval, olen, OID_KEY_USAGE, sizeof(OID_KEY_USAGE));
        int is_eku = oid_eq(oval, olen, OID_EXT_KEY_USAGE, sizeof(OID_EXT_KEY_USAGE));
        if (!is_san && !is_bc && !is_ku && !is_eku) continue; /* 관심 없는 확장 — 스킵 */

        uint8_t vtag; const uint8_t *vval; size_t vvlen;
        if (!read_any(&one, &vtag, &vval, &vvlen)) continue;
        if (vtag == 0x01) { /* optional critical BOOLEAN — 스킵하고 다음 필드가 진짜 값 */
            if (!read_any(&one, &vtag, &vval, &vvlen)) continue;
        }
        if (vtag != DER_TAG_OCTETSTRING) continue;

        if (is_san) extract_san_dns_names(vval, vvlen, out);
        else if (is_bc) parse_basic_constraints(vval, vvlen, out);
        else if (is_ku) parse_key_usage(vval, vvlen, out);
        else if (is_eku) parse_ext_key_usage(vval, vvlen, out);
    }
}

int x509_parse(const uint8_t *der, size_t der_len, x509_cert_t *out) {
    for (int i = 0; i < X509_MAX_SAN; i++) out->san[i][0] = '\0';
    out->san_count = 0;
    out->has_cn = 0;
    out->cn[0] = '\0';
    out->sig_is_rsa_sha256 = 0;
    out->sig_val = 0; out->sig_len = 0;
    out->tbs_der = 0; out->tbs_len = 0;
    out->not_before = 0; out->not_after = 0;
    out->has_basic_constraints = 0; out->is_ca = 0;
    out->has_path_len = 0; out->path_len = 0;
    out->has_key_usage = 0; out->key_cert_sign = 0;
    out->has_eku = 0; out->eku_server_auth = 0;

    der_reader_t cert;
    der_init(&cert, der, der_len);

    /* Certificate ::= SEQUENCE { tbsCertificate, signatureAlgorithm, signatureValue } */
    const uint8_t *certval; size_t certlen;
    if (!read_seq(&cert, &certval, &certlen)) return 0;
    der_reader_t certbody;
    der_enter(&certbody, certval, certlen);

    /* tbsCertificate ::= SEQUENCE { ... } — 원본 TLV 바이트(태그+길이 포함)를
     * 통째로 잡아둔다: 서명은 이 바이트 그대로에 대해 계산된다. */
    const uint8_t *tbs_start = certbody.p;
    const uint8_t *tbsval; size_t tbslen;
    if (!read_seq(&certbody, &tbsval, &tbslen)) return 0;
    out->tbs_der = tbs_start;
    out->tbs_len = (size_t)(certbody.p - tbs_start);

    der_reader_t tbs;
    der_enter(&tbs, tbsval, tbslen);

    uint8_t tag; const uint8_t *val; size_t vlen;
    if (!read_any(&tbs, &tag, &val, &vlen)) return 0;
    if (tag == 0xA0) {
        /* version [0] EXPLICIT — 있으면 스킵하고 다음(serialNumber) 읽기 */
        if (!read_any(&tbs, &tag, &val, &vlen)) return 0;
    }
    /* 지금 tag는 serialNumber(INTEGER)여야 함 — 그냥 지나간다 */
    if (!read_any(&tbs, &tag, &val, &vlen)) return 0; /* signature AlgorithmIdentifier (tbs 내부의 것 — sigAlg와 보통 동일, 검증엔 안 씀) */
    if (!read_any(&tbs, &tag, &val, &vlen)) return 0; /* issuer Name */
    out->issuer_der = val; out->issuer_len = vlen;
    if (!read_any(&tbs, &tag, &val, &vlen)) return 0; /* validity SEQUENCE { notBefore, notAfter } */
    if (tag == DER_TAG_SEQUENCE) {
        der_reader_t validity;
        der_enter(&validity, val, vlen);
        uint8_t vtag; const uint8_t *vval; size_t vvlen;
        if (read_any(&validity, &vtag, &vval, &vvlen)) parse_time(vtag, vval, vvlen, &out->not_before);
        if (read_any(&validity, &vtag, &vval, &vvlen)) parse_time(vtag, vval, vvlen, &out->not_after);
    }
    if (!read_any(&tbs, &tag, &val, &vlen)) return 0; /* subject Name */
    out->subject_der = val; out->subject_len = vlen;
    extract_cn(val, vlen, out);

    /* subjectPublicKeyInfo ::= SEQUENCE { algorithm, subjectPublicKey BIT STRING } */
    if (!read_any(&tbs, &tag, &val, &vlen)) return 0;
    if (tag != DER_TAG_SEQUENCE) return 0;
    der_reader_t spki;
    der_enter(&spki, val, vlen);

    if (!read_any(&spki, &tag, &val, &vlen)) return 0; /* AlgorithmIdentifier — RSA인지 OID 확인은
                                                          * 생략(알려진 단순화, M19부터) */
    if (!read_any(&spki, &tag, &val, &vlen)) return 0; /* subjectPublicKey BIT STRING */
    if (tag != DER_TAG_BITSTRING || vlen < 1) return 0;

    /* BIT STRING의 첫 바이트는 "미사용 비트 수"(RSA 키에서는 항상 0) */
    const uint8_t *rsakey_der = val + 1;
    size_t rsakey_len = vlen - 1;

    der_reader_t rsakey;
    der_init(&rsakey, rsakey_der, rsakey_len);
    const uint8_t *rsaval; size_t rsalen;
    if (!read_seq(&rsakey, &rsaval, &rsalen)) return 0; /* RSAPublicKey ::= SEQUENCE */
    der_reader_t rsabody;
    der_enter(&rsabody, rsaval, rsalen);

    const uint8_t *nval, *eval; size_t nlen, elen;
    if (!read_any(&rsabody, &tag, &nval, &nlen) || tag != DER_TAG_INTEGER) return 0;
    if (!read_any(&rsabody, &tag, &eval, &elen) || tag != DER_TAG_INTEGER) return 0;

    /* INTEGER 선행 0x00(양수 부호 바이트) 제거 */
    if (nlen > 1 && nval[0] == 0x00) { nval++; nlen--; }
    if (elen > 1 && eval[0] == 0x00) { eval++; elen--; }

    bn_from_bytes_be(&out->pubkey_n, nval, nlen);
    bn_from_bytes_be(&out->pubkey_e, eval, elen);

    /* 나머지 tbsCertificate 필드(issuerUniqueID/subjectUniqueID/extensions) —
     * v1 인증서는 아예 없을 수 있으므로 있는 만큼만 순회한다. */
    while (tbs.p < tbs.end) {
        uint8_t rtag; const uint8_t *rval; size_t rvlen;
        if (!read_any(&tbs, &rtag, &rval, &rvlen)) break;
        if (rtag == 0xA3) extract_extensions(rval, rvlen, out); /* extensions [3] EXPLICIT */
        /* 0xA1(issuerUniqueID)/0xA2(subjectUniqueID)는 관심 없어 그냥 지나감 */
    }

    /* signatureAlgorithm(Certificate 레벨) — sha256WithRSAEncryption인지만 확인 */
    if (!read_any(&certbody, &tag, &val, &vlen) || tag != DER_TAG_SEQUENCE) return 1; /* 못 읽어도 키 자체는 유효하니 1 반환, 서명 검증만 못 함 */
    {
        der_reader_t sigalg;
        der_enter(&sigalg, val, vlen);
        uint8_t soid_tag; const uint8_t *soid_val; size_t soid_len;
        if (read_any(&sigalg, &soid_tag, &soid_val, &soid_len) && soid_tag == 0x06) {
            out->sig_is_rsa_sha256 = oid_eq(soid_val, soid_len, OID_SHA256_WITH_RSA, sizeof(OID_SHA256_WITH_RSA));
        }
    }

    /* signatureValue BIT STRING */
    if (!read_any(&certbody, &tag, &val, &vlen) || tag != DER_TAG_BITSTRING || vlen < 1) return 1;
    out->sig_val = val + 1; /* unused-bits 바이트(항상 0이어야 함) 제거 */
    out->sig_len = vlen - 1;

    return 1;
}

int x509_verify_signature(const x509_cert_t *cert, const bignum_t *issuer_n, const bignum_t *issuer_e) {
    if (!cert->sig_is_rsa_sha256 || !cert->sig_val || !cert->tbs_der) return 0;

    uint8_t hash[32];
    sha256_oneshot(cert->tbs_der, cert->tbs_len, hash);

    /* Milestone 41: 실제 EM 검증 로직은 rsa_pkcs1_verify_sha256으로 뽑아냈다
     * (TLS DHE_RSA의 ServerKeyExchange 서명 검증에도 재사용하기 위함 —
     * 알고리즘은 완전히 같고 "무엇을 서명했는가"만 다름). */
    return rsa_pkcs1_verify_sha256(hash, cert->sig_val, cert->sig_len, issuer_n, issuer_e);
}

static int ascii_lower(int c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }

static size_t xstrlen(const char *s) { size_t n = 0; while (s[n]) n++; return n; }

/* 대소문자 무시 완전 일치. pattern에 최좌측 라벨이 "*" 하나뿐인 단일
 * 와일드카드만 지원(RFC 6125 6.4.3 간소화 — 그 외 와일드카드 형태,
 * 예: "f*.example.com"이나 다중 라벨 매치는 지원 안 함). */
static int name_matches(const char *pattern, size_t plen, const char *host, size_t hlen) {
    if (plen >= 2 && pattern[0] == '*' && pattern[1] == '.') {
        /* host도 최소 라벨 하나 + 나머지가 pattern의 ".뒷부분"과 일치해야 함,
         * 그리고 host의 첫 라벨 안에는 '.'이 없어야 함(다중 라벨 매치 방지) */
        size_t first_dot = 0;
        int found = 0;
        for (size_t i = 0; i < hlen; i++) { if (host[i] == '.') { first_dot = i; found = 1; break; } }
        if (!found || first_dot == 0) return 0;
        size_t suffix_len = plen - 2;      /* "example.com" 부분 길이 */
        size_t host_suffix_len = hlen - first_dot - 1;
        if (suffix_len != host_suffix_len) return 0;
        for (size_t i = 0; i < suffix_len; i++) {
            if (ascii_lower((unsigned char)pattern[2 + i]) != ascii_lower((unsigned char)host[first_dot + 1 + i])) return 0;
        }
        return 1;
    }
    if (plen != hlen) return 0;
    for (size_t i = 0; i < plen; i++) {
        if (ascii_lower((unsigned char)pattern[i]) != ascii_lower((unsigned char)host[i])) return 0;
    }
    return 1;
}

int x509_check_hostname(const x509_cert_t *cert, const char *host) {
    if (!host) return 0;
    size_t hlen = xstrlen(host);
    if (cert->san_count > 0) {
        for (int i = 0; i < cert->san_count; i++) {
            if (name_matches(cert->san[i], xstrlen(cert->san[i]), host, hlen)) return 1;
        }
        return 0; /* SAN이 있으면 CN 폴백 안 함(RFC 6125 6.4.4 권고사항) */
    }
    if (cert->has_cn) {
        return name_matches(cert->cn, xstrlen(cert->cn), host, hlen);
    }
    return 0;
}

int x509_check_validity(const x509_cert_t *cert, uint64_t now) {
    if (cert->not_before == 0 || cert->not_after == 0) return 0; /* 파싱 실패한 경우 안전하게 거부 */
    return now >= cert->not_before && now <= cert->not_after;
}
