/*
 * JetOS - kernel/hal/gdt.c
 * gdt.h 설명 참고. LGDT/LTR/세그먼트 리로드 자체는 x86_asm_shim.h에
 * 있고, 이 파일은 그 앞단계인 "테이블 내용을 순수 C로 채워넣는" 부분만
 * 담당한다.
 */

#include "gdt.h"
#include "x86_asm_shim.h"

typedef struct __attribute__((packed)) {
    uint16_t limit_low;
    uint16_t base_low;
    uint8_t  base_mid;
    uint8_t  access;
    uint8_t  gran;   /* 상위 니블 = 플래그(G,D/L,AVL), 하위 니블 = limit[19:16] */
    uint8_t  base_high;
} gdt_entry_t;

typedef struct __attribute__((packed)) {
    uint16_t limit_low;
    uint16_t base_low;
    uint8_t  base_mid;
    uint8_t  access;
    uint8_t  gran;
    uint8_t  base_high;
    uint32_t base_upper;
    uint32_t reserved;
} tss_desc_t; /* 16바이트 — long mode 시스템 세그먼트는 전부 이 크기 */

typedef struct __attribute__((packed)) {
    gdt_entry_t null_desc;
    gdt_entry_t kernel_code;
    gdt_entry_t kernel_data;
    gdt_entry_t user_code;
    gdt_entry_t user_data;
    tss_desc_t  tss;
} gdt_table_t;

typedef struct __attribute__((packed)) {
    uint32_t reserved0;
    uint64_t rsp0;
    uint64_t rsp1;
    uint64_t rsp2;
    uint64_t reserved1;
    uint64_t ist[7];
    uint64_t reserved2;
    uint16_t reserved3;
    uint16_t iomap_base;
} tss64_t; /* 104바이트, Intel SDM 표준 레이아웃 */

static gdt_table_t g_gdt __attribute__((aligned(16)));
static tss64_t g_tss __attribute__((aligned(16)));

/* Ring3→Ring0 전환(인터럽트/시스템콜) 시 CPU가 자동으로 갈아탈 커널
 * 스택. 지금은 테스트 스레드 하나만 고려하므로 정적 버퍼 하나로
 * 충분하다 — 여러 스레드가 각자 Ring3를 쓰게 되면 스레드 전환마다
 * gdt_set_kernel_stack()으로 RSP0를 바꿔줘야 한다(향후 과제). */
static uint8_t g_kernel_stack[16384] __attribute__((aligned(16)));

static void set_code_data_entry(gdt_entry_t *e, uint8_t access, int is_long_mode_code) {
    e->limit_low = 0xFFFF;
    e->base_low = 0;
    e->base_mid = 0;
    e->access = access;
    /* G=1(4KB 단위 리밋), L=1은 코드 세그먼트에서만; 데이터 세그먼트는
     * L비트가 의미 없으므로 0으로 둔다. 실제로 64비트 모드에서는
     * base/limit이 하드웨어적으로 무시되고 항상 flat으로 취급되므로
     * 이 값들은 형식을 갖추기 위한 것에 가깝다 — DPL/Type/Present와
     * 코드 세그먼트의 L비트만 실질적인 의미를 가진다. */
    uint8_t flags = is_long_mode_code ? 0xA : 0xC; /* 1010 or 1100 */
    e->gran = (uint8_t)((flags << 4) | 0x0F);
    e->base_high = 0;
}

static void set_tss_desc(tss_desc_t *d, uint64_t base, uint32_t limit) {
    d->limit_low = (uint16_t)(limit & 0xFFFF);
    d->base_low = (uint16_t)(base & 0xFFFF);
    d->base_mid = (uint8_t)((base >> 16) & 0xFF);
    d->access = 0x89; /* Present, DPL=0, Type=1001 (64비트 TSS, Available) */
    d->gran = (uint8_t)((limit >> 16) & 0x0F);
    d->base_high = (uint8_t)((base >> 24) & 0xFF);
    d->base_upper = (uint32_t)((base >> 32) & 0xFFFFFFFFu);
    d->reserved = 0;
}

void gdt_set_kernel_stack(uint64_t rsp0) {
    g_tss.rsp0 = rsp0;
}

void gdt_init(void) {
    gdt_table_t *g = &g_gdt;

    g->null_desc.limit_low = 0; g->null_desc.base_low = 0; g->null_desc.base_mid = 0;
    g->null_desc.access = 0; g->null_desc.gran = 0; g->null_desc.base_high = 0;

    set_code_data_entry(&g->kernel_code, 0x9A, 1); /* P=1,DPL=0,S=1,Type=코드(실행/읽기), L=1 */
    set_code_data_entry(&g->kernel_data, 0x92, 0); /* P=1,DPL=0,S=1,Type=데이터(읽기/쓰기) */
    set_code_data_entry(&g->user_code,   0xFA, 1); /* P=1,DPL=3,S=1,Type=코드, L=1 */
    set_code_data_entry(&g->user_data,   0xF2, 0); /* P=1,DPL=3,S=1,Type=데이터 */

    for (int i = 0; i < 104; i++) ((uint8_t *)&g_tss)[i] = 0;
    g_tss.rsp0 = (uint64_t)(g_kernel_stack + sizeof(g_kernel_stack));
    g_tss.iomap_base = sizeof(tss64_t); /* IO 비트맵 없음(= 리밋 밖) → 유저 모드의 in/out은 전부 #GP */
    set_tss_desc(&g->tss, (uint64_t)&g_tss, sizeof(tss64_t) - 1);

    struct hal_gdt_ptr ptr;
    ptr.limit = sizeof(g_gdt) - 1;
    ptr.base = (uint64_t)&g_gdt;
    hal_lgdt(&ptr);

    hal_reload_kernel_segments(GDT_SEL_KERNEL_CODE, GDT_SEL_KERNEL_DATA);
    hal_ltr(GDT_SEL_TSS);
}
