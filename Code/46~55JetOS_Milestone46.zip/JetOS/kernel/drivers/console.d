kernel/drivers/console.o: kernel/drivers/console.c \
 kernel/drivers/console.h kernel/drivers/font5x7.h kernel/drivers/utf8.h \
 kernel/drivers/hangul_font.h
kernel/drivers/console.h:
kernel/drivers/font5x7.h:
kernel/drivers/utf8.h:
kernel/drivers/hangul_font.h:
