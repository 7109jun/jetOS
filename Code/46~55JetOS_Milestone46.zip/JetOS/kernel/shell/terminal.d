kernel/shell/terminal.o: kernel/shell/terminal.c kernel/shell/terminal.h \
 kernel/shell/../fs/jetfs.h kernel/shell/../drivers/serial.h
kernel/shell/terminal.h:
kernel/shell/../fs/jetfs.h:
kernel/shell/../drivers/serial.h:
