kernel/proc/thread.o: kernel/proc/thread.c kernel/proc/thread.h \
 kernel/proc/scheduler.h kernel/proc/../mm/heap.h \
 kernel/proc/../drivers/serial.h
kernel/proc/thread.h:
kernel/proc/scheduler.h:
kernel/proc/../mm/heap.h:
kernel/proc/../drivers/serial.h:
