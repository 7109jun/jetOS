kernel/compat/win32.o: kernel/compat/win32.c kernel/compat/win32.h \
 kernel/compat/../../include/jetapi/jetapi.h kernel/compat/../gui/wm.h \
 kernel/compat/../gui/../drivers/console.h kernel/compat/../proc/thread.h \
 kernel/compat/../proc/scheduler.h kernel/compat/../proc/thread.h
kernel/compat/win32.h:
kernel/compat/../../include/jetapi/jetapi.h:
kernel/compat/../gui/wm.h:
kernel/compat/../gui/../drivers/console.h:
kernel/compat/../proc/thread.h:
kernel/compat/../proc/scheduler.h:
kernel/compat/../proc/thread.h:
