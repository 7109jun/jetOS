#ifndef JETOS_RING3_TEST_H
#define JETOS_RING3_TEST_H

/* JetOS - kernel/hal/ring3_test.h
 * Milestone 14에서 처음 작성된 Ring3 진입 자체 테스트.
 *
 * 주의(Milestone 15 이후): 이 테스트는 "공유 커널 identity 매핑 위의
 * 코드"를 그대로 Ring3에서 실행하는 방식이었다. Milestone 15에서
 * vmm.c가 그 공유 영역의 U비트를 제대로 제거(진짜 커널/유저 보안
 * 경계 구축)하면서, 이 방식은 이제 의도적으로 페이지 폴트가 난다 —
 * 더는 kernel_entry.c에서 호출하지 않는다. Ring3 자체의 유효성 검증은
 * kernel/exec/elf_loader.c의 elf_execute()가 진짜 격리된 유저 영역에
 * ELF를 적재해 실행하는 것으로 대체되었다. 이 파일은 "Ring3 전환
 * 메커니즘 자체(GDT/TSS/IRETQ/시스템콜)"가 처음 검증됐던 기록으로
 * 남겨둔다. */
void ring3_test_thread_fn(void *arg);

#endif
