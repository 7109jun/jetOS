/* JetOS - kernel/net/crypto/x509_trust.c - x509_trust.h 참고. */
#include "x509_trust.h"
#include "der.h"
#include "../../fs/jetfs.h"
#include <string.h> /* memcmp — 선언만 필요, 실제 심볼은 freestanding_libc.c가 제공(project convention) */

#define X509_TRUST_MAX_SUBJECT 256
/* 이어붙인 루트 DER 전체를 담는 버퍼 상한. 32KB면 일반적인 크기(1~2KB)의
 * 루트 인증서 십수 개를 담기에 충분하다 — 큰 정적 버퍼 금지 원칙(M22
 * 버그 15)과 균형을 맞춘 크기. 더 많은 루트가 필요하면 이 값과
 * X509_TRUST_MAX_ROOTS를 함께 늘릴 것. */
#define X509_TRUST_FILE_BUF 32768

typedef struct {
    bignum_t n, e;
    uint8_t subject[X509_TRUST_MAX_SUBJECT];
    size_t subject_len;
} x509_trust_root_t;

static x509_trust_root_t g_roots[X509_TRUST_MAX_ROOTS];
static int g_root_count = 0;

int x509_trust_load(const char *path) {
    static uint8_t filebuf[X509_TRUST_FILE_BUF];
    uint64_t size = 0;
    g_root_count = 0;

    if (!jetfs_read(path, filebuf, sizeof(filebuf), &size)) return 0;

    der_reader_t r;
    der_init(&r, filebuf, (size_t)size);
    while (r.p < r.end && g_root_count < X509_TRUST_MAX_ROOTS) {
        const uint8_t *cert_start = r.p;
        uint8_t tag; const uint8_t *val; size_t vlen;
        if (!der_read_tlv(&r, &tag, &val, &vlen)) break;
        if (tag != DER_TAG_SEQUENCE) break; /* 형식 오류 — 여기서부터는 포기(뒤에 쓰레기 바이트가 있어도 이미 읽은 루트는 유지) */
        size_t cert_len = (size_t)(r.p - cert_start);

        x509_cert_t c;
        if (x509_parse(cert_start, cert_len, &c) && c.subject_len <= X509_TRUST_MAX_SUBJECT) {
            x509_trust_root_t *root = &g_roots[g_root_count];
            root->n = c.pubkey_n;
            root->e = c.pubkey_e;
            for (size_t i = 0; i < c.subject_len; i++) root->subject[i] = c.subject_der[i];
            root->subject_len = c.subject_len;
            g_root_count++;
        }
        /* 파싱 실패한 개별 인증서는 그냥 건너뛰고 다음 것을 계속 시도한다
         * (파일 하나에 문제 있는 항목이 섞여도 나머지 루트는 살린다). */
    }
    return g_root_count;
}

int x509_trust_count(void) { return g_root_count; }

int x509_verify_chain(const x509_cert_t *chain, int chain_len, uint64_t now, const char **fail_reason) {
    if (chain_len <= 0) { if (fail_reason) *fail_reason = "빈 인증서 체인"; return 0; }
    if (chain_len > X509_TRUST_MAX_CHAIN) { if (fail_reason) *fail_reason = "인증서 체인이 너무 깁니다"; return 0; }

    for (int i = 0; i < chain_len; i++) {
        if (!x509_check_validity(&chain[i], now)) {
            if (fail_reason) *fail_reason = "인증서 유효기간을 벗어났습니다";
            return 0;
        }
    }

    /* Milestone 26: 리프 인증서에 extendedKeyUsage가 있다면 서버 인증
     * (serverAuth) 용도가 포함돼야 한다(예: codeSigning 전용 인증서로
     * TLS 서버 인증을 하려는 경우를 걸러냄). 확장 자체가 없으면 RFC
     * 5280대로 제약 없음으로 취급 — x509_min.h 상단 참고. */
    if (chain[0].has_eku && !chain[0].eku_server_auth) {
        if (fail_reason) *fail_reason = "리프 인증서의 extendedKeyUsage에 서버 인증(serverAuth) 용도가 없음";
        return 0;
    }

    for (int i = 0; i < chain_len - 1; i++) {
        const x509_cert_t *child = &chain[i];
        const x509_cert_t *parent = &chain[i + 1];
        if (child->issuer_len != parent->subject_len ||
            memcmp(child->issuer_der, parent->subject_der, child->issuer_len) != 0) {
            if (fail_reason) *fail_reason = "인증서 체인 연결 실패(issuer/subject 불일치)";
            return 0;
        }
        if (!x509_verify_signature(child, &parent->pubkey_n, &parent->pubkey_e)) {
            if (fail_reason) *fail_reason = "인증서 서명 검증 실패";
            return 0;
        }
        /* Milestone 25: parent가 실제로 "다른 인증서에 서명해도 되는 CA"로
         * 지정됐는지 확인 — basicConstraints가 아예 없거나 cA가 FALSE면
         * 서명 수학적으로는 맞아도 신뢰하지 않는다(그렇지 않으면 아무
         * 리프 인증서의 개인키만 훔쳐도 그걸로 다른 인증서를 "서명"해서
         * 체인에 끼워넣을 수 있음 — RFC 5280이 요구하는 최소한의 방어). */
        if (!parent->has_basic_constraints || !parent->is_ca) {
            if (fail_reason) *fail_reason = "발급자가 CA 인증서가 아님(basicConstraints cA:TRUE 없음)";
            return 0;
        }
        if (parent->has_key_usage && !parent->key_cert_sign) {
            if (fail_reason) *fail_reason = "발급자의 keyUsage에 keyCertSign이 없음";
            return 0;
        }
        /* pathLenConstraint: parent 아래로(리프 쪽으로) parent 자신을 뺀
         * 중간 CA 개수가 parent->path_len을 넘으면 안 된다(RFC 5280
         * 4.2.1.9). "parent 아래 중간 CA 개수" = i(= parent의 체인
         * 인덱스 i+1 바로 아래, 리프(index 0)까지의 인증서 중 리프 자신을
         * 뺀 개수) — 인덱스로 보면 정확히 i개(0..i-1 인덱스가 그 중간
         * CA들, 단 index 0은 리프라 실제 "중간 CA"는 i-1개지만, 이 구현은
         * 보수적으로 i(리프 포함)를 써서 더 엄격하게 잡는다 — 완화가
         * 아니라 강화 방향의 단순화라 안전함). */
        if (parent->has_path_len && i > parent->path_len) {
            if (fail_reason) *fail_reason = "pathLenConstraint 위반(체인이 너무 김)";
            return 0;
        }
    }

    if (g_root_count == 0) {
        if (fail_reason) *fail_reason = "신뢰 저장소가 비어있음(/system/certs/roots.der 없음)";
        return 0;
    }

    const x509_cert_t *last = &chain[chain_len - 1];
    for (int i = 0; i < g_root_count; i++) {
        x509_trust_root_t *root = &g_roots[i];
        if (last->issuer_len == root->subject_len &&
            memcmp(last->issuer_der, root->subject, last->issuer_len) == 0) {
            if (x509_verify_signature(last, &root->n, &root->e)) return 1;
        }
    }
    if (fail_reason) *fail_reason = "신뢰할 수 있는 루트 CA를 찾을 수 없음";
    return 0;
}
