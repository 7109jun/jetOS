kernel/fs/config.o: kernel/fs/config.c kernel/fs/config.h \
 kernel/fs/jetfs.h kernel/fs/../gui/theme.h kernel/fs/../gui/wm.h \
 kernel/fs/../gui/../drivers/console.h
kernel/fs/config.h:
kernel/fs/jetfs.h:
kernel/fs/../gui/theme.h:
kernel/fs/../gui/wm.h:
kernel/fs/../gui/../drivers/console.h:
