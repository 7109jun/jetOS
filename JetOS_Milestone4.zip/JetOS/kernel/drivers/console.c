/*
 * JetOS - kernel/drivers/console.c
 * UEFI GOP(Graphics Output Protocol)가 넘겨준 선형 프레임버퍼에 직접
 * 픽셀을 써서 화면 출력을 구현한다. 포트 I/O가 아닌 메모리 매핑된
 * 프레임버퍼이므로 순수 C 메모리 접근(포인터 대입)만으로 동작하며
 * 어셈블리가 전혀 필요 없다.
 */

#include "console.h"
#include "font5x7.h"

#define GLYPH_SCALE 2
#define GLYPH_ADVANCE ((FONT_W + 1) * GLYPH_SCALE)
#define LINE_ADVANCE  ((FONT_H + 2) * GLYPH_SCALE)

void console_init(console_t *con, uint32_t *fb, uint32_t width, uint32_t height, uint32_t pps) {
    con->fb = fb;
    con->width = width;
    con->height = height;
    con->pixels_per_scanline = pps;
    con->cursor_x = 0;
    con->cursor_y = 0;
    con->fg_color = 0x00E0E0E0; /* 밝은 회색 텍스트 */
    con->bg_color = 0x00101018; /* JetOS 기본 배경 (Windows와 다른 고유 톤) */
}

void console_put_pixel(console_t *con, uint32_t x, uint32_t y, uint32_t color) {
    if (x >= con->width || y >= con->height) return;
    con->fb[y * con->pixels_per_scanline + x] = color;
}

void console_fill_rect(console_t *con, uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint32_t color) {
    for (uint32_t j = 0; j < h; j++) {
        for (uint32_t i = 0; i < w; i++) {
            console_put_pixel(con, x + i, y + j, color);
        }
    }
}

void console_clear(console_t *con, uint32_t color) {
    console_fill_rect(con, 0, 0, con->width, con->height, color);
    con->cursor_x = 0;
    con->cursor_y = 0;
}

static const font_glyph_t *find_glyph(char c) {
    if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A'); /* 소문자는 대문자로 대체 (M1 임시) */
    for (uint32_t i = 0; i < FONT_GLYPH_COUNT; i++) {
        if (g_font5x7[i].ch == c) return &g_font5x7[i];
    }
    return &g_font5x7[0]; /* 미지원 문자는 공백 처리 */
}

void console_putc(console_t *con, char c) {
    if (c == '\n') {
        con->cursor_x = 0;
        con->cursor_y += LINE_ADVANCE;
        return;
    }
    if (con->cursor_x + GLYPH_ADVANCE > con->width) {
        con->cursor_x = 0;
        con->cursor_y += LINE_ADVANCE;
    }
    if (con->cursor_y + LINE_ADVANCE > con->height) {
        /* Milestone 1: 스크롤 없음. 화면 하단 도달 시 처음으로 되돌린다. */
        con->cursor_y = 0;
    }

    const font_glyph_t *g = find_glyph(c);
    for (int row = 0; row < FONT_H; row++) {
        uint8_t bits = g->rows[row];
        for (int col = 0; col < FONT_W; col++) {
            if (bits & (1 << (FONT_W - 1 - col))) {
                console_fill_rect(con,
                    con->cursor_x + col * GLYPH_SCALE,
                    con->cursor_y + row * GLYPH_SCALE,
                    GLYPH_SCALE, GLYPH_SCALE, con->fg_color);
            }
        }
    }
    con->cursor_x += GLYPH_ADVANCE;
}

void console_print(console_t *con, const char *s) {
    while (*s) {
        console_putc(con, *s++);
    }
}
