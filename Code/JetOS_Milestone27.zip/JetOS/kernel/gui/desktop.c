/*
 * JetOS - kernel/gui/desktop.c
 * 데스크톱 셸: 마우스로 창을 드래그하고, 시작메뉴를 열고, 키보드로
 * 메모장 창에 타이핑할 수 있는 최소 상호작용 루프.
 */

#include "desktop.h"
#include "wm.h"
#include <stddef.h>
#include "../kernel.h"
#include "../drivers/keyboard.h"
#include "../drivers/mouse.h"
#include "../drivers/console.h"
#include "../drivers/speaker.h"
#include "../drivers/serial.h"
#include "../proc/scheduler.h"
#include "../hal/x86_asm_shim.h"
#include "../apps/file_manager.h"
#include "../apps/settings.h"
#include "../apps/task_manager.h"
#include "../apps/jash.h"
#include "../apps/clock.h"
#include "../apps/browser.h"
#include "../fs/jetfs.h"

#define NOTEPAD_BUF_SIZE 256
#define NOTEPAD_FILE "/notepad.txt"

static char g_notepad_buf[NOTEPAD_BUF_SIZE];
static int g_notepad_len = 0;
static int g_notepad_window = -1;
static int g_notepad_dirty = 0; /* Milestone 17: 저장 안 된 변경사항 있음 */
static int g_shutdown_requested = 0;
static char g_notepad_status[40] = "";

static void str_copy_local(char *dst, const char *src, int dstsz) {
    int i = 0;
    while (src[i] && i < dstsz - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

static void notepad_update_title(void) {
    if (g_notepad_window < 0) return;
    wm_set_title(g_notepad_window, g_notepad_dirty ? "NOTEPAD *" : "NOTEPAD");
}

static void notepad_append(char c) {
    if (c == (char)KEY_F5) { /* 저장 */
        if (jetfs_write(NOTEPAD_FILE, g_notepad_buf, (uint32_t)g_notepad_len)) {
            str_copy_local(g_notepad_status, "[saved to notepad.txt]", sizeof(g_notepad_status));
            g_notepad_dirty = 0;
            notepad_update_title();
        } else if (jetfs_create(NOTEPAD_FILE, JETFS_TYPE_FILE) &&
                   jetfs_write(NOTEPAD_FILE, g_notepad_buf, (uint32_t)g_notepad_len)) {
            str_copy_local(g_notepad_status, "[saved to notepad.txt]", sizeof(g_notepad_status));
            g_notepad_dirty = 0;
            notepad_update_title();
        } else {
            str_copy_local(g_notepad_status, "[save failed]", sizeof(g_notepad_status));
        }
        return;
    }
    if (c == (char)KEY_F6) { /* 불러오기 */
        uint64_t got = 0;
        if (jetfs_read(NOTEPAD_FILE, g_notepad_buf, NOTEPAD_BUF_SIZE - 1, &got)) {
            g_notepad_len = (int)got;
            g_notepad_buf[g_notepad_len] = '\0';
            str_copy_local(g_notepad_status, "[loaded notepad.txt]", sizeof(g_notepad_status));
            g_notepad_dirty = 0;
            notepad_update_title();
        } else {
            str_copy_local(g_notepad_status, "[no saved file]", sizeof(g_notepad_status));
        }
        return;
    }
    if (c == '\b') {
        if (g_notepad_len > 0) {
            g_notepad_len--;
            g_notepad_buf[g_notepad_len] = '\0';
            g_notepad_dirty = 1;
            notepad_update_title();
        }
        return;
    }
    if (c == '\n') c = ' ';
    if (c >= 32 && c < 127 && g_notepad_len < NOTEPAD_BUF_SIZE - 1) {
        g_notepad_buf[g_notepad_len++] = c;
        g_notepad_buf[g_notepad_len] = '\0';
        g_notepad_dirty = 1;
        notepad_update_title();
    }
}

static void notepad_key_cb(char c, void *ctx) {
    (void)ctx;
    notepad_append(c);
}

static void notepad_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)w; (void)ctx;
    dc->cursor_x = (uint32_t)(x + 10);
    dc->cursor_y = (uint32_t)(y + 10);
    console_print(dc, g_notepad_buf);
    dc->cursor_x = (uint32_t)(x + 10);
    dc->cursor_y = (uint32_t)(y + h - 30);
    console_print(dc, "F5=save  F6=load");
    if (g_notepad_status[0]) {
        dc->cursor_x = (uint32_t)(x + 10);
        dc->cursor_y = (uint32_t)(y + h - 16);
        console_print(dc, g_notepad_status);
    }
}

/* Notepad는 별도 스레드가 아니라 desktop 루프 안에서 그려지므로,
 * 닫힐 때는 내용만 비우고 창은 wm_close_window()가 알아서 숨긴다
 * (다시 열 수 있는 시작메뉴 항목은 없음 — Milestone 7 범위에서는
 * 부팅 시 한 번 생성되는 데모 창이기 때문). */
static void notepad_on_close(void *ctx) {
    (void)ctx;
    g_notepad_len = 0;
    g_notepad_buf[0] = '\0';
    g_notepad_status[0] = '\0';
    g_notepad_dirty = 0;
}

void desktop_thread_fn(void *arg) {
    (void)arg;

    wm_init(&g_console);
    keyboard_init();
    mouse_init();

    wm_create_window("ABOUT JETOS", 160, 60, 260, 120, 0x00304050);
    g_notepad_window = wm_create_window("NOTEPAD", 440, 60, 260, 120, 0x00203040);
    wm_set_content_callback(g_notepad_window, notepad_content_cb, NULL);
    wm_set_close_callback(g_notepad_window, notepad_on_close, NULL);
    wm_set_key_callback(g_notepad_window, notepad_key_cb, NULL); /* Milestone 19: 포커스 라우팅 일반화 */

    serial_write("STAGE: GUI DESKTOP SHELL STARTED (keyboard+mouse+wm)\n");

    /* Milestone 22: 부팅 완료 팬파레 — PC 스피커로 짧은 3음 상승
     * 시퀀스. 데스크톱 스레드 자신을 잠깐 블로킹하지만(협조적으로
     * scheduler_yield()하며 대기) 다른 스레드는 계속 돈다. */
    {
        static const speaker_note_t boot_chime[] = { {523,90}, {659,90}, {784,220} };
        speaker_play_melody(boot_chime, sizeof(boot_chime) / sizeof(boot_chime[0]));
    }

    int dragging = -1;
    int resizing = -1;
    int scrollbar_dragging = -1;
    int drag_offset_hit_titlebar = 0;
    int prev_left = 0;
    int prev_right = 0;

    for (;;) {
        char kc = keyboard_poll_char();
        if (kc) {
            /* Milestone 19: 키 입력은 항상 현재 포커스된 창(마지막으로
             * 클릭했거나 새로 생성된 창)의 key_cb로 라우팅된다. 예전에는
             * "jash가 실행중이면 jash, 아니면 Notepad"로 하드코딩되어
             * 있었지만, 이제 클릭한 창에 자동으로 포커스가 가므로 여러
             * 텍스트 입력 창을 자연스럽게 동시에 다룰 수 있다. */
            wm_dispatch_key(kc);
        }

        mouse_event_t ev;
        if (mouse_poll_event(&ev)) {
            int nx, ny;
            wm_get_cursor(&nx, &ny);
            wm_set_cursor(nx + ev.dx, ny + ev.dy);
            wm_get_cursor(&nx, &ny); /* 화면 경계로 보정된 최종 좌표 */

            /* Milestone 20: 마우스 휠 — 커서 아래 창(포커스와 무관, 클릭
             * 안 해도 됨. 대부분의 실제 OS와 동일한 관례)로 스크롤 전달. */
            if (ev.wheel != 0) {
                int under = wm_window_at(nx, ny);
                if (under >= 0) {
                    /* 휠 한 칸(±1)당 대략 세 줄 정도 이동하는 감각으로 스케일 */
                    wm_scroll_by(under, -ev.wheel * (CONSOLE_LINE_H * 3));
                }
            }

            if (ev.right && !prev_right) {
                /* 우클릭: 컸텍스트 메뉴 열림/닫힘 토글 */
                if (wm_is_context_menu_open()) {
                    wm_close_context_menu();
                } else {
                    int idx = wm_window_at(nx, ny);
                    wm_open_context_menu(nx, ny, idx); /* idx=-1이면 데스크톱 메뉴 */
                }
            } else if (ev.left && !prev_left) {
                if (wm_is_context_menu_open()) {
                    /* 컸텍스트 메뉴가 떠 있는 동안의 좌클릭은 메뉴 항목
                     * 선택(또는 밖까 클릭 시 메뉴 닫기)으로만 처리한다. */
                    int item;
                    if (wm_hit_context_menu_item(nx, ny, &item)) {
                        int target = wm_context_menu_target();
                        if (target == -1) {
                            if (item == 0) { file_manager_launch(); }
                            else if (item == 1) { jash_launch(); }
                            else if (item == 2) { settings_launch(); }
                            else if (item == 3) { task_manager_launch(); }
                            else if (item == 4) { clock_launch(); }
                            else if (item == 5) { browser_launch(); }
                        } else {
                            if (item == 0) {
                                wm_close_window(target);
                            } else if (item == 1) {
                                if (wm_is_window_minimized(target)) wm_restore_window(target);
                                else wm_minimize_window(target);
                            }
                        }
                    }
                    wm_close_context_menu();
                } else if (wm_is_start_button_hit(nx, ny)) {
                    wm_set_start_menu_open(1);
                } else {
                    /* 눌림 엣지: 클릭 대상 판별 */
                    int item;
                    if (wm_is_start_menu_item_hit(nx, ny, &item)) {
                        wm_set_start_menu_open(0);
                        if (item == 0) { file_manager_launch(); }
                        else if (item == 1) { jash_launch(); }
                        else if (item == 2) { settings_launch(); }
                        else if (item == 3) { task_manager_launch(); }
                        else if (item == 4) { clock_launch(); }
                        else if (item == 5) { browser_launch(); }
                        else if (item == 6) { g_shutdown_requested = 1; }
                    } else {
                        wm_set_start_menu_open(0);
                        int tb_idx = wm_hit_taskbar_window_button(nx, ny);
                        if (tb_idx >= 0) {
                            if (wm_is_window_minimized(tb_idx)) {
                                wm_restore_window(tb_idx);
                            } else {
                                wm_minimize_window(tb_idx);
                            }
                        } else {
                            int idx = wm_window_at(nx, ny);
                            if (idx >= 0) {
                                if (wm_hit_close_button(idx, nx, ny)) {
                                    wm_close_window(idx);
                                } else if (wm_hit_minimize_button(idx, nx, ny)) {
                                    wm_minimize_window(idx);
                                } else if (wm_hit_maximize_button(idx, nx, ny)) {
                                    wm_toggle_maximize(idx);
                                } else if (wm_hit_resize_handle(idx, nx, ny)) {
                                    wm_bring_to_front(idx);
                                    resizing = idx;
                                } else if (wm_hit_scrollbar(idx, nx, ny)) {
                                    wm_bring_to_front(idx);
                                    scrollbar_dragging = idx;
                                    wm_scrollbar_drag_to(idx, ny);
                                } else {
                                    wm_bring_to_front(idx);
                                    if (wm_hit_titlebar(idx, nx, ny)) {
                                        dragging = idx;
                                        drag_offset_hit_titlebar = 1;
                                    } else {
                                        wm_dispatch_click(nx, ny);
                                    }
                                }
                            } else {
                                /* 데스크톱 빈 곳 — 아이콘 더블클릭 확인 */
                                int icon = wm_desktop_icon_double_click(nx, ny);
                                if (icon == 0) { file_manager_launch(); }
                                else if (icon == 1) { jash_launch(); }
                                else if (icon == 2) { settings_launch(); }
                                else if (icon == 3) { task_manager_launch(); }
                                else if (icon == 4) { clock_launch(); }
                                else if (icon == 5) { browser_launch(); }
                            }
                        }
                    }
                }
            } else if (!ev.left) {
                /* Milestone 27: 타이틀바 드래그를 놓았을 때 스냅 미리보기 존이
                 * 떠 있었다면(가장자리까지 끌고 왔었다면) 실제로 스냅을
                 * 적용한다. 위쪽 가장자리(zone 3)는 최대화, 좌/우는 반쪽 화면. */
                if (dragging >= 0 && drag_offset_hit_titlebar) {
                    int zone = wm_snap_zone_at(nx, ny);
                    if (zone == 3) wm_toggle_maximize(dragging);
                    else if (zone == 1 || zone == 2) wm_snap_window(dragging, zone);
                }
                wm_set_snap_preview(0);
                dragging = -1;
                resizing = -1;
                scrollbar_dragging = -1;
                drag_offset_hit_titlebar = 0;
            } else if (ev.left && dragging >= 0 && drag_offset_hit_titlebar) {
                /* 스냅/최대화된 창을 타이틀바로 다시 끌면(Windows 7과 동일하게)
                 * 원래 크기로 즉시 복원한 뒤 드래그를 이어간다 — 그래야 스냅된
                 * 채로 화면 밖으로 끌려나가는 어색한 동작을 피할 수 있다. */
                if (wm_is_window_maximized(dragging) || wm_is_window_snapped(dragging)) {
                    wm_unsnap_window(dragging);
                }
                wm_move_window(dragging, ev.dx, ev.dy);
                wm_set_snap_preview(wm_snap_zone_at(nx, ny));
            } else if (ev.left && resizing >= 0) {
                wm_resize_window(resizing, ev.dx, ev.dy);
            } else if (ev.left && scrollbar_dragging >= 0) {
                wm_scrollbar_drag_to(scrollbar_dragging, ny);
            }
            prev_left = ev.left;
            prev_right = ev.right;
        }

        wm_draw();
        wm_present();

        if (g_shutdown_requested) {
            g_console.cursor_x = 20; g_console.cursor_y = 20;
            console_fill_rect(&g_console, 0, 0, g_console.width, g_console.height, 0x00000000);
            g_console.cursor_x = 40; g_console.cursor_y = 40;
            console_print(&g_console, "JETOS IS SHUTTING DOWN...");
            serial_write("STAGE: SHUTDOWN REQUESTED FROM START MENU. HALTING.\n");
            for (;;) { hal_hlt(); }
        }

        scheduler_yield();
    }
}
