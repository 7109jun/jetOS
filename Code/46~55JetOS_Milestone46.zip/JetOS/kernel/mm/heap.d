kernel/mm/heap.o: kernel/mm/heap.c kernel/mm/heap.h kernel/mm/pmm.h \
 kernel/mm/../../include/efi/efi.h
kernel/mm/heap.h:
kernel/mm/pmm.h:
kernel/mm/../../include/efi/efi.h:
