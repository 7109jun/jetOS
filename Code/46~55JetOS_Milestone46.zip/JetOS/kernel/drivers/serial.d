kernel/drivers/serial.o: kernel/drivers/serial.c kernel/drivers/serial.h \
 kernel/drivers/../hal/x86_asm_shim.h
kernel/drivers/serial.h:
kernel/drivers/../hal/x86_asm_shim.h:
