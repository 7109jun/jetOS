kernel/hal/context_switch.o: kernel/hal/context_switch.c \
 kernel/hal/context_switch.h
kernel/hal/context_switch.h:
