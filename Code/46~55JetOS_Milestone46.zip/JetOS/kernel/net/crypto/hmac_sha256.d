kernel/net/crypto/hmac_sha256.o: kernel/net/crypto/hmac_sha256.c \
 kernel/net/crypto/hmac_sha256.h kernel/net/crypto/sha256.h
kernel/net/crypto/hmac_sha256.h:
kernel/net/crypto/sha256.h:
