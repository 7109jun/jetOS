/*
 * JetOS - kernel/drivers/mouse.c
 * PS/2 마우스 (8042 보조 포트, IRQ12, 표준 3바이트 패킷).
 */

#include "mouse.h"
#include "../hal/x86_asm_shim.h"
#include "../int/pic.h"
#include "serial.h"

#define I8042_DATA 0x60
#define I8042_STATUS 0x64
#define I8042_CMD 0x64

static uint8_t g_packet[4];
static int g_cycle = 0;
static int g_packet_size = 3; /* Milestone 20: IntelliMouse 감지되면 4로 전환 */

static int g_accum_dx = 0, g_accum_dy = 0, g_accum_wheel = 0;
static int g_left = 0, g_right = 0, g_middle = 0;
static int g_has_event = 0;

static void wait_input_clear(void) {
    for (volatile int i = 0; i < 100000; i++) {
        if (!(hal_inb(I8042_STATUS) & 0x02)) return;
    }
}
static void wait_output_full(void) {
    for (volatile int i = 0; i < 100000; i++) {
        if (hal_inb(I8042_STATUS) & 0x01) return;
    }
}

static void mouse_write(uint8_t val) {
    wait_input_clear();
    hal_outb(I8042_CMD, 0xD4); /* 다음 바이트는 마우스로 전달 */
    wait_input_clear();
    hal_outb(I8042_DATA, val);
    wait_output_full();
    hal_inb(I8042_DATA); /* ACK(0xFA) 소비 */
}

/* mouse_write()와 같지만, ACK 다음에 오는 응답 바이트 하나를 더 읽어서
 * 반환한다 — 0xF2(장치 ID 조회) 같은 명령에 쓴다. IRQ12가 마스크된
 * 상태(mouse_init 도중)에서만 안전하게 호출할 것: 그렇지 않으면 이
 * 응답 바이트를 IRQ 핸들러가 먼저 채가서 패킷 동기화가 깨진다. */
static uint8_t mouse_write_read(uint8_t val) {
    wait_input_clear();
    hal_outb(I8042_CMD, 0xD4);
    wait_input_clear();
    hal_outb(I8042_DATA, val);
    wait_output_full();
    hal_inb(I8042_DATA); /* ACK(0xFA) */
    wait_output_full();
    return hal_inb(I8042_DATA); /* 실제 응답(예: 장치 ID) */
}

void mouse_init(void) {
    /* 초기화 중 주고받는 ACK 바이트를 IRQ12 핸들러와 이 함수의 폴링
     * 읽기가 서로 가로채는 경쟁 상태를 막기 위해, 설정이 끝날 때까지
     * IRQ12를 마스크해 둔다 (그렇지 않으면 ACK 바이트가 인터럽트로도
     * 동시에 소비되어 마우스 패킷 동기화가 깨진다 — 실제로 겪은 버그). */
    pic_mask_irq(12);

    wait_input_clear();
    hal_outb(I8042_CMD, 0xA8); /* 보조(aux) 포트 활성화 */

    wait_input_clear();
    hal_outb(I8042_CMD, 0x20); /* 컨트롤러 설정 바이트 읽기 */
    wait_output_full();
    uint8_t status = hal_inb(I8042_DATA);
    status |= 0x02;   /* IRQ12 활성화 */
    status &= ~0x20;  /* 마우스 클럭 비활성화 비트 해제 */

    wait_input_clear();
    hal_outb(I8042_CMD, 0x60); /* 설정 바이트 쓰기 */
    wait_input_clear();
    hal_outb(I8042_DATA, status);

    mouse_write(0xF6); /* 기본값으로 설정 */

    /* Milestone 20: Microsoft IntelliMouse 매직 시퀀스로 휠 지원 여부를
     * 감지한다. 샘플링 레이트를 200 -> 100 -> 80 순서로 정확히 이
     * 순서대로 설정하면, 휠을 지원하는 마우스는 이후 장치 ID가 3으로
     * 바뀐다(표준 마우스는 0을 유지) — PS/2 마우스 확장의 사실상
     * 표준 관례. 리포팅은 이 감지가 끝난 뒤에 켠다(그 전에 켜면
     * 감지 도중 스트리밍되는 이동 패킷이 ID 조회 응답과 뒤섞일 수
     * 있어서 순서를 이렇게 잡았다). */
    mouse_write(0xF3); mouse_write(200);
    mouse_write(0xF3); mouse_write(100);
    mouse_write(0xF3); mouse_write(80);
    uint8_t device_id = mouse_write_read(0xF2);
    int has_wheel = (device_id == 0x03);
    g_packet_size = has_wheel ? 4 : 3;
    serial_write(has_wheel ? "STAGE: MOUSE WHEEL DETECTED (IntelliMouse, 4-byte packets)\n"
                            : "STAGE: MOUSE WHEEL NOT DETECTED (standard 3-byte packets)\n");

    mouse_write(0xF4); /* 데이터 리포팅 활성화 */

    g_cycle = 0;
    g_accum_dx = g_accum_dy = g_accum_wheel = 0;
    g_left = g_right = g_middle = 0;
    g_has_event = 0;

    pic_unmask_irq(12); /* 이제부터 실제 움직임 패킷은 인터럽트로만 들어온다 */
}

void mouse_irq_handler(void) {
    uint8_t data = hal_inb(I8042_DATA);

    if (g_cycle == 0 && !(data & 0x08)) return; /* 동기화 안 됨: 항상-1 비트 확인 */

    g_packet[g_cycle++] = data;
    if (g_cycle < g_packet_size) return;
    g_cycle = 0;

    uint8_t status = g_packet[0];
    int raw_dx = g_packet[1];
    int raw_dy = g_packet[2];
    if (status & 0x10) raw_dx -= 256;
    if (status & 0x20) raw_dy -= 256;

    g_accum_dx += raw_dx;
    g_accum_dy += -raw_dy; /* PS/2는 위쪽이 양수 -> 화면 좌표계로 부호 반전 */
    g_left   = status & 0x01;
    g_right  = status & 0x02;
    g_middle = status & 0x04;

    if (g_packet_size == 4) {
        /* IntelliMouse 4번째 바이트: 부호있는 8비트 휠 이동량(보통
         * ±1 단위, 한 클릭 = 1). 위로 굴리면 양수가 되도록(직관적인
         * "스크롤 업" 방향) 그대로 둔다 — 아래로 굴리면 음수. */
        int8_t wheel_delta = (int8_t)g_packet[3];
        g_accum_wheel += wheel_delta;
    }

    g_has_event = 1;
}

int mouse_poll_event(mouse_event_t *out) {
    if (!g_has_event) return 0;
    out->dx = g_accum_dx;
    out->dy = g_accum_dy;
    out->left = g_left;
    out->right = g_right;
    out->middle = g_middle;
    out->wheel = g_accum_wheel;
    g_accum_dx = 0;
    g_accum_dy = 0;
    g_accum_wheel = 0;
    g_has_event = 0;
    return 1;
}
