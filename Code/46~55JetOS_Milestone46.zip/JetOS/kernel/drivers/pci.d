kernel/drivers/pci.o: kernel/drivers/pci.c kernel/drivers/pci.h \
 kernel/drivers/../hal/x86_asm_shim.h
kernel/drivers/pci.h:
kernel/drivers/../hal/x86_asm_shim.h:
