#ifndef JETOS_WIN32_COMPAT_H
#define JETOS_WIN32_COMPAT_H

/*
 * JetOS Win32 호환 레이어 (Milestone 6 씨앗 단계 → Milestone 49에서
 * "진짜 mingw로 빌드한 PE32+가 실제로 실행되고 콘솔 출력까지 나온다"
 * 단계로 확장).
 *
 * Windows 개발자가 익숙한 함수 이름/시그니처를 그대로 제공하지만,
 * Microsoft의 Windows.h/SDK/DLL은 전혀 사용하지 않는다 — 아래 타입과
 * 함수는 전부 JetOS가 직접 정의/구현했으며, 내부적으로는 전부 JetAPI
 * (CreateWindowJ, WriteFileJ 등)나 커널 내부 API(kmalloc, serial_putc,
 * keyboard_poll_char 등)로 위임(delegate)된다.
 *
 * Wine이 리눅스에서 하는 것과 같은 접근이다: "Windows처럼 보이는 API
 * 표면"을 자체 구현으로 재현하는 것이지, Windows 코드를 가져다 쓰는
 * 것이 아니다.
 *
 * Milestone 49 실기 검증: x86_64-w64-mingw32-gcc로 (-nostdlib, CRT/
 * msvcrt 없이 순수 KERNEL32 임포트만 쓰는) 실제 PE32+를 빌드해
 * /test_pe.exe로 심어두고 실제 QEMU에서 pe_execute로 실행 — IAT가
 * ExitProcess/GetStdHandle/WriteFile을 전부 정상 연결했고,
 * WriteFile(STD_OUTPUT_HANDLE, ...)이 GetStdHandle이 반환한 콘솔
 * 핸들을 거쳐 시리얼에 정확한 문자열을 찍는 것까지 확인됨(커널 자체
 * 테스트로 매 부팅마다 자동 재검증, 아래 kernel_entry.c 참고).
 *
 * 아직 남은 큰 공백(정직한 한계): CRT/msvcrt(printf 등)는 구현 안 됨
 * — CRT 없이 순수 WinAPI만 쓰는 프로그램만 실행 가능. DLL 이름 구분
 * 없이 모든 임포트를 하나의 스텁 풀에서 찾음(진짜 다중 DLL 해석 아님).
 * 커맨드라인 인자는 항상 빈 문자열(GetCommandLineA). 이 공백들을 메우는
 * 게 "웬만한 프로그램을 JetOS에서 돌릴 수 있게" 하는 다음 마일스톤의
 * 핵심 과제다.
 */

#include <stdint.h>

/* WINAPI: PE32+ EXE(mingw 등으로 빌드된 실제 x64 Windows 바이너리)는
 * 함수를 호출할 때 Microsoft x64 호출 규약(인자를 RCX,RDX,R8,R9에 담음)을
 * 쓴다. 반면 JetOS 커널 자체는 기본적으로 System V AMD64 호출 규약
 * (RDI,RSI,RDX,RCX)으로 컴파일된다. IAT를 통해 EXE가 직접 호출하는
 * 모든 Win32 함수는 반드시 __attribute__((ms_abi))로 표시해 GCC가
 * MS 규약에 맞는 코드를 생성하도록 해야 한다 — 그렇지 않으면 인자가
 * 전부 엉뚱한 레지스터에서 읽혀 (사실상 무작위 쓰레기 값으로) 동작한다.
 * Wine이 같은 문제를 같은 방식(ms_abi 함수 포인터)으로 해결한다. */
#define WINAPI __attribute__((ms_abi))

typedef int32_t  BOOL;
typedef uint32_t DWORD;
typedef void*    LPVOID;
typedef const void* LPCVOID;
typedef const char* LPCSTR;
typedef void*    HANDLE;
typedef HANDLE   HWND;

#define TRUE  1
#define FALSE 0
#define NULL_HANDLE ((HANDLE)0)  /* NOLINT: efi.h에도 동명 매크로 존재, 동일 값이므로 무해 */

#define MEM_COMMIT  0x1000
#define PAGE_READWRITE 0x04

/* Milestone 49: 콘솔 표준 핸들. 진짜 Windows 값과 동일한 매직 넘버
 * (-10/-11/-12, DWORD로 재해석하면 매우 큰 값)를 그대로 써서, mingw로
 * 빌드된 실제 EXE가 STD_OUTPUT_HANDLE 등의 상수를 하드코딩해 넘겨도
 * (많은 프로그램이 GetStdHandle 매크로 대신 리터럴을 직접 쓰기도 함)
 * 그대로 맞물리게 한다. */
#define STD_INPUT_HANDLE  ((DWORD)-10)
#define STD_OUTPUT_HANDLE ((DWORD)-11)
#define STD_ERROR_HANDLE  ((DWORD)-12)

/* Milestone 49: HeapAlloc 플래그(가장 흔히 쓰이는 것만 — 나머지는
 * 무시해도 안전한 힌트 비트라 스코프 밖). */
#define HEAP_ZERO_MEMORY 0x00000008

/* 실제 CreateWindowExA 시그니처를 단순화했다 (부모/스타일/메뉴 등은
 * Milestone 6에서는 무시되고, 위치/크기/제목만 사용된다). */
WINAPI HWND CreateWindowA(LPCSTR title, int x, int y, int w, int h, DWORD color_as_style_placeholder);

WINAPI int MessageBoxA(HWND owner, LPCSTR text, LPCSTR title, DWORD type);

WINAPI HANDLE CreateFileA(LPCSTR path, DWORD desired_access, DWORD share_mode,
                    void *security_attrs, DWORD creation_disposition,
                    DWORD flags, HANDLE template_file);
WINAPI BOOL ReadFile(HANDLE file, LPVOID buffer, DWORD bytes_to_read, DWORD *bytes_read, void *overlapped);
WINAPI BOOL WriteFile(HANDLE file, LPCVOID buffer, DWORD bytes_to_write, DWORD *bytes_written, void *overlapped);
WINAPI BOOL CloseHandle(HANDLE h);
WINAPI DWORD GetFileSize(HANDLE file, DWORD *high);

WINAPI LPVOID VirtualAlloc(LPVOID addr, uint32_t size, DWORD alloc_type, DWORD protect);
WINAPI BOOL VirtualFree(LPVOID addr, uint32_t size, DWORD free_type);

WINAPI HANDLE GetStdHandle(DWORD std_handle);
WINAPI int lstrlenA(LPCSTR s);
WINAPI void Sleep(DWORD milliseconds);

/* Milestone 49: Windows 호환 레이어 확장.
 * 진짜 콘솔 서브시스템(WriteFile/WriteConsoleA로 stdout에 쓴 내용이
 * 실제로 어딘가에 보이는 것)과, mingw로 빌드된 평범한 콘솔 프로그램이
 * 자주 임포트하는 KERNEL32 함수 몇 가지를 추가한다. 여전히 Wine과
 * 같은 접근 — Windows 코드는 없고 전부 자체 구현이다. */
WINAPI BOOL WriteConsoleA(HANDLE console, LPCVOID buffer, DWORD chars_to_write,
                          DWORD *chars_written, void *reserved);
WINAPI BOOL ReadConsoleA(HANDLE console, LPVOID buffer, DWORD chars_to_read,
                         DWORD *chars_read, void *input_control);

WINAPI DWORD GetTickCount(void);
WINAPI LPCSTR GetCommandLineA(void);

/* Milestone 52: pe_loader.c가 실행 직전에 호출해 커맨드라인을 저장,
 * msvcrt.c의 __getmainargs가 파싱된 argv를 가져갈 때 쓴다. */
void win32_set_cmdline(const char *prog_path, const char *args);
int win32_get_argv(char ***out_argv); /* argc를 반환, *out_argv에 배열(NULL 종단) */
WINAPI HANDLE GetModuleHandleA(LPCSTR module_name);
WINAPI void *GetProcAddress(HANDLE module, LPCSTR proc_name);

WINAPI HANDLE GetProcessHeap(void);
WINAPI LPVOID HeapAlloc(HANDLE heap, DWORD flags, uint32_t size);
WINAPI BOOL HeapFree(HANDLE heap, DWORD flags, LPVOID mem);

WINAPI char *lstrcpyA(char *dst, LPCSTR src);
WINAPI char *lstrcatA(char *dst, LPCSTR src);

WINAPI void SetLastError(DWORD err);
WINAPI DWORD GetLastError(void);

WINAPI void OutputDebugStringA(LPCSTR msg);
WINAPI BOOL DeleteFileA(LPCSTR path);
WINAPI BOOL IsDebuggerPresent(void);

/* Milestone 54: 진짜 멀티스레딩. JetOS 자체 스레드(kernel/proc/thread.h)
 * 위에 얇게 얹은 것 — CreateThread가 리턴하는 HANDLE은 사실 그
 * thread_t*를 그대로 형변환한 값이다(별도 핸들 테이블 없이 재사용,
 * thread_t 구조체 자체는 스레드가 죽어도 즉시 안 없어진다는 스케줄러의
 * 기존 단순화(Milestone 3) 덕분에 안전하게 폴링 가능 — scheduler.c
 * 주석 참고).
 *
 * 정직한 경고(M54 조사 결과, 두 번 갱신됨): 부팅 자체테스트로 PE를
 * 5개 연달아 성공시킨 뒤 이 CreateThread 테스트 프로그램(6번째)을
 * 추가로 실행하면 6번째 스레드가 결과를 전혀 출력하지 않는다.
 *
 * 조사 경과: (1) 처음엔 "스케줄러 원형 연결리스트가 6번째 스레드를
 * 빠뜨린다"고 의심했으나, 실기 트레이스로 직접 확인한 결과 스케줄러
 * 링은 완전히 정상이었다(17개 스레드 전부 정확히 연결됨, enqueue/
 * pick_next/reap_dead 전부 무죄) — 이 가설은 틀렸다. (2) 그다음
 * "5번째(atexit) 테스트가 자기 atexit 핸들러 실행 직후 exit() 처리
 * 중 트리플폴트로 재부팅된다"고 의심했으나, 6번째 테스트를 완전히
 * 뺀 "정상" 5개 구성에서도 똑같이 cleanup1 ran 직후 재부팅이 반복
 * 되는 것을 확인 — 이건 실패가 아니라 이 커널 스냅샷의 기존 동작
 * (원인 미상, 이번 마일스톤 스코프 밖)이라 6번째 테스트 탓이 아니다.
 * 즉 두 가설 다 틀렸고, "6번째 스레드가 왜 출력을 안 내는지"는 아직도
 * 미해결이다.
 *
 * 그래서 이 CreateThread 구현 자체는 다 작성돼 있고 컴파일도 되지만,
 * 부팅 자체테스트 목록에서는 계속 빼둔다. 다음 세션 과제: 스케줄러는
 * 이미 결백이 확인됐으니 배제하고, PE 로더의 IAT 해석/이미지 재배치나
 * CreateThread가 실행되는 실제 시점(부팅 자체테스트 vs jash의 run
 * 명령)이 다를 때 재현되는지부터 좁혀볼 것. */
WINAPI HANDLE CreateThread(void *sec_attrs, uint32_t stack_size, void *start_addr,
                           LPVOID param, DWORD creation_flags, DWORD *thread_id);
__attribute__((noreturn)) WINAPI void ExitThread(DWORD exit_code);
WINAPI DWORD WaitForSingleObject(HANDLE h, DWORD timeout_ms);
WINAPI DWORD GetCurrentThreadId(void);

#define INFINITE ((DWORD)0xFFFFFFFF)
#define WAIT_OBJECT_0 0
#define WAIT_TIMEOUT 258

__attribute__((noreturn)) WINAPI void ExitProcess(DWORD exit_code);

#endif
