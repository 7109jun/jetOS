kernel/apps/jash.o: kernel/apps/jash.c kernel/apps/jash.h \
 kernel/apps/../../include/jetapi/jetapi.h \
 kernel/apps/../drivers/keyboard.h kernel/apps/../drivers/console.h \
 kernel/apps/../drivers/serial.h kernel/apps/../gui/wm.h \
 kernel/apps/../gui/../drivers/console.h kernel/apps/../gui/widget.h \
 kernel/apps/../gui/clipboard.h kernel/apps/../proc/scheduler.h \
 kernel/apps/../proc/thread.h kernel/apps/../proc/thread.h \
 kernel/apps/../fs/jetfs.h kernel/apps/../fs/recyclebin.h \
 kernel/apps/../hal/power.h kernel/apps/../fs/perm.h \
 kernel/apps/../fs/programs.h kernel/apps/../drivers/virtio_input.h \
 kernel/apps/../gui/notify.h kernel/apps/../fs/vfs.h \
 kernel/apps/../fs/fat32.h kernel/apps/../hal/x86_asm_shim.h \
 kernel/apps/../exec/pe_loader.h kernel/apps/../exec/elf_loader.h \
 kernel/apps/../net/net.h kernel/apps/../net/tcp.h \
 kernel/apps/../net/dns.h kernel/apps/../net/tls.h \
 kernel/apps/../drivers/speaker.h kernel/apps/../apps/browser.h \
 kernel/apps/../int/pit.h
kernel/apps/jash.h:
kernel/apps/../../include/jetapi/jetapi.h:
kernel/apps/../drivers/keyboard.h:
kernel/apps/../drivers/console.h:
kernel/apps/../drivers/serial.h:
kernel/apps/../gui/wm.h:
kernel/apps/../gui/../drivers/console.h:
kernel/apps/../gui/widget.h:
kernel/apps/../gui/clipboard.h:
kernel/apps/../proc/scheduler.h:
kernel/apps/../proc/thread.h:
kernel/apps/../proc/thread.h:
kernel/apps/../fs/jetfs.h:
kernel/apps/../fs/recyclebin.h:
kernel/apps/../hal/power.h:
kernel/apps/../fs/perm.h:
kernel/apps/../fs/programs.h:
kernel/apps/../drivers/virtio_input.h:
kernel/apps/../gui/notify.h:
kernel/apps/../fs/vfs.h:
kernel/apps/../fs/fat32.h:
kernel/apps/../hal/x86_asm_shim.h:
kernel/apps/../exec/pe_loader.h:
kernel/apps/../exec/elf_loader.h:
kernel/apps/../net/net.h:
kernel/apps/../net/tcp.h:
kernel/apps/../net/dns.h:
kernel/apps/../net/tls.h:
kernel/apps/../drivers/speaker.h:
kernel/apps/../apps/browser.h:
kernel/apps/../int/pit.h:
