/*
 * JetOS - kernel/drivers/hangul_font.c
 * hangul_font.h 설명 참고 — 획(stroke) 기반 한글 음절 조합 렌더러.
 */
#include "hangul_font.h"

#define HANGUL_BASE 0xAC00u
#define HANGUL_LAST 0xD7A3u
#define N_LEAD  19
#define N_VOWEL 21
#define N_TAIL  28

int hangul_is_syllable(uint32_t cp) {
    return cp >= HANGUL_BASE && cp <= HANGUL_LAST;
}

/* ---- 획 정의: 8x8 단위 격자 위의 선분들 ---- */
#define MAX_SEGS 7
typedef struct { int8_t x0, y0, x1, y1; } seg_t;
typedef struct { int count; seg_t segs[MAX_SEGS]; } shape_t;

/* 초성/종성 공용 19개 자음 모양 (8x8 격자, 단순화된 블록체) */
static const shape_t CONSONANT[N_LEAD] = {
    /* 0 ㄱ */ { 2, { {1,1,7,1}, {7,1,7,7} } },
    /* 1 ㄲ */ { 4, { {1,1,4,1}, {4,1,4,6}, {5,1,8,1}, {8,1,8,6} } },
    /* 2 ㄴ */ { 2, { {1,1,1,7}, {1,7,7,7} } },
    /* 3 ㄷ */ { 3, { {1,1,1,7}, {1,7,7,7}, {1,1,7,1} } },
    /* 4 ㄸ */ { 6, { {1,1,1,4}, {1,4,4,4}, {1,1,4,1}, {5,1,5,4}, {5,4,8,4}, {5,1,8,1} } },
    /* 5 ㄹ */ { 5, { {1,1,7,1}, {7,1,7,4}, {1,4,7,4}, {1,4,1,7}, {1,7,7,7} } },
    /* 6 ㅁ */ { 4, { {1,1,7,1}, {7,1,7,7}, {7,7,1,7}, {1,7,1,1} } },
    /* 7 ㅂ */ { 4, { {1,1,1,7}, {7,1,7,7}, {1,1,7,1}, {1,4,7,4} } },
    /* 8 ㅃ */ { 6, { {1,1,1,6}, {3,1,3,6}, {1,3,3,3}, {5,1,5,6}, {7,1,7,6}, {5,3,7,3} } },
    /* 9 ㅅ */ { 2, { {4,1,1,7}, {4,1,7,7} } },
    /*10 ㅆ */ { 4, { {3,1,1,6}, {3,1,5,6}, {6,1,4,6}, {6,1,8,6} } },
    /*11 ㅇ */ { 4, { {4,1,7,4}, {7,4,4,7}, {4,7,1,4}, {1,4,4,1} } },
    /*12 ㅈ */ { 3, { {1,1,7,1}, {4,1,1,7}, {4,1,7,7} } },
    /*13 ㅉ */ { 6, { {1,1,4,1}, {2,1,1,6}, {2,1,4,6}, {5,1,8,1}, {6,1,5,6}, {6,1,8,6} } },
    /*14 ㅊ */ { 4, { {3,0,5,1}, {1,2,7,2}, {4,2,1,7}, {4,2,7,7} } },
    /*15 ㅋ */ { 3, { {1,1,7,1}, {7,1,7,7}, {3,4,7,4} } },
    /*16 ㅌ */ { 4, { {1,1,1,7}, {1,7,7,7}, {1,1,7,1}, {1,4,6,4} } },
    /*17 ㅍ */ { 4, { {1,1,7,1}, {2,1,2,6}, {6,1,6,6}, {1,7,7,7} } },
    /*18 ㅎ */ { 4, { {3,0,5,0}, {1,2,7,2}, {5,4,7,6}, {3,6,5,4} } },
};

/* ---- 중성(모음) 21개 분류: 세로형/가로형/복합형 ---- */
typedef enum { V_VERT, V_HORIZ, V_BOTH } vowel_layout_t;

static vowel_layout_t vowel_layout(int vi) {
    switch (vi) {
        case 8: case 12: case 13: case 17: case 18: return V_HORIZ; /* ㅗㅛㅜㅠㅡ */
        case 9: case 10: case 11: case 14: case 15: case 16: case 19: return V_BOTH; /* ㅘㅙㅚㅝㅞㅟㅢ */
        default: return V_VERT; /* ㅏㅐㅑㅒㅓㅔㅕㅖㅣ */
    }
}

/* 세로형 모음 그리기: 자음 박스(0..8,0..8) 오른쪽 x=9..13에 그린다 */
static void draw_vowel_vert(console_t *con, int ox, int oy, int scale, int vi, uint32_t color);
static void draw_vowel_horiz(console_t *con, int ox, int oy, int scale, int vi, uint32_t color);

/* ---- 선분 하나를 그리는 간단한 DDA ---- */
static void draw_seg(console_t *con, int ox, int oy, int scale, int x0, int y0, int x1, int y1, uint32_t color) {
    int dx = x1 - x0, dy = y1 - y0;
    int steps = dx > 0 ? dx : -dx;
    int ay = dy > 0 ? dy : -dy;
    if (ay > steps) steps = ay;
    if (steps == 0) {
        console_fill_rect(con, (uint32_t)(ox + x0 * scale), (uint32_t)(oy + y0 * scale), (uint32_t)scale, (uint32_t)scale, color);
        return;
    }
    for (int i = 0; i <= steps; i++) {
        int x = x0 + dx * i / steps;
        int y = y0 + dy * i / steps;
        console_fill_rect(con, (uint32_t)(ox + x * scale), (uint32_t)(oy + y * scale), (uint32_t)scale, (uint32_t)scale, color);
    }
}

static void draw_shape(console_t *con, int ox, int oy, int scale, const shape_t *sh, uint32_t color) {
    for (int i = 0; i < sh->count; i++) {
        const seg_t *s = &sh->segs[i];
        draw_seg(con, ox, oy, scale, s->x0, s->y0, s->x1, s->y1, color);
    }
}

static void draw_vowel_vert(console_t *con, int ox, int oy, int scale, int vi, uint32_t color) {
    /* 분류: 전설(오른쪽으로 트임)/후설(왼쪽으로 트임), y계열(이중 획), e계열(추가 세로줄) */
    static const int is_front[21] = {1,1,1,1,0,0,0,0, 0,0,0,0,0,0,0,0,0,0,0,0, 0};
    static const int is_y[21]     = {0,0,1,1,0,0,1,1, 0,0,0,0,0,0,0,0,0,0,0,0, 0};
    static const int is_e[21]     = {0,1,0,1,0,1,0,1, 0,0,0,0,0,0,0,0,0,0,0,0, 0};
    int front = is_front[vi];
    int y = is_y[vi];
    int e = is_e[vi];
    int main_x = (vi == 20) ? 11 : (front ? 9 : 12);

    draw_seg(con, ox, oy, scale, main_x, 0, main_x, 15, color);
    if (vi != 20) {
        int tx0 = front ? main_x : main_x - 2;
        int tx1 = front ? main_x + 2 : main_x;
        draw_seg(con, ox, oy, scale, tx0, 7, tx1, 7, color);
        if (y) draw_seg(con, ox, oy, scale, tx0, 11, tx1, 11, color);
    }
    if (e) draw_seg(con, ox, oy, scale, 13, 0, 13, 15, color);
}

static void draw_vowel_horiz(console_t *con, int ox, int oy, int scale, int vi, uint32_t color) {
    /* ㅗㅛ(위로 뻗음) / ㅜㅠ(아래로 뻗음) / ㅡ(줄기 없음) */
    draw_seg(con, ox, oy, scale, 1, 9, 12, 9, color);
    if (vi == 8 || vi == 12) { /* ㅗ ㅛ */
        draw_seg(con, ox, oy, scale, 5, 1, 5, 9, color);
        if (vi == 12) draw_seg(con, ox, oy, scale, 8, 1, 8, 9, color);
    } else if (vi == 13 || vi == 17) { /* ㅜ ㅠ */
        draw_seg(con, ox, oy, scale, 5, 9, 5, 15, color);
        if (vi == 17) draw_seg(con, ox, oy, scale, 8, 9, 8, 15, color);
    }
    /* vi==18 (ㅡ)는 가로줄만 */
}

static void draw_vowel_both(console_t *con, int ox, int oy, int scale, int vi, uint32_t color) {
    /* 복합모음(ㅘㅙㅚㅝㅞㅟㅢ): 가로 줄기(자음 아래) + 세로 줄기(오른쪽) 근사 */
    (void)vi;
    draw_seg(con, ox, oy, scale, 1, 8, 8, 8, color);
    draw_seg(con, ox, oy, scale, 12, 0, 12, 15, color);
    draw_seg(con, ox, oy, scale, 10, 7, 12, 7, color);
}

void hangul_draw_syllable(console_t *con, int x, int y, uint32_t codepoint, uint32_t color, int scale) {
    if (!hangul_is_syllable(codepoint)) return;
    uint32_t code = codepoint - HANGUL_BASE;
    int lead = (int)(code / (N_VOWEL * N_TAIL));
    int vowel = (int)((code / N_TAIL) % N_VOWEL);
    int tail = (int)(code % N_TAIL);

    if (lead < 0 || lead >= N_LEAD) return;

    /* 초성: 항상 같은 8x8 박스에 그린다 (레이아웃별 실제 활자 비례는
     * 다르지만, 구현 단순화를 위해 위치를 통일했다 — hangul_font.h
     * 문서의 알려진 단순화 참고). */
    draw_shape(con, x, y, scale, &CONSONANT[lead], color);

    vowel_layout_t layout = vowel_layout(vowel);
    if (layout == V_VERT) draw_vowel_vert(con, x, y, scale, vowel, color);
    else if (layout == V_HORIZ) draw_vowel_horiz(con, x, y, scale, vowel, color);
    else draw_vowel_both(con, x, y, scale, vowel, color);

    /* 종성: 있으면 하단(y=16..21 확장 영역)에 같은 자음 모양을 축소해
     * 그린다. 겹받침은 첫 자음 모양만 사용한다(단순화). */
    if (tail > 0) {
        static const int tail_to_lead[N_TAIL] = {
            -1, 0,1,0,2,2,2,3,5,5,5,5,5,5,5,5,5,6,7,9,10,11,12,14,15,16,17,18
        };
        int lc = tail_to_lead[tail];
        if (lc >= 0 && lc < N_LEAD) {
            /* 8x8 자음 모양을 아래쪽 y=16..21 영역(가로 12, 세로 6)에 축소 배치 */
            const shape_t *sh = &CONSONANT[lc];
            for (int i = 0; i < sh->count; i++) {
                const seg_t *s = &sh->segs[i];
                int x0 = 2 + s->x0 * 8 / 10, y0 = 16 + s->y0 * 5 / 8;
                int x1 = 2 + s->x1 * 8 / 10, y1 = 16 + s->y1 * 5 / 8;
                draw_seg(con, x, y, scale, x0, y0, x1, y1, color);
            }
        }
    }
}
