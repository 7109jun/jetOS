#ifndef JETOS_HEAP_H
#define JETOS_HEAP_H

#include <stddef.h>
#include <stdint.h>

/* PMM 위에 구축되는 First-Fit 프리리스트 커널 힙.
 * heap_init()은 PMM에서 초기 블록(페이지 단위)을 할당해 힙을 시작하고,
 * 공간이 부족해지면 kmalloc이 자동으로 PMM에서 추가 페이지를 확보해
 * 힙을 확장한다. */
void heap_init(uint64_t initial_pages);
void *kmalloc(size_t size);
void kfree(void *ptr);

typedef struct {
    uint64_t total_bytes;
    uint64_t used_bytes;
    uint64_t free_bytes;
    uint64_t block_count;
} heap_stats_t;

void heap_get_stats(heap_stats_t *out);

#endif
