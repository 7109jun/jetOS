kernel/drivers/ahci.o: kernel/drivers/ahci.c kernel/drivers/ahci.h \
 kernel/drivers/pci.h kernel/drivers/../mm/pmm.h \
 kernel/drivers/../mm/../../include/efi/efi.h
kernel/drivers/ahci.h:
kernel/drivers/pci.h:
kernel/drivers/../mm/pmm.h:
kernel/drivers/../mm/../../include/efi/efi.h:
