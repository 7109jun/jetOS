#ifndef JETOS_APP_RUN_DIALOG_H
#define JETOS_APP_RUN_DIALOG_H

/*
 * JetOS - kernel/apps/run_dialog.h
 * Milestone 35: 실행(Run) 대화상자. JCC(M30)나 PE 컴파일 결과물을
 * 실행하려면 지금까지 반드시 jash를 열고 `run <path>`를 타이핑해야
 * 했다 — 프로그램을 실행하는 것 자체가 "터미널을 아는 사람만 가능한 일"
 * 이었다는 뜻이다. Windows의 Win+R 실행 대화상자처럼, 경로 하나
 * 입력하고 Enter만 누르면 되는 GUI 창을 추가한다. 내부 로직(ELF 매직
 * 바이트 감지 → elf_execute, 아니면 pe_execute)은 jash.c의 cmd_run()과
 * 동일하다 — 재사용 대신 다시 구현한 이유는 다른 M35 앱들과 같다
 * (file_manager.c/search.c 등도 전부 자기 완결적인 독립 프로그램).
 */
void run_dialog_launch(void);

#endif
