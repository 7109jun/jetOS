typedef unsigned long DWORD;
typedef void* HANDLE;
typedef int BOOL;
typedef const char* LPCSTR;
typedef void* LPVOID;
typedef const void* LPCVOID;

#define WINAPI __attribute__((ms_abi))
#define STD_OUTPUT_HANDLE ((DWORD)-11)

extern HANDLE WINAPI GetStdHandle(DWORD);
extern BOOL WINAPI WriteFile(HANDLE, LPCVOID, DWORD, DWORD*, void*);
extern void WINAPI ExitProcess(DWORD) __attribute__((noreturn));

void _start(void) {
    HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);
    const char msg[] = "Hello from a real PE32+ EXE running on JetOS!\n";
    DWORD written = 0;
    WriteFile(out, msg, sizeof(msg) - 1, &written, 0);
    ExitProcess(0);
}

/*
 * 빌드 (Milestone 49):
 *   x86_64-w64-mingw32-gcc -nostdlib -Wl,--entry=_start \
 *       -Wl,--subsystem,console -o hello_pe.exe hello_pe.c -lkernel32
 *
 * JETFS에 심기:
 *   build/jetfs_import build/jetfs.img hello_pe.exe /test_pe.exe
 *
 * kernel_entry.c의 JETFS 마운트 성공 블록 안에서
 * pe_execute("/test_pe.exe", NULL)로 매 부팅 자동 실행/검증된다.
 */
