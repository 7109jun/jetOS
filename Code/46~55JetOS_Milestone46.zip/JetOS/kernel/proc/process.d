kernel/proc/process.o: kernel/proc/process.c kernel/proc/process.h \
 kernel/proc/thread.h kernel/proc/../mm/heap.h
kernel/proc/process.h:
kernel/proc/thread.h:
kernel/proc/../mm/heap.h:
