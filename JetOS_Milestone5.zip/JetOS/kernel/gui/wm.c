/*
 * JetOS - kernel/gui/wm.c
 * 최소 윈도우 매니저: 창 위치/크기/Z-order/포커스, 작업표시줄, 시작메뉴,
 * 커서 오버레이를 오프스크린 백버퍼에 합성(compositing)한 뒤
 * wm_present()로 한 번에 실제 프레임버퍼에 반영한다 (더블 버퍼링으로
 * 테어링 방지).
 */

#include "wm.h"
#include "../mm/heap.h"
#include <stddef.h>

#define START_MENU_ITEMS 4
static const char *START_MENU_LABELS[START_MENU_ITEMS] = {
    "FILE MANAGER", "TERMINAL", "SETTINGS", "SHUTDOWN"
};

static console_t *g_front = NULL; /* 실제 프레임버퍼(화면에 보이는 것) */
static console_t g_back;          /* 오프스크린 백버퍼 (더블 버퍼링) */
static console_t *g_con = NULL;   /* 모든 그리기 함수가 실제로 그리는 대상 = &g_back */
static wm_window_t g_windows[WM_MAX_WINDOWS];
static int g_order[WM_MAX_WINDOWS]; /* 뒤->앞 순서로 창 인덱스 나열 */
static int g_window_count = 0;

static int g_cursor_x = 0, g_cursor_y = 0;
static int g_start_menu_open = 0;

#define TASKBAR_COLOR   0x00202030
#define START_BTN_COLOR 0x00355070
#define START_BTN_W     90
#define DESKTOP_BG      0x00101018
#define MENU_COLOR      0x00283850
#define MENU_ITEM_H     22
#define TASKBAR_LABEL_GAP 140

void wm_init(console_t *con) {
    g_front = con;

    /* 오프스크린 백버퍼 할당: 프레임버퍼와 같은 크기의 순수 RAM 픽셀
     * 배열. 여기에 전부 그린 뒤 한 번에 실제 프레임버퍼로 복사하면,
     * 화면이 "그려지는 중간 상태"로 노출되는 테어링(tearing) 현상이
     * 사라진다 (매 프레임 통째로 다시 그리는 구조라 이 문제가 특히
     * 두드러졌었다 — 실제로 겪은 문제). */
    uint32_t *backbuf = (uint32_t *)kmalloc((size_t)con->width * con->height * sizeof(uint32_t));
    console_init(&g_back, backbuf, con->width, con->height, con->width);

    g_con = &g_back;
    g_window_count = 0;
    for (int i = 0; i < WM_MAX_WINDOWS; i++) { g_windows[i].used = 0; g_order[i] = -1; }
    g_cursor_x = (int)con->width / 2;
    g_cursor_y = (int)con->height / 2;
    g_start_menu_open = 0;
}

console_t *wm_get_draw_console(void) { return g_con; }

void wm_present(void) {
    if (!g_front || !g_con || !g_con->fb || !g_front->fb) return;
    uint32_t total = g_front->width * g_front->height;
    for (uint32_t i = 0; i < total; i++) {
        g_front->fb[i] = g_con->fb[i];
    }
}

int wm_create_window(const char *title, int x, int y, int w, int h, uint32_t color) {
    if (g_window_count >= WM_MAX_WINDOWS) return -1;
    int idx = g_window_count++;
    wm_window_t *win = &g_windows[idx];
    win->x = x; win->y = y; win->w = w; win->h = h;
    win->color = color;
    win->visible = 1;
    win->used = 1;
    int i = 0;
    for (; i < 31 && title[i]; i++) win->title[i] = title[i];
    win->title[i] = '\0';
    g_order[idx] = idx;
    return idx;
}

void wm_bring_to_front(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    int pos = -1;
    for (int i = 0; i < g_window_count; i++) if (g_order[i] == idx) { pos = i; break; }
    if (pos < 0) return;
    for (int i = pos; i < g_window_count - 1; i++) g_order[i] = g_order[i + 1];
    g_order[g_window_count - 1] = idx;
}

void wm_move_window(int idx, int dx, int dy) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].x += dx;
    g_windows[idx].y += dy;
}

int wm_window_at(int x, int y) {
    for (int i = g_window_count - 1; i >= 0; i--) {
        int idx = g_order[i];
        wm_window_t *w = &g_windows[idx];
        if (!w->visible) continue;
        if (x >= w->x && x < w->x + w->w && y >= w->y && y < w->y + w->h + WM_TITLEBAR_H) {
            return idx;
        }
    }
    return -1;
}

int wm_hit_titlebar(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    return (x >= w->x && x < w->x + w->w && y >= w->y && y < w->y + WM_TITLEBAR_H);
}

void wm_get_window_bounds(int idx, int *x, int *y, int *w, int *h) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *win = &g_windows[idx];
    if (x) *x = win->x;
    if (y) *y = win->y;
    if (w) *w = win->w;
    if (h) *h = win->h;
}

void wm_set_cursor(int x, int y) {
    if (!g_con) return;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x >= (int)g_con->width) x = (int)g_con->width - 1;
    if (y >= (int)g_con->height) y = (int)g_con->height - 1;
    g_cursor_x = x;
    g_cursor_y = y;
}

void wm_get_cursor(int *x, int *y) {
    if (x) *x = g_cursor_x;
    if (y) *y = g_cursor_y;
}

void wm_set_start_menu_open(int open) { g_start_menu_open = open; }

int wm_is_start_button_hit(int x, int y) {
    if (!g_con) return 0;
    int taskbar_y = (int)g_con->height - WM_TASKBAR_H;
    return (x >= 0 && x < START_BTN_W && y >= taskbar_y && y < (int)g_con->height);
}

int wm_is_start_menu_item_hit(int x, int y, int *out_item_index) {
    if (!g_con || !g_start_menu_open) return 0;
    int taskbar_y = (int)g_con->height - WM_TASKBAR_H;
    int menu_h = START_MENU_ITEMS * MENU_ITEM_H;
    int menu_y = taskbar_y - menu_h;
    if (x < 0 || x >= START_BTN_W + 60) return 0;
    if (y < menu_y || y >= taskbar_y) return 0;
    int item = (y - menu_y) / MENU_ITEM_H;
    if (item < 0 || item >= START_MENU_ITEMS) return 0;
    if (out_item_index) *out_item_index = item;
    return 1;
}

static void draw_text(int x, int y, const char *s, uint32_t color) {
    g_con->cursor_x = (uint32_t)x;
    g_con->cursor_y = (uint32_t)y;
    uint32_t saved = g_con->fg_color;
    g_con->fg_color = color;
    console_print(g_con, s);
    g_con->fg_color = saved;
}

static void draw_cursor(void) {
    uint32_t c = 0x00FFFFFF;
    for (int i = 0; i < 8; i++) {
        console_put_pixel(g_con, (uint32_t)(g_cursor_x + i), (uint32_t)(g_cursor_y + i), c);
        console_put_pixel(g_con, (uint32_t)(g_cursor_x + i), (uint32_t)(g_cursor_y), c);
        console_put_pixel(g_con, (uint32_t)(g_cursor_x), (uint32_t)(g_cursor_y + i), c);
    }
}

void wm_draw(void) {
    if (!g_con) return;
    console_fill_rect(g_con, 0, 0, g_con->width, g_con->height, DESKTOP_BG);

    for (int i = 0; i < g_window_count; i++) {
        wm_window_t *w = &g_windows[g_order[i]];
        if (!w->visible) continue;
        console_fill_rect(g_con, (uint32_t)w->x, (uint32_t)(w->y + WM_TITLEBAR_H),
                           (uint32_t)w->w, (uint32_t)w->h, w->color);
        console_fill_rect(g_con, (uint32_t)w->x, (uint32_t)w->y, (uint32_t)w->w, WM_TITLEBAR_H, 0x00404860);
        draw_text(w->x + 4, w->y + 5, w->title, 0x00FFFFFF);
    }

    int taskbar_y = (int)g_con->height - WM_TASKBAR_H;
    console_fill_rect(g_con, 0, (uint32_t)taskbar_y, g_con->width, WM_TASKBAR_H, TASKBAR_COLOR);
    console_fill_rect(g_con, 0, (uint32_t)taskbar_y, START_BTN_W, WM_TASKBAR_H, START_BTN_COLOR);
    draw_text(8, taskbar_y + 6, "START", 0x00FFFFFF);

    int tx = START_BTN_W + 10;
    for (int i = 0; i < g_window_count; i++) {
        wm_window_t *w = &g_windows[g_order[i]];
        if (!w->visible) continue;
        draw_text(tx, taskbar_y + 6, w->title, 0x00C0C0C0);
        tx += TASKBAR_LABEL_GAP;
    }

    if (g_start_menu_open) {
        int menu_h = START_MENU_ITEMS * MENU_ITEM_H;
        int menu_y = taskbar_y - menu_h;
        console_fill_rect(g_con, 0, (uint32_t)menu_y, START_BTN_W + 60, (uint32_t)menu_h, MENU_COLOR);
        for (int i = 0; i < START_MENU_ITEMS; i++) {
            draw_text(8, menu_y + i * MENU_ITEM_H + 6, START_MENU_LABELS[i], 0x00FFFFFF);
        }
    }

    draw_cursor();
}
