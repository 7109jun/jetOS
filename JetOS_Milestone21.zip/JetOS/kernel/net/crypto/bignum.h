#ifndef JETOS_BIGNUM_H
#define JETOS_BIGNUM_H

/*
 * JetOS - kernel/net/crypto/bignum.h
 * Milestone 19: TLS의 RSA 키 교환에 필요한 최소한의 임의정밀도
 * 정수 연산. "최소한"인 이유: 여기서는 서버 인증서의 RSA 공개키로
 * pre-master secret을 암호화하는 공개키 연산(c = m^e mod n, e는
 * 보통 65537이라 아주 작음)만 하면 되고, 개인키 연산(비밀지수로
 * 복호화/서명)은 클라이언트가 할 일이 없다. 그래서 division이나
 * CRT 최적화 없이 "modexp 하나"만 목표로 최소 구현했다.
 *
 * 표현: 32비트 리밈(limb) 배열, 리틀엔디안(limb[0]이 최하위),
 * 최대 BIGNUM_MAX_LIMBS개(4096비트 키까지 커버: 4096/32=128).
 */

#include <stdint.h>
#include <stddef.h>

#define BIGNUM_MAX_LIMBS 128 /* 4096비트 RSA까지 지원 */

typedef struct {
    uint32_t limb[BIGNUM_MAX_LIMBS];
    int nlimbs; /* 실제 사용중인(0이 아닌 최상위 리밈 다음) 개수, 0이면 값=0 */
} bignum_t;

void bn_from_bytes_be(bignum_t *r, const uint8_t *buf, size_t len); /* 빅엔디안 바이트열 -> bignum */
int  bn_to_bytes_be(const bignum_t *a, uint8_t *out, size_t outlen); /* bignum -> 정확히 outlen 바이트(빅엔디안, 0으로 좌측 패딩). 값이 넘치면 0 반환 */
void bn_from_u32(bignum_t *r, uint32_t v);
int  bn_is_zero(const bignum_t *a);
int  bn_cmp(const bignum_t *a, const bignum_t *b); /* a<b:-1 a==b:0 a>b:1 */

/* r = base^exp mod mod. r/base/mod가 같은 포인터여도 안전(내부 임시 사용). */
void bn_modexp(bignum_t *r, const bignum_t *base, const bignum_t *exp, const bignum_t *mod);

#endif
