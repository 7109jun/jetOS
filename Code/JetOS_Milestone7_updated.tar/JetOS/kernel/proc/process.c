#include "process.h"
#include "../mm/heap.h"

static uint32_t g_next_process_id = 1;

process_t *process_create(const char *name) {
    process_t *p = (process_t *)kmalloc(sizeof(process_t));
    if (!p) return NULL;
    p->id = g_next_process_id++;
    p->thread_count = 0;
    int i = 0;
    for (; i < PROCESS_NAME_MAX - 1 && name && name[i]; i++) p->name[i] = name[i];
    p->name[i] = '\0';
    for (i = 0; i < PROCESS_MAX_THREADS; i++) p->threads[i] = NULL;
    return p;
}

thread_t *process_spawn_thread(process_t *proc, const char *name,
                                void (*entry)(void *arg), void *arg) {
    if (!proc || proc->thread_count >= PROCESS_MAX_THREADS) return NULL;
    thread_t *t = thread_create(name, entry, arg);
    if (!t) return NULL;
    proc->threads[proc->thread_count++] = t;
    return t;
}
