#ifndef JETOS_MSVCRT_COMPAT_H
#define JETOS_MSVCRT_COMPAT_H

/*
 * JetOS - kernel/compat/msvcrt.h (Milestone 50)
 *
 * win32.h가 KERNEL32.dll 표면을 흉내내는 것과 같은 정신으로, mingw가
 * "평범하게"(-nostdlib 없이, 진짜 CRT로) 컴파일한 EXE가 임포트하는
 * msvcrt.dll 함수들을 흉내낸다. Microsoft의 진짜 msvcrt.dll이나 mingw의
 * CRT 소스를 가져다 쓰지 않고, 필요한 함수들을 이름과 관찰된 동작만
 * 보고 처음부터 다시 구현했다 — win32.h 헤더 주석의 "Wine과 같은 접근"
 * 그대로다.
 *
 * 핵심 통찰: __iob_func()가 돌려주는 FILE*는 진짜 Windows _iobuf 구조체와
 * 바이트 단위로 같을 필요가 없다. mingw가 정적으로 링크해 넣는 printf()
 * 자신의 코드는 그 포인터를 그냥 "값"으로만 다루다가 vfprintf에
 * 넘기는데, vfprintf도 우리가 구현하므로 우리가 돌려준 포인터를 우리가
 * "이건 stdout이다/stderr다"로 알아만 보면 충분하다 — 실제 필드 레이아웃은
 * 전혀 안 건드린다(포인터 값 비교만). 이 덕분에 진짜 Windows 구조체를
 * 리버스 엔지니어링할 필요가 없었다.
 */

#include <stdint.h>
#include <stdarg.h>
#include "win32.h"

/* 실제 필드는 절대 안 읽는다(위 주석 참고) — 크기는 실기 테스트로
 * 맞춘 값이다: 32바이트(진짜 Windows 레거시 _iobuf 크기)로 시작했더니
 * 이 mingw 툴체인이 만든 코드가 실제로 쓰는 인덱스 간격은 48바이트였다
 * (fputc에 넘어온 stream 포인터를 시리얼로 직접 찍어서 비교 확인) —
 * 그래서 48로 맞춤. */
typedef struct { uint8_t _opaque[48]; } jetos_FILE;

void msvcrt_init(void); /* g_iob 3개(stdin/stdout/stderr) 초기화 */

WINAPI jetos_FILE *__iob_func(int index);
WINAPI int __getmainargs(int *argc, char ***argv, char ***envp,
                          int do_wildcard, void *startinfo);
/* Milestone 50: __initenv는 실제로는 "함수"가 아니라 msvcrt.dll이
 * export하는 데이터 심볼(char** 변수 그 자체)이다 — IAT 슬롯에는 이
 * 변수의 "주소"가 들어가야 하고, exe는 그 주소를 역참조해서 값을
 * 읽는다. pe_loader.c가 이 이름을 함수 스텁이 아니라
 * &g_win32_initenv(변수 주소)로 연결한다(아래 msvcrt.c 참고). */
extern char **g_win32_initenv;
WINAPI int __set_app_type(int type);
WINAPI int __setusermatherr(void *handler);
WINAPI int *___mb_cur_max_func(void);
WINAPI unsigned int *___lc_codepage_func(void);

WINAPI void _amsg_exit(int code);
WINAPI void _cexit(void);
WINAPI int *_commode(void);
WINAPI int *_errno(void);
WINAPI int *_fmode(void);
WINAPI void _initterm(void **begin, void **end);
WINAPI void _lock(int locknum);
WINAPI void _unlock(int locknum);
WINAPI void *_onexit(void *fn);

WINAPI void abort(void) __attribute__((noreturn));
WINAPI void exit(int code) __attribute__((noreturn));
WINAPI void *calloc(uint32_t count, uint32_t size);
WINAPI void *malloc(uint32_t size);
WINAPI void free(void *p);
WINAPI void *msvcrt_memcpy(void *dst, const void *src, uint32_t n);
WINAPI void *msvcrt_memset(void *dst, int val, uint32_t n);
WINAPI uint32_t strlen(const char *s);
WINAPI int strncmp(const char *a, const char *b, uint32_t n);
WINAPI char *strerror(int err);
WINAPI uint32_t wcslen(const uint16_t *s);
WINAPI void *signal(int sig, void *handler);
WINAPI void *localeconv(void);

WINAPI int fputc(int c, jetos_FILE *stream);
WINAPI uint32_t fwrite(const void *ptr, uint32_t size, uint32_t count, jetos_FILE *stream);
WINAPI int fprintf(jetos_FILE *stream, const char *fmt, ...);
WINAPI int vfprintf(jetos_FILE *stream, const char *fmt, va_list args);

/* Milestone 51: 진짜 파일 스트림(fopen/fread/fclose 등). 콘솔 스트림
 * (g_iob[0..2])과 구분하는 방법은 msvcrt.c의 is_console_file() 참고 —
 * fopen이 리턴하는 포인터는 g_iob 배열 범위 밖의 별도 kmalloc 블록이라
 * 포인터 비교만으로 확실히 구분된다. 항상 파일 전체를 메모리에 올려
 * 놓고 다루는 구현이다(jetfs_read/jetfs_write 자체가 스트리밍이 아니라
 * "한 번에 통째로" API라 — jetfs.h 주석 참고) — 그래서 겁나게 큰
 * 파일에는 안 맞지만(정직한 한계), 설정 파일/작은 텍스트 파일을 열고
 * 읽고 쓰는 절대다수의 "평범한 프로그램" 용도에는 충분하다. */
WINAPI jetos_FILE *fopen(LPCSTR path, LPCSTR mode);
WINAPI int fclose(jetos_FILE *stream);
WINAPI uint32_t fread(void *ptr, uint32_t size, uint32_t count, jetos_FILE *stream);
WINAPI int feof(jetos_FILE *stream);
WINAPI char *fgets(char *buf, int n, jetos_FILE *stream);
WINAPI int fputs(const char *s, jetos_FILE *stream);
WINAPI int fflush(jetos_FILE *stream);

/* SEH(구조적 예외 처리) 진입점 — 실제로 풀어내지 않는다(정직한 한계,
 * 아래 msvcrt.c 주석 참고). 크래시 없는 직선 실행 경로에서는 호출조차
 * 안 되는 경우가 대부분이라 이 정도로 충분히 많은 프로그램을 돌릴 수
 * 있다. */
WINAPI void *__C_specific_handler(void);

/* KERNEL32 쪽 CRT 초기화가 흔히 같이 쓰는 것들(win32.h로 옮기기엔
 * msvcrt 쪽 CRT 흐름 전용이라 여기 둠). */
WINAPI void InitializeCriticalSection(void *cs);
WINAPI void EnterCriticalSection(void *cs);
WINAPI void LeaveCriticalSection(void *cs);
WINAPI void DeleteCriticalSection(void *cs);
WINAPI void *TlsGetValue(DWORD index);
WINAPI BOOL VirtualProtect(LPVOID addr, uint32_t size, DWORD new_protect, DWORD *old_protect);
WINAPI uint32_t VirtualQuery(LPCVOID addr, void *info, uint32_t len);
WINAPI void *SetUnhandledExceptionFilter(void *filter);
WINAPI int MultiByteToWideChar(int codepage, DWORD flags, LPCSTR src, int src_len,
                                uint16_t *dst, int dst_len);
WINAPI int WideCharToMultiByte(int codepage, DWORD flags, const uint16_t *src, int src_len,
                                char *dst, int dst_len, LPCSTR default_char, BOOL *used_default);
WINAPI BOOL IsDBCSLeadByteEx(int codepage, uint8_t test_char);

#endif
