kernel/net/crypto/aes128.o: kernel/net/crypto/aes128.c \
 kernel/net/crypto/aes128.h
kernel/net/crypto/aes128.h:
