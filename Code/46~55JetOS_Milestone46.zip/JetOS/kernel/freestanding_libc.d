kernel/freestanding_libc.o: kernel/freestanding_libc.c
