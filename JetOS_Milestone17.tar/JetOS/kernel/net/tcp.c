/*
 * JetOS - kernel/net/tcp.c
 * 최소 TCP 클라이언트. tcp.h의 알려진 단순화 목록 참고.
 */
#include "tcp.h"
#include "net.h"
#include "../int/pit.h"
#include "../proc/scheduler.h"
#include <stddef.h>

#pragma pack(push, 1)
typedef struct {
    uint16_t src_port;
    uint16_t dst_port;
    uint32_t seq;
    uint32_t ack;
    uint16_t offset_flags; /* 상위 4비트=데이터 오프셋(32비트 워드), 하위 6비트=플래그 */
    uint16_t window;
    uint16_t checksum;
    uint16_t urgent_ptr;
} tcp_header_t;
#pragma pack(pop)

#define TCP_FLAG_FIN 0x01
#define TCP_FLAG_SYN 0x02
#define TCP_FLAG_RST 0x04
#define TCP_FLAG_PSH 0x08
#define TCP_FLAG_ACK 0x10
#define TCP_FLAG_URG 0x20

static uint16_t t_htons(uint16_t v) { return (uint16_t)((v << 8) | (v >> 8)); }
#define t_ntohs t_htons

typedef enum {
    TCP_CLOSED = 0,
    TCP_SYN_SENT,
    TCP_ESTABLISHED,
    TCP_FIN_WAIT,
    TCP_CLOSE_WAIT_LOCAL /* 상대가 FIN을 보냈고, 우리도 FIN을 보내는 중 */
} tcp_state_t;

static tcp_state_t g_state = TCP_CLOSED;
static uint32_t g_remote_ip = 0;
static uint16_t g_remote_port = 0;
static uint16_t g_local_port = 0;
static uint32_t g_snd_nxt = 0; /* 다음에 보낼 시퀀스 번호 */
static uint32_t g_rcv_nxt = 0; /* 다음에 기대하는 상대측 시퀀스 번호 */
static volatile int g_syn_ack_received = 0;
static volatile int g_last_ack_matched = 0; /* 마지막으로 기다리던 ACK가 왔는지 */
static uint32_t g_wait_for_ack_of = 0;       /* tcp_send가 기다리는 snd_nxt 값 */
static volatile int g_fin_received = 0;
static volatile int g_rst_received = 0;

/* 수신 데이터는 tcp_recv_until_close()가 호출되기 "전"부터도 도착할 수
 * 있다(예: HTTP 서버가 우리 GET을 ACK하자마자 응답을 바로 보내는 경우,
 * tcp_send()가 자신의 ACK을 기다리는 사이에 이미 도착해버릴 수 있다).
 * 그래서 수신 버퍼는 tcp_recv_until_close() 호출 여부와 무관하게
 * ESTABLISHED 상태가 되는 순간부터 항상 켜져 있는 내부 누적 버퍼로
 * 구현한다 — "호출 시점에만 받는 버퍼"였을 때는 그 틈에 도착한
 * 데이터가 seq만 소비되고(ACK되고) 실제 바이트는 유실되는 버그가 있었다. */
#define TCP_INTERNAL_RX_CAP 16384
static uint8_t g_internal_rx[TCP_INTERNAL_RX_CAP];
static uint32_t g_internal_rx_len = 0;   /* 누적된 바이트 수 */
static uint32_t g_internal_rx_read = 0;  /* tcp_recv_until_close()가 이미 꺼내간 바이트 수 */

static uint16_t tcp_checksum(uint32_t src_ip, uint32_t dst_ip, const void *tcp_seg, uint32_t seg_len) {
    /* 유사헤더(pseudo header) 12바이트 + 실제 세그먼트를 이어붙여 계산.
     * 스택에 작은 버퍼를 잡아 처리한다(세그먼트가 크지 않으므로 충분). */
    uint8_t buf[12 + 1480];
    if (seg_len > 1480) return 0; /* 우리 세그먼트는 항상 이보다 작음 */

    buf[0] = (uint8_t)(src_ip >> 24); buf[1] = (uint8_t)(src_ip >> 16);
    buf[2] = (uint8_t)(src_ip >> 8);  buf[3] = (uint8_t)src_ip;
    buf[4] = (uint8_t)(dst_ip >> 24); buf[5] = (uint8_t)(dst_ip >> 16);
    buf[6] = (uint8_t)(dst_ip >> 8);  buf[7] = (uint8_t)dst_ip;
    buf[8] = 0;
    buf[9] = 6; /* TCP */
    buf[10] = (uint8_t)(seg_len >> 8);
    buf[11] = (uint8_t)seg_len;

    const uint8_t *src = (const uint8_t *)tcp_seg;
    for (uint32_t i = 0; i < seg_len; i++) buf[12 + i] = src[i];

    uint32_t total = 12 + seg_len;
    uint32_t len = total;
    const uint8_t *p = buf;
    uint32_t sum = 0;
    while (len > 1) { sum += (uint32_t)((p[0] << 8) | p[1]); p += 2; len -= 2; }
    if (len == 1) sum += (uint32_t)(p[0] << 8);
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    return (uint16_t)~sum;
}

static int send_segment(uint8_t flags, uint32_t seq, uint32_t ack,
                         const void *payload, uint32_t payload_len, int with_mss_option) {
    uint8_t seg[20 + 4 + 1460];
    uint32_t hdr_len = with_mss_option ? 24 : 20;
    if (hdr_len + payload_len > sizeof(seg)) return 0;

    tcp_header_t *tcp = (tcp_header_t *)seg;
    tcp->src_port = t_htons(g_local_port);
    tcp->dst_port = t_htons(g_remote_port);
    tcp->seq = ((seq & 0xFF) << 24) | ((seq & 0xFF00) << 8) | ((seq & 0xFF0000) >> 8) | ((seq >> 24) & 0xFF);
    tcp->ack = ((ack & 0xFF) << 24) | ((ack & 0xFF00) << 8) | ((ack & 0xFF0000) >> 8) | ((ack >> 24) & 0xFF);
    uint16_t doff_flags = (uint16_t)(((hdr_len / 4) << 12) | flags);
    tcp->offset_flags = t_htons(doff_flags);
    tcp->window = t_htons(8192);
    tcp->checksum = 0;
    tcp->urgent_ptr = 0;

    if (with_mss_option) {
        uint8_t *opt = seg + 20;
        opt[0] = 2;    /* kind = MSS */
        opt[1] = 4;    /* option length */
        opt[2] = (1460 >> 8) & 0xFF;
        opt[3] = 1460 & 0xFF;
    }

    uint8_t *data = seg + hdr_len;
    const uint8_t *src = (const uint8_t *)payload;
    for (uint32_t i = 0; i < payload_len; i++) data[i] = src[i];

    uint32_t seg_len = hdr_len + payload_len;
    tcp->checksum = t_htons(tcp_checksum(NET_MY_IP, g_remote_ip, seg, seg_len));

    return net_ip_send(g_remote_ip, 6 /* IP_PROTO_TCP */, seg, seg_len);
}

static uint32_t rd_seq(const uint8_t *be4) {
    return ((uint32_t)be4[0] << 24) | ((uint32_t)be4[1] << 16) | ((uint32_t)be4[2] << 8) | be4[3];
}

static int is_all_zero(const uint8_t *p, uint32_t n) {
    for (uint32_t i = 0; i < n; i++) if (p[i] != 0) return 0;
    return 1;
}

void tcp_on_ip_packet(uint32_t src_ip, const uint8_t *payload, uint32_t len) {
    if (g_state == TCP_CLOSED) return;
    if (len < sizeof(tcp_header_t)) return;
    const tcp_header_t *tcp = (const tcp_header_t *)payload;

    uint16_t src_port = t_ntohs(tcp->src_port);
    uint16_t dst_port = t_ntohs(tcp->dst_port);
    if (src_ip != g_remote_ip || src_port != g_remote_port || dst_port != g_local_port) return;

    uint16_t offset_flags = t_ntohs(tcp->offset_flags);
    uint8_t flags = (uint8_t)(offset_flags & 0x3F);
    uint32_t hdr_len = ((offset_flags >> 12) & 0xF) * 4;
    if (hdr_len < sizeof(tcp_header_t) || hdr_len > len) return;

    uint32_t seq = rd_seq((const uint8_t *)&tcp->seq);
    uint32_t ack = rd_seq((const uint8_t *)&tcp->ack);
    uint32_t data_len = len - hdr_len;
    const uint8_t *data = payload + hdr_len;

    if (flags & TCP_FLAG_RST) { g_rst_received = 1; return; }

    if (g_state == TCP_SYN_SENT) {
        if ((flags & TCP_FLAG_SYN) && (flags & TCP_FLAG_ACK)) {
            g_rcv_nxt = seq + 1;
            g_syn_ack_received = 1;
            (void)ack;
        }
        return;
    }

    /* ESTABLISHED / FIN_WAIT / CLOSE_WAIT_LOCAL 공통: 순서대로 온
     * 데이터만 받아들인다. 완전한 재조립 큐는 없지만(tcp.h 참고),
     * "이미 받은 부분과 겹치는 재전송"만큼은 처리한다 — seq가 우리가
     * 기대하는 지점보다 앞이더라도 그 세그먼트의 끝이 기대 지점을
     * 넘어선다면, 이미 받은 앞부분만 잘라내고 새로운 뒷부분은
     * 받아들인다. (완전히 미래의 데이터라 순서가 어긋난 경우는
     * 여전히 버린다.) */
    if (data_len > 0) {
        uint32_t use_seq = seq;
        const uint8_t *use_data = data;
        uint32_t use_len = data_len;
        if (seq != g_rcv_nxt && seq < g_rcv_nxt && (seq + data_len) > g_rcv_nxt) {
            uint32_t skip = g_rcv_nxt - seq;
            use_seq = g_rcv_nxt;
            use_data = data + skip;
            use_len = data_len - skip;
        }
        if (use_seq == g_rcv_nxt) {
            /* 실측 결과, 짧은(≤8바이트) 전부 0인 "데이터" 세그먼트가
             * 매번 rcv_nxt와 정확히 일치하는 seq로 반복 관측되었다 —
             * 실제 애플리케이션 데이터라기엔 내용이 항상 0이라는 점이
             * 부자연스럽다(HTTP 응답 텍스트가 이렇게 시작할 리 없음).
             * RTL8139 링버퍼 경계 처리의 잔재로 보이는 이런 스퓨리어스
             * 세그먼트는 실제 데이터로 받아들이지 않고 조용히 무시한다
             * (ACK도 보내지 않음 — 상대는 이미 보낸 것으로 알고 있는
             * 시퀀스 구간이므로 별도 ACK가 없어도 재전송/타임아웃으로
             * 자연히 정리된다). */
            if (use_len <= 8 && is_all_zero(use_data, use_len)) {
                /* 무시 */
            } else {
                uint32_t space = TCP_INTERNAL_RX_CAP - g_internal_rx_len;
                uint32_t n = use_len < space ? use_len : space;
                for (uint32_t i = 0; i < n; i++) g_internal_rx[g_internal_rx_len + i] = use_data[i];
                g_internal_rx_len += n;
                g_rcv_nxt += use_len;
                /* 데이터를 받았다는 걸 즉시 ACK (지연 ACK 없음 — 단순화) */
                send_segment(TCP_FLAG_ACK, g_snd_nxt, g_rcv_nxt, NULL, 0, 0);
            }
        }
    }

    if (flags & TCP_FLAG_FIN) {
        /* FIN도 시퀀스 번호를 1 소비한다 */
        if (seq + data_len == g_rcv_nxt || data_len == 0) {
            g_rcv_nxt = (seq == g_rcv_nxt) ? g_rcv_nxt + 1 : g_rcv_nxt;
            g_fin_received = 1;
            send_segment(TCP_FLAG_ACK, g_snd_nxt, g_rcv_nxt, NULL, 0, 0);
        }
    }

    if ((flags & TCP_FLAG_ACK) && ack == g_wait_for_ack_of) {
        g_last_ack_matched = 1;
    }
}

int tcp_connect(uint32_t dst_ip, uint16_t dst_port, uint32_t timeout_ticks) {
    static uint16_t ephemeral = 49152;
    g_remote_ip = dst_ip;
    g_remote_port = dst_port;
    g_local_port = ephemeral++;
    if (ephemeral == 0) ephemeral = 49152;

    uint32_t isn = (uint32_t)(g_timer_ticks * 2654435761u + 12345u);
    g_snd_nxt = isn;
    g_syn_ack_received = 0;
    g_fin_received = 0;
    g_rst_received = 0;
    g_internal_rx_len = 0; g_internal_rx_read = 0;
    g_state = TCP_SYN_SENT;

    send_segment(TCP_FLAG_SYN, g_snd_nxt, 0, NULL, 0, 1 /* MSS 옵션 포함 */);
    g_snd_nxt += 1; /* SYN은 시퀀스 1을 소비 */

    uint64_t deadline = g_timer_ticks + timeout_ticks;
    uint64_t last_retry = g_timer_ticks;
    while (g_timer_ticks < deadline) {
        net_poll();
        if (g_rst_received) { g_state = TCP_CLOSED; return 0; }
        if (g_syn_ack_received) {
            send_segment(TCP_FLAG_ACK, g_snd_nxt, g_rcv_nxt, NULL, 0, 0);
            g_state = TCP_ESTABLISHED;
            return 1;
        }
        if (g_timer_ticks - last_retry >= 20) { /* 200ms마다 SYN 재전송 */
            send_segment(TCP_FLAG_SYN, isn, 0, NULL, 0, 1);
            last_retry = g_timer_ticks;
        }
        scheduler_yield();
    }
    g_state = TCP_CLOSED;
    return 0;
}

int tcp_send(const void *data, uint32_t len, uint32_t timeout_ticks) {
    if (g_state != TCP_ESTABLISHED && g_state != TCP_CLOSE_WAIT_LOCAL) return 0;

    const uint8_t *p = (const uint8_t *)data;
    uint32_t sent = 0;
    while (sent < len) {
        uint32_t chunk = len - sent;
        if (chunk > 1400) chunk = 1400; /* 보수적인 세그먼트 크기 */

        g_wait_for_ack_of = g_snd_nxt + chunk;
        g_last_ack_matched = 0;
        if (!send_segment(TCP_FLAG_ACK | TCP_FLAG_PSH, g_snd_nxt, g_rcv_nxt, p + sent, chunk, 0)) return 0;

        uint64_t deadline = g_timer_ticks + timeout_ticks;
        while (g_timer_ticks < deadline && !g_last_ack_matched) {
            net_poll();
            if (g_rst_received) return 0;
            scheduler_yield();
        }
        if (!g_last_ack_matched) return 0; /* 타임아웃 — 재전송 없이 실패 처리(단순화) */

        g_snd_nxt += chunk;
        sent += chunk;
    }
    return 1;
}

uint32_t tcp_recv_until_close(void *buf, uint32_t buf_size, uint32_t timeout_ticks) {
    if (g_state != TCP_ESTABLISHED) return 0;

    /* g_internal_rx는 ESTABLISHED가 된 순간부터 이미 채워지고 있었을 수
     * 있으므로(HTTP 응답이 우리가 이 함수를 부르기도 전에 도착했을 수
     * 있음), 여기서는 그냥 "버퍼가 다 찼거나, FIN/RST를 받았거나,
     * 타임아웃될 때까지" 기다렸다가 지금까지 쌓인 걸 통째로 복사해
     * 돌려주면 된다. */
    uint64_t deadline = g_timer_ticks + timeout_ticks;
    while ((g_internal_rx_len - g_internal_rx_read) < buf_size &&
           !g_fin_received && !g_rst_received && g_timer_ticks < deadline) {
        net_poll();
        scheduler_yield();
    }

    uint32_t available = g_internal_rx_len - g_internal_rx_read;
    uint32_t n = available < buf_size ? available : buf_size;
    uint8_t *dst = (uint8_t *)buf;
    for (uint32_t i = 0; i < n; i++) dst[i] = g_internal_rx[g_internal_rx_read + i];
    g_internal_rx_read += n;
    return n;
}

void tcp_close(void) {
    if (g_state == TCP_CLOSED) return;

    send_segment(TCP_FLAG_FIN | TCP_FLAG_ACK, g_snd_nxt, g_rcv_nxt, NULL, 0, 0);
    g_wait_for_ack_of = g_snd_nxt + 1;
    g_last_ack_matched = 0;

    uint64_t deadline = g_timer_ticks + 100; /* 최대 1초만 대기, 안 되면 그냥 닫음 */
    while (g_timer_ticks < deadline && !g_last_ack_matched) {
        net_poll();
        scheduler_yield();
    }

    g_state = TCP_CLOSED;
}
