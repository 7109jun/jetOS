/*
 * JetOS - kernel/int/exceptions.c
 *
 * 모든 예외 핸들러는 GCC의 x86 `interrupt` 함수 속성으로 작성된 순수
 * C 함수다. 이 속성을 사용하면 컴파일러가 인터럽트 진입/복귀에 필요한
 * 레지스터 저장/복원과 iretq 를 자동으로 생성해 주므로, 핸들러 코드 자체는
 * 단 한 줄의 인라인 어셈블리도 필요로 하지 않는다.
 */

#include "exceptions.h"
#include "../panic.h"
#include "../hal/x86_asm_shim.h"
#include "pic.h"
#include "pit.h"
#include "../proc/scheduler.h"
#include "../proc/thread.h"
#include "../drivers/keyboard.h"
#include "../drivers/mouse.h"
#include "../drivers/serial.h"

/* Milestone 16: 유저 모드(Ring3) 프로세스 오류 격리.
 *
 * 지금까지는 어떤 예외든 무조건 jetos_panic()으로 시스템 전체를
 * 멈췄다 — 커널 자신의 버그라면 맞는 대응이지만, 유저 프로세스가
 * NULL 포인터를 역참조하거나 0으로 나누는 것까지 커널 전체가 멎어야
 * 할 이유는 없다. 리눅스가 그런 경우 해당 프로세스에게만 SIGSEGV/
 * SIGFPE를 보내고 나머지 시스템은 계속 돌아가는 것과 같은 개념으로,
 * 예외 발생 시점의 CS 레지스터 하위 2비트(RPL)를 보고 판단한다:
 * RPL==3이면 Ring3(유저 모드)에서 난 것이므로 그 스레드만
 * thread_exit()으로 끝내고, RPL==0(커널 자신의 버그)이면 여전히
 * jetos_panic()으로 전체를 세운다 — 커널 버그를 조용히 넘기는 건
 * 더 위험하기 때문이다. */
static void handle_fault_or_panic(const char *name, unsigned long long error_code,
                                   uint64_t fault_addr, struct interrupt_frame *frame) {
    if ((frame->cs & 3) == 3) {
        thread_t *t = scheduler_current();
        serial_write("\n[USER FAULT] ");
        serial_write(name);
        serial_write(" in thread '");
        serial_write(t ? t->name : "?");
        serial_write("' -> terminating this process only (kernel continues)\n");
        serial_write("  error_code="); serial_write_hex64(error_code);
        serial_write(" fault_addr="); serial_write_hex64(fault_addr);
        serial_write(" rip="); serial_write_hex64(frame->ip);
        serial_write("\n");
        thread_exit(); /* 돌아오지 않음 — scheduler_exit_current()가 다음 스레드로 전환 */
    }
    jetos_panic(name, error_code, fault_addr);
}

__attribute__((interrupt))
void isr_divide_by_zero(struct interrupt_frame *frame) {
    handle_fault_or_panic("DIVIDE BY ZERO", 0, frame->ip, frame);
}

__attribute__((interrupt))
void isr_breakpoint(struct interrupt_frame *frame) {
    /* 브레이크포인트는 치명적이지 않다: Milestone 1에서는 로그만 남기고
     * 다음 명령으로 복귀한다 (디버거 지원은 이후 마일스톤 과제). */
    (void)frame;
}

__attribute__((interrupt))
void isr_invalid_opcode(struct interrupt_frame *frame) {
    handle_fault_or_panic("INVALID OPCODE", 0, frame->ip, frame);
}

__attribute__((interrupt))
void isr_double_fault(struct interrupt_frame *frame, unsigned long long error_code) {
    /* 더블 폴트는 "예외 처리 중 또 예외가 난" 상황 — 스택 자체가 이미
     * 망가졌을 가능성이 높으므로 유저/커널 구분 없이 항상 패닉한다. */
    jetos_panic("DOUBLE FAULT", error_code, frame->ip);
}

__attribute__((interrupt))
void isr_general_protection(struct interrupt_frame *frame, unsigned long long error_code) {
    handle_fault_or_panic("GENERAL PROTECTION FAULT", error_code, frame->ip, frame);
}

__attribute__((interrupt))
void isr_page_fault(struct interrupt_frame *frame, unsigned long long error_code) {
    handle_fault_or_panic("PAGE FAULT", error_code, hal_read_cr2(), frame);
}

__attribute__((interrupt))
void isr_default_handler(struct interrupt_frame *frame) {
    /* 정의되지 않은 벡터: Milestone 1에서는 무시하고 복귀한다. */
    (void)frame;
}

__attribute__((interrupt))
void isr_timer(struct interrupt_frame *frame) {
    (void)frame;
    g_timer_ticks++;
    /* EOI는 반드시 스케줄러 전환(스택 교체) 이전에 보내야 한다. 그렇지
     * 않으면 이 스레드가 다시 스케줄될 때까지 PIC의 IRQ0 in-service
     * 비트가 해제되지 않아 이후의 모든 타이머 인터럽트가 막혀버린다
     * (교착 상태). */
    pic_send_eoi(0);
    scheduler_tick_from_isr();
}

__attribute__((interrupt))
void isr_keyboard(struct interrupt_frame *frame) {
    (void)frame;
    keyboard_irq_handler();
    pic_send_eoi(1);
}

__attribute__((interrupt))
void isr_mouse(struct interrupt_frame *frame) {
    (void)frame;
    mouse_irq_handler();
    pic_send_eoi(12);
}
