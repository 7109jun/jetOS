#ifndef JETOS_CONSOLE_H
#define JETOS_CONSOLE_H

#include <stdint.h>

typedef struct {
    uint32_t *fb;          /* framebuffer 시작 주소 (32bpp) */
    uint32_t width;
    uint32_t height;
    uint32_t pixels_per_scanline;
    uint32_t cursor_x;
    uint32_t cursor_y;
    uint32_t fg_color;
    uint32_t bg_color;
} console_t;

void console_init(console_t *con, uint32_t *fb, uint32_t width, uint32_t height, uint32_t pps);
void console_clear(console_t *con, uint32_t color);
void console_put_pixel(console_t *con, uint32_t x, uint32_t y, uint32_t color);
void console_fill_rect(console_t *con, uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint32_t color);
void console_putc(console_t *con, char c);
void console_print(console_t *con, const char *s);

#endif
