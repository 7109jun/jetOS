/*
 * JetOS - kernel/drivers/ahci.c
 *
 * 최소 폴링(polling) 방식 AHCI 드라이버. 여러 SATA 드라이브(포트)를
 * 지원하며, 각 포트마다 독립된 커맨드 리스트/FIS/커맨드 테이블을
 * 가진다. 각 포트는 커맨드 슬롯 0번만 사용해 한 번에 하나의 요청만
 * 처리한다 (동시성 없음 — 인터럽트 기반 큐잉은 향후 마일스톤 과제).
 *
 * 모든 HBA/포트 레지스터 접근은 PCI BAR5(ABAR)로 매핑된 MMIO 영역에
 * 대한 일반 포인터 읽기/쓰기이므로 순수 C다. PCI 설정공간 탐색에만
 * (pci.c에서) 포트 I/O를 사용한다.
 */

#include "ahci.h"
#include "pci.h"
#include "../mm/pmm.h"

typedef volatile struct {
    uint32_t clb, clbu;
    uint32_t fb, fbu;
    uint32_t is, ie;
    uint32_t cmd;
    uint32_t rsv0;
    uint32_t tfd;
    uint32_t sig;
    uint32_t ssts, sctl, serr, sact;
    uint32_t ci;
    uint32_t sntf;
    uint32_t fbs;
    uint32_t rsv1[11];
    uint32_t vendor[4];
} hba_port_t;

typedef volatile struct {
    uint32_t cap, ghc, is, pi, vs, ccc_ctl, ccc_pts, em_loc, em_ctl, cap2, bohc;
    uint8_t  rsv[0xA0 - 0x2C];
    uint8_t  vendor[0x100 - 0xA0];
    hba_port_t ports[32];
} hba_mem_t;

typedef struct {
    uint32_t dw0;
    uint32_t prdbc;
    uint32_t ctba, ctbau;
    uint32_t rsv[4];
} hba_cmd_header_t;

typedef struct {
    uint32_t dba, dbau, rsv0, dbc_flags;
} hba_prdt_entry_t;

typedef struct {
    uint8_t cfis[64];
    uint8_t acmd[16];
    uint8_t rsv[48];
    hba_prdt_entry_t prdt[1];
} hba_cmd_table_t;

#define HBA_PORT_CMD_ST   0x0001
#define HBA_PORT_CMD_FRE  0x0010
#define HBA_PORT_CMD_FR   0x4000
#define HBA_PORT_CMD_CR   0x8000

#define HBA_PORT_DET_PRESENT 3
#define HBA_PORT_IPM_ACTIVE  1

#define SATA_SIG_ATA   0x00000101

#define ATA_CMD_READ_DMA_EXT  0x25
#define ATA_CMD_WRITE_DMA_EXT 0x35
#define FIS_TYPE_REG_H2D 0x27

typedef struct {
    hba_port_t *port;
    hba_cmd_header_t *cmdlist;
    hba_cmd_table_t *cmdtable;
} ahci_drive_t;

static hba_mem_t *g_hba = NULL;
static ahci_drive_t g_drives[AHCI_MAX_DRIVES];
static int g_drive_count = 0;

static void zero_page(void *p) {
    uint8_t *b = (uint8_t *)p;
    for (uint32_t i = 0; i < 4096; i++) b[i] = 0;
}

static void port_stop(hba_port_t *p) {
    p->cmd &= ~HBA_PORT_CMD_ST;
    p->cmd &= ~HBA_PORT_CMD_FRE;
    for (volatile int i = 0; i < 1000000; i++) {
        if (!(p->cmd & (HBA_PORT_CMD_FR | HBA_PORT_CMD_CR))) break;
    }
}

static void port_start(hba_port_t *p) {
    for (volatile int i = 0; i < 1000000; i++) {
        if (!(p->cmd & HBA_PORT_CMD_CR)) break;
    }
    p->cmd |= HBA_PORT_CMD_FRE;
    p->cmd |= HBA_PORT_CMD_ST;
}

int ahci_init(void) {
    pci_device_t dev;
    if (!pci_find_ahci_controller(&dev)) return 0;

    uint64_t abar = dev.bar[5] & 0xFFFFFFF0u;
    if (abar == 0) return 0;
    g_hba = (hba_mem_t *)abar;
    g_hba->ghc |= (1u << 31); /* GHC.AE */

    g_drive_count = 0;
    for (int i = 0; i < 32 && g_drive_count < AHCI_MAX_DRIVES; i++) {
        if (!(g_hba->pi & (1u << i))) continue;
        hba_port_t *p = &g_hba->ports[i];
        uint32_t ssts = p->ssts;
        uint8_t det = ssts & 0x0F;
        uint8_t ipm = (ssts >> 8) & 0x0F;
        if (det != HBA_PORT_DET_PRESENT || ipm != HBA_PORT_IPM_ACTIVE) continue;
        if (p->sig != SATA_SIG_ATA) continue; /* ATAPI(광학드라이브) 제외 */

        port_stop(p);

        uint64_t cmdlist_phys  = pmm_alloc_page();
        uint64_t fis_phys      = pmm_alloc_page();
        uint64_t cmdtable_phys = pmm_alloc_page();
        if (!cmdlist_phys || !fis_phys || !cmdtable_phys) continue;

        zero_page((void *)cmdlist_phys);
        zero_page((void *)fis_phys);
        zero_page((void *)cmdtable_phys);

        p->clb  = (uint32_t)(cmdlist_phys & 0xFFFFFFFF);
        p->clbu = (uint32_t)(cmdlist_phys >> 32);
        p->fb   = (uint32_t)(fis_phys & 0xFFFFFFFF);
        p->fbu  = (uint32_t)(fis_phys >> 32);

        hba_cmd_header_t *cmdlist = (hba_cmd_header_t *)cmdlist_phys;
        cmdlist[0].ctba  = (uint32_t)(cmdtable_phys & 0xFFFFFFFF);
        cmdlist[0].ctbau = (uint32_t)(cmdtable_phys >> 32);

        p->serr = 0xFFFFFFFF;
        p->is   = 0xFFFFFFFF;

        port_start(p);

        g_drives[g_drive_count].port = p;
        g_drives[g_drive_count].cmdlist = cmdlist;
        g_drives[g_drive_count].cmdtable = (hba_cmd_table_t *)cmdtable_phys;
        g_drive_count++;
    }

    return g_drive_count;
}

int ahci_drive_count(void) {
    return g_drive_count;
}

static int ahci_do_io(ahci_drive_t *d, uint64_t lba, uint32_t count, void *buffer, int is_write) {
    hba_port_t *port = d->port;

    for (volatile int i = 0; i < 1000000; i++) {
        if (!(port->tfd & 0x88)) break;
    }
    port->is = 0xFFFFFFFF;

    hba_cmd_header_t *cmd = &d->cmdlist[0];
    cmd->dw0 = 5 | (is_write ? (1u << 6) : 0) | (1u << 16);
    cmd->prdbc = 0;

    hba_cmd_table_t *tbl = d->cmdtable;
    for (int i = 0; i < 64; i++) tbl->cfis[i] = 0;

    tbl->prdt[0].dba  = (uint32_t)((uint64_t)(uintptr_t)buffer & 0xFFFFFFFF);
    tbl->prdt[0].dbau = (uint32_t)((uint64_t)(uintptr_t)buffer >> 32);
    tbl->prdt[0].dbc_flags = (count * AHCI_SECTOR_SIZE) - 1;

    uint8_t *fis = tbl->cfis;
    fis[0] = FIS_TYPE_REG_H2D;
    fis[1] = 0x80;
    fis[2] = is_write ? ATA_CMD_WRITE_DMA_EXT : ATA_CMD_READ_DMA_EXT;
    fis[4] = (uint8_t)(lba & 0xFF);
    fis[5] = (uint8_t)((lba >> 8) & 0xFF);
    fis[6] = (uint8_t)((lba >> 16) & 0xFF);
    fis[7] = 0x40;
    fis[8] = (uint8_t)((lba >> 24) & 0xFF);
    fis[9] = (uint8_t)((lba >> 32) & 0xFF);
    fis[10] = (uint8_t)((lba >> 40) & 0xFF);
    fis[12] = (uint8_t)(count & 0xFF);
    fis[13] = (uint8_t)((count >> 8) & 0xFF);

    port->ci = 1u;

    for (volatile int i = 0; i < 5000000; i++) {
        if (!(port->ci & 1u)) break;
        if (port->is & (1u << 30)) return 0;
    }
    if (port->ci & 1u) return 0;

    return 1;
}

int ahci_read_sectors(int drive_index, uint64_t lba, uint32_t count, void *buffer) {
    if (drive_index < 0 || drive_index >= g_drive_count) return 0;
    return ahci_do_io(&g_drives[drive_index], lba, count, buffer, 0);
}

int ahci_write_sectors(int drive_index, uint64_t lba, uint32_t count, const void *buffer) {
    if (drive_index < 0 || drive_index >= g_drive_count) return 0;
    return ahci_do_io(&g_drives[drive_index], lba, count, (void *)(uintptr_t)buffer, 1);
}
