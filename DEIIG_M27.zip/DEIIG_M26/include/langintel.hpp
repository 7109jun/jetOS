#pragma once
#include <string>
#include <vector>
namespace deiig::langintel { struct Symbol{std::string name,file;size_t line;}; std::vector<Symbol> index(const std::string&root); void print_outline(const std::string&root); void find_refs(const std::string&root,const std::string&needle); }
