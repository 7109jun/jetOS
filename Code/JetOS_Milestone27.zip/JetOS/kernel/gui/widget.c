/*
 * JetOS - kernel/gui/widget.c
 * Milestone 19: 재사용 가능한 위젯 툴킷 구현. widget.h 참고.
 */

#include "widget.h"
#include "../drivers/keyboard.h"
#include <stddef.h>

static void wstr_copy(char *dst, const char *src, int cap) {
    int i = 0;
    for (; src && src[i] && i < cap - 1; i++) dst[i] = src[i];
    dst[i] = '\0';
}

static int wstr_len(const char *s) {
    int n = 0;
    while (s && s[n]) n++;
    return n;
}

/* ---------- 버튼 ---------- */
void widget_button_init(widget_button_t *b, int x, int y, int w, int h, const char *label) {
    b->x = x; b->y = y; b->w = w; b->h = h;
    wstr_copy(b->label, label, (int)sizeof(b->label));
}

void widget_button_draw(console_t *dc, const widget_button_t *b, uint32_t bg, uint32_t fg, int pressed) {
    uint32_t body = pressed ? (bg & 0x00CFCFCFu) : bg; /* 눌림 표시: 살짝 어둡게 */
    console_fill_rect(dc, (uint32_t)b->x, (uint32_t)b->y, (uint32_t)b->w, (uint32_t)b->h, body);
    /* 테두리 */
    console_fill_rect(dc, (uint32_t)b->x, (uint32_t)b->y, (uint32_t)b->w, 1, 0x00707070);
    console_fill_rect(dc, (uint32_t)b->x, (uint32_t)(b->y + b->h - 1), (uint32_t)b->w, 1, 0x00303030);
    console_fill_rect(dc, (uint32_t)b->x, (uint32_t)b->y, 1, (uint32_t)b->h, 0x00707070);
    console_fill_rect(dc, (uint32_t)(b->x + b->w - 1), (uint32_t)b->y, 1, (uint32_t)b->h, 0x00303030);

    dc->fg_color = fg;
    dc->cursor_x = (uint32_t)(b->x + 6);
    dc->cursor_y = (uint32_t)(b->y + (b->h > 14 ? (b->h - 14) / 2 : 2));
    console_print(dc, b->label);
}

int widget_button_hit(const widget_button_t *b, int x, int y) {
    return (x >= b->x && x < b->x + b->w && y >= b->y && y < b->y + b->h);
}

/* ---------- 텍스트박스 ---------- */
void widget_textbox_init(widget_textbox_t *tb, int x, int y, int w, int h, const char *initial) {
    tb->x = x; tb->y = y; tb->w = w; tb->h = h;
    wstr_copy(tb->buf, initial, WIDGET_TEXTBOX_CAP);
    tb->len = wstr_len(tb->buf);
    tb->cursor = tb->len;
}

void widget_textbox_set(widget_textbox_t *tb, const char *text) {
    wstr_copy(tb->buf, text, WIDGET_TEXTBOX_CAP);
    tb->len = wstr_len(tb->buf);
    tb->cursor = tb->len;
}

void widget_textbox_key(widget_textbox_t *tb, char c) {
    if (c == '\b') {
        if (tb->cursor > 0) {
            for (int i = tb->cursor - 1; i < tb->len - 1; i++) tb->buf[i] = tb->buf[i + 1];
            tb->len--; tb->cursor--;
            tb->buf[tb->len] = '\0';
        }
        return;
    }
    if (c == (char)KEY_DEL) {
        if (tb->cursor < tb->len) {
            for (int i = tb->cursor; i < tb->len - 1; i++) tb->buf[i] = tb->buf[i + 1];
            tb->len--;
            tb->buf[tb->len] = '\0';
        }
        return;
    }
    if (c == (char)KEY_LEFT) { if (tb->cursor > 0) tb->cursor--; return; }
    if (c == (char)KEY_RIGHT) { if (tb->cursor < tb->len) tb->cursor++; return; }
    if (c == (char)KEY_HOME) { tb->cursor = 0; return; }
    if (c == (char)KEY_END) { tb->cursor = tb->len; return; }
    if (c >= 32 && c < 127 && tb->len < WIDGET_TEXTBOX_CAP - 1) {
        for (int i = tb->len; i > tb->cursor; i--) tb->buf[i] = tb->buf[i - 1];
        tb->buf[tb->cursor] = c;
        tb->len++; tb->cursor++;
        tb->buf[tb->len] = '\0';
    }
}

void widget_textbox_draw(console_t *dc, const widget_textbox_t *tb, int focused) {
    uint32_t border = focused ? 0x0060A0E0u : 0x00707070u;
    console_fill_rect(dc, (uint32_t)tb->x, (uint32_t)tb->y, (uint32_t)tb->w, (uint32_t)tb->h, 0x00FFFFFFu);
    console_fill_rect(dc, (uint32_t)tb->x, (uint32_t)tb->y, (uint32_t)tb->w, 1, border);
    console_fill_rect(dc, (uint32_t)tb->x, (uint32_t)(tb->y + tb->h - 1), (uint32_t)tb->w, 1, border);
    console_fill_rect(dc, (uint32_t)tb->x, (uint32_t)tb->y, 1, (uint32_t)tb->h, border);
    console_fill_rect(dc, (uint32_t)(tb->x + tb->w - 1), (uint32_t)tb->y, 1, (uint32_t)tb->h, border);

    dc->fg_color = 0x00101010u;
    dc->cursor_x = (uint32_t)(tb->x + 4);
    dc->cursor_y = (uint32_t)(tb->y + (tb->h > 14 ? (tb->h - 14) / 2 : 2));
    console_print(dc, tb->buf);

    if (focused) {
        /* 커서 위치에 세로 막대 — 글자폭 근사치(GLYPH_ADVANCE=12)로 계산 */
        int cx = tb->x + 4 + tb->cursor * 12;
        console_fill_rect(dc, (uint32_t)cx, (uint32_t)(tb->y + 3), 1, (uint32_t)(tb->h - 6), 0x00000000u);
    }
}

int widget_textbox_hit(const widget_textbox_t *tb, int x, int y) {
    return (x >= tb->x && x < tb->x + tb->w && y >= tb->y && y < tb->y + tb->h);
}

/* ---------- 스크롤 가능한 여러 줄 텍스트 ---------- */
int widget_draw_scrollable_text(console_t *dc, int x, int y, int w, int h,
                                 const char *text, int scroll_y, uint32_t color) {
    (void)w;
    if (!text) return 0;
    char line[220];
    int li = 0;
    int line_no = 0;
    int total_lines = 1;

    dc->fg_color = color;

    for (int i = 0; ; i++) {
        char c = text[i];
        int flush = (c == '\n' || c == '\0');
        if (!flush && li < (int)sizeof(line) - 1) {
            line[li++] = c;
        }
        if (flush) {
            line[li] = '\0';
            int line_y = y + line_no * CONSOLE_LINE_H - scroll_y;
            /* 수직 클리핑: 창 콘텐츠 영역(y..y+h) 밖이면 그리지 않는다 */
            if (line_y + CONSOLE_LINE_H > y && line_y < y + h) {
                dc->cursor_x = (uint32_t)x;
                dc->cursor_y = (uint32_t)line_y;
                console_print(dc, line);
            }
            li = 0;
            line_no++;
            if (c == '\n') total_lines++;
            if (c == '\0') break;
        }
    }

    return total_lines * CONSOLE_LINE_H;
}
