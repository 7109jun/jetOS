/*
 * JetOS - kernel/apps/search.c
 * Milestone 34: 검색(파일) 앱. 설계 이유는 search.h 참고.
 */

#include <stddef.h>
#include "search.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../gui/widget.h"
#include "../drivers/console.h"
#include "../drivers/keyboard.h"
#include "../proc/scheduler.h"
#include "../fs/jetfs.h"

#define SEARCH_BOX_H 22
#define SEARCH_MAX_DEPTH 6
#define SEARCH_MAX_RESULTS 40
#define SEARCH_PATH_CAP 96
#define SEARCH_RESULT_BUF_CAP (SEARCH_MAX_RESULTS * SEARCH_PATH_CAP)

static widget_textbox_t g_query_box;
static int g_search_win = -1;
static int g_focused = 0;
static volatile int g_running = 0;

static char g_result_buf[SEARCH_RESULT_BUF_CAP]; /* widget_draw_scrollable_text용 — '\n' 구분 */
static int g_result_count = 0;

static int str_len_local(const char *s) { int n = 0; while (s && s[n]) n++; return n; }

static int str_contains_ci(const char *hay, const char *needle) {
    int hn = str_len_local(hay), nn = str_len_local(needle);
    if (nn == 0) return 0; /* 빈 검색어로 전체 나열하지 않음(부담스러운 결과 방지) */
    for (int i = 0; i + nn <= hn; i++) {
        int match = 1;
        for (int k = 0; k < nn; k++) {
            char a = hay[i + k], b = needle[k];
            if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
            if (b >= 'A' && b <= 'Z') b = (char)(b + 32);
            if (a != b) { match = 0; break; }
        }
        if (match) return 1;
    }
    return 0;
}

static void join_path(const char *dir, const char *name, char *out, int outsz) {
    int i = 0;
    const char *d = dir;
    while (*d && i < outsz - 1) out[i++] = *d++;
    if (i == 0 || out[i - 1] != '/') { if (i < outsz - 1) out[i++] = '/'; }
    const char *n = name;
    while (*n && i < outsz - 1) out[i++] = *n++;
    out[i] = '\0';
}

static void append_result(const char *path) {
    if (g_result_count >= SEARCH_MAX_RESULTS) return;
    int len = str_len_local(g_result_buf);
    int budget = SEARCH_RESULT_BUF_CAP - len - 2;
    if (budget <= 0) return;
    int i = 0;
    if (len > 0) g_result_buf[len++] = '\n';
    const char *p = path;
    while (*p && i < budget) { g_result_buf[len++] = *p++; i++; }
    g_result_buf[len] = '\0';
    g_result_count++;
}

typedef struct {
    const char *term;
    char parent[SEARCH_PATH_CAP];
    int depth;
} search_walk_ctx_t;

static void search_walk(const char *dir, const char *term, int depth);

static void search_walk_cb(const char *name, jetfs_inode_type_t type, uint64_t size, void *ctx) {
    (void)size;
    search_walk_ctx_t *w = (search_walk_ctx_t *)ctx;
    if (g_result_count >= SEARCH_MAX_RESULTS) return;
    char full[SEARCH_PATH_CAP];
    join_path(w->parent, name, full, sizeof(full));

    if (str_contains_ci(name, w->term)) append_result(full);
    if (type == JETFS_TYPE_DIR && w->depth < SEARCH_MAX_DEPTH) {
        search_walk(full, w->term, w->depth + 1);
    }
}

static void search_walk(const char *dir, const char *term, int depth) {
    if (g_result_count >= SEARCH_MAX_RESULTS) return;
    search_walk_ctx_t w;
    w.term = term;
    int i = 0; const char *d = dir; while (*d && i < (int)sizeof(w.parent) - 1) w.parent[i++] = *d++;
    w.parent[i] = '\0';
    w.depth = depth;
    jetfs_list(dir, search_walk_cb, &w);
}

static void run_search(void) {
    g_result_buf[0] = '\0';
    g_result_count = 0;
    if (g_query_box.len == 0) return;
    search_walk("/", g_query_box.buf, 0);
    if (g_result_count == 0) {
        const char *none = "(no matches)";
        int i = 0; while (none[i] && i < SEARCH_RESULT_BUF_CAP - 1) { g_result_buf[i] = none[i]; i++; }
        g_result_buf[i] = '\0';
    }
    /* 새 검색 결과는 맨 위부터 보이게 — 큰 음수로 스크롤을 위로
     * 클램프시킨다(wm_scroll_by는 범위를 벗어나면 자동으로 잘라줌). */
    if (g_search_win >= 0) wm_scroll_by(g_search_win, -1000000);
}

static void search_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)ctx;
    g_query_box.x = x + 6;
    g_query_box.y = y + 4;
    widget_textbox_draw(dc, &g_query_box, g_focused);

    dc->fg_color = 0x00A0A8B8u;
    dc->cursor_x = (uint32_t)(x + 6);
    dc->cursor_y = (uint32_t)(y + SEARCH_BOX_H + 8);
    console_print(dc, "Enter=search");

    int body_y = y + SEARCH_BOX_H + 22;
    int body_h = h - SEARCH_BOX_H - 22;
    if (body_h < 0) body_h = 0;
    int scroll = wm_get_scroll(g_search_win);
    int content_px = widget_draw_scrollable_text(dc, x + 6, body_y, w - 12, body_h,
                                                  g_result_buf, scroll, 0x00E0E0E0u);
    wm_set_content_height(g_search_win, SEARCH_BOX_H + 22 + content_px);
}

static void search_click_cb(int lx, int ly, void *ctx) {
    (void)ctx;
    g_focused = (ly < SEARCH_BOX_H);
}

static void search_key_cb(char c, void *ctx) {
    (void)ctx;
    if (!g_focused) return;
    if (c == '\n' || c == '\r') { run_search(); return; }
    widget_textbox_key(&g_query_box, c);
}

static void search_on_close(void *ctx) {
    (void)ctx;
    g_running = 0;
}

static void search_thread_fn(void *arg) {
    (void)arg;
    g_running = 1;
    g_focused = 1;
    g_result_buf[0] = '\0';
    g_result_count = 0;

    g_search_win = CreateWindowJ("SEARCH", 340, 200, 280, 220, 0x00302838);
    if (g_search_win >= 0) {
        widget_textbox_init(&g_query_box, 0, 0, 260, SEARCH_BOX_H - 5, "");
        wm_set_content_callback(g_search_win, search_content_cb, NULL);
        wm_set_close_callback(g_search_win, search_on_close, NULL);
        wm_set_click_callback(g_search_win, search_click_cb, NULL);
        wm_set_key_callback(g_search_win, search_key_cb, NULL);
    }

    while (g_running) {
        scheduler_yield();
    }
}

void search_launch(void) {
    static int launched = 0;
    if (launched && g_running) return;
    launched = 1;
    CreateThreadJ("search", search_thread_fn, NULL);
}
