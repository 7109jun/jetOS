#ifndef JETOS_PIT_H
#define JETOS_PIT_H

#include <stdint.h>

#define PIT_BASE_FREQUENCY 1193182ULL

/* Programmable Interval Timer(8253/8254) 채널0을 지정 주파수(Hz)로
 * 사각파 모드(모드3)로 설정해 IRQ0을 주기적으로 발생시킨다. */
void pit_init(uint32_t frequency_hz);

/* 타이머 인터럽트(IRQ0) 발생 횟수. exceptions.c의 isr_timer가 증가시킨다. */
extern volatile uint64_t g_timer_ticks;

#endif
