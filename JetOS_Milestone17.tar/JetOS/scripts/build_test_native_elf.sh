#!/usr/bin/env bash
# tools/testdata/test_elf.c 를 네이티브 x86_64 gcc(호스트가 리눅스라
# ELF64를 그대로 만들어줌)로 빌드해 JetOS의 int $0x80 syscall ABI를
# 쓰는 실제 ELF64 실행파일을 만들고, build/jetfs_import로
# build/jetfs.img 안에 /test_elf 로 넣는다.
#
# 전제:
#   - build/jetfs.img 가 이미 mkjetfs로 포맷되어 있음
#     (없으면: make mkjetfs && ./build/mkjetfs build/jetfs.img 16)
#
# 사용 후 QEMU 부팅해서 jash에서:
#   run /test_elf
set -e

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [ ! -f build/jetfs.img ]; then
    echo "오류: build/jetfs.img 가 없습니다. 먼저 다음을 실행하세요:"
    echo "  make mkjetfs && ./build/jetfs.img build/jetfs.img 16"
    exit 1
fi

make jetfs_import

echo "네이티브 ELF 빌드 중: tools/testdata/test_elf.c -> build/test_elf"
gcc -nostdlib -static -O2 -fno-pic -no-pie -fno-stack-protector -mcmodel=large \
    -Wl,--build-id=none -T tools/testdata/elf_link.ld \
    -o build/test_elf tools/testdata/test_elf.c

echo "JETFS 이미지에 삽입: build/test_elf -> /test_elf"
./build/jetfs_import build/jetfs.img build/test_elf /test_elf

echo "네이티브 ELF(크래시 테스트) 빌드 중: tools/testdata/test_elf_crash.c -> build/test_elf_crash"
gcc -nostdlib -static -O2 -fno-pic -no-pie -fno-stack-protector -mcmodel=large \
    -Wl,--build-id=none -T tools/testdata/elf_link.ld \
    -o build/test_elf_crash tools/testdata/test_elf_crash.c

echo "JETFS 이미지에 삽입: build/test_elf_crash -> /test_elf_crash"
./build/jetfs_import build/jetfs.img build/test_elf_crash /test_elf_crash

echo "완료. QEMU 부팅 후 jash에서 'run /test_elf' 또는 'run /test_elf_crash' 실행."
