#pragma once
#include "plugin_api.hpp"
#include <filesystem>
#include <string>
#include <vector>

namespace deiig {

struct PluginInfo {
    std::filesystem::path path;
    std::string name;
    std::string description;
    bool loaded = false;
};

class PluginManager {
public:
    PluginManager();
    ~PluginManager();
    PluginManager(const PluginManager&) = delete;
    PluginManager& operator=(const PluginManager&) = delete;

    void set_project_dir(const std::filesystem::path& path);
    void set_log(void (*fn)(const std::string&));
    void discover();
    bool load_all();
    bool load_file(const std::filesystem::path& path);
    std::vector<PluginInfo> list() const;
    int invoke(const std::string& command_line);
    bool has_command(const std::string& name) const;
    std::vector<std::string> commands() const;
    std::filesystem::path project_plugin_dir() const;

public:
    struct Impl;
    Impl* impl_;
};

} // namespace deiig
