#include <cctype>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <fstream>
#include <functional>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
#include <filesystem>
#include <algorithm>
#include <random>
#include <chrono>
#include <thread>
#ifndef _WIN32
#include <unistd.h>
#endif
#ifdef _WIN32
#include <windows.h>
#endif

namespace digg {

struct Value {
    enum class Type { Nil, Number, String, Bool } type = Type::Nil;
    double number = 0.0;
    std::string str;
    bool boolean = false;

    static Value Nil() { return {}; }
    static Value Number(double v) { Value x; x.type = Type::Number; x.number = v; return x; }
    static Value String(std::string v) { Value x; x.type = Type::String; x.str = std::move(v); return x; }
    static Value Bool(bool v) { Value x; x.type = Type::Bool; x.boolean = v; return x; }
};

static std::string toString(const Value& v) {
    switch (v.type) {
    case Value::Type::Number: {
        std::ostringstream out;
        out << v.number;
        return out.str();
    }
    case Value::Type::String: return v.str;
    case Value::Type::Bool: return v.boolean ? "true" : "false";
    default: return "nil";
    }
}

static bool truthy(const Value& v) {
    if (v.type == Value::Type::Bool) return v.boolean;
    if (v.type == Value::Type::Number) return v.number != 0.0;
    if (v.type == Value::Type::String) return !v.str.empty();
    return false;
}

struct Token {
    enum class Kind { End, Identifier, Number, String, LParen, RParen, LBrace, RBrace,
                      Comma, Semicolon, Dot, Plus, Minus, Star, Slash, Equal, EqualEqual,
                      BangEqual, Less, LessEqual, Greater, GreaterEqual, Bang, Keyword };
    Kind kind;
    std::string text;
    int line = 1;
    int column = 1;
};

class Lexer {
public:
    explicit Lexer(std::string source) : src_(std::move(source)) {}

    std::vector<Token> lex() {
        std::vector<Token> out;
        while (!atEnd()) {
            char c = advance();
            switch (c) {
            case ' ': case '\r': case '\t': break;
            case '\n': ++line_; col_ = 1; break;
            case '/':
                if (match('/')) { while (!atEnd() && peek() != '\n') advance(); }
                else if (match('*')) { blockComment(); }
                else out.push_back(tok(Token::Kind::Slash, "/"));
                break;
            case '(': out.push_back(tok(Token::Kind::LParen, "(")); break;
            case ')': out.push_back(tok(Token::Kind::RParen, ")")); break;
            case '{': out.push_back(tok(Token::Kind::LBrace, "{")); break;
            case '}': out.push_back(tok(Token::Kind::RBrace, "}")); break;
            case ',': out.push_back(tok(Token::Kind::Comma, ",")); break;
            case ';': out.push_back(tok(Token::Kind::Semicolon, ";")); break;
            case '.': out.push_back(tok(Token::Kind::Dot, ".")); break;
            case '+': out.push_back(tok(Token::Kind::Plus, "+")); break;
            case '-': out.push_back(tok(Token::Kind::Minus, "-")); break;
            case '*': out.push_back(tok(Token::Kind::Star, "*")); break;
            case '!': out.push_back(tok(match('=') ? Token::Kind::BangEqual : Token::Kind::Bang, matchText("!"))); break;
            case '=': out.push_back(tok(match('=') ? Token::Kind::EqualEqual : Token::Kind::Equal, "=")); break;
            case '<': out.push_back(tok(match('=') ? Token::Kind::LessEqual : Token::Kind::Less, "<")); break;
            case '>': out.push_back(tok(match('=') ? Token::Kind::GreaterEqual : Token::Kind::Greater, ">")); break;
            case '"': out.push_back(stringToken()); break;
            default:
                if (std::isdigit(static_cast<unsigned char>(c)) || (c == '.' && std::isdigit(static_cast<unsigned char>(peek())))) out.push_back(number(c));
                else if (std::isalpha(static_cast<unsigned char>(c)) || c == '_') out.push_back(identifier(c));
                else error("unexpected character '" + std::string(1, c) + "'");
            }
        }
        out.push_back({Token::Kind::End, "", line_, col_});
        return out;
    }

private:
    std::string src_;
    size_t pos_ = 0;
    int line_ = 1;
    int col_ = 1;

    bool atEnd() const { return pos_ >= src_.size(); }
    char peek() const { return atEnd() ? '\0' : src_[pos_]; }
    char peek2() const { return pos_ + 1 >= src_.size() ? '\0' : src_[pos_ + 1]; }
    char advance() { char c = src_[pos_++]; ++col_; return c; }
    bool match(char expected) { if (peek() != expected) return false; advance(); return true; }
    std::string matchText(const std::string& first) const { return first; }
    Token tok(Token::Kind k, std::string text) const { return {k, std::move(text), line_, col_}; }
    void error(const std::string& msg) const { throw std::runtime_error("line " + std::to_string(line_) + ": " + msg); }

    void blockComment() {
        while (!atEnd()) {
            if (peek() == '*' && peek2() == '/') { advance(); advance(); return; }
            char c = advance(); if (c == '\n') { ++line_; col_ = 1; }
        }
        error("unterminated block comment");
    }

    Token stringToken() {
        std::string out;
        int start = col_;
        while (!atEnd() && peek() != '"') {
            char c = advance();
            if (c == '\n') { ++line_; col_ = 1; }
            if (c == '\\' && !atEnd()) {
                char e = advance();
                switch (e) { case 'n': out += '\n'; break; case 't': out += '\t'; break; case 'r': out += '\r'; break; default: out += e; break; }
            } else out += c;
        }
        if (atEnd()) error("unterminated string");
        advance();
        return {Token::Kind::String, out, line_, start};
    }

    Token number(char first) {
        std::string s(1, first);
        while (std::isdigit(static_cast<unsigned char>(peek())) || peek() == '.') s += advance();
        return tok(Token::Kind::Number, s);
    }

    Token identifier(char first) {
        std::string s(1, first);
        while (std::isalnum(static_cast<unsigned char>(peek())) || peek() == '_') s += advance();
        static const char* kws[] = {"fn","let","if","else","while","return","true","false","nil"};
        for (const char* k : kws) if (s == k) return tok(Token::Kind::Keyword, s);
        return tok(Token::Kind::Identifier, s);
    }
};

struct ReturnSignal { Value value; };

static std::string readFile(const std::string& path);

static std::string lowerCopy(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
    return s;
}

static std::string upperCopy(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::toupper(c)); });
    return s;
}

static double numberArg(const std::vector<Value>& args, size_t index, const std::string& name) {
    if (index >= args.size() || args[index].type != Value::Type::Number)
        throw std::runtime_error(name + " expects a number at argument " + std::to_string(index + 1));
    return args[index].number;
}

static std::string stringArg(const std::vector<Value>& args, size_t index, const std::string& name) {
    if (index >= args.size() || args[index].type != Value::Type::String)
        throw std::runtime_error(name + " expects a string at argument " + std::to_string(index + 1));
    return args[index].str;
}

static void expectArity(const std::vector<Value>& args, size_t n, const std::string& name) {
    if (args.size() != n)
        throw std::runtime_error(name + " expects " + std::to_string(n) + " argument(s)");
}

static Value callStdlib(const std::string& name, const std::vector<Value>& args) {
    if (name == "file.read") {
        expectArity(args, 1, name); return Value::String(readFile(stringArg(args, 0, name)));
    }
    if (name == "file.write") {
        expectArity(args, 2, name);
        std::ofstream f(stringArg(args, 0, name), std::ios::binary | std::ios::trunc);
        if (!f) throw std::runtime_error("file.write: cannot open file");
        f << stringArg(args, 1, name);
        return Value::Bool(f.good());
    }
    if (name == "file.append") {
        expectArity(args, 2, name);
        std::ofstream f(stringArg(args, 0, name), std::ios::binary | std::ios::app);
        if (!f) throw std::runtime_error("file.append: cannot open file");
        f << stringArg(args, 1, name);
        return Value::Bool(f.good());
    }
    if (name == "file.exists") {
        expectArity(args, 1, name); std::error_code ec; return Value::Bool(std::filesystem::exists(stringArg(args, 0, name), ec) && !ec);
    }
    if (name == "file.remove") {
        expectArity(args, 1, name); std::error_code ec; return Value::Bool(std::filesystem::remove(stringArg(args, 0, name), ec) && !ec);
    }
    if (name == "string.len") { expectArity(args, 1, name); return Value::Number(static_cast<double>(stringArg(args,0,name).size())); }
    if (name == "string.upper") { expectArity(args,1,name); return Value::String(upperCopy(stringArg(args,0,name))); }
    if (name == "string.lower") { expectArity(args,1,name); return Value::String(lowerCopy(stringArg(args,0,name))); }
    if (name == "string.contains") { expectArity(args,2,name); return Value::Bool(stringArg(args,0,name).find(stringArg(args,1,name)) != std::string::npos); }
    if (name == "string.starts_with") { expectArity(args,2,name); auto a=stringArg(args,0,name), b=stringArg(args,1,name); return Value::Bool(a.rfind(b,0)==0); }
    if (name == "string.ends_with") { expectArity(args,2,name); auto a=stringArg(args,0,name), b=stringArg(args,1,name); return Value::Bool(a.size()>=b.size() && a.compare(a.size()-b.size(),b.size(),b)==0); }
    if (name == "math.abs") { expectArity(args,1,name); return Value::Number(std::fabs(numberArg(args,0,name))); }
    if (name == "math.sqrt") { expectArity(args,1,name); return Value::Number(std::sqrt(numberArg(args,0,name))); }
    if (name == "math.pow") { expectArity(args,2,name); return Value::Number(std::pow(numberArg(args,0,name), numberArg(args,1,name))); }
    if (name == "math.floor") { expectArity(args,1,name); return Value::Number(std::floor(numberArg(args,0,name))); }
    if (name == "math.ceil") { expectArity(args,1,name); return Value::Number(std::ceil(numberArg(args,0,name))); }
    if (name == "math.round") { expectArity(args,1,name); return Value::Number(std::round(numberArg(args,0,name))); }
    if (name == "math.min") { expectArity(args,2,name); return Value::Number(std::min(numberArg(args,0,name), numberArg(args,1,name))); }
    if (name == "math.max") { expectArity(args,2,name); return Value::Number(std::max(numberArg(args,0,name), numberArg(args,1,name))); }
    if (name == "system.cwd") { expectArity(args,0,name); return Value::String(std::filesystem::current_path().string()); }
    if (name == "system.env") {
        expectArity(args,1,name); const char* v = std::getenv(stringArg(args,0,name).c_str()); return v ? Value::String(v) : Value::Nil();
    }
    if (name == "system.exec") {
        expectArity(args,1,name); int rc = std::system(stringArg(args,0,name).c_str()); return Value::Number(static_cast<double>(rc));
    }
    if (name == "process.sleep") {
        expectArity(args,1,name);
        auto ms = static_cast<long long>(numberArg(args,0,name));
        std::this_thread::sleep_for(std::chrono::milliseconds(ms));
        return Value::Nil();
    }
    if (name == "process.pid") {
#ifdef _WIN32
        expectArity(args,0,name); return Value::Number(static_cast<double>(GetCurrentProcessId()));
#else
        expectArity(args,0,name); return Value::Number(static_cast<double>(::getpid()));
#endif
    }
    if (name == "http.get") {
        expectArity(args,1,name);
        std::string url = stringArg(args,0,name);
        if (url.find('\'') != std::string::npos || url.find('"') != std::string::npos || url.find('\n') != std::string::npos || url.find('\r') != std::string::npos)
            throw std::runtime_error("http.get: unsafe URL characters");
        std::string command = "curl -fsSL --max-time 20 \"" + url + "\"";
#ifdef _WIN32
        command += " 2>nul";
        FILE* pipe = _popen(command.c_str(), "r");
#else
        command += " 2>/dev/null";
        FILE* pipe = popen(command.c_str(), "r");
#endif
        if (!pipe) throw std::runtime_error("http.get: failed to start curl");
        std::string output;
        char buffer[4096];
        while (fgets(buffer, sizeof(buffer), pipe)) output += buffer;
#ifdef _WIN32
        int rc = _pclose(pipe);
#else
        int rc = pclose(pipe);
#endif
        if (rc != 0) throw std::runtime_error("http.get: curl failed with exit code " + std::to_string(rc));
        return Value::String(std::move(output));
    }
    throw std::runtime_error("unknown standard library function '" + name + "'");
}

class Parser {
public:
    explicit Parser(std::vector<Token> tokens) : t_(std::move(tokens)) {}

    void run() {
        while (!check(Token::Kind::End)) {
            if (matchKeyword("fn")) parseFunction();
            else executeStatement();
        }
        auto it = functions_.find("main");
        if (it != functions_.end()) callFunction("main", {});
    }

private:
    std::vector<Token> t_;
    size_t i_ = 0;
    std::unordered_map<std::string, std::pair<std::vector<std::string>, std::vector<Token>>> functions_;
    std::unordered_map<std::string, Value> globals_;

    const Token& cur() const { return t_[i_]; }
    bool check(Token::Kind k) const { return cur().kind == k; }
    const Token& advance() { if (!check(Token::Kind::End)) ++i_; return t_[i_-1]; }
    bool match(Token::Kind k) { if (!check(k)) return false; advance(); return true; }
    bool matchKeyword(const std::string& k) { if (cur().kind != Token::Kind::Keyword || cur().text != k) return false; advance(); return true; }

    [[noreturn]] void fail(const std::string& msg) const { throw std::runtime_error("line " + std::to_string(cur().line) + ": " + msg); }
    void expect(Token::Kind k, const std::string& msg) { if (!match(k)) fail(msg); }

    void parseFunction() {
        if (!check(Token::Kind::Identifier)) fail("expected function name");
        std::string name = advance().text;
        expect(Token::Kind::LParen, "expected '('");
        std::vector<std::string> params;
        if (!check(Token::Kind::RParen)) {
            do {
                if (!check(Token::Kind::Identifier)) fail("expected parameter name");
                params.push_back(advance().text);
            } while (match(Token::Kind::Comma));
        }
        expect(Token::Kind::RParen, "expected ')'");
        expect(Token::Kind::LBrace, "expected '{'");
        const size_t start = i_;
        int depth = 1;
        while (depth > 0 && !check(Token::Kind::End)) {
            if (check(Token::Kind::LBrace)) ++depth;
            else if (check(Token::Kind::RBrace)) --depth;
            advance();
        }
        if (depth != 0) fail("unterminated function body");
        const size_t finish = i_ - 1;
        functions_[name] = {params, std::vector<Token>(t_.begin() + static_cast<long>(start), t_.begin() + static_cast<long>(finish))};
    }

    Value evalExpression() { return comparison(); }

    Value comparison() {
        Value left = addition();
        while (cur().kind == Token::Kind::EqualEqual || cur().kind == Token::Kind::BangEqual ||
               cur().kind == Token::Kind::Less || cur().kind == Token::Kind::LessEqual ||
               cur().kind == Token::Kind::Greater || cur().kind == Token::Kind::GreaterEqual) {
            auto op = advance().kind; Value right = addition();
            double a = left.type == Value::Type::Number ? left.number : 0.0;
            double b = right.type == Value::Type::Number ? right.number : 0.0;
            bool eq = left.type == right.type && ((left.type == Value::Type::String && left.str == right.str) || (left.type == Value::Type::Number && a == b) || (left.type == Value::Type::Bool && left.boolean == right.boolean) || left.type == Value::Type::Nil);
            bool r = false;
            switch (op) { case Token::Kind::EqualEqual: r = eq; break; case Token::Kind::BangEqual: r = !eq; break; case Token::Kind::Less: r = a < b; break; case Token::Kind::LessEqual: r = a <= b; break; case Token::Kind::Greater: r = a > b; break; case Token::Kind::GreaterEqual: r = a >= b; break; default: break; }
            left = Value::Bool(r);
        }
        return left;
    }

    Value addition() {
        Value left = multiplication();
        while (check(Token::Kind::Plus) || check(Token::Kind::Minus)) {
            auto op = advance().kind; Value right = multiplication();
            if (op == Token::Kind::Plus && (left.type == Value::Type::String || right.type == Value::Type::String)) left = Value::String(toString(left) + toString(right));
            else { double a = left.type == Value::Type::Number ? left.number : 0; double b = right.type == Value::Type::Number ? right.number : 0; left = Value::Number(op == Token::Kind::Plus ? a + b : a - b); }
        }
        return left;
    }

    Value multiplication() {
        Value left = unary();
        while (check(Token::Kind::Star) || check(Token::Kind::Slash)) {
            auto op = advance().kind; Value right = unary();
            double a = left.type == Value::Type::Number ? left.number : 0; double b = right.type == Value::Type::Number ? right.number : 0;
            if (op == Token::Kind::Slash && b == 0) fail("division by zero");
            left = Value::Number(op == Token::Kind::Star ? a * b : a / b);
        }
        return left;
    }

    Value unary() {
        if (match(Token::Kind::Minus)) { Value v = unary(); return Value::Number(-(v.type == Value::Type::Number ? v.number : 0)); }
        if (match(Token::Kind::Bang)) return Value::Bool(!truthy(unary()));
        return primary();
    }

    Value primary() {
        if (match(Token::Kind::Number)) return Value::Number(std::stod(t_[i_-1].text));
        if (match(Token::Kind::String)) return Value::String(t_[i_-1].text);
        if (matchKeyword("true")) return Value::Bool(true);
        if (matchKeyword("false")) return Value::Bool(false);
        if (matchKeyword("nil")) return Value::Nil();
        if (match(Token::Kind::Identifier)) {
            std::string name = t_[i_-1].text;
            while (match(Token::Kind::Dot)) {
                if (!check(Token::Kind::Identifier)) fail("expected identifier after '.'");
                name += "." + advance().text;
            }
            if (match(Token::Kind::LParen)) {
                std::vector<Value> args;
                if (!check(Token::Kind::RParen)) { do { args.push_back(evalExpression()); } while (match(Token::Kind::Comma)); }
                expect(Token::Kind::RParen, "expected ')' after arguments");
                if (name == "print" || name == "println") { for (size_t n = 0; n < args.size(); ++n) { if (n) std::cout << ' '; std::cout << toString(args[n]); } std::cout << '\n'; return Value::Nil(); }
                if (name == "len") return args.empty() ? Value::Number(0) : Value::Number(toString(args[0]).size());
                if (name.find('.') != std::string::npos) return callStdlib(name, args);
                return callFunction(name, args);
            }
            auto it = globals_.find(name);
            return it == globals_.end() ? Value::Nil() : it->second;
        }
        if (match(Token::Kind::LParen)) { Value v = evalExpression(); expect(Token::Kind::RParen, "expected ')'"); return v; }
        fail("expected expression");
    }

    void executeStatement() {
        if (matchKeyword("let")) {
            if (!check(Token::Kind::Identifier)) fail("expected variable name");
            std::string name = advance().text;
            expect(Token::Kind::Equal, "expected '=' after variable name");
            globals_[name] = evalExpression(); match(Token::Kind::Semicolon); return;
        }
        if (matchKeyword("if")) {
            expect(Token::Kind::LParen, "expected '('"); Value condition = evalExpression(); expect(Token::Kind::RParen, "expected ')'");
            executeBlock(truthy(condition));
            if (matchKeyword("else")) executeBlock(!truthy(condition));
            return;
        }
        if (matchKeyword("while")) {
            expect(Token::Kind::LParen, "expected '('");
            const size_t condStart = i_;
            (void)evalExpression();
            const size_t condEnd = i_;
            expect(Token::Kind::RParen, "expected ')'");
            if (!check(Token::Kind::LBrace)) fail("expected '{'");
            advance();
            const size_t bodyStart = i_;
            int depth = 1;
            while (depth > 0 && !check(Token::Kind::End)) {
                if (check(Token::Kind::LBrace)) ++depth;
                else if (check(Token::Kind::RBrace)) --depth;
                advance();
            }
            if (depth != 0) fail("unterminated while body");
            const size_t bodyEnd = i_ - 1;
            const size_t afterLoop = i_;

            const std::vector<Token> original = t_;
            const std::vector<Token> cond(original.begin() + static_cast<long>(condStart), original.begin() + static_cast<long>(condEnd));
            const std::vector<Token> body(original.begin() + static_cast<long>(bodyStart), original.begin() + static_cast<long>(bodyEnd));
            for (int guard = 0; guard < 100000; ++guard) {
                t_ = cond;
                t_.push_back({Token::Kind::End, "", cur().line, cur().column});
                i_ = 0;
                Value c = evalExpression();
                if (!truthy(c)) break;

                t_ = body;
                t_.push_back({Token::Kind::End, "", 0, 0});
                i_ = 0;
                while (!check(Token::Kind::End)) executeStatement();
            }
            t_ = original;
            i_ = afterLoop;
            return;
        }
        if (matchKeyword("return")) { Value v = check(Token::Kind::RBrace) ? Value::Nil() : evalExpression(); match(Token::Kind::Semicolon); throw ReturnSignal{v}; }
        if (check(Token::Kind::Identifier) && i_ + 1 < t_.size() && t_[i_+1].kind == Token::Kind::Equal) {
            std::string name = advance().text; advance(); globals_[name] = evalExpression(); match(Token::Kind::Semicolon); return;
        }
        (void)evalExpression(); match(Token::Kind::Semicolon);
    }

    void executeBlock(bool shouldRun) {
        expect(Token::Kind::LBrace, "expected '{'");
        size_t start = i_; int depth = 1; while (depth && !check(Token::Kind::End)) { if (check(Token::Kind::LBrace)) ++depth; else if (check(Token::Kind::RBrace)) --depth; advance(); }
        size_t end = i_ - 1;
        if (!shouldRun) return;
        auto save = std::move(t_); auto saveI = i_;
        t_ = std::vector<Token>(save.begin() + static_cast<long>(start), save.begin() + static_cast<long>(end));
        i_ = 0; while (!check(Token::Kind::End)) executeStatement();
        t_ = std::move(save); i_ = saveI;
    }

    Value callFunction(const std::string& name, const std::vector<Value>& args) {
        auto it = functions_.find(name);
        if (it == functions_.end()) fail("unknown function '" + name + "'");
        auto saved = globals_;
        for (size_t n = 0; n < it->second.first.size(); ++n) globals_[it->second.first[n]] = n < args.size() ? args[n] : Value::Nil();
        auto saveTokens = std::move(t_); auto saveIndex = i_;
        t_ = it->second.second; t_.push_back({Token::Kind::End, "", 0, 0}); i_ = 0;
        Value result = Value::Nil();
        try { while (!check(Token::Kind::End)) executeStatement(); }
        catch (const ReturnSignal& r) { result = r.value; }
        t_ = std::move(saveTokens); i_ = saveIndex; globals_ = std::move(saved);
        return result;
    }
};

static std::string readFile(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) throw std::runtime_error("cannot open '" + path + "'");
    std::ostringstream ss; ss << f.rdbuf(); return ss.str();
}

} // namespace digg

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cerr << "Usage: digg-runtime <file.diggcode>\n";
        return 2;
    }
    try {
        std::string path = argv[1];
        if (path.size() < 9 || path.substr(path.size() - 9) != ".diggcode") throw std::runtime_error("DIGG runtime expects a .diggcode file");
        auto source = digg::readFile(path);
        digg::Lexer lexer(source);
        auto tokens = lexer.lex();
        digg::Parser parser(std::move(tokens));
        parser.run();
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "DIGG error: " << e.what() << '\n';
        return 1;
    }
}
