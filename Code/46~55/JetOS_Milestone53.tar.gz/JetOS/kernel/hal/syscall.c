/*
 * JetOS - kernel/hal/syscall.c
 * syscall.h 참고. syscall_entry.c(어셈블리 트램폴린)가 레지스터를 저장한
 * 뒤 이 함수를 부른다 — 여기서부터는 100% 순수 C.
 */
#include "syscall.h"
#include "../drivers/serial.h"
#include "../int/pit.h"
#include "../proc/thread.h"
#include "../proc/scheduler.h"
#include "../mm/vmm.h"
#include "../mm/pmm.h"
#include "../mm/heap.h" /* Milestone 36: SYS_READ 임시 버퍼 */
#include "../fs/jetfs.h" /* Milestone 36: 파일 I/O 시스템콜 */

#define SYS_FILE_READ_CAP (64 * 1024) /* Milestone 36: 이 시스템콜 경로가 다루는 파일 크기 상한(정직한 한계 — syscall.h 주석 참고) */

/* Milestone 19: 유저 포인터 검증. 현재 스레드가 프로세스 주소공간에
 * 묶여 있지 않으면(cr3==0, 공유 커널 주소공간) 유저 영역이라는 개념
 * 자체가 없으므로 무조건 거부한다 — 시스템콜은 Ring3(유저 프로세스)
 * 에서만 오는 게 정상이라 이 경로를 타면 이미 뭔가 잘못된 것이다. */
int syscall_check_user_range(const void *ptr, uint64_t len) {
    thread_t *cur = scheduler_current();
    if (!cur || cur->cr3 == 0) return 0;

    uint64_t base = vmm_user_virt_base();
    uint64_t size = vmm_user_region_size();
    uint64_t p = (uint64_t)ptr;

    if (len == 0) return (p >= base && p <= base + size);
    if (p < base) return 0;
    /* p + len 오버플로 방지: len이 남은 영역보다 크면 거부 (뺄셈으로
     * 비교해 p+len 오버플로 자체를 계산하지 않는다) */
    if (p - base > size - len) return 0;
    return 1;
}

int64_t syscall_check_user_cstr(const char *ptr, uint64_t max_len) {
    thread_t *cur = scheduler_current();
    if (!cur || cur->cr3 == 0) return -1;

    uint64_t base = vmm_user_virt_base();
    uint64_t size = vmm_user_region_size();
    uint64_t p = (uint64_t)ptr;
    if (p < base || p >= base + size) return -1;

    uint64_t max_reachable = (base + size) - p; /* 유저 영역 끝까지 남은 바이트 */
    uint64_t limit = (max_len < max_reachable) ? max_len : max_reachable;

    for (uint64_t i = 0; i < limit; i++) {
        if (ptr[i] == '\0') return (int64_t)i;
    }
    return -1; /* limit 안에 NUL 없음 — 잘렸거나 악의적으로 긴 문자열 */
}

void syscall_dispatch(syscall_regs_t *regs) {
    switch (regs->rax) {
        case SYS_WRITE: {
            const char *s = (const char *)regs->rdi;
            int64_t slen = syscall_check_user_cstr(s, 4096);
            if (slen < 0) {
                serial_write("[syscall] SYS_WRITE: invalid user pointer — killing thread\n");
                thread_exit(); /* Milestone 16과 동일한 원칙: 그 프로세스만 종료, 커널은 계속 */
            }
            serial_write(s);
            /* Milestone 37: 이 프로세스를 띄운 쪽(예: jash)이 stdout_sink를
             * 걸어뒀으면 그쪽에도 그대로 보여준다 — 지금까지는 유저
             * 프로그램이 뭘 출력해도 시리얼(디버그 로그)에만 보이고
             * 정작 그 프로그램을 실행한 터미널 창엔 아무것도 안 보였다
             * (M36에서 실기 검증 중 발견한 한계). */
            {
                thread_t *cur = scheduler_current();
                if (cur && cur->stdout_sink) cur->stdout_sink(s);
            }
            regs->rax = 0;
            break;
        }
        case SYS_GETTICK: {
            regs->rax = g_timer_ticks;
            break;
        }
        case SYS_BRK: {
            thread_t *cur = scheduler_current();
            uint64_t requested = regs->rdi;
            if (!cur || cur->cr3 == 0) { regs->rax = 0; break; } /* 커널 스레드에서 올 일 없음(방어적) */

            if (requested == 0) { regs->rax = cur->user_brk; break; } /* 조회 */

            uint64_t cur_brk = cur->user_brk;
            uint64_t base = vmm_user_virt_base();
            uint64_t cap = base + vmm_user_region_size();

            if (requested <= cur_brk) { regs->rax = cur_brk; break; } /* 축소 미지원 — 단순화(syscall.h 참고) */
            if (requested > cap) { regs->rax = cur_brk; break; } /* 유저 영역 상한 초과 — 실패, brk 그대로 */

            uint64_t new_brk_aligned = (requested + 0xFFFULL) & ~0xFFFULL;
            uint64_t page_va = cur_brk;
            int ok = 1;
            while (page_va < new_brk_aligned) {
                uint64_t phys = pmm_alloc_page();
                if (!phys) { ok = 0; break; } /* 물리 메모리 부족 — 여기까지 매핑된 건 그대로 두고 중단 */
                uint8_t *dst = (uint8_t *)phys; /* 커널은 항등매핑이라 바로 접근 가능 */
                for (int k = 0; k < 4096; k++) dst[k] = 0;
                if (!vmm_map_user_page(cur->cr3, page_va, phys, 1)) { ok = 0; break; }
                page_va += 4096;
            }
            cur->user_brk = page_va; /* 일부만 성공했어도 거기까지는 유효 — 진행분 반영 */
            (void)ok;
            regs->rax = cur->user_brk;
            break;
        }
        case SYS_EXIT: {
            thread_exit(); /* 돌아오지 않음 */
            break;
        }

        /* ---- Milestone 36: 최소 파일 I/O — 설계는 syscall.h 주석 참고 ---- */
        case SYS_OPEN: {
            thread_t *cur = scheduler_current();
            if (!cur || cur->cr3 == 0) { regs->rax = (uint64_t)-1; break; }

            const char *upath = (const char *)regs->rdi;
            int64_t plen = syscall_check_user_cstr(upath, THREAD_FD_PATH_MAX - 1);
            if (plen < 0) {
                serial_write("[syscall] SYS_OPEN: invalid user path pointer — killing thread\n");
                thread_exit();
            }
            int mode = (int)regs->rsi;
            if (mode != 0 && mode != 1) { regs->rax = (uint64_t)-1; break; }

            int slot = -1;
            for (int i = 0; i < THREAD_MAX_FDS; i++) { if (cur->fd_mode[i] == 0) { slot = i; break; } }
            if (slot < 0) { regs->rax = (uint64_t)-1; break; } /* fd 테이블 꽉 참 */

            char kpath[THREAD_FD_PATH_MAX];
            int i = 0;
            for (; i <= (int)plen; i++) kpath[i] = upath[i]; /* NUL까지 포함해서 복사 */

            if (mode == 0) { /* 읽기: 존재하는 일반 파일이어야 함 */
                jetfs_inode_type_t t;
                if (!jetfs_stat(kpath, &t, NULL) || t != JETFS_TYPE_FILE) { regs->rax = (uint64_t)-1; break; }
            } else { /* 쓰기: 없으면 만들어서 append가 그 위에서 동작하게 함 */
                if (!jetfs_stat(kpath, NULL, NULL)) {
                    if (!jetfs_create(kpath, JETFS_TYPE_FILE)) { regs->rax = (uint64_t)-1; break; }
                }
            }

            int k = 0; for (; kpath[k]; k++) cur->fd_path[slot][k] = kpath[k]; cur->fd_path[slot][k] = '\0';
            cur->fd_pos[slot] = 0;
            cur->fd_mode[slot] = mode + 1; /* thread.h: 1=읽기, 2=쓰기(0=닫힘과 안 겹치게 +1) */
            regs->rax = (uint64_t)slot;
            break;
        }
        case SYS_READ: {
            thread_t *cur = scheduler_current();
            if (!cur || cur->cr3 == 0) { regs->rax = (uint64_t)-1; break; }
            int fd = (int)regs->rdi;
            if (fd < 0 || fd >= THREAD_MAX_FDS || cur->fd_mode[fd] != 1) { regs->rax = (uint64_t)-1; break; }

            char *ubuf = (char *)regs->rsi;
            uint64_t maxlen = regs->rdx;
            if (!syscall_check_user_range(ubuf, maxlen)) {
                serial_write("[syscall] SYS_READ: invalid user buffer — killing thread\n");
                thread_exit();
            }

            uint64_t want_end = cur->fd_pos[fd] + maxlen;
            if (want_end > SYS_FILE_READ_CAP) want_end = SYS_FILE_READ_CAP;
            uint8_t *tmp = (uint8_t *)kmalloc(want_end > 0 ? want_end : 1);
            if (!tmp) { regs->rax = (uint64_t)-1; break; }
            uint64_t got = 0;
            /* 매번 파일 처음부터 다시 읽는다(JETFS엔 오프셋 지정 읽기가
             * 없음) — 여러 번에 걸쳐 큰 파일을 순차로 읽으면 O(n^2)가
             * 되는 정직한 비효율. 이 OS 규모(작은 파일)에서는 실용적으로
             * 문제없다고 판단했다(syscall.h 주석 참고). */
            jetfs_read(cur->fd_path[fd], tmp, want_end, &got);
            uint64_t avail = (got > cur->fd_pos[fd]) ? (got - cur->fd_pos[fd]) : 0;
            uint64_t n = (avail < maxlen) ? avail : maxlen;
            for (uint64_t kk = 0; kk < n; kk++) ubuf[kk] = (char)tmp[cur->fd_pos[fd] + kk];
            cur->fd_pos[fd] += n;
            kfree(tmp);
            regs->rax = n;
            break;
        }
        case SYS_WRITE_FD: {
            thread_t *cur = scheduler_current();
            if (!cur || cur->cr3 == 0) { regs->rax = (uint64_t)-1; break; }
            int fd = (int)regs->rdi;
            if (fd < 0 || fd >= THREAD_MAX_FDS || cur->fd_mode[fd] != 2) { regs->rax = (uint64_t)-1; break; }

            const char *ubuf = (const char *)regs->rsi;
            uint64_t len = regs->rdx;
            if (!syscall_check_user_range(ubuf, len)) {
                serial_write("[syscall] SYS_WRITE_FD: invalid user buffer — killing thread\n");
                thread_exit();
            }
            if (jetfs_append(cur->fd_path[fd], ubuf, len)) regs->rax = len;
            else regs->rax = (uint64_t)-1;
            break;
        }
        case SYS_CLOSE: {
            thread_t *cur = scheduler_current();
            if (!cur || cur->cr3 == 0) { regs->rax = (uint64_t)-1; break; }
            int fd = (int)regs->rdi;
            if (fd < 0 || fd >= THREAD_MAX_FDS || cur->fd_mode[fd] == 0) { regs->rax = (uint64_t)-1; break; }
            cur->fd_mode[fd] = 0;
            cur->fd_pos[fd] = 0;
            cur->fd_path[fd][0] = '\0';
            regs->rax = 0;
            break;
        }
        default: {
            serial_write("[syscall] unknown syscall number\n");
            regs->rax = (uint64_t)-1;
            break;
        }
    }
}
