#ifndef JETOS_RTC_H
#define JETOS_RTC_H

#include <stdint.h>

/*
 * JetOS - kernel/drivers/rtc.h
 * Milestone 13: CMOS RTC(Real-Time Clock, 포트 0x70/0x71)에서 실제
 * 벽시계 시각을 읽어온다. 인터럽트 없이 폴링/직접 읽기 방식.
 */

typedef struct {
    uint8_t second, minute, hour;
    uint8_t day, month;
    uint16_t year;
} rtc_time_t;

void rtc_read(rtc_time_t *out);

#endif
