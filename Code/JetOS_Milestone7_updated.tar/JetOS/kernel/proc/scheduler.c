/*
 * JetOS - kernel/proc/scheduler.c
 *
 * 원형 연결 리스트 기반 라운드로빈 스케줄러.
 *   - 협조적 양보(scheduler_yield)와 타이머 기반 선점(scheduler_tick_from_isr)
 *     을 모두 지원한다.
 *   - 선점은 isr_timer(순수 C, GCC interrupt attribute) 안에서
 *     scheduler_tick_from_isr()를 호출하는 방식으로 이루어진다. 실제
 *     스택 교체는 switch_context() (kernel/hal/context_switch.c, 유일한
 *     예외적 어셈블리) 가 담당하고, 이 파일 자체는 순수 C다.
 *
 * 알려진 단순화(Milestone 3 범위): 종료된(THREAD_DEAD) 스레드의 스택은
 * 아직 회수(kfree)하지 않는다 — 실행 중인 스택을 자기 자신이 free할 수
 * 없는 문제(전형적인 "zombie reaping" 문제) 때문이며, 이는 다음
 * 마일스톤에서 "다른 스레드가 대신 회수" 하는 방식으로 해결할 예정이다.
 */

#include "scheduler.h"
#include "../hal/context_switch.h"
#include "../mm/heap.h"
#include <stddef.h>

static thread_t *g_head = NULL;   /* 준비 큐 원형 리스트의 임의의 시작점 */
static thread_t *g_tail = NULL;
static thread_t *g_current = NULL;
static thread_t g_boot_pseudo;    /* scheduler_start() 최초 전환 시 저장용 (재사용 안 함) */
static uint64_t g_slice_counter = 0;

void scheduler_init(void) {
    g_head = NULL;
    g_tail = NULL;
    g_current = NULL;
    g_slice_counter = 0;
}

void scheduler_enqueue(thread_t *t) {
    if (!g_head) {
        g_head = t;
        g_tail = t;
        t->next = t;
    } else {
        t->next = g_head;
        g_tail->next = t;
        g_tail = t;
    }
}

thread_t *scheduler_current(void) {
    return g_current;
}

static thread_t *pick_next(thread_t *from) {
    if (!from) return g_head;
    thread_t *cand = from->next;
    for (uint32_t i = 0; i < 4096 && cand != from; i++) {
        if (cand->state == THREAD_READY) return cand;
        cand = cand->next;
    }
    /* from 자신이 아직 실행 가능하면 그대로 유지, 아니면 아무것도 없음 */
    return (from->state == THREAD_READY || from->state == THREAD_RUNNING) ? from : NULL;
}

void scheduler_yield(void) {
    thread_t *old = g_current;
    thread_t *next = pick_next(old);
    if (!next || next == old) return; /* 전환할 대상이 없음 */

    if (old && old->state == THREAD_RUNNING) old->state = THREAD_READY;
    next->state = THREAD_RUNNING;
    g_current = next;
    g_slice_counter = 0;

    switch_context(&old->rsp, next->rsp);
}

void scheduler_tick_from_isr(void) {
    if (!g_current) return;
    g_slice_counter++;
    if (g_slice_counter >= SCHED_TIME_SLICE_TICKS) {
        scheduler_yield();
    }
}

void scheduler_start(void) {
    thread_t *first = pick_next(NULL);
    if (!first) {
        /* 실행할 스레드가 없음 — 이는 최소 idle 스레드가 항상 등록된다는
         * kernel_entry.c의 계약을 위반한 상태이므로 발생해서는 안 된다. */
        for (;;) { __asm__ volatile ("hlt"); }
    }
    first->state = THREAD_RUNNING;
    g_current = first;
    switch_context(&g_boot_pseudo.rsp, first->rsp);
    __builtin_unreachable();
}

void scheduler_exit_current(void) {
    thread_t *dead = g_current;
    dead->state = THREAD_DEAD;

    thread_t *next = pick_next(dead);
    if (!next) {
        for (;;) { __asm__ volatile ("hlt"); }
    }
    next->state = THREAD_RUNNING;
    g_current = next;
    g_slice_counter = 0;

    switch_context(&dead->rsp, next->rsp);
    __builtin_unreachable();
}

void scheduler_reap_dead(void) {
    if (!g_head) return;

    /* 현재 링 크기를 먼저 세어 순회 횟수 상한으로 사용한다 (링이
     * 회수 도중 줄어들어도 안전하게 종료되도록). */
    uint32_t total = 0;
    thread_t *t = g_head;
    do { total++; t = t->next; } while (t != g_head);

    thread_t *prev = g_tail;
    thread_t *cur = g_head;
    for (uint32_t i = 0; i < total && g_head != NULL; i++) {
        thread_t *next = cur->next;
        int is_last_alive = (cur == g_head && cur == g_tail);
        if (cur->state == THREAD_DEAD && cur != g_current && !is_last_alive) {
            prev->next = next;
            if (cur == g_head) g_head = next;
            if (cur == g_tail) g_tail = prev;
            kfree(cur->stack_base);
            kfree(cur);
            cur = next;
            /* prev는 그대로: 방금 제거된 자리에 다음 노드가 이어짐 */
        } else {
            prev = cur;
            cur = next;
        }
    }
}

void scheduler_for_each(scheduler_thread_cb cb, void *ctx) {
    if (!g_head || !cb) return;
    thread_t *t = g_head;
    do {
        cb(t, ctx);
        t = t->next;
    } while (t != g_head);
}
