kernel/apps/calculator.o: kernel/apps/calculator.c \
 kernel/apps/calculator.h kernel/apps/../../include/jetapi/jetapi.h \
 kernel/apps/../gui/wm.h kernel/apps/../gui/../drivers/console.h \
 kernel/apps/../drivers/console.h kernel/apps/../proc/scheduler.h \
 kernel/apps/../proc/thread.h
kernel/apps/calculator.h:
kernel/apps/../../include/jetapi/jetapi.h:
kernel/apps/../gui/wm.h:
kernel/apps/../gui/../drivers/console.h:
kernel/apps/../drivers/console.h:
kernel/apps/../proc/scheduler.h:
kernel/apps/../proc/thread.h:
