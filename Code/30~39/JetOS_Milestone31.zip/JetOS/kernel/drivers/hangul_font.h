#ifndef JETOS_HANGUL_FONT_H
#define JETOS_HANGUL_FONT_H

#include <stdint.h>
#include "console.h"

/*
 * JetOS - kernel/drivers/hangul_font.h
 *
 * Milestone 13: 한글 음절(U+AC00~U+D7A3) 렌더링.
 *
 * 완성형 11,172자를 전부 비트맵으로 저장하는 대신, 실제 한글 조합
 * 원리(초성+중성+종성)를 그대로 따라 획(stroke) 단위로 "그려서"
 * 만든다 — 초성 19개 + 중성 21개 + 종성(재사용) 조합만 정의하면
 * 되므로 데이터량이 훨씬 작다.
 *
 * 알려진 단순화:
 *   - 겹받침(ㄳㄵㄶㄺㄻㄼㄽㄾㄿㅀㅄ, 11개)은 정확한 두 자모 형태 대신
 *     첫 번째 자음의 모양만 사용한다.
 *   - 복합 모음(ㅘㅙㅚㅝㅞㅟㅢ)은 세로형 모음과 같은 배치를 쓰되
 *     보조 획 하나를 더해 근사한다 — 정확한 활자 비례는 아니다.
 *   - 8x8 도트 시대의 "찍는 폰트"에 가까운 단순화된 형태이며, 실제
 *     인쇄용 명조/고딕체 수준의 정확한 자형은 아니다.
 */

#define HANGUL_CELL_W 14
#define HANGUL_CELL_H 22

/* codepoint가 완성형 한글 음절 범위(U+AC00~U+D7A3)인지 */
int hangul_is_syllable(uint32_t codepoint);

/* con의 (x,y)를 좌상단으로 해서 한 음절을 그린다. scale은 픽셀
 * 배율(보통 1이나 2). 실제로 차지하는 폭은 HANGUL_CELL_W*scale. */
void hangul_draw_syllable(console_t *con, int x, int y, uint32_t codepoint, uint32_t color, int scale);

#endif
