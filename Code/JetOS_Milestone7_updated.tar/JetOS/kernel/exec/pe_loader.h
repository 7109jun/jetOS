#ifndef JETOS_PE_LOADER_H
#define JETOS_PE_LOADER_H

#include <stdint.h>

/*
 * JetOS PE32+ (.exe) 로더
 *
 * 접근 방식: Wine/ReactOS와 동일한 철학 — Microsoft 코드나 DLL을 전혀
 * 사용하지 않고, PE 헤더를 직접 파싱해 세그먼트를 메모리에 적재한 뒤,
 * Import Address Table(IAT)을 JetOS 자체 Win32 스텁 함수들로 연결한다.
 *
 * 지원 범위 (Milestone 7):
 *   - PE32+ (64비트 EXE, IMAGE_NT_OPTIONAL_HDR64_MAGIC)
 *   - Import Table 해석 (KERNEL32.DLL 스텁만 해석, 나머지는 null-stub으로 처리)
 *   - Relocation (IMAGE_DIRECTORY_ENTRY_BASERELOC) 적용
 *   - 커널 스레드로 실행 (Ring3 전환 없음 — 커널 권한으로 동작하는 보호 없는 실행)
 *
 * 참고: Linux의 binfmt_pe는 없고, Wine/ReactOS의 접근법을 참고했다.
 * Wine은 ntdll.so 안에서 PE 헤더를 파싱해 같은 프로세스 내에 적재한다.
 * JetOS는 같은 원리를 커널 스레드 컨텍스트에서 수행한다.
 *
 * 실행 가능 .exe 요건:
 *   - PE32+ (x64), EXE, ASLR 없거나 재배치 테이블 포함
 *   - 이미지 기반 주소(ImageBase)가 4GiB 이내
 *   - KERNEL32.DLL만 임포트하는 간단한 프로그램
 *   - subsystem: Console 또는 GUI
 *   - 표준 라이브러리(CRT, MSVCRT) 미사용 (JetOS에 CRT 없음 —
 *     이 점은 ReactOS와 동일: 시스템 DLL을 자체 구현하기 전까지
 *     CRT에 의존하는 EXE는 실행 불가)
 */

typedef struct {
    int error_code;        /* 0=성공, 음수=오류 코드 */
    const char *error_msg; /* 사람이 읽을 수 있는 오류 설명 */
    uint64_t entry_point;  /* 성공 시 실제 진입점 주소 */
    uint64_t image_base;   /* 실제 적재된 이미지 기반 주소 */
} pe_load_result_t;

/* JETFS에서 .exe 파일을 읽어 메모리에 적재하고, IAT를 JetOS Win32 스텁으로 연결한다.
 * 성공 시 result->error_code == 0 이고 entry_point가 유효하다.
 * 실제 실행은 이 함수가 직접 하지 않는다 — 호출자가 entry_point로 점프한다. */
void pe_load(const char *path, pe_load_result_t *result);

/* 로드된 EXE를 커널 스레드로 실행한다. path는 JETFS 경로. */
int pe_execute(const char *path, const char *cmdline);

#endif
