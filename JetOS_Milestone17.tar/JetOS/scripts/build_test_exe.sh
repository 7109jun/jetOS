#!/usr/bin/env bash
# tools/testdata/hello.c 를 mingw-w64로 빌드해 진짜 PE32+ EXE를 만들고,
# build/jetfs_import로 build/jetfs.img 안에 /hello.exe 로 넣는다.
#
# 전제:
#   - mingw-w64 설치됨 (x86_64-w64-mingw32-gcc)
#   - build/jetfs.img 가 이미 mkjetfs로 포맷되어 있음
#     (없으면: make mkjetfs && ./build/mkjetfs build/jetfs.img 16)
#
# 사용 후 QEMU 부팅해서 jash에서:
#   run /hello.exe
set -e

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if ! command -v x86_64-w64-mingw32-gcc >/dev/null 2>&1; then
    echo "오류: x86_64-w64-mingw32-gcc 를 찾을 수 없습니다. 설치: apt install mingw-w64"
    exit 1
fi

if [ ! -f build/jetfs.img ]; then
    echo "오류: build/jetfs.img 가 없습니다. 먼저 다음을 실행하세요:"
    echo "  make mkjetfs && ./build/mkjetfs build/jetfs.img 16"
    exit 1
fi

make jetfs_import

echo "테스트 EXE 빌드 중: tools/testdata/hello.c -> build/hello.exe"
x86_64-w64-mingw32-gcc -O2 -nostdlib -Wl,-e,start \
    -o build/hello.exe tools/testdata/hello.c -lkernel32 -luser32

echo "JETFS 이미지에 삽입: build/hello.exe -> /hello.exe"
./build/jetfs_import build/jetfs.img build/hello.exe /hello.exe

echo "완료. QEMU 부팅 후 jash에서 'run /hello.exe' 실행."
