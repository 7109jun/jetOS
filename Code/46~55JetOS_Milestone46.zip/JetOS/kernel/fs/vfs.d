kernel/fs/vfs.o: kernel/fs/vfs.c kernel/fs/vfs.h
kernel/fs/vfs.h:
