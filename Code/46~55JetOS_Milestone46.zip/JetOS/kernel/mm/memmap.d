kernel/mm/memmap.o: kernel/mm/memmap.c kernel/mm/memmap.h \
 kernel/mm/../../include/efi/efi.h
kernel/mm/memmap.h:
kernel/mm/../../include/efi/efi.h:
