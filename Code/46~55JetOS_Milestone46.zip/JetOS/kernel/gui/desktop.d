kernel/gui/desktop.o: kernel/gui/desktop.c kernel/gui/desktop.h \
 kernel/gui/wm.h kernel/gui/../drivers/console.h kernel/gui/clipboard.h \
 kernel/gui/../kernel.h kernel/gui/../drivers/console.h \
 kernel/gui/../drivers/keyboard.h kernel/gui/../drivers/mouse.h \
 kernel/gui/../drivers/speaker.h kernel/gui/../drivers/serial.h \
 kernel/gui/../proc/scheduler.h kernel/gui/../proc/thread.h \
 kernel/gui/../hal/x86_asm_shim.h kernel/gui/../apps/file_manager.h \
 kernel/gui/../apps/settings.h kernel/gui/../apps/task_manager.h \
 kernel/gui/../apps/jash.h kernel/gui/../apps/clock.h \
 kernel/gui/../apps/browser.h kernel/gui/../apps/search.h \
 kernel/gui/../apps/recyclebin_gui.h kernel/gui/../apps/run_dialog.h \
 kernel/gui/../apps/calculator.h kernel/gui/../apps/programs_gui.h \
 kernel/gui/../drivers/virtio_input.h kernel/gui/../fs/jetfs.h \
 kernel/gui/../fs/perm.h kernel/gui/../gui/notify.h \
 kernel/gui/../hal/auth.h
kernel/gui/desktop.h:
kernel/gui/wm.h:
kernel/gui/../drivers/console.h:
kernel/gui/clipboard.h:
kernel/gui/../kernel.h:
kernel/gui/../drivers/console.h:
kernel/gui/../drivers/keyboard.h:
kernel/gui/../drivers/mouse.h:
kernel/gui/../drivers/speaker.h:
kernel/gui/../drivers/serial.h:
kernel/gui/../proc/scheduler.h:
kernel/gui/../proc/thread.h:
kernel/gui/../hal/x86_asm_shim.h:
kernel/gui/../apps/file_manager.h:
kernel/gui/../apps/settings.h:
kernel/gui/../apps/task_manager.h:
kernel/gui/../apps/jash.h:
kernel/gui/../apps/clock.h:
kernel/gui/../apps/browser.h:
kernel/gui/../apps/search.h:
kernel/gui/../apps/recyclebin_gui.h:
kernel/gui/../apps/run_dialog.h:
kernel/gui/../apps/calculator.h:
kernel/gui/../apps/programs_gui.h:
kernel/gui/../drivers/virtio_input.h:
kernel/gui/../fs/jetfs.h:
kernel/gui/../fs/perm.h:
kernel/gui/../gui/notify.h:
kernel/gui/../hal/auth.h:
