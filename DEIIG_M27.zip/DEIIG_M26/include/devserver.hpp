#pragma once
#include <string>
namespace deiig::devserver { int start(const std::string& command,int port); int stop(); int status(); }
