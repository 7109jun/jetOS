/*
 * JetOS - kernel/gui/wm.c
 * 윈도우 매니저 + 렌더러. Milestone 7에서 디자인 시스템을 전면 적용해
 * 더 Windows답게 느껴지는 비주얼로 개선했다.
 */

#include "wm.h"
#include "theme.h"
#include "../mm/heap.h"
#include "../int/pit.h"
#include "../drivers/rtc.h"
#include "../drivers/keyboard.h"
#include "../net/net.h"
#include <stddef.h>

#define START_MENU_ITEMS 7
static const char *START_MENU_LABELS[START_MENU_ITEMS] = {
    "File Manager", "Terminal", "Settings", "Task Manager", "Clock", "Browser", "Shutdown"
};

static console_t *g_front = NULL;
static console_t g_back;
static console_t *g_con = NULL;

static wm_window_t g_windows[WM_MAX_WINDOWS];
static int g_order[WM_MAX_WINDOWS];
static int g_window_count = 0;
static int g_focused_idx = -1;

static int g_cursor_x = 0, g_cursor_y = 0;
static int g_start_menu_open = 0;

/* 우클릭 컨텍스트 메뉴 상태 */
static int g_ctx_menu_open = 0;
static int g_ctx_menu_x = 0, g_ctx_menu_y = 0;
static int g_ctx_menu_target = -1; /* -1 = 데스크톱 메뉴, 그 외 = 창 idx */
#define CTX_MENU_W 130
#define DESKTOP_CTX_ITEMS 6  /* File Manager / Terminal / Settings / Task Manager / Clock / Browser */
#define WINDOW_CTX_ITEMS 2   /* Close / Minimize|Restore */

#define START_BTN_W 80
#define MENU_ITEM_H 22
#define TASKBAR_LABEL_W 130
#define BORDER_SZ 2

void wm_init(console_t *con) {
    g_front = con;
    uint32_t *backbuf = (uint32_t *)kmalloc((size_t)con->width * con->height * 4);
    console_init(&g_back, backbuf, con->width, con->height, con->width);
    g_con = &g_back;
    g_window_count = 0;
    g_focused_idx = -1;
    for (int i = 0; i < WM_MAX_WINDOWS; i++) { g_windows[i].used = 0; g_order[i] = -1; }
    g_cursor_x = (int)con->width / 2;
    g_cursor_y = (int)con->height / 2;
    g_start_menu_open = 0;
    g_ctx_menu_open = 0;
    g_ctx_menu_target = -1;
}

int wm_create_window(const char *title, int x, int y, int w, int h, uint32_t color) {
    if (g_window_count >= WM_MAX_WINDOWS) return -1;
    int idx = g_window_count++;
    wm_window_t *win = &g_windows[idx];
    win->x = x; win->y = y; win->w = w; win->h = h;
    win->color = color;
    win->visible = 1;
    win->minimized = 0;
    win->closed = 0;
    win->used = 1;
    win->content_cb = NULL;
    win->content_ctx = NULL;
    win->close_cb = NULL;
    win->close_ctx = NULL;
    win->click_cb = NULL;
    win->click_ctx = NULL;
    win->key_cb = NULL;
    win->key_ctx = NULL;
    win->scroll_cb = NULL;
    win->scroll_ctx = NULL;
    win->content_h = 0;
    win->scroll_y = 0;
    win->win32_style = 0;
    int i = 0;
    for (; i < 31 && title[i]; i++) win->title[i] = title[i];
    win->title[i] = '\0';
    g_order[idx] = idx;
    g_focused_idx = idx;
    return idx;
}

void wm_bring_to_front(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    int pos = -1;
    for (int i = 0; i < g_window_count; i++) if (g_order[i] == idx) { pos = i; break; }
    if (pos < 0) return;
    for (int i = pos; i < g_window_count - 1; i++) g_order[i] = g_order[i + 1];
    g_order[g_window_count - 1] = idx;
    g_focused_idx = idx;
}

void wm_move_window(int idx, int dx, int dy) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].x += dx;
    g_windows[idx].y += dy;
}

#define WM_MIN_WIDTH 140
#define WM_MIN_HEIGHT 80

void wm_resize_window(int idx, int dw, int dh) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    int nw = w->w + dw;
    int nh = w->h + dh;
    if (nw < WM_MIN_WIDTH) nw = WM_MIN_WIDTH;
    if (nh < WM_MIN_HEIGHT) nh = WM_MIN_HEIGHT;
    if (g_con) {
        if ((uint32_t)(w->x + nw) > g_con->width) nw = (int)g_con->width - w->x;
        if ((uint32_t)(w->y + WM_TITLEBAR_H + nh) > g_con->height - WM_TASKBAR_H)
            nh = (int)(g_con->height - WM_TASKBAR_H) - w->y - WM_TITLEBAR_H;
    }
    w->w = nw;
    w->h = nh;
}

int wm_hit_resize_handle(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    int hx = w->x + w->w - 10;
    int hy = w->y + WM_TITLEBAR_H + w->h - 10;
    return (x >= hx && x < hx + 10 && y >= hy && y < hy + 10);
}

int wm_window_at(int x, int y) {
    for (int i = g_window_count - 1; i >= 0; i--) {
        int idx = g_order[i];
        wm_window_t *w = &g_windows[idx];
        if (!w->visible || w->minimized || w->closed) continue;
        if (x >= w->x - BORDER_SZ && x < w->x + w->w + BORDER_SZ &&
            y >= w->y && y < w->y + w->h + WM_TITLEBAR_H) {
            return idx;
        }
    }
    return -1;
}

int wm_hit_titlebar(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    return (x >= w->x && x < w->x + w->w && y >= w->y && y < w->y + WM_TITLEBAR_H);
}

int wm_hit_close_button(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    int bx = w->x + w->w - 18;
    int by = w->y + 3;
    return (x >= bx && x < bx + 14 && y >= by && y < by + 12);
}

int wm_hit_maximize_button(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    int bx = w->x + w->w - 18 - 16;
    int by = w->y + 3;
    return (x >= bx && x < bx + 14 && y >= by && y < by + 12);
}

int wm_hit_minimize_button(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    int bx = w->x + w->w - 18 - 32;
    int by = w->y + 3;
    return (x >= bx && x < bx + 14 && y >= by && y < by + 12);
}

void wm_toggle_maximize(int idx) {
    if (idx < 0 || idx >= g_window_count || !g_con) return;
    wm_window_t *w = &g_windows[idx];
    if (w->maximized) {
        w->x = w->saved_x; w->y = w->saved_y; w->w = w->saved_w; w->h = w->saved_h;
        w->maximized = 0;
    } else {
        w->saved_x = w->x; w->saved_y = w->y; w->saved_w = w->w; w->saved_h = w->h;
        w->x = 4; w->y = 4;
        w->w = (int)g_con->width - 8;
        w->h = (int)(g_con->height - WM_TASKBAR_H) - WM_TITLEBAR_H - 8;
        w->maximized = 1;
    }
}

void wm_close_window(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    if (w->closed) return;
    w->visible = 0;
    w->minimized = 0;
    w->closed = 1;
    if (w->close_cb) w->close_cb(w->close_ctx);
    if (g_focused_idx == idx) {
        g_focused_idx = -1;
        for (int i = g_window_count - 1; i >= 0; i--) {
            int oi = g_order[i];
            if (!g_windows[oi].closed) { g_focused_idx = oi; break; }
        }
    }
}

void wm_minimize_window(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    if (w->closed) return;
    w->minimized = 1;
    w->visible = 0;
    if (g_focused_idx == idx) {
        g_focused_idx = -1;
        for (int i = g_window_count - 1; i >= 0; i--) {
            int oi = g_order[i];
            if (!g_windows[oi].closed && !g_windows[oi].minimized) { g_focused_idx = oi; break; }
        }
    }
}

void wm_restore_window(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    if (w->closed) return;
    w->minimized = 0;
    w->visible = 1;
    wm_bring_to_front(idx);
}

int wm_is_window_minimized(int idx) {
    if (idx < 0 || idx >= g_window_count) return 0;
    return g_windows[idx].minimized;
}

int wm_hit_taskbar_window_button(int x, int y) {
    if (!g_con) return -1;
    int tbY = (int)g_con->height - WM_TASKBAR_H;
    if (y < tbY + 2 || y >= tbY + WM_TASKBAR_H - 2) return -1;
    int tx = START_BTN_W + 4;
    for (int i = 0; i < g_window_count; i++) {
        int idx = g_order[i];
        wm_window_t *w = &g_windows[idx];
        if (w->closed) continue;
        if (x >= tx && x < tx + TASKBAR_LABEL_W - 4) return idx;
        tx += TASKBAR_LABEL_W;
    }
    return -1;
}

void wm_get_window_bounds(int idx, int *x, int *y, int *w, int *h) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *win = &g_windows[idx];
    if (x) *x = win->x;
    if (y) *y = win->y;
    if (w) *w = win->w;
    if (h) *h = win->h;
}

void wm_set_content_callback(int idx, wm_content_draw_fn cb, void *ctx) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].content_cb = cb;
    g_windows[idx].content_ctx = ctx;
}

void wm_set_close_callback(int idx, wm_close_fn cb, void *ctx) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].close_cb = cb;
    g_windows[idx].close_ctx = ctx;
}

void wm_set_click_callback(int idx, wm_click_fn cb, void *ctx) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].click_cb = cb;
    g_windows[idx].click_ctx = ctx;
}

int wm_dispatch_click(int screen_x, int screen_y) {
    int idx = wm_window_at(screen_x, screen_y);
    if (idx < 0) return 0;
    wm_window_t *w = &g_windows[idx];
    if (!w->click_cb) return 0;
    int content_y0 = w->y + WM_TITLEBAR_H;
    if (screen_x < w->x || screen_x >= w->x + w->w) return 0;
    if (screen_y < content_y0 || screen_y >= content_y0 + w->h) return 0;
    w->click_cb(screen_x - w->x, screen_y - content_y0, w->click_ctx);
    return 1;
}

/* ===== 키보드 포커스 라우팅 (Milestone 19) ===== */
void wm_set_key_callback(int idx, wm_key_fn cb, void *ctx) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].key_cb = cb;
    g_windows[idx].key_ctx = ctx;
}

int wm_get_focused_window(void) {
    return g_focused_idx;
}

void wm_dispatch_key(char c) {
    if (g_focused_idx < 0 || g_focused_idx >= g_window_count) return;
    wm_window_t *w = &g_windows[g_focused_idx];
    if (w->closed) return;
    /* PgUp/PgDn은 스크롤 가능한 창이면 WM이 직접 처리하고 앱에는
     * 전달하지 않는다(앱마다 별도 스크롤 처리를 구현할 필요 없게). */
    if (w->content_h > w->h) {
        if (c == (char)KEY_PGUP) { wm_scroll_by(g_focused_idx, -w->h / 2); return; }
        if (c == (char)KEY_PGDN) { wm_scroll_by(g_focused_idx, w->h / 2); return; }
    }
    if (!w->key_cb) return;
    w->key_cb(c, w->key_ctx);
}

/* ===== 스크롤 (Milestone 19) ===== */
#define WM_SCROLLBAR_W 10

void wm_set_content_height(int idx, int content_h) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    w->content_h = content_h;
    int visible_h = w->h;
    int max_scroll = content_h - visible_h;
    if (max_scroll < 0) max_scroll = 0;
    if (w->scroll_y > max_scroll) w->scroll_y = max_scroll;
}

void wm_set_scroll_callback(int idx, wm_scroll_fn cb, void *ctx) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].scroll_cb = cb;
    g_windows[idx].scroll_ctx = ctx;
}

int wm_get_scroll(int idx) {
    if (idx < 0 || idx >= g_window_count) return 0;
    return g_windows[idx].scroll_y;
}

void wm_scroll_by(int idx, int delta) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    if (w->content_h <= w->h) { w->scroll_y = 0; return; }
    int max_scroll = w->content_h - w->h;
    int ny = w->scroll_y + delta;
    if (ny < 0) ny = 0;
    if (ny > max_scroll) ny = max_scroll;
    w->scroll_y = ny;
    if (w->scroll_cb) w->scroll_cb(w->scroll_y, w->scroll_ctx);
}

/* 새 출력이 추가된 콘솔류 창(jash 등)이 "스크롤을 직접 위로 올리지
 * 않은 한" 항상 최신 줄을 보여주도록 하는 헬퍼. */
void wm_scroll_to_bottom(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    int max_scroll = w->content_h - w->h;
    if (max_scroll < 0) max_scroll = 0;
    w->scroll_y = max_scroll;
}

int wm_hit_scrollbar(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    if (w->content_h <= w->h) return 0; /* 스크롤 불필요 */
    int sx = w->x + w->w - WM_SCROLLBAR_W;
    int sy0 = w->y + WM_TITLEBAR_H;
    int sy1 = w->y + WM_TITLEBAR_H + w->h;
    return (x >= sx && x < w->x + w->w && y >= sy0 && y < sy1);
}

void wm_scrollbar_drag_to(int idx, int y) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    if (w->content_h <= w->h) return;
    int track_top = w->y + WM_TITLEBAR_H;
    int track_h = w->h;
    int thumb_h = (track_h * w->h) / w->content_h;
    if (thumb_h < 12) thumb_h = 12;
    int usable = track_h - thumb_h;
    if (usable < 1) usable = 1;
    int rel = y - track_top - thumb_h / 2;
    if (rel < 0) rel = 0;
    if (rel > usable) rel = usable;
    int max_scroll = w->content_h - w->h;
    int ny = (rel * max_scroll) / usable;
    w->scroll_y = ny;
    if (w->scroll_cb) w->scroll_cb(w->scroll_y, w->scroll_ctx);
}

void wm_set_win32_style(int idx, int enabled) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].win32_style = enabled;
}

void wm_set_title(int idx, const char *title) {
    if (idx < 0 || idx >= g_window_count || !title) return;
    int i = 0;
    for (; title[i] && i < (int)sizeof(g_windows[idx].title) - 1; i++) {
        g_windows[idx].title[i] = title[i];
    }
    g_windows[idx].title[i] = '\0';
}

void wm_set_cursor(int x, int y) {
    if (!g_con) return;
    if (x < 0) x = 0; if (y < 0) y = 0;
    if (x >= (int)g_con->width) x = (int)g_con->width - 1;
    if (y >= (int)g_con->height) y = (int)g_con->height - 1;
    g_cursor_x = x; g_cursor_y = y;
}

void wm_get_cursor(int *x, int *y) {
    if (x) *x = g_cursor_x;
    if (y) *y = g_cursor_y;
}

void wm_set_start_menu_open(int open) { g_start_menu_open = open; }

int wm_is_start_button_hit(int x, int y) {
    if (!g_con) return 0;
    int ty = (int)g_con->height - WM_TASKBAR_H;
    return (x >= 0 && x < START_BTN_W && y >= ty && y < (int)g_con->height);
}

int wm_is_start_menu_item_hit(int x, int y, int *out_item_index) {
    if (!g_con || !g_start_menu_open) return 0;
    int ty = (int)g_con->height - WM_TASKBAR_H;
    int menu_h = START_MENU_ITEMS * MENU_ITEM_H + 4;
    int menu_y = ty - menu_h;
    if (x < 0 || x >= START_BTN_W + 80) return 0;
    if (y < menu_y || y >= ty) return 0;
    int item = (y - menu_y - 2) / MENU_ITEM_H;
    if (item < 0 || item >= START_MENU_ITEMS) return 0;
    if (out_item_index) *out_item_index = item;
    return 1;
}

/* ---- 우클릭 컨텍스트 메뉴 ---- */
static int ctx_menu_item_count(void) {
    return (g_ctx_menu_target == -1) ? DESKTOP_CTX_ITEMS : WINDOW_CTX_ITEMS;
}

void wm_open_context_menu(int x, int y, int window_idx) {
    if (!g_con) return;
    g_ctx_menu_open = 1;
    g_ctx_menu_target = window_idx;
    g_ctx_menu_x = x;
    g_ctx_menu_y = y;
    /* 화면 밖으로 나가지 않도록 보정 */
    int menu_h = ctx_menu_item_count() * MENU_ITEM_H + 4;
    if (g_ctx_menu_x + CTX_MENU_W > (int)g_con->width) g_ctx_menu_x = (int)g_con->width - CTX_MENU_W;
    if (g_ctx_menu_y + menu_h > (int)g_con->height - WM_TASKBAR_H)
        g_ctx_menu_y = (int)g_con->height - WM_TASKBAR_H - menu_h;
    if (g_ctx_menu_x < 0) g_ctx_menu_x = 0;
    if (g_ctx_menu_y < 0) g_ctx_menu_y = 0;
    g_start_menu_open = 0;
}

void wm_close_context_menu(void) { g_ctx_menu_open = 0; g_ctx_menu_target = -1; }
int  wm_is_context_menu_open(void) { return g_ctx_menu_open; }
int  wm_context_menu_target(void) { return g_ctx_menu_target; }

int wm_hit_context_menu(int x, int y) {
    if (!g_ctx_menu_open) return 0;
    int menu_h = ctx_menu_item_count() * MENU_ITEM_H + 4;
    return (x >= g_ctx_menu_x && x < g_ctx_menu_x + CTX_MENU_W &&
            y >= g_ctx_menu_y && y < g_ctx_menu_y + menu_h);
}

int wm_hit_context_menu_item(int x, int y, int *out_item_index) {
    if (!wm_hit_context_menu(x, y)) return 0;
    int item = (y - g_ctx_menu_y - 2) / MENU_ITEM_H;
    int n = ctx_menu_item_count();
    if (item < 0 || item >= n) return 0;
    if (out_item_index) *out_item_index = item;
    return 1;
}

/* ---- 렌더링 헬퍼 ---- */
static void fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint32_t c) {
    console_fill_rect(g_con, x, y, w, h, c);
}

static void hline(int x, int y, int w, uint32_t c) {
    if (y < 0 || y >= (int)g_con->height) return;
    for (int i = 0; i < w; i++) {
        if (x + i >= 0 && x + i < (int)g_con->width)
            console_put_pixel(g_con, (uint32_t)(x + i), (uint32_t)y, c);
    }
}

static void vline(int x, int y, int h, uint32_t c) {
    if (x < 0 || x >= (int)g_con->width) return;
    for (int i = 0; i < h; i++) {
        if (y + i >= 0 && y + i < (int)g_con->height)
            console_put_pixel(g_con, (uint32_t)x, (uint32_t)(y + i), c);
    }
}

/* Milestone 21: "절대 단색 안 됨" 요구사항 대응 — 사각 영역을 왼쪽→
 * 오른쪽 색상으로 선형 보간해 채우는 헬퍼. 세로 그라디언트가 필요하면
 * 폭을 1로 여러 번 부르는 대신 draw_titlebar_gradient처럼 밴드 단위로
 * 직접 호출하면 된다 — 이 함수는 가로 방향 전용(작업표시줄/시작버튼처럼
 * 넓고 얇은 가로 띠에 쓰기 좋음). RGB 각 채널을 정수 보간한다. */
static void fill_gradient_h(int x, int y, int w, int h, uint32_t c0, uint32_t c1) {
    if (w <= 0 || h <= 0) return;
    int r0 = (c0 >> 16) & 0xFF, g0 = (c0 >> 8) & 0xFF, b0 = c0 & 0xFF;
    int r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
    for (int i = 0; i < w; i++) {
        int r = r0 + (r1 - r0) * i / (w > 1 ? w - 1 : 1);
        int g = g0 + (g1 - g0) * i / (w > 1 ? w - 1 : 1);
        int b = b0 + (b1 - b0) * i / (w > 1 ? w - 1 : 1);
        uint32_t col = ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
        fill((uint32_t)(x + i), (uint32_t)y, 1, (uint32_t)h, col);
    }
}

static void draw_text(int x, int y, const char *s, uint32_t color) {
    if (!s || !g_con) return;
    g_con->cursor_x = (uint32_t)x;
    g_con->cursor_y = (uint32_t)y;
    uint32_t saved = g_con->fg_color;
    g_con->fg_color = color;
    console_print(g_con, s);
    g_con->fg_color = saved;
}

/* Milestone 17: 단색 배경 대신 그라디언트 벽지.
 * Milestone 21: "색깔이 단색이면 안 된다" 요구사항 + "배경화면"
 * 요청에 맞춰 단일 톤 세로 그라디언트에서 3구간(인디고→마젠타→
 * 주황빛 노을) 다색 그라디언트로 다시 그렸다. 여전히 2픽셀 밴드
 * 단위라 매 프레임 다시 그려도 가볍다. */
static uint32_t isqrt64(uint64_t n) {
    if (n == 0) return 0;
    uint64_t x = n, y = (x + 1) / 2;
    while (y < x) { x = y; y = (x + n / x) / 2; }
    return (uint32_t)x;
}

static void lerp_rgb(uint32_t c0, uint32_t c1, int t, int max, int *r, int *g, int *b) {
    int r0 = (c0 >> 16) & 0xFF, g0 = (c0 >> 8) & 0xFF, b0 = c0 & 0xFF;
    int r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
    if (max < 1) max = 1;
    *r = r0 + (r1 - r0) * t / max;
    *g = g0 + (g1 - g0) * t / max;
    *b = b0 + (b1 - b0) * t / max;
}

static void draw_wallpaper(void) {
    uint32_t w = g_con->width, h = g_con->height;
    if (h == 0) return;

    /* 3개 색상 정점을 위→아래로: 짙은 인디고 → 노을 마젠타 → 따뜻한
     * 주황. 화면을 절반씩 나눠 각 구간에서 선형 보간한다. */
    const uint32_t top    = 0x00201040; /* 짙은 인디고 */
    const uint32_t mid    = 0x00602868; /* 노을 마젠타 */
    const uint32_t bottom = 0x00885030; /* 따뜻한 주황빛 갈색(노을 아랫단) */
    uint32_t half = h / 2;

    for (uint32_t y = 0; y < h; y += 2) {
        int r, g, b;
        if (y < half) {
            lerp_rgb(top, mid, (int)y, (int)half, &r, &g, &b);
        } else {
            lerp_rgb(mid, bottom, (int)(y - half), (int)(h - half), &r, &g, &b);
        }
        uint32_t color = ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
        fill(0, y, w, 2, color);
    }

    /* 은은한 "태양/달" 원 — 오른쪽 위, 배경보다 살짝 밝은 단색 원반이
     * 아니라 중심에서 바깥으로 밝기가 줄어드는 원형 그라디언트로 그려
     * 여기도 단색이 되지 않게 한다. Milestone 23: 가장자리를 계단현상
     * 없이 매끄럽게 — isqrt로 실제 거리(8.8 고정소수점)를 구해 반지름
     * ±0.5px 폭의 경계 밴드에서 배경과 서서히 섞이도록 한다. */
    int sun_cx = (int)w - 140, sun_cy = 90, sun_r = 46;
    for (int dy = -sun_r - 1; dy <= sun_r + 1; dy++) {
        int yy = sun_cy + dy;
        if (yy < 0 || yy >= (int)h) continue;
        for (int dx = -sun_r - 1; dx <= sun_r + 1; dx++) {
            uint64_t dist2 = (uint64_t)(dx * dx + dy * dy);
            uint32_t dist256 = isqrt64(dist2 << 16); /* dist * 256, 8.8 고정소수점 */
            int32_t edge = (int32_t)(sun_r * 256 - (int32_t)dist256) + 128;
            if (edge <= 0) continue;      /* 완전히 바깥 */
            if (edge > 256) edge = 256;   /* 완전히 안쪽 */

            int dist2i = dx * dx + dy * dy;
            int t = (dist2i * 100) / (sun_r * sun_r);
            if (t > 100) t = 100;
            int r2, g2, b2;
            lerp_rgb(0x00FFE8A0 /* 중심: 밝은 크림 */, 0x00E07850 /* 가장자리: 노을빛 */, t, 100, &r2, &g2, &b2);
            uint32_t col = ((uint32_t)r2 << 16) | ((uint32_t)g2 << 8) | (uint32_t)b2;
            console_blend_pixel(g_con, sun_cx + dx, yy, edge, col);
        }
    }
}

/* ---- 데스크톱 아이콘 (Milestone 17) ---- */
#define DESKTOP_ICON_COUNT 6
#define ICON_CELL_H 68
#define ICON_BOX 32
#define ICON_X 20

typedef struct { const char *label; int kind; } desktop_icon_def_t;
static const desktop_icon_def_t DESKTOP_ICONS[DESKTOP_ICON_COUNT] = {
    { "File Mgr",  0 },
    { "Terminal",  1 },
    { "Settings",  2 },
    { "Task Mgr",  3 },
    { "Clock",     4 },
    { "Browser",   5 },
};

static void icon_rect(int i, int *x, int *y) {
    *x = ICON_X;
    *y = 20 + i * ICON_CELL_H;
}

static void draw_icon_glyph(int x, int y, int kind) {
    uint32_t line = 0x00D8E4F0;
    switch (kind) {
        case 0: /* File Manager: 폴더 */
            fill((uint32_t)x, (uint32_t)(y + 6), 6, 4, 0x00E0B84A);
            fill((uint32_t)x, (uint32_t)(y + 10), ICON_BOX, ICON_BOX - 14, 0x00F0C860);
            hline(x, y + 10, ICON_BOX, 0x00A07830);
            hline(x, y + ICON_BOX - 4, ICON_BOX, 0x00A07830);
            break;
        case 1: /* Terminal: 검은 박스 + ">_" */
            fill((uint32_t)x, (uint32_t)y, ICON_BOX, ICON_BOX, 0x00101820);
            hline(x, y, ICON_BOX, line); hline(x, y + ICON_BOX - 1, ICON_BOX, line);
            vline(x, y, ICON_BOX, line); vline(x + ICON_BOX - 1, y, ICON_BOX, line);
            draw_text(x + 4, y + 12, ">_", 0x0040FF80);
            break;
        case 2: /* Settings: 톱니(다이아몬드로 단순화) */
            for (int i = 0; i < ICON_BOX / 2; i++) {
                hline(x + ICON_BOX / 2 - i, y + i, i * 2, 0x00A0B0C0);
                hline(x + ICON_BOX / 2 - i, y + ICON_BOX - 1 - i, i * 2, 0x00A0B0C0);
            }
            fill((uint32_t)(x + ICON_BOX / 2 - 4), (uint32_t)(y + ICON_BOX / 2 - 4), 8, 8, 0x00303840);
            break;
        case 3: /* Task Manager: 막대그래프 */
            fill((uint32_t)(x + 2), (uint32_t)(y + ICON_BOX - 10), 5, 10, 0x006090E0);
            fill((uint32_t)(x + 10), (uint32_t)(y + ICON_BOX - 18), 5, 18, 0x0060C090);
            fill((uint32_t)(x + 18), (uint32_t)(y + ICON_BOX - 14), 5, 14, 0x00E0A050);
            fill((uint32_t)(x + 26), (uint32_t)(y + ICON_BOX - 22), 5, 22, 0x00E06060);
            break;
        case 4: /* Clock: 원형(팔각 근사) + 바늘 */
            fill((uint32_t)(x + 6), (uint32_t)(y + 2), ICON_BOX - 12, ICON_BOX - 4, 0x00E8E8E8);
            fill((uint32_t)(x + 2), (uint32_t)(y + 6), ICON_BOX - 4, ICON_BOX - 12, 0x00E8E8E8);
            vline(x + ICON_BOX / 2, y + 6, ICON_BOX / 2 - 6, 0x00202020);
            hline(x + ICON_BOX / 2, y + ICON_BOX / 2, 7, 0x00202020);
            break;
        case 5: /* Browser: 지구본(원 + 가로/세로 선) */
            fill((uint32_t)(x + 6), (uint32_t)(y + 2), ICON_BOX - 12, ICON_BOX - 4, 0x004090D0);
            fill((uint32_t)(x + 2), (uint32_t)(y + 6), ICON_BOX - 4, ICON_BOX - 12, 0x004090D0);
            hline(x + 3, y + ICON_BOX / 2, ICON_BOX - 6, 0x0020608F);
            vline(x + ICON_BOX / 2, y + 3, ICON_BOX - 6, 0x0020608F);
            break;
    }
}

static void draw_desktop_icons(void) {
    for (int i = 0; i < DESKTOP_ICON_COUNT; i++) {
        int x, y; icon_rect(i, &x, &y);
        draw_icon_glyph(x, y, DESKTOP_ICONS[i].kind);
        /* 라벨: 아이콘 중앙 정렬 근사(짧은 라벨이라 좌측 정렬로도 충분히 붙어보임) */
        draw_text(x - 4, y + ICON_BOX + 4, DESKTOP_ICONS[i].label, THEME_TEXT_SECONDARY);
    }
}

/* 더블클릭 판정: 같은 아이콘을 짧은 시간(400ms=40틱) 안에 두 번 클릭하면
 * 그 아이콘 인덱스를 반환하고 상태를 리셋한다. 아니면 -1(아직 첫
 * 클릭으로만 기록). 데스크톱 빈 곳을 클릭했을 때만 desktop.c가 이
 * 함수를 부른다. */
static int g_icon_armed = -1;
static uint64_t g_icon_armed_tick = 0;

int wm_desktop_icon_hit(int x, int y) {
    for (int i = 0; i < DESKTOP_ICON_COUNT; i++) {
        int ix, iy; icon_rect(i, &ix, &iy);
        if (x >= ix - 6 && x < ix + ICON_BOX + 6 && y >= iy - 2 && y < iy + ICON_BOX + 16) return i;
    }
    return -1;
}

int wm_desktop_icon_double_click(int x, int y) {
    int idx = wm_desktop_icon_hit(x, y);
    if (idx < 0) { g_icon_armed = -1; return -1; }
    uint64_t now = g_timer_ticks;
    if (g_icon_armed == idx && (now - g_icon_armed_tick) < 40) {
        g_icon_armed = -1;
        return idx;
    }
    g_icon_armed = idx;
    g_icon_armed_tick = now;
    return -1;
}

/* 타이틀바 그라데이션 효과: 위→아래로 점점 어두워지는 2단 그라데이션 */
static void draw_titlebar_gradient(int x, int y, int w, uint32_t base) {
    int h = WM_TITLEBAR_H;
    for (int row = 0; row < h; row++) {
        /* base에서 row가 늘어날수록 R/G/B 각 채널을 약간씩 어둡게 */
        int dim = (row * 30) / h;
        uint32_t r = ((base >> 16) & 0xFF);
        uint32_t g = ((base >> 8) & 0xFF);
        uint32_t b = ((base) & 0xFF);
        r = (r > dim) ? r - dim : 0;
        g = (g > dim) ? g - dim : 0;
        b = (b > dim) ? b - dim : 0;
        uint32_t c = (r << 16) | (g << 8) | b;
        for (int col = 0; col < w; col++) {
            console_put_pixel(g_con, (uint32_t)(x + col), (uint32_t)(y + row), c);
        }
    }
}

/* 창 X 버튼 (닫기) */
static void draw_close_btn(int wx, int wy, int ww) {
    int bx = wx + ww - 18;
    int by = wy + 3;
    fill((uint32_t)bx, (uint32_t)by, 14, 12, 0x00803030);
    /* 작은 X */
    console_put_pixel(g_con, (uint32_t)(bx+3),(uint32_t)(by+2), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+4),(uint32_t)(by+3), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+5),(uint32_t)(by+4), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+6),(uint32_t)(by+5), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+7),(uint32_t)(by+4), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+8),(uint32_t)(by+3), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+9),(uint32_t)(by+2), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+9),(uint32_t)(by+8), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+8),(uint32_t)(by+7), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+7),(uint32_t)(by+6), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+5),(uint32_t)(by+6), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+4),(uint32_t)(by+7), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+3),(uint32_t)(by+8), 0x00FFFFFF);
}

/* JetOS 스타일 창의 최소화(_)/최대화(o)/복원(r) 버튼. offset_from_close는
 * 닫기 버튼 왼쪽으로 몇 픽셀 떨어졌는지(16=최소화, 32=최대화 위치). */
static void draw_min_max_btn(int wx, int wy, int ww, int offset_from_close, char glyph) {
    int bx = wx + ww - 18 - offset_from_close;
    int by = wy + 3;
    fill((uint32_t)bx, (uint32_t)by, 14, 12, 0x00304050);
    hline(bx, by, 14, 0x00405868);
    hline(bx, by + 11, 14, 0x00203040);
    uint32_t c = 0x00D8E8F8;
    if (glyph == '_') {
        hline(bx + 3, by + 8, 8, c);
    } else if (glyph == 'o') {
        hline(bx + 3, by + 3, 8, c); hline(bx + 3, by + 8, 8, c);
        vline(bx + 3, by + 3, 6, c); vline(bx + 10, by + 3, 6, c);
    } else { /* 'r' = 복원(작은 겹친 사각형) */
        hline(bx + 3, by + 2, 6, c); vline(bx + 3, by + 2, 5, c); vline(bx + 8, by + 2, 5, c); hline(bx+3,by+6,6,c);
        hline(bx + 5, by + 5, 6, c); vline(bx + 5, by + 5, 4, c); vline(bx + 10, by + 5, 4, c); hline(bx+5,by+8,6,c);
    }
}

/* ---- Win32(PE EXE) 스타일 창 렌더링: 클래식 Windows 95/98 느낌 ----
 * CreateWindowA()로 만들어진 창(win32_style=1)은 JetOS 고유의 어두운
 * 청회색 테마 대신, 밝은 회색 3D 베벨 + 네이비 타이틀바로 그린다 —
 * "익숙한 Windows 느낌"을 위해 Win32 호환 레이어가 만든 창임을
 * 시각적으로도 구분해준다. */
#define WIN32_FACE       0x00C0C0C0u /* 표준 버튼/배경 회색 */
#define WIN32_HIGHLIGHT  0x00FFFFFFu /* 베벨 밝은 쪽 */
#define WIN32_SHADOW     0x00808080u /* 베벨 어두운 쪽 */
#define WIN32_DARKSHADOW 0x00404040u
#define WIN32_TITLE_ACTIVE   0x00000080u /* 네이비 */
#define WIN32_TITLE_INACTIVE 0x00808080u

static void win32_bevel_rect(int x, int y, int w, int h, int raised) {
    uint32_t top_left = raised ? WIN32_HIGHLIGHT : WIN32_DARKSHADOW;
    uint32_t bot_right = raised ? WIN32_DARKSHADOW : WIN32_HIGHLIGHT;
    hline(x, y, w, top_left);
    vline(x, y, h, top_left);
    hline(x, y + h - 1, w, bot_right);
    vline(x + w - 1, y, h, bot_right);
}

static void win32_titlebar_button(int x, int y, char glyph) {
    /* 14x12짜리 작은 버튼 (최소화/최대화/닫기 공용 모양), glyph는
     * '_'(최소화), 'o'(최대화), 'x'(닫기)로 간단히 표시 */
    fill((uint32_t)x, (uint32_t)y, 14, 12, WIN32_FACE);
    win32_bevel_rect(x, y, 14, 12, 1);
    uint32_t c = 0x00000000;
    if (glyph == '_') {
        hline(x + 3, y + 8, 8, c);
    } else if (glyph == 'o') {
        hline(x + 3, y + 3, 8, c);
        hline(x + 3, y + 8, 8, c);
        vline(x + 3, y + 3, 6, c);
        vline(x + 10, y + 3, 6, c);
    } else { /* 'x' */
        for (int i = 0; i < 7; i++) {
            console_put_pixel(g_con, (uint32_t)(x + 3 + i), (uint32_t)(y + 2 + i), c);
            console_put_pixel(g_con, (uint32_t)(x + 3 + i), (uint32_t)(y + 8 - i), c);
        }
    }
}

static void draw_win32_window(wm_window_t *w, int focused) {
    int fx = w->x, fy = w->y, fw = w->w, fh = w->h + WM_TITLEBAR_H;

    /* 바깥 3D 베벨(창 전체 프레임) */
    fill((uint32_t)(fx - 2), (uint32_t)(fy - 2), fw + 4, fh + 4, WIN32_FACE);
    win32_bevel_rect(fx - 2, fy - 2, fw + 4, fh + 4, 1);
    win32_bevel_rect(fx - 1, fy - 1, fw + 2, fh + 2, 1);

    /* 타이틀바 */
    uint32_t tcolor = focused ? WIN32_TITLE_ACTIVE : WIN32_TITLE_INACTIVE;
    fill((uint32_t)fx, (uint32_t)fy, fw, WM_TITLEBAR_H, tcolor);
    draw_text(fx + 4, fy + 5, w->title, 0x00FFFFFF);

    /* 최소화/최대화/닫기 버튼 3개 (오른쪽 정렬) — 실제 클릭 판정은
     * wm_hit_close_button()이 쓰는 위치(맨 오른쪽 X)와 맞춰둔다 */
    int bx = fx + fw - 18 - 1;
    win32_titlebar_button(bx, fy + 3, 'x');
    win32_titlebar_button(bx - 16, fy + 3, 'o');
    win32_titlebar_button(bx - 32, fy + 3, '_');

    /* 클라이언트 영역: 안쪽으로 살짝 파인 베벨 + 밝은 회색 배경 */
    int cy = fy + WM_TITLEBAR_H;
    fill((uint32_t)fx, (uint32_t)cy, fw, w->h, WIN32_FACE);
    win32_bevel_rect(fx, cy, fw, w->h, 0);

    /* 크기 조절 손잡이 */
    {
        int gx = fx + fw - 8, gy = cy + w->h - 8;
        for (int k = 0; k < 3; k++) {
            hline(gx + k * 2, gy + 6 - k * 2, 2, WIN32_DARKSHADOW);
        }
    }
}

/* Milestone 25(M23 예고분, 실제로는 보안 작업에 밀려 M26에서 처리):
 * 작업표시줄 아이콘 중 곡선/대각선이 있는 것들(별/날씨 원·구름/스피커)에
 * 안티에일리어싱 적용. 신호 막대는 순수 축정렬 사각형이라 원래도 계단
 * 현상이 없어서 그대로 둔다(적용할 게 없음 — 아래 draw_network_icon
 * 참고).
 *
 * 별과 스피커 나팔부는 원이 아니라 다각형이라 배경 태양(M23)에 쓴
 * "중심 거리 기반 isqrt 블렌딩"을 그대로 쓸 수 없다. 대신 여기서는
 * 다각형을 삼각형들로 쪼갠 뒤, 픽셀 하나당 4x4(=16) 서브샘플을 찍어
 * "그 중 몇 개가 다각형 안에 들어가는지" 비율을 커버리지로 써서
 * console_blend_pixel로 섞는 방식(supersampling)을 쓴다 — 다각형 전체
 * 모양에 상관없이 적용 가능해서 별(10개 삼각형 부채꼴)과 스피커
 * 나팔부(사다리꼴, 삼각형 2개) 둘 다 같은 헬퍼로 처리했다. */
static int sign_tri2(int px, int py, int ax, int ay, int bx, int by) {
    return (px - bx) * (ay - by) - (ax - bx) * (py - by);
}
static int point_in_triangle(int px, int py, int ax, int ay, int bx, int by, int cx2, int cy2) {
    int d1 = sign_tri2(px, py, ax, ay, bx, by);
    int d2 = sign_tri2(px, py, bx, by, cx2, cy2);
    int d3 = sign_tri2(px, py, cx2, cy2, ax, ay);
    int has_neg = (d1 < 0) || (d2 < 0) || (d3 < 0);
    int has_pos = (d1 > 0) || (d2 > 0) || (d3 > 0);
    return !(has_neg && has_pos);
}

#define POLY_SS 4              /* 픽셀당 4x4 서브샘플 */
#define POLY_F  (POLY_SS * 2)  /* 정수 고정소수점 배율(부동소수점 없이 서브픽셀 중심 좌표를 표현) */

/* 삼각형 목록(triangles[i] = {ax,ay,bx,by,cx,cy}, tri_count개)의 합집합을
 * bbox 범위에서 supersampling으로 채운다 — 삼각형들이 서로 겹치는
 * 내부 경계(부채꼴 인접면 등)에서도 이중 블렌딩 없이 한 픽셀당 한 번만
 * 섞이므로 이음매 얼룩이 생기지 않는다. */
static void fill_triangle_union_aa(const int tris[][6], int tri_count,
                                    int bbox_min_x, int bbox_min_y, int bbox_max_x, int bbox_max_y,
                                    uint32_t color) {
    for (int py = bbox_min_y; py <= bbox_max_y; py++) {
        for (int px = bbox_min_x; px <= bbox_max_x; px++) {
            int covered = 0;
            for (int sy = 0; sy < POLY_SS; sy++) {
                int spy = py * POLY_F + (2 * sy + 1);
                for (int sx = 0; sx < POLY_SS; sx++) {
                    int spx = px * POLY_F + (2 * sx + 1);
                    for (int t = 0; t < tri_count; t++) {
                        if (point_in_triangle(spx, spy,
                                               tris[t][0], tris[t][1],
                                               tris[t][2], tris[t][3],
                                               tris[t][4], tris[t][5])) {
                            covered++;
                            break; /* 이 서브샘플은 어차피 "안에 있음" 확정 — 다른 삼각형은 더 안 봐도 됨(합집합) */
                        }
                    }
                }
            }
            if (covered == 0) continue;
            int coverage256 = covered * 256 / (POLY_SS * POLY_SS);
            if (coverage256 > 256) coverage256 = 256;
            console_blend_pixel(g_con, px, py, coverage256, color);
        }
    }
}

/* 회색 별(시작 버튼용) — Windows의 4각 사각형 로고 대신 사용. 5개
 * 꼭짓점을 좌표로 직접 찍고 fill로 몸통을 채우는 대신, 작은 크기라
 * 방사형으로 픽셀을 찍는 방식이 더 깔끔하게 나온다. Milestone 26:
 * 예전엔 스캔라인 정수 채우기라 대각선 변에 계단현상이 있었는데,
 * fill_triangle_union_aa로 바꿔서 매끄럽게 그린다. */
static void draw_star(int cx, int cy, int r, uint32_t color) {
    /* 10개 정점(별 끝 5개 + 안쪽 5개)을 근사 좌표로 미리 계산해뒀다
     * (부동소수점 없이, r=7 기준 정수 좌표 — 다른 반지름에도 비율로
     * 대충 맞도록 8분율 근사). */
    static const int outer_x8[5] = { 0, 76, 47, -47, -76 };
    static const int outer_y8[5] = { -100, -31, 81, 81, -31 };
    static const int inner_x8[5] = { 0, 47, 29, -29, -47 };
    static const int inner_y8[5] = { -38, -12, 31, 31, -12 };

    int ox[5], oy[5], ix[5], iy[5];
    for (int i = 0; i < 5; i++) {
        ox[i] = cx + outer_x8[i] * r / 100; oy[i] = cy + outer_y8[i] * r / 100;
        ix[i] = cx + inner_x8[i] * r / 100; iy[i] = cy + inner_y8[i] * r / 100;
    }

    int tris[10][6];
    for (int i = 0; i < 5; i++) {
        int i2 = (i + 4) % 5; /* 이전 안쪽 꼭짓점(부채꼴 반대편) */
        /* 중심-바깥꼭짓점-안쪽꼭짓점(양쪽) 삼각형 2개 */
        tris[i * 2 + 0][0] = cx * POLY_F; tris[i * 2 + 0][1] = cy * POLY_F;
        tris[i * 2 + 0][2] = ox[i] * POLY_F; tris[i * 2 + 0][3] = oy[i] * POLY_F;
        tris[i * 2 + 0][4] = ix[i] * POLY_F; tris[i * 2 + 0][5] = iy[i] * POLY_F;

        tris[i * 2 + 1][0] = cx * POLY_F; tris[i * 2 + 1][1] = cy * POLY_F;
        tris[i * 2 + 1][2] = ox[i] * POLY_F; tris[i * 2 + 1][3] = oy[i] * POLY_F;
        tris[i * 2 + 1][4] = ix[i2] * POLY_F; tris[i * 2 + 1][5] = iy[i2] * POLY_F;
    }
    fill_triangle_union_aa(tris, 10, cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1, color);
}

/* 태양+구름 (날씨 위젯용). Milestone 26: 원형 부분(태양 몸체, 구름
 * 오른쪽 둥근 부분)을 배경화면 태양(M23, draw_wallpaper 참고)과 같은
 * isqrt 거리 기반 서브픽셀 블렌딩으로 다시 그렸다. 사각형인 구름 본체는
 * 원래도 계단현상이 없어 그대로 fill 사용. */
static void draw_weather_icon(int x, int y, uint32_t sun_color, uint32_t cloud_color) {
    /* 태양 몸체(반지름 4) — 가장자리를 isqrt 거리로 부드럽게 */
    int sun_r = 4;
    for (int dy = -sun_r - 1; dy <= sun_r + 1; dy++) {
        for (int dx = -sun_r - 1; dx <= sun_r + 1; dx++) {
            uint32_t dist2 = (uint32_t)(dx * dx + dy * dy);
            uint32_t dist256 = isqrt64((uint64_t)dist2 << 16);
            int32_t edge = (int32_t)(sun_r * 256 - (int32_t)dist256) + 128;
            if (edge <= 0) continue;
            if (edge > 256) edge = 256;
            console_blend_pixel(g_con, x + dx, y + dy, edge, sun_color);
        }
    }
    /* 짧은 광선 4개(단일 픽셀이라 안티에일리어싱 대상 아님) */
    console_put_pixel(g_con, (uint32_t)x, (uint32_t)(y - 7), sun_color);
    console_put_pixel(g_con, (uint32_t)x, (uint32_t)(y + 7), sun_color);
    console_put_pixel(g_con, (uint32_t)(x - 7), (uint32_t)y, sun_color);
    console_put_pixel(g_con, (uint32_t)(x + 7), (uint32_t)y, sun_color);

    /* 구름: 사각 본체(축정렬이라 원래도 매끈함) + 오른쪽 둥근 부분(원,
     * isqrt 블렌딩으로 매끈하게) */
    fill((uint32_t)(x + 2), (uint32_t)(y + 3), 10, 5, cloud_color);
    int bump_cx = x + 6, bump_cy = y + 3, bump_r = 3;
    for (int dy = -bump_r - 1; dy <= bump_r + 1; dy++) {
        for (int dx = -bump_r - 1; dx <= bump_r + 1; dx++) {
            uint32_t dist2 = (uint32_t)(dx * dx + dy * dy);
            uint32_t dist256 = isqrt64((uint64_t)dist2 << 16);
            int32_t edge = (int32_t)(bump_r * 256 - (int32_t)dist256) + 128;
            if (edge <= 0) continue;
            if (edge > 256) edge = 256;
            console_blend_pixel(g_con, bump_cx + dx, bump_cy + dy, edge, cloud_color);
        }
    }
}

/* 스피커(음량 위젯용) — 사각 몸통(축정렬, 그대로 fill) + 사다리꼴
 * 나팔부. Milestone 26: 나팔부가 대각선 두 변을 가진 사다리꼴이라
 * 계단현상이 있었는데, 사다리꼴을 삼각형 2개로 쪼개 fill_triangle_union_aa로
 * 다시 그렸다(별과 같은 헬퍼 재사용). */
static void draw_speaker_icon(int x, int y, uint32_t color) {
    fill((uint32_t)x, (uint32_t)(y - 2), 4, 4, color);

    /* 나팔부 사다리꼴 네 꼭짓점: 왼쪽위/왼쪽아래(몸통과 맞닿는 짧은 변) →
     * 오른쪽위/오른쪽아래(벌어진 긴 변). 예전 vline 루프(i=0..4, x+4+i,
     * y-2-i/2 ~ y+2+i/2)가 그리던 모양을 그대로 사다리꼴 꼭짓점으로 옮김. */
    int lx = x + 4, ltop = y - 2, lbot = y + 2;
    int rx = x + 8, rtop = y - 4, rbot = y + 4;
    int tris[2][6] = {
        { lx * POLY_F, ltop * POLY_F, rx * POLY_F, rtop * POLY_F, lx * POLY_F, lbot * POLY_F },
        { rx * POLY_F, rtop * POLY_F, rx * POLY_F, rbot * POLY_F, lx * POLY_F, lbot * POLY_F },
    };
    fill_triangle_union_aa(tris, 2, lx - 1, rtop - 1, rx + 1, rbot + 1, color);

    /* 음파(오른쪽 위 작은 호 2개 — 단일 픽셀 점 근사, 안티에일리어싱
     * 대상 아님) */
    console_put_pixel(g_con, (uint32_t)(x + 11), (uint32_t)(y - 3), color);
    console_put_pixel(g_con, (uint32_t)(x + 12), (uint32_t)y, color);
    console_put_pixel(g_con, (uint32_t)(x + 11), (uint32_t)(y + 3), color);
    console_put_pixel(g_con, (uint32_t)(x + 14), (uint32_t)(y - 5), color);
    console_put_pixel(g_con, (uint32_t)(x + 15), (uint32_t)y, color);
    console_put_pixel(g_con, (uint32_t)(x + 14), (uint32_t)(y + 5), color);
}

/* 신호 막대(네트워크 위젯용) — net_available()에 따라 실제로 색이
 * 바뀐다(꺼져 있으면 회색, 켜져 있으면 초록) — 이 셋 중 유일하게
 * 장식이 아니라 실데이터를 반영하는 위젯. Milestone 26: 다른 세
 * 아이콘과 달리 안티에일리어싱을 적용하지 않았다 — 막대가 전부
 * 축정렬 사각형(fill)이라 애초에 대각선/곡선이 없고, 따라서 계단현상
 * 자체가 존재하지 않는다(적용할 대상이 없음 — M23/M24 문서가 예고한
 * "나머지 아이콘"의 마지막 항목이었지만, 확인해보니 실제로는 손댈
 * 부분이 없었다는 뜻). */
static void draw_network_icon(int x, int y, int connected) {
    uint32_t color = connected ? 0x0050D080u : 0x00707070u;
    for (int bar = 0; bar < 4; bar++) {
        int bh = 3 + bar * 3;
        uint32_t c = connected ? color : (bar < 1 ? color : 0x00404040u);
        fill((uint32_t)(x + bar * 5), (uint32_t)(y + (14 - bh)), 3, (uint32_t)bh, c);
    }
}


/* 마우스 커서 (Milestone 21: Windows 클래식 스타일 흰색 채움 + 검은
 * 테두리 화살표로 다시 그림 — 예전엔 5x8짜리 작은 얼룩에 가까운
 * 모양이었다). 13x16 비트맵: 'B'=검은 테두리, 'W'=흰색 채움,
 * '.'=투명. 핫스팟(클릭 지점)은 왼쪽 위 꼭짓점(0,0). */
static const char *CURSOR_BITMAP[16] = {
    "B............",
    "BB...........",
    "BWB..........",
    "BWWB.........",
    "BWWWB........",
    "BWWWWB.......",
    "BWWWWWB......",
    "BWWWWWWB.....",
    "BWWWWWWWB....",
    "BWWWWWWWWB...",
    "BWWWWWWWWWB..",
    "BWWWWWBBBBBB.",
    "BWWBWWB......",
    "BWB.BWWB.....",
    "BB...BWWB....",
    ".......BB....",
};

static void draw_cursor(void) {
    int cx = g_cursor_x, cy = g_cursor_y;
    for (int row = 0; row < 16; row++) {
        const char *line = CURSOR_BITMAP[row];
        for (int col = 0; line[col] != '\0'; col++) {
            char c = line[col];
            if (c == '.') continue;
            uint32_t color = (c == 'B') ? 0x00000000u : THEME_CURSOR_COLOR;
            console_put_pixel(g_con, (uint32_t)(cx + col), (uint32_t)(cy + row), color);
        }
    }
}

void wm_draw(void) {
    if (!g_con) return;

    /* 데스크탑 배경 — Milestone 17: 단색 대신 은은한 대각선 그라디언트
     * 벽지. 매 프레임 다시 그리지만 단순한 픽셀 연산이라 비용은 작다. */
    draw_wallpaper();
    draw_desktop_icons();

    /* 창 렌더링 (뒤→앞) */
    for (int i = 0; i < g_window_count; i++) {
        wm_window_t *w = &g_windows[g_order[i]];
        if (!w->visible) continue;
        int focused = (g_order[i] == g_focused_idx);
        uint32_t title_color = focused ? theme_title_active() : THEME_WIN_TITLE_INACTIVE;

        if (w->win32_style) {
            draw_win32_window(w, focused);
            if (w->content_cb) {
                w->content_cb(g_con, w->x, w->y + WM_TITLEBAR_H, w->w, w->h, w->content_ctx);
            }
            continue;
        }

        /* 창 바깥 테두리 */
        hline(w->x - BORDER_SZ, w->y - BORDER_SZ, w->w + BORDER_SZ * 2 + 1, THEME_WIN_BORDER);
        hline(w->x - BORDER_SZ, w->y + WM_TITLEBAR_H + w->h + BORDER_SZ, w->w + BORDER_SZ * 2 + 1, THEME_WIN_BORDER);
        vline(w->x - BORDER_SZ, w->y, w->h + WM_TITLEBAR_H + BORDER_SZ, THEME_WIN_BORDER);
        vline(w->x + w->w + BORDER_SZ - 1, w->y, w->h + WM_TITLEBAR_H + BORDER_SZ, THEME_WIN_BORDER);

        /* 타이틀바 (그라데이션) */
        draw_titlebar_gradient(w->x, w->y, w->w, title_color);

        /* 타이틀바 하단 구분선 */
        hline(w->x, w->y + WM_TITLEBAR_H - 1, w->w, THEME_WIN_BORDER);

        /* 타이틀 텍스트 */
        draw_text(w->x + 8, w->y + 5, w->title, THEME_WIN_TITLE_TEXT);

        /* 닫기 버튼 */
        draw_close_btn(w->x, w->y, w->w);
        /* 최소화/최대화 버튼 (Milestone 18) */
        draw_min_max_btn(w->x, w->y, w->w, 16, '_'); /* 최소화 */
        draw_min_max_btn(w->x, w->y, w->w, 32, w->maximized ? 'r' : 'o'); /* 최대화/복원 */

        /* 창 본문 */
        fill((uint32_t)w->x, (uint32_t)(w->y + WM_TITLEBAR_H),
              (uint32_t)w->w, (uint32_t)w->h, THEME_WIN_CLIENT);

        /* 내용 콜백 (스크롤 중이면 content_cb 내부에서 wm_get_scroll(idx)로
         * 오프셋을 얻어 그 줄부터 그린다 — 시그니처 하위호환 유지) */
        if (w->content_cb) {
            w->content_cb(g_con, w->x, w->y + WM_TITLEBAR_H, w->w, w->h, w->content_ctx);
        }

        /* 스크롤바 (Milestone 19) — content_h가 설정된 창만 그린다 */
        if (w->content_h > w->h) {
            int sx = w->x + w->w - WM_SCROLLBAR_W;
            int sy0 = w->y + WM_TITLEBAR_H;
            fill((uint32_t)sx, (uint32_t)sy0, WM_SCROLLBAR_W, (uint32_t)w->h, THEME_WIN_BORDER);
            int thumb_h = (w->h * w->h) / w->content_h;
            if (thumb_h < 12) thumb_h = 12;
            int usable = w->h - thumb_h;
            if (usable < 1) usable = 1;
            int max_scroll = w->content_h - w->h;
            int thumb_y = sy0 + (max_scroll > 0 ? (usable * w->scroll_y) / max_scroll : 0);
            fill((uint32_t)(sx + 1), (uint32_t)thumb_y, WM_SCROLLBAR_W - 2, (uint32_t)thumb_h, THEME_TEXT_HIGHLIGHT);
        }

        /* 크기 조절 손잡이(우하단 대각선 3줄) — Milestone 17 */
        {
            int gx = w->x + w->w - 8, gy = w->y + WM_TITLEBAR_H + w->h - 8;
            for (int k = 0; k < 3; k++) {
                hline(gx + k * 2, gy + 6 - k * 2, 2, THEME_WIN_BORDER);
            }
        }
    }

    /* 작업표시줄 (Milestone 21: 단색 배경 대신 가로 그라디언트) */
    int tbY = (int)g_con->height - WM_TASKBAR_H;
    fill_gradient_h(0, tbY, (int)g_con->width, WM_TASKBAR_H, 0x00181828, 0x00302840);
    hline(0, tbY, (int)g_con->width, THEME_TASKBAR_BORDER); /* 상단 구분선 */

    int icon_mid_y = tbY + WM_TASKBAR_H / 2;

    /* ---- 오른쪽 클러스터: 음량 | 시간 | 네트워크 (요청 순서 그대로,
     * 화면 맨 오른쪽이 네트워크가 되도록 배치) ---- */
    const int NET_W = 24, VOL_W = 22, CLOCK_W = 60, GAP = 10;
    int net_x = (int)g_con->width - NET_W - 8;
    int clock_x = net_x - CLOCK_W - GAP;
    int vol_x = clock_x - VOL_W - GAP;

    draw_network_icon(net_x, tbY + 7, net_available());
    draw_speaker_icon(vol_x, icon_mid_y, 0x00D8D8E0u);

    {
        rtc_time_t t;
        rtc_read(&t);
        char clk[6];
        clk[0] = (char)('0' + (t.hour / 10) % 10);
        clk[1] = (char)('0' + t.hour % 10);
        clk[2] = ':';
        clk[3] = (char)('0' + (t.minute / 10) % 10);
        clk[4] = (char)('0' + t.minute % 10);
        clk[5] = '\0';
        draw_text(clock_x, tbY + 6, clk, THEME_TEXT_HIGHLIGHT);
    }

    /* ---- 시작 버튼: Windows의 4각 사각형 로고 대신 회색 별 ---- */
    fill_gradient_h(0, tbY + 2, START_BTN_W - 4, WM_TASKBAR_H - 4, THEME_START_NORMAL, theme_accent());
    hline(0, tbY + 2, START_BTN_W - 4, theme_accent());
    hline(0, tbY + WM_TASKBAR_H - 3, START_BTN_W - 4, theme_accent());
    draw_star(16, icon_mid_y, 9, 0x00A8A8B0u); /* 회색 별 */
    draw_text(30, tbY + 6, "START", THEME_START_TEXT);

    /* ---- 맨 왼쪽(시작 버튼 바로 다음): 날씨 위젯 ----
     * 알려진 단순화: 실제 기상 데이터/네트워크 API가 아니라 고정
     * 표시값이다(오디오 드라이버가 없어서 음량도 마찬가지) — 이
     * 셋 중 네트워크 아이콘만 net_available()로 실제 상태를 반영한다. */
    const int WEATHER_X = START_BTN_W + 20;
    draw_weather_icon(WEATHER_X, icon_mid_y, 0x00FFD060u, 0x00D8D8E0u);
    draw_text(WEATHER_X + 14, tbY + 6, "22C", THEME_TEXT_HIGHLIGHT);
    const int WEATHER_W = 60;

    /* 창 목록 버튼 (날씨 위젯 다음부터, 그라디언트로) */
    int tx = WEATHER_X + WEATHER_W + 8;
    for (int i = 0; i < g_window_count; i++) {
        wm_window_t *w = &g_windows[g_order[i]];
        if (w->closed) continue;
        int active = (g_order[i] == g_focused_idx) && !w->minimized;
        uint32_t btn_c0 = active ? theme_taskbar_active() : THEME_TASKBAR_BTN_NORMAL;
        uint32_t btn_c1 = active ? theme_accent() : 0x00202030u;
        fill_gradient_h(tx, tbY + 2, TASKBAR_LABEL_W - 4, WM_TASKBAR_H - 4, btn_c0, btn_c1);
        if (active) hline(tx, tbY + 2, TASKBAR_LABEL_W - 4, theme_accent());
        draw_text(tx + 6, tbY + 7, w->title, active ? THEME_TEXT_HIGHLIGHT : THEME_TEXT_SECONDARY);
        tx += TASKBAR_LABEL_W;
    }

    /* 시작 메뉴 */
    if (g_start_menu_open) {
        int menu_w = START_BTN_W + 80;
        int menu_h = START_MENU_ITEMS * MENU_ITEM_H + 4;
        int menu_y = tbY - menu_h;
        fill(0, (uint32_t)menu_y, (uint32_t)menu_w, (uint32_t)menu_h, THEME_MENU_BG);
        hline(0, menu_y, menu_w, THEME_WIN_BORDER);
        vline(menu_w - 1, menu_y, menu_h, THEME_WIN_BORDER);
        for (int i = 0; i < START_MENU_ITEMS; i++) {
            int item_y = menu_y + 2 + i * MENU_ITEM_H;
            if (i == START_MENU_ITEMS - 1) { /* SHUTDOWN 앞에 구분선 */
                hline(4, item_y - 1, menu_w - 8, THEME_MENU_SEPARATOR);
            }
            draw_text(10, item_y + 5, START_MENU_LABELS[i], THEME_MENU_TEXT);
        }
    }

    /* 우클릭 컨텍스트 메뉴 */
    if (g_ctx_menu_open) {
        int n = ctx_menu_item_count();
        int menu_h = n * MENU_ITEM_H + 4;
        fill((uint32_t)g_ctx_menu_x, (uint32_t)g_ctx_menu_y, CTX_MENU_W, (uint32_t)menu_h, THEME_MENU_BG);
        hline(g_ctx_menu_x, g_ctx_menu_y, CTX_MENU_W, THEME_WIN_BORDER);
        vline(g_ctx_menu_x + CTX_MENU_W - 1, g_ctx_menu_y, menu_h, THEME_WIN_BORDER);
        vline(g_ctx_menu_x, g_ctx_menu_y, menu_h, THEME_WIN_BORDER);
        hline(g_ctx_menu_x, g_ctx_menu_y + menu_h - 1, CTX_MENU_W, THEME_WIN_BORDER);
        if (g_ctx_menu_target == -1) {
            for (int i = 0; i < DESKTOP_CTX_ITEMS; i++) {
                int item_y = g_ctx_menu_y + 2 + i * MENU_ITEM_H;
                draw_text(g_ctx_menu_x + 8, item_y + 5, START_MENU_LABELS[i], THEME_MENU_TEXT);
            }
        } else {
            int minimized = (g_ctx_menu_target >= 0 && g_ctx_menu_target < g_window_count)
                             ? g_windows[g_ctx_menu_target].minimized : 0;
            const char *labels[WINDOW_CTX_ITEMS] = { "Close", minimized ? "Restore" : "Minimize" };
            for (int i = 0; i < WINDOW_CTX_ITEMS; i++) {
                int item_y = g_ctx_menu_y + 2 + i * MENU_ITEM_H;
                draw_text(g_ctx_menu_x + 8, item_y + 5, labels[i], THEME_MENU_TEXT);
            }
        }
    }

    draw_cursor();
}

void wm_present(void) {
    if (!g_front || !g_con || !g_con->fb || !g_front->fb) return;
    uint32_t total = g_front->width * g_front->height;
    for (uint32_t i = 0; i < total; i++) g_front->fb[i] = g_con->fb[i];
}

console_t *wm_get_draw_console(void) { return g_con; }
