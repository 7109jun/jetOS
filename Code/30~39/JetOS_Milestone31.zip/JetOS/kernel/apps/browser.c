/*
 * JetOS - kernel/apps/browser.c
 * browser.h 참고. Milestone 11/12의 TCP/DNS 스택을 그대로 재사용해
 * 실제 HTTP GET을 하고, 아주 단순한 HTML 태그 제거만 거쳐 창에 보여준다.
 */

#include <stddef.h>
#include "browser.h"
#include "../../include/jetapi/jetapi.h"
#include "../gui/wm.h"
#include "../gui/widget.h"
#include "../drivers/console.h"
#include "../drivers/keyboard.h"
#include "../proc/scheduler.h"
#include "../mm/heap.h"
#include "../net/net.h"
#include "../net/tcp.h"
#include "../net/dns.h"
#include "../net/tls.h"

#define PAGE_BUF_SIZE 8192
#define ADDR_BAR_H 20

static char g_page_buf[PAGE_BUF_SIZE];
static char g_page_status[80] = "(no page loaded)";
static char g_page_url[80] = "";

/* Milestone 19: 주소창을 실제로 GUI에서 타이핑할 수 있게 됨(예전에는
 * jash 명령으로만 URL 지정 가능했던 한계 — wm의 키 포커스 라우팅
 * 일반화 덕분에 창 안의 특정 영역(주소창)만 키를 받게 나눌 수 있다). */
static widget_textbox_t g_addr_box;
static int g_addr_focused = 0;

/* 아주 단순한 HTML 태그 제거: '<'~'>' 사이는 전부 버리고, 몇 가지
 * 흔한 엔티티만 풀어준다. 실제 레이아웃/CSS/JS는 전혀 처리하지 않는다
 * — "텍스트만이라도 읽을 수 있게" 하는 수준의 단순화다. */
static void html_strip(const char *in, uint32_t in_len, char *out, uint32_t out_cap) {
    uint32_t o = 0;
    int in_tag = 0;
    for (uint32_t i = 0; i < in_len && o + 1 < out_cap; i++) {
        char c = in[i];
        if (c == '<') { in_tag = 1; continue; }
        if (c == '>') { in_tag = 0; continue; }
        if (in_tag) continue;

        if (c == '&' && i + 4 < in_len) {
            if (in[i+1]=='l' && in[i+2]=='t' && in[i+3]==';') { out[o++]='<'; i+=3; continue; }
            if (in[i+1]=='g' && in[i+2]=='t' && in[i+3]==';') { out[o++]='>'; i+=3; continue; }
            if (i+5<in_len && in[i+1]=='a' && in[i+2]=='m' && in[i+3]=='p' && in[i+4]==';') { out[o++]='&'; i+=4; continue; }
        }
        /* 공백/개행 연속을 하나로 압축 */
        if ((c == ' ' || c == '\n' || c == '\r' || c == '\t') && o > 0 && out[o-1] == '\n') continue;
        out[o++] = (c == '\r' || c == '\t') ? ' ' : c;
    }
    out[o] = '\0';
}

static void set_status(const char *s) {
    int i = 0;
    for (; s[i] && i < (int)sizeof(g_page_status) - 1; i++) g_page_status[i] = s[i];
    g_page_status[i] = '\0';
}

static void do_fetch(const char *host, int port, const char *path, int use_tls) {
    set_status("loading...");

    if (!net_available()) { html_strip("NIC not available.", 19, g_page_buf, PAGE_BUF_SIZE); return; }

    uint32_t ip;
    if (!dns_resolve(host, &ip, 300)) {
        html_strip("DNS resolution failed.", 23, g_page_buf, PAGE_BUF_SIZE);
        set_status("DNS failed");
        return;
    }

    /* SNI: host가 IP literal이면 보내지 않는다(RFC 6066 — 일부 서버가
     * IP를 SNI로 받으면 거부한다, tls.c 참고). */
    int looks_like_ip = 1;
    for (const char *p = host; *p; p++) {
        if (!((*p >= '0' && *p <= '9') || *p == '.')) { looks_like_ip = 0; break; }
    }

    if (use_tls) {
        if (!tls_connect(looks_like_ip ? NULL : host, ip, (uint16_t)port, 300)) {
            /* Milestone 24: tls_last_error()로 구체적 사유(인증서 만료/
             * 신뢰 저장소 없음/호스트명 불일치 등)를 페이지에 그대로 보여준다 —
             * 예전엔 "TLS handshake failed"로 뭉뚱그려서 원인을 알 수 없었다. */
            const char *terr = tls_last_error();
            uint32_t terr_len = 0; while (terr[terr_len]) terr_len++;
            html_strip(terr, terr_len, g_page_buf, PAGE_BUF_SIZE);
            set_status("TLS handshake failed");
            return;
        }
    } else {
        if (!tcp_connect(ip, (uint16_t)port, 300)) {
            html_strip("TCP connect failed/timeout.", 28, g_page_buf, PAGE_BUF_SIZE);
            set_status("connect failed");
            return;
        }
    }

    char req[256]; int ri = 0;
    const char *m1 = "GET ";
    for (int k = 0; m1[k]; k++) req[ri++] = m1[k];
    for (int k = 0; path[k] && ri < 200; k++) req[ri++] = path[k];
    const char *m2 = " HTTP/1.0\r\nHost: ";
    for (int k = 0; m2[k]; k++) req[ri++] = m2[k];
    for (int k = 0; host[k] && ri < 230; k++) req[ri++] = host[k];
    const char *m3 = "\r\nUser-Agent: JetOS-Browser/1.0\r\nConnection: close\r\n\r\n";
    for (int k = 0; m3[k]; k++) req[ri++] = m3[k];

    int send_ok = use_tls ? tls_send(req, (uint32_t)ri, 300) : tcp_send(req, (uint32_t)ri, 100);
    if (!send_ok) {
        html_strip("HTTP request send failed.", 26, g_page_buf, PAGE_BUF_SIZE);
        set_status("send failed");
        if (use_tls) tls_close(); else tcp_close();
        return;
    }

    static char resp[PAGE_BUF_SIZE];
    uint32_t n = use_tls
        ? tls_recv_until_close(resp, sizeof(resp) - 1, 300)
        : tcp_recv_until_close(resp, sizeof(resp) - 1, 300);
    if (use_tls) tls_close(); else tcp_close();
    resp[n] = '\0';

    /* 헤더(\r\n\r\n까지)는 건너뛰고 본문만 보여준다 */
    uint32_t body_start = 0;
    for (uint32_t k = 0; k + 3 < n; k++) {
        if (resp[k] == '\r' && resp[k+1] == '\n' && resp[k+2] == '\r' && resp[k+3] == '\n') {
            body_start = k + 4;
            break;
        }
    }
    html_strip(resp + body_start, n - body_start, g_page_buf, PAGE_BUF_SIZE);
    set_status(use_tls ? "loaded (TLS 1.2, cert not verified)." : "loaded.");
}

static volatile int g_browser_running = 0;
static int g_browser_win = -1;

static void browser_content_cb(console_t *dc, int x, int y, int w, int h, void *ctx) {
    (void)ctx;
    /* Milestone 26 버그 수정: g_addr_box는 browser_thread_entry에서 창을
     * 만들 때 딱 한 번(4,3)으로 초기화된 뒤 한 번도 갱신되지 않았다.
     * widget_textbox_draw는 tb->x/y를 "화면 절대좌표"로 그대로 쓰는데
     * (widget.h에 문서화된 규약), (4,3)은 창이 실제로 열린 위치
     * (CreateWindowJ 호출의 200,200)와 전혀 무관한 화면 맨 위-왼쪽
     * 좌표라 주소창이 브라우저 창 안이 아니라 화면 구석(데스크톱
     * 아이콘/작업표시줄 근처)에 그려지는 위젯 겹침 버그였다. 매 프레임
     * 실제 창 위치(x,y — content_cb가 매번 새로 받는 절대좌표, wm.c의
     * w->x/w->y 기반)로 다시 맞춰준다. */
    g_addr_box.x = x + 4;
    g_addr_box.y = y + 3;
    widget_textbox_draw(dc, &g_addr_box, g_addr_focused);

    dc->fg_color = 0x00C0C0C0u;
    dc->cursor_x = (uint32_t)(x + 8);
    dc->cursor_y = (uint32_t)(y + ADDR_BAR_H + 4);
    console_print(dc, g_page_status);

    int body_y = y + ADDR_BAR_H + 18;
    int body_h = h - ADDR_BAR_H - 18;
    if (body_h < 0) body_h = 0;
    int scroll = wm_get_scroll(g_browser_win);
    int content_px = widget_draw_scrollable_text(dc, x + 8, body_y, w - 8, body_h,
                                                  g_page_buf, scroll, 0x00E0E0E0u);
    wm_set_content_height(g_browser_win, ADDR_BAR_H + 18 + content_px);
}

static void browser_on_close(void *ctx) {
    (void)ctx;
    g_browser_running = 0;
}

typedef struct { char host[80]; int port; char path[96]; int use_tls; } browser_ctx_t;

/* "http://host[:port][/path]" 또는 "https://host[:port][/path]" 최소
 * URL 파서. 스킴이 https면 use_tls=1, 기본 포트도 443이 된다. */
static int parse_url(const char *url, char *host, int hostcap, int *port, char *path, int pathcap, int *use_tls) {
    const char *p = url;
    *use_tls = 0;
    if (p[0]=='h'&&p[1]=='t'&&p[2]=='t'&&p[3]=='p'&&p[4]=='s'&&p[5]==':'&&p[6]=='/'&&p[7]=='/') {
        p += 8; *use_tls = 1;
    } else if (p[0]=='h'&&p[1]=='t'&&p[2]=='t'&&p[3]=='p'&&p[4]==':'&&p[5]=='/'&&p[6]=='/') {
        p += 7;
    }
    int hi = 0;
    while (*p && *p != ':' && *p != '/' && hi < hostcap - 1) host[hi++] = *p++;
    host[hi] = '\0';
    if (hi == 0) return 0;
    *port = *use_tls ? 443 : 80;
    if (*p == ':') {
        p++;
        int pv = 0;
        while (*p >= '0' && *p <= '9') { pv = pv * 10 + (*p - '0'); p++; }
        if (pv > 0) *port = pv;
    }
    if (*p == '\0') {
        path[0] = '/'; path[1] = '\0';
    } else {
        int pi = 0;
        while (*p && pi < pathcap - 1) path[pi++] = *p++;
        path[pi] = '\0';
    }
    return 1;
}

static void navigate_thread_entry(void *arg) {
    browser_ctx_t *bc = (browser_ctx_t *)arg;
    if (!bc) return;
    int i = 0;
    const char *pre = bc->use_tls ? "https://" : "http://";
    for (; pre[i]; i++) g_page_url[i] = pre[i];
    for (int k = 0; bc->host[k] && i < 60; k++) g_page_url[i++] = bc->host[k];
    for (int k = 0; bc->path[k] && i < 78; k++) g_page_url[i++] = bc->path[k];
    g_page_url[i] = '\0';
    widget_textbox_set(&g_addr_box, g_page_url);

    do_fetch(bc->host, bc->port, bc->path, bc->use_tls);
    kfree(bc);
}

static void browser_navigate(const char *host, int port, const char *path, int use_tls) {
    browser_ctx_t *bc = (browser_ctx_t *)kmalloc(sizeof(browser_ctx_t));
    if (!bc) return;
    int i = 0; for (; host[i] && i < (int)sizeof(bc->host) - 1; i++) bc->host[i] = host[i];
    bc->host[i] = '\0';
    bc->port = port;
    bc->use_tls = use_tls;
    i = 0; for (; path[i] && i < (int)sizeof(bc->path) - 1; i++) bc->path[i] = path[i];
    bc->path[i] = '\0';
    CreateThreadJ("browser-nav", navigate_thread_entry, bc);
}

/* 주소창 클릭/타이핑 라우팅 (Milestone 19) */
static void browser_click_cb(int lx, int ly, void *ctx) {
    (void)lx; (void)ctx;
    g_addr_focused = (ly < ADDR_BAR_H);
}

static void browser_key_cb(char c, void *ctx) {
    (void)ctx;
    if (!g_addr_focused) return;
    if (c == '\n' || c == '\r') {
        char host[80]; int port; char path[96]; int use_tls;
        if (parse_url(g_addr_box.buf, host, (int)sizeof(host), &port, path, (int)sizeof(path), &use_tls)) {
            set_status(use_tls ? "loading (TLS)..." : "loading...");
            browser_navigate(host, port, path, use_tls);
        }
        return;
    }
    widget_textbox_key(&g_addr_box, c);
}

static void browser_thread_entry(void *arg) {
    browser_ctx_t *bc = (browser_ctx_t *)arg;
    g_browser_running = 1;

    g_browser_win = CreateWindowJ("JETOS BROWSER", 200, 200, 420, 260, 0x00203848);
    if (g_browser_win >= 0) {
        /* x,y는 실제로 안 쓰인다(매 프레임 browser_content_cb가 창의
         * 현재 위치로 다시 계산해서 덮어씀 — 위의 위젯 겹침 버그 수정
         * 참고) — w,h만 여기서 확정된다. */
        widget_textbox_init(&g_addr_box, 0, 0, 400, ADDR_BAR_H - 5, "");
        wm_set_content_callback(g_browser_win, browser_content_cb, NULL);
        wm_set_close_callback(g_browser_win, browser_on_close, NULL);
        wm_set_click_callback(g_browser_win, browser_click_cb, NULL);
        wm_set_key_callback(g_browser_win, browser_key_cb, NULL);
    }

    if (bc) {
        navigate_thread_entry(bc); /* 최초 페이지는 이 스레드 안에서 바로 로드 */
    }

    while (g_browser_running) {
        scheduler_yield();
    }
}

void browser_launch_url(const char *host, int port, const char *path) {
    browser_ctx_t *bc = (browser_ctx_t *)kmalloc(sizeof(browser_ctx_t));
    if (!bc) return;
    int i = 0; for (; host[i] && i < (int)sizeof(bc->host) - 1; i++) bc->host[i] = host[i];
    bc->host[i] = '\0';
    bc->port = port;
    bc->use_tls = 0; /* jash "browser <host> <port> </path>"는 스킴 개념이 없어 평문 HTTP만
                       * — HTTPS로 열려면 GUI 주소창에 https://를 직접 타이핑(Milestone 19) */
    i = 0; for (; path[i] && i < (int)sizeof(bc->path) - 1; i++) bc->path[i] = path[i];
    bc->path[i] = '\0';
    CreateThreadJ("browser", browser_thread_entry, bc);
}

void browser_launch(void) {
    /* 데모용 기본 페이지: 네트워킹 자체 테스트와 같은 호스트의 테스트
     * 서버(10.0.2.2:8000)를 기본값으로 연다. 실제 인터넷 주소를 열려면
     * jash의 'browser <host> <port> </path>' 명령을 쓰면 된다(DNS 지원). */
    browser_launch_url("10.0.2.2", 8000, "/index.html");
}
