#ifndef JETOS_VIRTIO_GPU_H
#define JETOS_VIRTIO_GPU_H

#include <stdint.h>

/*
 * JetOS - kernel/drivers/virtio_gpu.h
 * Milestone 31: VirtIO-GPU(2D 모드) 드라이버 — "진짜 GPU"를 붙인다.
 *
 * ===== 먼저 반드시 읽을 것: 이 드라이버의 검증 상태 =====
 * 이 개발 환경에는 QEMU가 없다(다른 마일스톤 문서들, 특히 M30에서도
 * 이미 밝힌 사실 — 이번엔 그 한계가 훨씬 더 크게 영향을 준다).
 * AHCI/RTL8139 등 기존 드라이버는 그래도 "호스트에서 로직 일부를
 * 시뮬레이션"하거나 "산출물을 다른 도구로 검증"할 방법이 있었지만,
 * PCI 설정공간 접근·MMIO 레지스터·virtqueue 프로토콜은 실제
 * 하드웨어(또는 QEMU)와 대화해야만 진짜로 검증되는 종류의 코드라서,
 * **이 파일은 이 프로젝트에서 가장 약하게 검증된 코드다.** 명세
 * (virtio 1.1)를 최대한 정확히 따르고 기존 드라이버(ahci.c/pci.c)의
 * 스타일과 관례를 그대로 따랐지만, 실제 QEMU 부팅으로 단 한 번도
 * 확인하지 못했다는 점을 정직하게 밝힌다.
 *
 * 그래서 극도로 방어적으로 설계했다:
 *   - 초기화의 모든 단계(장치 탐색/기능 협상/큐 설정/첫 커맨드 응답
 *     대기)에 g_timer_ticks 기반 타임아웃이 있다 — 뭔가 잘못돼도
 *     부팅이 영원히 멈추는 일은 없다.
 *   - 한 단계라도 실패하면 그 즉시 깨끗하게 포기하고 0을 반환한다.
 *     실패해도 부작용이 남지 않도록, 이미 확보한 자원을 되돌리려
 *     애쓰지 않는다(어차피 부팅 초반 1회성 초기화라 실패하면 그냥
 *     "GPU 없음" 상태로 계속 진행 — 자원 누수보다 코드 단순성/안전성을
 *     택함, 알려진 단순화).
 *   - virtio_gpu_init()이 실패해도 DirexJ(kernel/gfx/direxj.c)는 예전
 *     그대로 순수 CPU present 경로만 쓴다 — 이 드라이버가 통째로
 *     틀렸어도 "GPU를 아예 안 쓰던 M29 이전 상태"로 안전하게 남는다.
 *
 * ===== 지원 범위(정직하게 문서화) =====
 *   - 2D 모드만(RESOURCE_CREATE_2D/TRANSFER_TO_HOST_2D/RESOURCE_FLUSH).
 *     3D/virgl은 시도하지 않는다(VIRTIO_GPU_F_VIRGL 기능을 요청 안 함).
 *   - "modern"(virtio 1.0+) PCI 장치만 인식한다(device id 0x1050) —
 *     레거시/transitional 장치(0x1000대)는 지원 안 함.
 *   - 디스플레이(scanout) 1개만 쓴다(멀티 모니터 없음).
 *   - GOP 프레임버퍼의 pixels_per_scanline이 width와 다르면(스캔라인
 *     사이에 패딩이 있으면) 초기화 자체를 포기한다 — 이 경우 virtio-gpu
 *     2D 리소스의 내부 스트라이드 가정(width 그대로)과 실제 백킹 메모리
 *     레이아웃이 어긋나 화면이 밀려 보일 위험이 있는데, 이 환경에서
 *     확인할 방법이 없어서 안전한 쪽(포기)을 택했다.
 *   - 인터럽트 없이 폴링만 쓴다(AHCI와 같은 스타일) — 커맨드 하나
 *     보내고 완료될 때까지 짧게 기다리는 동기 방식.
 */

/* PCI에서 virtio-gpu 장치를 찾아 초기화를 시도한다(장치 탐색 -> 기능
 * 협상 -> controlq 설정 -> 2D 리소스 생성 -> 기존 GOP 프레임버퍼를
 * 백킹으로 붙이기 -> scanout 연결까지). 성공(이후 virtio_gpu_present
 * 사용 가능) 1, 실패(장치 없음/이 구현이 지원 안 하는 구성/타임아웃)
 * 0 — 실패해도 완전히 안전하다(위 설명 참고). 부팅 중 한 번만 호출할 것. */
int virtio_gpu_init(uint64_t fb_phys_addr, uint32_t width, uint32_t height, uint32_t pixels_per_scanline);

int virtio_gpu_available(void);

/* 프레임버퍼의 (x,y,w,h) 영역이 CPU에 의해 갱신됐으니 실제 화면에
 * 반영해달라고 GPU에 알린다(TRANSFER_TO_HOST_2D + RESOURCE_FLUSH).
 * virtio_gpu_init이 성공했을 때만 의미 있고, 실패했으면 아무 것도
 * 안 하고 즉시 리턴한다(호출측이 매번 virtio_gpu_available()을 먼저
 * 확인할 필요 없이 그냥 불러도 안전하도록). */
void virtio_gpu_present(int x, int y, int w, int h);

#endif
