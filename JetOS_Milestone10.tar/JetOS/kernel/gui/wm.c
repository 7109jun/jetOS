/*
 * JetOS - kernel/gui/wm.c
 * 윈도우 매니저 + 렌더러. Milestone 7에서 디자인 시스템을 전면 적용해
 * 더 Windows답게 느껴지는 비주얼로 개선했다.
 */

#include "wm.h"
#include "theme.h"
#include "../mm/heap.h"
#include <stddef.h>

#define START_MENU_ITEMS 5
static const char *START_MENU_LABELS[START_MENU_ITEMS] = {
    "File Manager", "Terminal", "Settings", "Task Manager", "Shutdown"
};

static console_t *g_front = NULL;
static console_t g_back;
static console_t *g_con = NULL;

static wm_window_t g_windows[WM_MAX_WINDOWS];
static int g_order[WM_MAX_WINDOWS];
static int g_window_count = 0;
static int g_focused_idx = -1;

static int g_cursor_x = 0, g_cursor_y = 0;
static int g_start_menu_open = 0;

/* 우클릭 컨텍스트 메뉴 상태 */
static int g_ctx_menu_open = 0;
static int g_ctx_menu_x = 0, g_ctx_menu_y = 0;
static int g_ctx_menu_target = -1; /* -1 = 데스크톱 메뉴, 그 외 = 창 idx */
#define CTX_MENU_W 130
#define DESKTOP_CTX_ITEMS 4  /* File Manager / Terminal / Settings / Task Manager */
#define WINDOW_CTX_ITEMS 2   /* Close / Minimize|Restore */

#define START_BTN_W 80
#define MENU_ITEM_H 22
#define TASKBAR_LABEL_W 130
#define BORDER_SZ 2

void wm_init(console_t *con) {
    g_front = con;
    uint32_t *backbuf = (uint32_t *)kmalloc((size_t)con->width * con->height * 4);
    console_init(&g_back, backbuf, con->width, con->height, con->width);
    g_con = &g_back;
    g_window_count = 0;
    g_focused_idx = -1;
    for (int i = 0; i < WM_MAX_WINDOWS; i++) { g_windows[i].used = 0; g_order[i] = -1; }
    g_cursor_x = (int)con->width / 2;
    g_cursor_y = (int)con->height / 2;
    g_start_menu_open = 0;
    g_ctx_menu_open = 0;
    g_ctx_menu_target = -1;
}

int wm_create_window(const char *title, int x, int y, int w, int h, uint32_t color) {
    if (g_window_count >= WM_MAX_WINDOWS) return -1;
    int idx = g_window_count++;
    wm_window_t *win = &g_windows[idx];
    win->x = x; win->y = y; win->w = w; win->h = h;
    win->color = color;
    win->visible = 1;
    win->minimized = 0;
    win->closed = 0;
    win->used = 1;
    win->content_cb = NULL;
    win->content_ctx = NULL;
    win->close_cb = NULL;
    win->close_ctx = NULL;
    int i = 0;
    for (; i < 31 && title[i]; i++) win->title[i] = title[i];
    win->title[i] = '\0';
    g_order[idx] = idx;
    g_focused_idx = idx;
    return idx;
}

void wm_bring_to_front(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    int pos = -1;
    for (int i = 0; i < g_window_count; i++) if (g_order[i] == idx) { pos = i; break; }
    if (pos < 0) return;
    for (int i = pos; i < g_window_count - 1; i++) g_order[i] = g_order[i + 1];
    g_order[g_window_count - 1] = idx;
    g_focused_idx = idx;
}

void wm_move_window(int idx, int dx, int dy) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].x += dx;
    g_windows[idx].y += dy;
}

int wm_window_at(int x, int y) {
    for (int i = g_window_count - 1; i >= 0; i--) {
        int idx = g_order[i];
        wm_window_t *w = &g_windows[idx];
        if (!w->visible || w->minimized || w->closed) continue;
        if (x >= w->x - BORDER_SZ && x < w->x + w->w + BORDER_SZ &&
            y >= w->y && y < w->y + w->h + WM_TITLEBAR_H) {
            return idx;
        }
    }
    return -1;
}

int wm_hit_titlebar(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    return (x >= w->x && x < w->x + w->w && y >= w->y && y < w->y + WM_TITLEBAR_H);
}

int wm_hit_close_button(int idx, int x, int y) {
    if (idx < 0 || idx >= g_window_count) return 0;
    wm_window_t *w = &g_windows[idx];
    int bx = w->x + w->w - 18;
    int by = w->y + 3;
    return (x >= bx && x < bx + 14 && y >= by && y < by + 12);
}

void wm_close_window(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    if (w->closed) return;
    w->visible = 0;
    w->minimized = 0;
    w->closed = 1;
    if (w->close_cb) w->close_cb(w->close_ctx);
    if (g_focused_idx == idx) {
        g_focused_idx = -1;
        for (int i = g_window_count - 1; i >= 0; i--) {
            int oi = g_order[i];
            if (!g_windows[oi].closed) { g_focused_idx = oi; break; }
        }
    }
}

void wm_minimize_window(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    if (w->closed) return;
    w->minimized = 1;
    w->visible = 0;
    if (g_focused_idx == idx) {
        g_focused_idx = -1;
        for (int i = g_window_count - 1; i >= 0; i--) {
            int oi = g_order[i];
            if (!g_windows[oi].closed && !g_windows[oi].minimized) { g_focused_idx = oi; break; }
        }
    }
}

void wm_restore_window(int idx) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *w = &g_windows[idx];
    if (w->closed) return;
    w->minimized = 0;
    w->visible = 1;
    wm_bring_to_front(idx);
}

int wm_is_window_minimized(int idx) {
    if (idx < 0 || idx >= g_window_count) return 0;
    return g_windows[idx].minimized;
}

int wm_hit_taskbar_window_button(int x, int y) {
    if (!g_con) return -1;
    int tbY = (int)g_con->height - WM_TASKBAR_H;
    if (y < tbY + 2 || y >= tbY + WM_TASKBAR_H - 2) return -1;
    int tx = START_BTN_W + 4;
    for (int i = 0; i < g_window_count; i++) {
        int idx = g_order[i];
        wm_window_t *w = &g_windows[idx];
        if (w->closed) continue;
        if (x >= tx && x < tx + TASKBAR_LABEL_W - 4) return idx;
        tx += TASKBAR_LABEL_W;
    }
    return -1;
}

void wm_get_window_bounds(int idx, int *x, int *y, int *w, int *h) {
    if (idx < 0 || idx >= g_window_count) return;
    wm_window_t *win = &g_windows[idx];
    if (x) *x = win->x;
    if (y) *y = win->y;
    if (w) *w = win->w;
    if (h) *h = win->h;
}

void wm_set_content_callback(int idx, wm_content_draw_fn cb, void *ctx) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].content_cb = cb;
    g_windows[idx].content_ctx = ctx;
}

void wm_set_close_callback(int idx, wm_close_fn cb, void *ctx) {
    if (idx < 0 || idx >= g_window_count) return;
    g_windows[idx].close_cb = cb;
    g_windows[idx].close_ctx = ctx;
}

void wm_set_cursor(int x, int y) {
    if (!g_con) return;
    if (x < 0) x = 0; if (y < 0) y = 0;
    if (x >= (int)g_con->width) x = (int)g_con->width - 1;
    if (y >= (int)g_con->height) y = (int)g_con->height - 1;
    g_cursor_x = x; g_cursor_y = y;
}

void wm_get_cursor(int *x, int *y) {
    if (x) *x = g_cursor_x;
    if (y) *y = g_cursor_y;
}

void wm_set_start_menu_open(int open) { g_start_menu_open = open; }

int wm_is_start_button_hit(int x, int y) {
    if (!g_con) return 0;
    int ty = (int)g_con->height - WM_TASKBAR_H;
    return (x >= 0 && x < START_BTN_W && y >= ty && y < (int)g_con->height);
}

int wm_is_start_menu_item_hit(int x, int y, int *out_item_index) {
    if (!g_con || !g_start_menu_open) return 0;
    int ty = (int)g_con->height - WM_TASKBAR_H;
    int menu_h = START_MENU_ITEMS * MENU_ITEM_H + 4;
    int menu_y = ty - menu_h;
    if (x < 0 || x >= START_BTN_W + 80) return 0;
    if (y < menu_y || y >= ty) return 0;
    int item = (y - menu_y - 2) / MENU_ITEM_H;
    if (item < 0 || item >= START_MENU_ITEMS) return 0;
    if (out_item_index) *out_item_index = item;
    return 1;
}

/* ---- 우클릭 컨텍스트 메뉴 ---- */
static int ctx_menu_item_count(void) {
    return (g_ctx_menu_target == -1) ? DESKTOP_CTX_ITEMS : WINDOW_CTX_ITEMS;
}

void wm_open_context_menu(int x, int y, int window_idx) {
    if (!g_con) return;
    g_ctx_menu_open = 1;
    g_ctx_menu_target = window_idx;
    g_ctx_menu_x = x;
    g_ctx_menu_y = y;
    /* 화면 밖으로 나가지 않도록 보정 */
    int menu_h = ctx_menu_item_count() * MENU_ITEM_H + 4;
    if (g_ctx_menu_x + CTX_MENU_W > (int)g_con->width) g_ctx_menu_x = (int)g_con->width - CTX_MENU_W;
    if (g_ctx_menu_y + menu_h > (int)g_con->height - WM_TASKBAR_H)
        g_ctx_menu_y = (int)g_con->height - WM_TASKBAR_H - menu_h;
    if (g_ctx_menu_x < 0) g_ctx_menu_x = 0;
    if (g_ctx_menu_y < 0) g_ctx_menu_y = 0;
    g_start_menu_open = 0;
}

void wm_close_context_menu(void) { g_ctx_menu_open = 0; g_ctx_menu_target = -1; }
int  wm_is_context_menu_open(void) { return g_ctx_menu_open; }
int  wm_context_menu_target(void) { return g_ctx_menu_target; }

int wm_hit_context_menu(int x, int y) {
    if (!g_ctx_menu_open) return 0;
    int menu_h = ctx_menu_item_count() * MENU_ITEM_H + 4;
    return (x >= g_ctx_menu_x && x < g_ctx_menu_x + CTX_MENU_W &&
            y >= g_ctx_menu_y && y < g_ctx_menu_y + menu_h);
}

int wm_hit_context_menu_item(int x, int y, int *out_item_index) {
    if (!wm_hit_context_menu(x, y)) return 0;
    int item = (y - g_ctx_menu_y - 2) / MENU_ITEM_H;
    int n = ctx_menu_item_count();
    if (item < 0 || item >= n) return 0;
    if (out_item_index) *out_item_index = item;
    return 1;
}

/* ---- 렌더링 헬퍼 ---- */
static void fill(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint32_t c) {
    console_fill_rect(g_con, x, y, w, h, c);
}

static void hline(int x, int y, int w, uint32_t c) {
    if (y < 0 || y >= (int)g_con->height) return;
    for (int i = 0; i < w; i++) {
        if (x + i >= 0 && x + i < (int)g_con->width)
            console_put_pixel(g_con, (uint32_t)(x + i), (uint32_t)y, c);
    }
}

static void vline(int x, int y, int h, uint32_t c) {
    if (x < 0 || x >= (int)g_con->width) return;
    for (int i = 0; i < h; i++) {
        if (y + i >= 0 && y + i < (int)g_con->height)
            console_put_pixel(g_con, (uint32_t)x, (uint32_t)(y + i), c);
    }
}

static void draw_text(int x, int y, const char *s, uint32_t color) {
    if (!s || !g_con) return;
    g_con->cursor_x = (uint32_t)x;
    g_con->cursor_y = (uint32_t)y;
    uint32_t saved = g_con->fg_color;
    g_con->fg_color = color;
    console_print(g_con, s);
    g_con->fg_color = saved;
}

/* 타이틀바 그라데이션 효과: 위→아래로 점점 어두워지는 2단 그라데이션 */
static void draw_titlebar_gradient(int x, int y, int w, uint32_t base) {
    int h = WM_TITLEBAR_H;
    for (int row = 0; row < h; row++) {
        /* base에서 row가 늘어날수록 R/G/B 각 채널을 약간씩 어둡게 */
        int dim = (row * 30) / h;
        uint32_t r = ((base >> 16) & 0xFF);
        uint32_t g = ((base >> 8) & 0xFF);
        uint32_t b = ((base) & 0xFF);
        r = (r > dim) ? r - dim : 0;
        g = (g > dim) ? g - dim : 0;
        b = (b > dim) ? b - dim : 0;
        uint32_t c = (r << 16) | (g << 8) | b;
        for (int col = 0; col < w; col++) {
            console_put_pixel(g_con, (uint32_t)(x + col), (uint32_t)(y + row), c);
        }
    }
}

/* 창 X 버튼 (닫기) */
static void draw_close_btn(int wx, int wy, int ww) {
    int bx = wx + ww - 18;
    int by = wy + 3;
    fill((uint32_t)bx, (uint32_t)by, 14, 12, 0x00803030);
    /* 작은 X */
    console_put_pixel(g_con, (uint32_t)(bx+3),(uint32_t)(by+2), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+4),(uint32_t)(by+3), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+5),(uint32_t)(by+4), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+6),(uint32_t)(by+5), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+7),(uint32_t)(by+4), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+8),(uint32_t)(by+3), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+9),(uint32_t)(by+2), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+9),(uint32_t)(by+8), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+8),(uint32_t)(by+7), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+7),(uint32_t)(by+6), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+5),(uint32_t)(by+6), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+4),(uint32_t)(by+7), 0x00FFFFFF);
    console_put_pixel(g_con, (uint32_t)(bx+3),(uint32_t)(by+8), 0x00FFFFFF);
}

/* 마우스 커서 (화살표 모양, 11x11) */
static void draw_cursor(void) {
    int cx = g_cursor_x, cy = g_cursor_y;
    uint32_t c  = THEME_CURSOR_COLOR;
    uint32_t cs = 0x00000000; /* 그림자 (순수 검정 테두리) */
    /* 외곽선 */
    for (int i = 0; i < 10; i++) {
        console_put_pixel(g_con, (uint32_t)(cx), (uint32_t)(cy+i), cs);
        console_put_pixel(g_con, (uint32_t)(cx+1), (uint32_t)(cy+i+1), cs);
    }
    /* 채우기 */
    for (int i = 0; i < 8; i++) {
        console_put_pixel(g_con, (uint32_t)(cx+1), (uint32_t)(cy+1+i), c);
    }
    console_put_pixel(g_con, (uint32_t)(cx+2), (uint32_t)(cy+2), c);
    console_put_pixel(g_con, (uint32_t)(cx+2), (uint32_t)(cy+3), c);
    console_put_pixel(g_con, (uint32_t)(cx+3), (uint32_t)(cy+3), c);
    console_put_pixel(g_con, (uint32_t)(cx+3), (uint32_t)(cy+4), c);
    console_put_pixel(g_con, (uint32_t)(cx+2), (uint32_t)(cy+5), c);
    console_put_pixel(g_con, (uint32_t)(cx+3), (uint32_t)(cy+5), c);
    console_put_pixel(g_con, (uint32_t)(cx+4), (uint32_t)(cy+4), c);
    console_put_pixel(g_con, (uint32_t)(cx+5), (uint32_t)(cy+3), c);
}

void wm_draw(void) {
    if (!g_con) return;

    /* 데스크탑 배경 */
    fill(0, 0, g_con->width, g_con->height, THEME_DESKTOP_BG);

    /* 창 렌더링 (뒤→앞) */
    for (int i = 0; i < g_window_count; i++) {
        wm_window_t *w = &g_windows[g_order[i]];
        if (!w->visible) continue;
        int focused = (g_order[i] == g_focused_idx);
        uint32_t title_color = focused ? THEME_WIN_TITLE_ACTIVE : THEME_WIN_TITLE_INACTIVE;

        /* 창 바깥 테두리 */
        hline(w->x - BORDER_SZ, w->y - BORDER_SZ, w->w + BORDER_SZ * 2 + 1, THEME_WIN_BORDER);
        hline(w->x - BORDER_SZ, w->y + WM_TITLEBAR_H + w->h + BORDER_SZ, w->w + BORDER_SZ * 2 + 1, THEME_WIN_BORDER);
        vline(w->x - BORDER_SZ, w->y, w->h + WM_TITLEBAR_H + BORDER_SZ, THEME_WIN_BORDER);
        vline(w->x + w->w + BORDER_SZ - 1, w->y, w->h + WM_TITLEBAR_H + BORDER_SZ, THEME_WIN_BORDER);

        /* 타이틀바 (그라데이션) */
        draw_titlebar_gradient(w->x, w->y, w->w, title_color);

        /* 타이틀바 하단 구분선 */
        hline(w->x, w->y + WM_TITLEBAR_H - 1, w->w, THEME_WIN_BORDER);

        /* 타이틀 텍스트 */
        draw_text(w->x + 8, w->y + 5, w->title, THEME_WIN_TITLE_TEXT);

        /* 닫기 버튼 */
        draw_close_btn(w->x, w->y, w->w);

        /* 창 본문 */
        fill((uint32_t)w->x, (uint32_t)(w->y + WM_TITLEBAR_H),
              (uint32_t)w->w, (uint32_t)w->h, THEME_WIN_CLIENT);

        /* 내용 콜백 */
        if (w->content_cb) {
            w->content_cb(g_con, w->x, w->y + WM_TITLEBAR_H, w->w, w->h, w->content_ctx);
        }
    }

    /* 작업표시줄 */
    int tbY = (int)g_con->height - WM_TASKBAR_H;
    fill(0, (uint32_t)tbY, g_con->width, WM_TASKBAR_H, THEME_TASKBAR_BG);
    hline(0, tbY, (int)g_con->width, THEME_TASKBAR_BORDER); /* 상단 구분선 */

    /* 시작 버튼 */
    fill(0, (uint32_t)tbY + 2, START_BTN_W - 4, WM_TASKBAR_H - 4, THEME_START_NORMAL);
    hline(0, tbY + 2, START_BTN_W - 4, THEME_ACCENT_BLUE);
    hline(0, tbY + WM_TASKBAR_H - 3, START_BTN_W - 4, THEME_ACCENT_BLUE);
    draw_text(8, tbY + 6, "START", THEME_START_TEXT);

    /* 창 목록 버튼 */
    int tx = START_BTN_W + 4;
    for (int i = 0; i < g_window_count; i++) {
        wm_window_t *w = &g_windows[g_order[i]];
        if (w->closed) continue;
        int active = (g_order[i] == g_focused_idx) && !w->minimized;
        uint32_t btn_c = active ? THEME_TASKBAR_BTN_ACTIVE : THEME_TASKBAR_BTN_NORMAL;
        fill((uint32_t)tx, (uint32_t)(tbY + 2), TASKBAR_LABEL_W - 4, WM_TASKBAR_H - 4, btn_c);
        if (active) hline(tx, tbY + 2, TASKBAR_LABEL_W - 4, THEME_ACCENT_BLUE);
        draw_text(tx + 6, tbY + 7, w->title, active ? THEME_TEXT_HIGHLIGHT : THEME_TEXT_SECONDARY);
        tx += TASKBAR_LABEL_W;
    }

    /* 시작 메뉴 */
    if (g_start_menu_open) {
        int menu_w = START_BTN_W + 80;
        int menu_h = START_MENU_ITEMS * MENU_ITEM_H + 4;
        int menu_y = tbY - menu_h;
        fill(0, (uint32_t)menu_y, (uint32_t)menu_w, (uint32_t)menu_h, THEME_MENU_BG);
        hline(0, menu_y, menu_w, THEME_WIN_BORDER);
        vline(menu_w - 1, menu_y, menu_h, THEME_WIN_BORDER);
        for (int i = 0; i < START_MENU_ITEMS; i++) {
            int item_y = menu_y + 2 + i * MENU_ITEM_H;
            if (i == START_MENU_ITEMS - 1) { /* SHUTDOWN 앞에 구분선 */
                hline(4, item_y - 1, menu_w - 8, THEME_MENU_SEPARATOR);
            }
            draw_text(10, item_y + 5, START_MENU_LABELS[i], THEME_MENU_TEXT);
        }
    }

    /* 우클릭 컨텍스트 메뉴 */
    if (g_ctx_menu_open) {
        int n = ctx_menu_item_count();
        int menu_h = n * MENU_ITEM_H + 4;
        fill((uint32_t)g_ctx_menu_x, (uint32_t)g_ctx_menu_y, CTX_MENU_W, (uint32_t)menu_h, THEME_MENU_BG);
        hline(g_ctx_menu_x, g_ctx_menu_y, CTX_MENU_W, THEME_WIN_BORDER);
        vline(g_ctx_menu_x + CTX_MENU_W - 1, g_ctx_menu_y, menu_h, THEME_WIN_BORDER);
        vline(g_ctx_menu_x, g_ctx_menu_y, menu_h, THEME_WIN_BORDER);
        hline(g_ctx_menu_x, g_ctx_menu_y + menu_h - 1, CTX_MENU_W, THEME_WIN_BORDER);
        if (g_ctx_menu_target == -1) {
            for (int i = 0; i < DESKTOP_CTX_ITEMS; i++) {
                int item_y = g_ctx_menu_y + 2 + i * MENU_ITEM_H;
                draw_text(g_ctx_menu_x + 8, item_y + 5, START_MENU_LABELS[i], THEME_MENU_TEXT);
            }
        } else {
            int minimized = (g_ctx_menu_target >= 0 && g_ctx_menu_target < g_window_count)
                             ? g_windows[g_ctx_menu_target].minimized : 0;
            const char *labels[WINDOW_CTX_ITEMS] = { "Close", minimized ? "Restore" : "Minimize" };
            for (int i = 0; i < WINDOW_CTX_ITEMS; i++) {
                int item_y = g_ctx_menu_y + 2 + i * MENU_ITEM_H;
                draw_text(g_ctx_menu_x + 8, item_y + 5, labels[i], THEME_MENU_TEXT);
            }
        }
    }

    draw_cursor();
}

void wm_present(void) {
    if (!g_front || !g_con || !g_con->fb || !g_front->fb) return;
    uint32_t total = g_front->width * g_front->height;
    for (uint32_t i = 0; i < total; i++) g_front->fb[i] = g_con->fb[i];
}

console_t *wm_get_draw_console(void) { return g_con; }
