/* JetOS 네이티브 ELF 테스트 프로그램 #3 — Milestone 19 유저 포인터
 * 검증을 확인하기 위한 것.
 *
 * 일부러 SYS_WRITE에 "자기 프로세스의 유저 영역 밖" 포인터(커널
 * identity 매핑 영역의 임의 주소)를 넘긴다. syscall_check_user_cstr()이
 * 이를 거부하고 이 프로세스만 종료시켜야 한다 — 커널이 그 주소를
 * 그대로 읽어 로그를 유출하거나(정보 누출) 잘못된 메모리를 건드려
 * 패닉이 나면 안 된다. */

static long jsyscall(long num, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile (
        "int $0x80"
        : "=a"(ret)
        : "a"(num), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory"
    );
    return ret;
}

#define SYS_WRITE 0

void _start(void) {
    static const char msg1[] =
        "[baduptr-test process] about to SYS_WRITE with an out-of-region pointer...\n";
    jsyscall(SYS_WRITE, (long)msg1, 0, 0);

    /* 커널 identity 매핑 영역(예: 0x100000 부근)은 이 프로세스의
     * 유저 영역(vmm_user_virt_base()..+2MiB) 밖이다. 유효한 문자열이
     * 아니어도 상관없다 — 애초에 syscall이 이 주소를 들여다보면 안
     * 된다는 걸 확인하는 것이 목적이다. */
    const char *bad_ptr = (const char *)0x100000UL;
    jsyscall(SYS_WRITE, (long)bad_ptr, 0, 0);

    /* 검증이 제대로 됐다면 위 호출에서 이 스레드는 즉시 종료되어
     * 여기 도달하지 않는다. 도달하면 검증이 뚫린 것 — 실패 신호. */
    static const char msg2[] =
        "[baduptr-test process] ERROR: reached code after bad SYS_WRITE (validation failed!)\n";
    jsyscall(SYS_WRITE, (long)msg2, 0, 0);
    for (;;) { }
}
