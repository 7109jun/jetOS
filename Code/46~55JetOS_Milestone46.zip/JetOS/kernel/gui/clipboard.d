kernel/gui/clipboard.o: kernel/gui/clipboard.c kernel/gui/clipboard.h
kernel/gui/clipboard.h:
