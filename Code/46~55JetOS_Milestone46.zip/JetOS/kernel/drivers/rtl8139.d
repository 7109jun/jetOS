kernel/drivers/rtl8139.o: kernel/drivers/rtl8139.c \
 kernel/drivers/rtl8139.h kernel/drivers/pci.h \
 kernel/drivers/../hal/x86_asm_shim.h kernel/drivers/../mm/pmm.h \
 kernel/drivers/../mm/../../include/efi/efi.h
kernel/drivers/rtl8139.h:
kernel/drivers/pci.h:
kernel/drivers/../hal/x86_asm_shim.h:
kernel/drivers/../mm/pmm.h:
kernel/drivers/../mm/../../include/efi/efi.h:
