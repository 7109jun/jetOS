/*
 * JetOS - tools/mkjetfs.c
 *
 * JETFS로 디스크 이미지를 포맷하는 호스트(리눅스) 도구.
 * JetOS 커널이 아니라 개발 머신에서 빌드/실행되는 일반 프로그램이다
 * (표준 libc 사용, freestanding 아님). kernel/fs/jetfs.h 의 구조체
 * 정의를 그대로 재사용해 온디스크 레이아웃이 커널 구현과 100% 일치하도록
 * 보장한다.
 *
 * 사용법: mkjetfs <이미지파일> <크기MB>
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../kernel/fs/jetfs.h"

#define INODES_PER_BLOCK (JETFS_BLOCK_SIZE / sizeof(jetfs_inode_t))

int main(int argc, char **argv) {
    if (argc != 3) {
        fprintf(stderr, "사용법: %s <이미지파일> <크기MB>\n", argv[0]);
        return 1;
    }
    const char *path = argv[1];
    uint32_t size_mb = (uint32_t)atoi(argv[2]);
    if (size_mb == 0) { fprintf(stderr, "크기는 1MB 이상이어야 합니다.\n"); return 1; }

    uint64_t total_bytes = (uint64_t)size_mb * 1024ULL * 1024ULL;
    uint32_t total_blocks = (uint32_t)(total_bytes / JETFS_BLOCK_SIZE);

    /* Milestone 47: 저널 영역이 슈퍼블록(블록 0) 바로 뒤에 고정 크기로
     * 들어간다 — inode 테이블/비트맵/데이터 영역이 전부 그만큼 뒤로
     * 밀린다. */
    uint32_t journal_start = 1;
    uint32_t inode_table_blocks = (JETFS_MAX_INODES + INODES_PER_BLOCK - 1) / INODES_PER_BLOCK;

    uint32_t bitmap_blocks = 1;
    uint32_t data_start = 0;
    for (int iter = 0; iter < 8; iter++) {
        data_start = journal_start + JETFS_JOURNAL_BLOCKS + inode_table_blocks + bitmap_blocks;
        uint32_t data_blocks = (total_blocks > data_start) ? (total_blocks - data_start) : 0;
        uint32_t bitmap_bytes = (data_blocks + 7) / 8;
        uint32_t needed = (bitmap_bytes + JETFS_BLOCK_SIZE - 1) / JETFS_BLOCK_SIZE;
        if (needed == 0) needed = 1;
        if (needed == bitmap_blocks) break;
        bitmap_blocks = needed;
    }
    data_start = journal_start + JETFS_JOURNAL_BLOCKS + inode_table_blocks + bitmap_blocks;

    if (data_start >= total_blocks) {
        fprintf(stderr, "이미지가 너무 작습니다 (메타데이터만으로 %u블록 필요).\n", data_start);
        return 1;
    }

    FILE *f = fopen(path, "wb");
    if (!f) { perror("fopen"); return 1; }

    uint8_t *zero = (uint8_t *)calloc(1, JETFS_BLOCK_SIZE);

    /* 전체 이미지를 0으로 채운다 */
    for (uint32_t b = 0; b < total_blocks; b++) {
        fwrite(zero, 1, JETFS_BLOCK_SIZE, f);
    }

    /* 슈퍼블록 */
    jetfs_superblock_t sb;
    memset(&sb, 0, sizeof(sb));
    sb.magic = JETFS_MAGIC;
    sb.total_blocks = total_blocks;
    sb.journal_start = journal_start;
    sb.inode_table_start = journal_start + JETFS_JOURNAL_BLOCKS;
    sb.inode_table_blocks = inode_table_blocks;
    sb.bitmap_start = sb.inode_table_start + inode_table_blocks;
    sb.bitmap_blocks = bitmap_blocks;
    sb.data_start = data_start;
    sb.root_inode = JETFS_ROOT_INODE;
    sb.inode_struct_size = (uint32_t)sizeof(jetfs_inode_t); /* Milestone 48 */

    fseek(f, 0, SEEK_SET);
    fwrite(&sb, 1, sizeof(sb), f);

    /* Milestone 47: 저널 헤더를 "비어있음"으로 명시적으로 초기화.
     * (전체 이미지를 0으로 미리 채워서 어차피 magic이 0=EMPTY가 아닌
     * 값과 우연히도 안 겹치긴 하지만, 의도를 코드에 명확히 남기려고
     * 실제로 써준다.) */
    {
        uint8_t jbuf[JETFS_BLOCK_SIZE];
        memset(jbuf, 0, sizeof(jbuf));
        jetfs_journal_header_t *jh = (jetfs_journal_header_t *)jbuf;
        jh->magic = JETFS_JOURNAL_MAGIC_EMPTY;
        fseek(f, (long)((uint64_t)journal_start * JETFS_BLOCK_SIZE), SEEK_SET);
        fwrite(jbuf, 1, JETFS_BLOCK_SIZE, f);
    }

    /* 루트 디렉터리 inode (inode 0) */
    jetfs_inode_t root;
    memset(&root, 0, sizeof(root));
    root.type = JETFS_TYPE_DIR;
    root.size = 0;
    root.block_count = 0;
    root.used = 1;

    fseek(f, (long)(sb.inode_table_start * JETFS_BLOCK_SIZE), SEEK_SET);
    fwrite(&root, 1, sizeof(root), f);

    fclose(f);
    free(zero);

    printf("JETFS 포맷 완료: %s\n", path);
    printf("  total_blocks=%u journal_start=%u(%u블록) inode_table_blocks=%u bitmap_blocks=%u data_start=%u\n",
           total_blocks, journal_start, (unsigned)JETFS_JOURNAL_BLOCKS, inode_table_blocks, bitmap_blocks, data_start);
    return 0;
}
