/*
 * JetOS - examples/prelude.c
 * Milestone 30: JCC용 최소 "표준 라이브러리". jcc는 전처리기(#include)가
 * 없어서(tools/jcc.c 참고) 진짜로 include할 수는 없다 — 이 파일의
 * 내용을 필요한 .c 파일 맨 위에 그대로 복사해 붙여넣어 쓴다(단일
 * 번역 단위, 링커도 없음). examples/hello.c가 실제로 이렇게 쓴 예시.
 */

/* 정수 n을 10진수 문자열로 출력한다(음수 포함). char 배열/인덱싱/
 * 나눗셈-나머지/단항 음수화 등을 실제로 조합해 검증된 함수 —
 * M30 상태 문서의 "검증 방법론" 참고. */
void print_int(int n) {
    char buf[12];
    char out[13];
    int i;
    int j;
    int neg;
    neg = 0;
    if (n < 0) { neg = 1; n = -n; }
    i = 0;
    if (n == 0) { buf[i] = '0'; i = i + 1; }
    while (n > 0) {
        buf[i] = (n % 10) + '0';
        n = n / 10;
        i = i + 1;
    }
    if (neg) { buf[i] = '-'; i = i + 1; }
    j = 0;
    while (i > 0) {
        i = i - 1;
        out[j] = buf[i];
        j = j + 1;
    }
    out[j] = 0;
    _write(out);
}
