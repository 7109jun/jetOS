kernel/net/crypto/rsa_pkcs1.o: kernel/net/crypto/rsa_pkcs1.c \
 kernel/net/crypto/rsa_pkcs1.h kernel/net/crypto/bignum.h \
 kernel/net/crypto/rng.h
kernel/net/crypto/rsa_pkcs1.h:
kernel/net/crypto/bignum.h:
kernel/net/crypto/rng.h:
