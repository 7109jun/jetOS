#ifndef JETOS_WM_H
#define JETOS_WM_H

#include <stdint.h>
#include "../drivers/console.h"

#define WM_MAX_WINDOWS 8
#define WM_TITLEBAR_H 18
#define WM_TASKBAR_H 28

typedef void (*wm_content_draw_fn)(console_t *dc, int x, int y, int w, int h, void *ctx);

typedef struct {
    int x, y, w, h;
    char title[32];
    uint32_t color;
    int visible;
    int used;
    wm_content_draw_fn content_cb;
    void *content_ctx;
} wm_window_t;

void wm_init(console_t *con);
console_t *wm_get_draw_console(void); /* 오프스크린 백버퍼용 콘솔 (더블 버퍼링) */
void wm_present(void); /* 백버퍼를 실제 프레임버퍼로 한 번에 블릿 */
int  wm_create_window(const char *title, int x, int y, int w, int h, uint32_t color);
void wm_move_window(int idx, int dx, int dy);
void wm_bring_to_front(int idx);
int  wm_window_at(int x, int y);            /* 클릭 지점에 있는 최상위 창 인덱스, 없으면 -1 */
int  wm_hit_titlebar(int idx, int x, int y); /* 그 창의 타이틀바를 클릭했는지 */
void wm_get_window_bounds(int idx, int *x, int *y, int *w, int *h);
void wm_set_content_callback(int idx, wm_content_draw_fn cb, void *ctx);

void wm_draw(void);

/* 커서/작업표시줄/시작메뉴 상태 (desktop.c가 갱신) */
void wm_set_cursor(int x, int y);
void wm_get_cursor(int *x, int *y);
void wm_set_start_menu_open(int open);
int  wm_is_start_button_hit(int x, int y);
int  wm_is_start_menu_item_hit(int x, int y, int *out_item_index);

#endif
