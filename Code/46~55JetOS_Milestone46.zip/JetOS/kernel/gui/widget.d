kernel/gui/widget.o: kernel/gui/widget.c kernel/gui/widget.h \
 kernel/gui/../drivers/console.h kernel/gui/../drivers/keyboard.h \
 kernel/gui/clipboard.h
kernel/gui/widget.h:
kernel/gui/../drivers/console.h:
kernel/gui/../drivers/keyboard.h:
kernel/gui/clipboard.h:
