#include "vfs.h"

typedef struct { const char *prefix; } ns_entry_t;

static const ns_entry_t NS_TABLE[] = {
    { ":>" }, /* 로컬 디스크 */
    { ":]" }, /* 드라이브 */
    { ":)" }, /* 미디어 */
    { ":<" }, /* 다운로드 */
    { ":/" }, /* 네트워크 */
};
#define NS_COUNT (sizeof(NS_TABLE) / sizeof(NS_TABLE[0]))

const char *vfs_translate(const char *ns_path, char *out_buf, int out_buf_size) {
    for (unsigned i = 0; i < NS_COUNT; i++) {
        const char *pfx = NS_TABLE[i].prefix;
        if (ns_path[0] == pfx[0] && ns_path[1] == pfx[1]) {
            const char *rest = ns_path + 2;
            int j = 0;
            if (*rest != '/') out_buf[j++] = '/';
            while (*rest && j < out_buf_size - 1) out_buf[j++] = *rest++;
            out_buf[j] = '\0';
            return out_buf;
        }
    }
    return ns_path; /* 접두사가 없으면 이미 일반 경로로 간주 */
}
