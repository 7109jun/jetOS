#ifndef JETOS_RSA_PKCS1_H
#define JETOS_RSA_PKCS1_H

/* JetOS - kernel/net/crypto/rsa_pkcs1.h
 * RSAES-PKCS1-v1_5 공개키 암호화(RFC 8017 7.2.1) — TLS RSA 키 교환에서
 * pre-master secret을 서버 공개키로 암호화하는 데 쓴다. 개인키 연산
 * (복호화/서명)은 필요 없다(클라이언트는 암호화만 함). */

#include <stdint.h>
#include <stddef.h>
#include "bignum.h"

/* msg(mlen바이트, mlen <= modulus_bytes - 11)를 서버 공개키(n,e)로
 * PKCS#1 v1.5 패딩 후 암호화한다. out은 정확히 modulus_bytes(=n의
 * 바이트 길이)만큼 채워진다. 성공 1, 실패(메시지가 너무 김 등) 0. */
int rsa_pkcs1_encrypt(const bignum_t *n, const bignum_t *e,
                       const uint8_t *msg, size_t mlen,
                       uint8_t *out, size_t modulus_bytes);

#endif
