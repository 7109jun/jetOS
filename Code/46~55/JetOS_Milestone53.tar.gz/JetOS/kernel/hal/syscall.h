#ifndef JETOS_SYSCALL_H
#define JETOS_SYSCALL_H

#include <stdint.h>

/*
 * JetOS - kernel/hal/syscall.h
 * Milestone 14: INT 0x80 기반 최소 시스템콜 게이트.
 *
 * 호출 규약(단순화된 SysV 유사 방식): RAX=시스템콜 번호, RDI/RSI/RDX=
 * 인자 0~2. 반환값은 RAX. 유저 코드는 `int $0x80` 한 줄로 커널에 진입한다.
 *
 * Milestone 19: 유저 포인터 검증 추가. Milestone 15/16에서 프로세스별
 * 주소공간(PML4)이 생겼음에도, 그때까지는 시스템콜에 유저가 넘긴
 * 포인터가 "정말 그 프로세스의 유저 영역(vmm_user_virt_base()..+
 * vmm_user_region_size()) 안인지" 확인하는 절차가 없었다 — 즉 Ring3
 * 코드가 SYS_WRITE에 커널 힙이나 다른 프로세스 메모리 주소를 넘겨도
 * 커널이 그대로 읽어버리는 신뢰 경계 부재 상태였다. 이제
 * syscall_check_user_range()가 모든 포인터 인자를 시스템콜 진입 시
 * 검증하고, 범위를 벗어나면 그 스레드를 즉시 종료시킨다(커널
 * 전체에는 영향 없음 — Milestone 16의 장애 격리와 동일한 원칙:
 * 유저 실수/공격은 그 프로세스만 죽는다).
 */

typedef struct {
    uint64_t r15, r14, r13, r12, r11, r10, r9, r8;
    uint64_t rbp, rdi, rsi, rdx, rcx, rbx, rax;
} syscall_regs_t;

#define SYS_WRITE   0 /* rdi = const char* (NUL 종료 문자열, 유저 영역 안이어야 함) */
#define SYS_EXIT    1 /* 유저 스레드 종료 (돌아오지 않음) */
#define SYS_GETTICK 2 /* 반환값(rax) = g_timer_ticks */
#define SYS_BRK     3 /* Milestone 20: rdi = 요청하는 새 brk(유저 가상주소).
                        * rdi==0이면 그냥 "현재 brk 알려줘" 조회. 성공하면
                        * rax = 새(또는 조회된) brk. 실패(유저 영역 상한
                        * 초과, 물리 페이지 부족 등)하면 rax = 이전 brk
                        * (즉 아무 일도 안 일어났다는 뜻 — 실패를 별도
                        * 에러코드로 구분하지 않는 단순화, 표준 brk()와
                        * 유사한 관례). 축소(rdi < 현재 brk)는 지원하지
                        * 않는다 — 요청을 무시하고 현재 brk를 그대로
                        * 반환한다(알려진 단순화, 향후 페이지 반납 구현 시
                        * 함께 다룰 것).*/

/* Milestone 36: 최소 파일 I/O. "상업적으로 쓸 수 있는 OS"로 가려면
 * 유저 프로그램이 화면에 문자열을 찍는 것(SYS_WRITE, 사실 디버그용
 * 시리얼 출력이지 진짜 stdout도 아님)만으론 턱없이 부족하다는 판단—
 * 실제로 파일을 읽고 쓸 수 있어야 "쓸모있는 프로그램"이 나온다.
 * JETFS의 실제 능력(전체 재작성 jetfs_write / 끝에 이어붙이기
 * jetfs_append만 있고, 임의 위치 쓰기나 파일별 열기/잠금 개념이 없음)에
 * 맞춰 정직하게 단순화했다 — POSIX pread/pwrite가 아니다:
 *   - 쓰기는 항상 파일 끝에 append만 된다(그 세션 안에서 SYS_WRITE_FD를
 *     여러 번 불러도 이어붙여짐 — 임의 위치를 덮어쓰는 건 불가능).
 *   - 읽기는 fd별로 현재 위치(fd_pos)부터 순차적으로만 가능(되감기나
 *     임의 seek 없음).
 *   - 프로세스당 최대 THREAD_MAX_FDS(8)개까지 동시에 열 수 있음.
 * 이 넷 다 kernel/proc/thread.h의 프로세스별 fd 테이블을 씀 — 파일
 * 시스템 자체(JETFS)는 전혀 안 바꿨다(온디스크 포맷 무변경). */
#define SYS_OPEN     4 /* rdi = const char* path, rsi = mode(0=읽기,1=쓰기).
                         * 성공 시 rax = fd(0 이상 정수), 실패(경로 검증
                         * 실패/fd 테이블 꽉 참/읽기모드인데 파일 없음) 시
                         * rax = (uint64_t)-1. */
#define SYS_READ     5 /* rdi = fd, rsi = char* buf(유저 영역), rdx = 최대
                         * 바이트 수. 반환 rax = 실제로 읽은 바이트 수(0이면
                         * EOF), 오류 시 (uint64_t)-1. */
#define SYS_WRITE_FD 6 /* rdi = fd, rsi = const char* buf(유저 영역),
                         * rdx = 바이트 수. 파일 끝에 append. 반환 rax =
                         * 실제로 쓴 바이트 수, 오류 시 (uint64_t)-1. */
#define SYS_CLOSE    7 /* rdi = fd. 성공 0, 실패 (uint64_t)-1. */

/* 유저가 넘긴 [ptr, ptr+len) 구간이 현재 실행중인 스레드의 유저
 * 주소공간 안에 완전히 들어있는지 확인한다. 커널 스레드(cr3==0, 즉
 * 공유 커널 주소공간에서 도는 스레드 — 원래 시스템콜을 걸지 않아야
 * 정상이지만 방어적으로 처리)나 범위를 벗어나는 포인터는 0을
 * 반환한다. 오버플로 안전(포인터+길이 wrap-around도 거부). */
int syscall_check_user_range(const void *ptr, uint64_t len);

/* 유저가 넘긴 NUL 종료 문자열 포인터를 검증하며 길이를 센다.
 * max_len 안에서 NUL을 못 찾거나 범위를 벗어나면 -1. */
int64_t syscall_check_user_cstr(const char *ptr, uint64_t max_len);

/* 시스템콜 진입점(naked, 어셈블리) — idt.c가 벡터 0x80에 이 함수를 건다. */
void syscall_entry(void);

/* 실제 처리 로직(순수 C) — syscall_entry가 레지스터를 저장한 뒤 호출한다. */
void syscall_dispatch(syscall_regs_t *regs);

#endif
