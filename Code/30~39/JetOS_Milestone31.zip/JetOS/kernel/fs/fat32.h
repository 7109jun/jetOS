#ifndef JETOS_FAT32_H
#define JETOS_FAT32_H

#include <stdint.h>

/*
 * JetOS - kernel/fs/fat32.h
 * Milestone 20: 읽기 전용 FAT32 드라이버로 시작.
 * Milestone 26: 쓰기(파일 생성/덮어쓰기) 지원 추가.
 *
 * 목적: "USB 드라이브에 파일을 넣어서 JetOS로 가져오기(import)"를
 * 실현하려면, 빌드 타임에만 채울 수 있는 JETFS(jetfs_import 호스트
 * 도구)와 달리 런타임에 임의 디스크를 읽을 수 있어야 한다. FAT32는
 * 사실상 모든 OS/도구가 만들 수 있는 최소공배수 포맷이라 이걸 골랐다.
 * M26에서 쓰기까지 넣은 이유: JetOS에서 만든 파일(예: browser로 받은
 * 페이지, jash 결과물)을 USB에 담아 다른 OS로 "내보내기(export)"하려면
 * 읽기만으로는 부족했다.
 *
 * 알려진 단순화(정직하게 문서화):
 *   - 루트 디렉터리만 지원한다 — 하위 디렉터리 진입/생성 불가. USB
 *     드라이브 최상위에 파일을 바로 두고 쓰는 용도로 충분하다는 전제.
 *   - 8.3 짧은 이름만 인식/생성한다. LFN(Long File Name, VFAT) 항목은
 *     읽을 때 건너뛰고, 쓸 때도 만들지 않는다 — 즉 fat32_write_file에
 *     넘기는 이름은 이름부 8자/확장자 3자를 넘을 수 없다(넘으면 실패).
 *   - FAT12/16은 지원하지 않는다(FAT32만).
 *   - 쓰기는 "새로 만들거나 통째로 덮어쓰기"만 지원한다(jetfs_write와
 *     같은 계약) — 이어쓰기(append)/부분 수정/삭제는 없다.
 *   - 디렉터리 엔트리의 생성/수정 날짜·시간 필드는 항상 0(사실상
 *     "정보 없음")으로 쓴다 — RTC를 FAT 타임스탬프 형식으로 변환하는
 *     로직은 이 최소 구현의 스코프 밖(대부분의 리더가 0을 허용함).
 */

typedef struct {
    char short_name[13]; /* "NAME.EXT\0" 형태로 정규화됨 */
    uint32_t size;
    uint32_t first_cluster;
    int is_dir;
} fat32_dirent_t;

/* drive_index(ahci.h의 drive_index와 동일한 체계)의 디스크를 FAT32로
 * 마운트한다. 성공 1, 실패(서명이 FAT32가 아님 등) 0. */
int fat32_mount(int drive_index);

/* 루트 디렉터리 항목을 순서대로 꺼낸다. index=0부터 시작해서 항목이
 * 없을 때까지 호출측이 증가시키며 반복. 항목이 있으면 1, 없으면(범위
 * 끝) 0. LFN/볼륨라벨/삭제된 항목은 자동으로 건너뛰고 세지 않는다. */
int fat32_list_root(int index, fat32_dirent_t *out);

/* 루트 디렉터리에서 8.3 이름(대소문자 무관)으로 파일을 찾아 전체
 * 내용을 buf에 읽어온다. 반환값은 실제로 읽은 바이트 수(0이면 못
 * 찾았거나 buf_cap이 부족해서 잘림 — 반환값이 buf_cap-1과 같으면
 * 잘렸을 수 있으니 호출측이 원본 크기를 fat32_list_root로 미리
 * 확인하는 걸 권장). */
uint32_t fat32_read_file(const char *short_name, uint8_t *buf, uint32_t buf_cap);

/* Milestone 26: short_name(8.3, 대소문자 무관 — 내부적으로 대문자
 * 정규화)으로 루트 디렉터리에 파일을 만든다. 이미 같은 이름의 파일이
 * 있으면 기존 클러스터 체인을 반납하고 통째로 덮어쓴다(디렉터리
 * 엔트리 자체는 재사용). 성공 1, 실패(마운트 안 됨/이름이 8.3 형식이
 * 아님/디스크에 남은 클러스터나 디렉터리 슬롯이 없음) 0. */
int fat32_write_file(const char *short_name, const uint8_t *data, uint32_t len);

#endif
