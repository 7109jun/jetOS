/*
 * JetOS - kernel/gui/notify.c
 * Milestone 34: 알림 큐. 설계 이유는 notify.h 참고.
 */

#include "notify.h"
#include "../int/pit.h"
#include <stddef.h>

#define NOTIFY_QUEUE_CAP 8

typedef struct {
    char msg[NOTIFY_MSG_CAP];
    uint64_t expire_tick; /* g_timer_ticks 기준(100Hz — kernel_entry.c의 pit_init(100)) */
    int used;
} notify_entry_t;

static notify_entry_t g_queue[NOTIFY_QUEUE_CAP];
static int g_next_slot = 0;

static void copy_msg(char *dst, const char *src) {
    int i = 0;
    while (src[i] && i < NOTIFY_MSG_CAP - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

void notify_push(const char *msg, uint32_t ttl_ms) {
    int slot = g_next_slot;
    g_next_slot = (g_next_slot + 1) % NOTIFY_QUEUE_CAP;
    copy_msg(g_queue[slot].msg, msg);
    g_queue[slot].expire_tick = g_timer_ticks + (uint64_t)(ttl_ms / 10);
    g_queue[slot].used = 1;
}

int notify_get_visible(char out[NOTIFY_MAX_VISIBLE][NOTIFY_MSG_CAP]) {
    for (int i = 0; i < NOTIFY_QUEUE_CAP; i++) {
        if (g_queue[i].used && g_timer_ticks >= g_queue[i].expire_tick) {
            g_queue[i].used = 0;
        }
    }

    int count = 0;
    /* 링버퍼를 최신 순(g_next_slot 바로 이전부터 역순)으로 훑어 최대
     * NOTIFY_MAX_VISIBLE개 수집 — 최근 알림이 화면에서 맨 위(또는 맨
     * 아래, wm.c 배치에 따름)에 오도록. */
    for (int k = 0; k < NOTIFY_QUEUE_CAP && count < NOTIFY_MAX_VISIBLE; k++) {
        int idx = (g_next_slot - 1 - k + NOTIFY_QUEUE_CAP) % NOTIFY_QUEUE_CAP;
        if (g_queue[idx].used) {
            copy_msg(out[count], g_queue[idx].msg);
            count++;
        }
    }
    return count;
}
