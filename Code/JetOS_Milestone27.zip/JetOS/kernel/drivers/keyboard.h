#ifndef JETOS_KEYBOARD_H
#define JETOS_KEYBOARD_H

#include <stdint.h>

/* 확장(0xE0) 키에 대해 링버퍼로 내보내는 가상 코드.
 * 출력 가능 ASCII(32~126) 및 기존 제어문자(\b \t \n)와 겹치지 않는
 * 0x01~0x06 대역을 사용한다. */
#define KEY_UP    0x01
#define KEY_DOWN  0x02
#define KEY_LEFT  0x03
#define KEY_RIGHT 0x04
#define KEY_HOME  0x05
#define KEY_END   0x06
#define KEY_DEL   0x07
#define KEY_F5    0x08 /* Notepad 저장 (jetfs) */
#define KEY_F6    0x09 /* Notepad 불러오기 (jetfs) */
#define KEY_PGUP  0x0A /* Milestone 19: 스크롤 위 */
#define KEY_PGDN  0x0B /* Milestone 19: 스크롤 아래 */

void keyboard_init(void);

/* IRQ1 핸들러(순수 C)에서 호출된다. 포트 0x60에서 스캔코드를 읽어
 * 내부 링버퍼에 ASCII로 변환해 채운다. */
void keyboard_irq_handler(void);

/* 링버퍼에서 문자 하나를 꺼낸다. 없으면 0을 반환한다(논블로킹). */
char keyboard_poll_char(void);

#endif
