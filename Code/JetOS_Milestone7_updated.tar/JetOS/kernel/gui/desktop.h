#ifndef JETOS_DESKTOP_H
#define JETOS_DESKTOP_H

/* 데스크톱 셸의 메인 루프. 스케줄러 스레드로 등록되어 영원히 실행된다
 * (키보드/마우스 입력 처리 + 창 그리기). Milestone 3의 스레드 인프라
 * 위에서 동작하는 "진짜 애플리케이션"의 첫 사례다. */
void desktop_thread_fn(void *arg);

#endif
