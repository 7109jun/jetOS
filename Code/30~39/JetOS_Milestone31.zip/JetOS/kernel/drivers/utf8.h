#ifndef JETOS_UTF8_H
#define JETOS_UTF8_H

#include <stdint.h>

/*
 * JetOS - kernel/drivers/utf8.h
 * Milestone 13: 최소 UTF-8 디코더. console_print()가 문자열을
 * "코드포인트 단위"로 읽어 ASCII는 기존 5x7 폰트로, 한글 음절
 * (U+AC00~U+D7A3)은 hangul_font로, 그 외 지원 안 하는 코드포인트는
 * 자리표시 박스로 렌더링할 수 있게 해준다.
 */

/* s가 가리키는 위치에서 UTF-8 문자 하나를 디코드한다.
 * *out_codepoint에 유니코드 코드포인트를, 반환값으로 그 문자가 차지한
 * 바이트 수(1~4)를 준다. 잘못된 시퀀스를 만나면 코드포인트로 해당
 * 바이트값(0~255, 라틴1 폴백)을 주고 1을 반환한다(디코더가 멈추지
 * 않고 계속 진행할 수 있도록). 문자열 끝(널 바이트)이면 0을 반환한다. */
int utf8_decode(const char *s, uint32_t *out_codepoint);

#endif
