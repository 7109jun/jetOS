#ifndef JETOS_AHCI_H
#define JETOS_AHCI_H

#include <stdint.h>

#define AHCI_SECTOR_SIZE 512
#define AHCI_MAX_DRIVES 4

/* AHCI 컨트롤러를 PCI에서 찾아 초기화하고, SATA 드라이브가 연결된
 * 포트를 최대 AHCI_MAX_DRIVES개까지 찾아 활성화한다.
 * 반환값: 찾은 드라이브 개수 (0이면 실패). drive_index는 0부터
 * 발견된 순서대로 매겨진다 (보통 drive 0 = 부팅 ESP 디스크). */
int ahci_init(void);
int ahci_drive_count(void);

int ahci_read_sectors(int drive_index, uint64_t lba, uint32_t count, void *buffer);
int ahci_write_sectors(int drive_index, uint64_t lba, uint32_t count, const void *buffer);

#endif
