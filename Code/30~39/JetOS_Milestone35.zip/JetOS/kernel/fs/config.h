#ifndef JETOS_CONFIG_H
#define JETOS_CONFIG_H

/*
 * JetOS - kernel/fs/config.h
 * Milestone 33: 영속 구성(persistent configuration).
 *
 * M32 문서 "다음 작업" 1순위: "재부팅해도 남는 설정이 지금은 없다 —
 * 배경화면/음량/시계 형식 등이 매번 하드코딩된 기본값으로 리셋된다."
 *
 * 정직한 스코프 축소: 이 프로젝트에 지금 실제로 "런타임에 바뀌는 상태"가
 * 있는 설정은 테마 프리셋(M18, theme.c)뿐이었다. 배경화면은 아예 커스텀
 * 불가능한 고정 그라디언트+태양이고(M21/M23 — "다음 작업" 목록에 별도
 * 11번으로 이미 있음), 볼륨은 스피커가 디지털 오디오가 아니라 단일 톤
 * 비프음이라 "음량"이라는 개념 자체가 코드에 없다(둘 다 이 마일스톤
 * 스코프 밖 — 문서화된 한계). 그래서 이번엔 (1) 이미 있던 테마 프리셋을
 * 영속화하고, (2) 시계를 12/24시간제 중 고를 수 있게 새로 만들어서 그것도
 * 같이 영속화했다 — "설정이 남는다"는 걸 실제로 눈에 보이는 두 가지로
 * 증명.
 *
 * 저장 형식: JETFS의 /system/config.txt에 "key=value\n" 텍스트 줄.
 * 사람이 jash로 cat해서 직접 읽고 확인할 수 있도록 일부러 바이너리
 * 대신 텍스트를 골랐다. 알 수 없는 키는 파싱 시 조용히 무시하므로,
 * 나중에 설정이 늘어나도 이전 버전 커널이 새 config.txt를 만나도
 * 깨지지 않는다(그 반대도 마찬가지 — 옛날 config.txt에 새 키가
 * 없으면 그냥 기본값을 씀).
 */

/* 부팅 시 1회 호출: JETFS에서 읽어 적용한다(테마는 theme_set_preset까지
 * 즉시 호출됨). 파일이 없으면(첫 부팅 등) 기본값을 적용하고 그 자리에서
 * config_save()로 새로 만들어둔다. JETFS가 마운트된 뒤에만 호출할 것 —
 * 마운트 전에 부르면 아무 효과 없이 기본값만 적용된다. */
void config_load(void);

/* 현재 메모리상의 설정 값을 /system/config.txt에 즉시 기록한다.
 * 성공 시 1, 실패(마운트 안 됨/쓰기 실패) 시 0. */
int config_save(void);

int  config_get_theme_preset(void);
/* idx를 적용(theme_set_preset)하고 즉시 저장까지 수행한다. */
void config_set_theme_preset(int idx);

/* 1 = 24시간제(기본값), 0 = 12시간제(AM/PM) */
int  config_get_clock_24h(void);
/* 즉시 저장까지 수행한다. */
void config_set_clock_24h(int is_24h);

/* Milestone 34: 배경화면 프리셋(wm.c의 WALLPAPER_PRESETS 인덱스). */
int  config_get_wallpaper_preset(void);
void config_set_wallpaper_preset(int idx);

#endif
